#!/usr/bin/env python3
# nyosig_state_audit_v1.0a.py
# Creates/updates project state DB, scans files by content/name, detects duplicates/gaps,
# writes mirror exports + human report.
# English only inside functional outputs; Czech allowed only in file names outside this tool.

import os
import re
import json
import time
import hashlib
import sqlite3
from pathlib import Path

VERSION_RE = re.compile(r"\bv(\d+)\.(\d+)([a-z])?\b", re.IGNORECASE)

def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def read_head_text(p: Path, max_bytes: int = 64 * 1024) -> str:
    try:
        b = p.read_bytes()[:max_bytes]
    except Exception:
        return ""
    # allow ASCII/UTF-8 read; we only use it for detection
    try:
        return b.decode("utf-8", errors="replace")
    except Exception:
        try:
            return b.decode("latin-1", errors="replace")
        except Exception:
            return ""

def extract_version_from_text(text: str) -> str:
    m = VERSION_RE.search(text or "")
    if not m:
        return ""
    major = int(m.group(1))
    minor = int(m.group(2))
    letter = (m.group(3) or "").lower()
    return f"v{major}.{minor}{letter}" if letter else f"v{major}.{minor}"

def extract_version_from_name(name: str) -> str:
    m = re.search(r"_v(\d+)\.(\d+)([a-z])?\.py$", name, flags=re.IGNORECASE)
    if not m:
        return ""
    major = int(m.group(1))
    minor = int(m.group(2))
    letter = (m.group(3) or "").lower()
    return f"v{major}.{minor}{letter}" if letter else f"v{major}.{minor}"

def now_utc_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

def ensure_dirs(project_root: Path):
    (project_root / "reports").mkdir(parents=True, exist_ok=True)
    (project_root / "db").mkdir(parents=True, exist_ok=True)

def db_path(project_root: Path) -> Path:
    return project_root / "db" / "nyosig_state.db"

def db_connect(p: Path) -> sqlite3.Connection:
    con = sqlite3.connect(str(p))
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL;")
    con.execute("PRAGMA foreign_keys=ON;")
    return con

def ensure_schema(con: sqlite3.Connection):
    con.execute("""
    CREATE TABLE IF NOT EXISTS project_state (
      k TEXT PRIMARY KEY,
      v TEXT NOT NULL,
      updated_utc TEXT NOT NULL
    );
    """)
    con.execute("""
    CREATE TABLE IF NOT EXISTS artifacts (
      artifact_id INTEGER PRIMARY KEY AUTOINCREMENT,
      rel_path TEXT NOT NULL,
      abs_path TEXT NOT NULL,
      kind TEXT NOT NULL,
      version_label TEXT,
      sha256 TEXT NOT NULL,
      size_bytes INTEGER NOT NULL,
      mtime_utc TEXT NOT NULL,
      first_seen_utc TEXT NOT NULL,
      last_seen_utc TEXT NOT NULL,
      UNIQUE(rel_path, sha256)
    );
    """)
    con.execute("""
    CREATE TABLE IF NOT EXISTS versions (
      version_label TEXT NOT NULL,
      sha256 TEXT NOT NULL,
      rel_path TEXT NOT NULL,
      abs_path TEXT NOT NULL,
      first_seen_utc TEXT NOT NULL,
      last_seen_utc TEXT NOT NULL,
      PRIMARY KEY (version_label, sha256)
    );
    """)
    con.execute("""
    CREATE TABLE IF NOT EXISTS runs (
      run_id INTEGER PRIMARY KEY AUTOINCREMENT,
      launched_utc TEXT NOT NULL,
      script_rel_path TEXT NOT NULL,
      script_sha256 TEXT NOT NULL,
      version_label TEXT,
      note TEXT
    );
    """)
    con.execute("CREATE INDEX IF NOT EXISTS idx_runs_launched ON runs(launched_utc);")
    con.execute("CREATE INDEX IF NOT EXISTS idx_artifacts_kind ON artifacts(kind);")
    con.execute("CREATE INDEX IF NOT EXISTS idx_versions_label ON versions(version_label);")

def set_state(con: sqlite3.Connection, k: str, v: str):
    con.execute("""
    INSERT INTO project_state(k, v, updated_utc) VALUES(?, ?, ?)
    ON CONFLICT(k) DO UPDATE SET v=excluded.v, updated_utc=excluded.updated_utc
    """, (k, v, now_utc_iso()))

def get_state(con: sqlite3.Connection, k: str, default: str = "") -> str:
    row = con.execute("SELECT v FROM project_state WHERE k=?", (k,)).fetchone()
    return str(row["v"]) if row else default

def classify(rel_path: str) -> str:
    rp = rel_path.replace("\\", "/").lower()
    if rp.endswith(".py"):
        if "launcher" in rp:
            return "launcher"
        if "/versions/" in rp or rp.startswith("versions/"):
            return "version_script"
        return "script"
    if rp.endswith(".sql"):
        return "sql"
    if rp.endswith(".txt"):
        return "text"
    if rp.endswith(".docx"):
        return "docx"
    return "other"

def scan_project(project_root: Path):
    # Include all; skip enormous binary dirs if needed
    skip_dirs = {".git", "__pycache__", ".pytest_cache", "venv", ".venv"}
    files = []
    for p in project_root.rglob("*"):
        if p.is_dir():
            if p.name in skip_dirs:
                # prune by not descending is hard with rglob; ignore below
                pass
            continue
        rel = p.relative_to(project_root).as_posix()
        parts = set(rel.split("/"))
        if parts & skip_dirs:
            continue
        files.append((p, rel))
    return files

def parse_versions(files):
    out = []
    for p, rel in files:
        if not rel.lower().endswith(".py"):
            continue
        name_ver = extract_version_from_name(p.name)
        head = read_head_text(p)
        text_ver = extract_version_from_text(head)
        version_label = name_ver or text_ver
        if version_label:
            out.append((version_label, p, rel))
    return out

def version_tuple(vlabel: str):
    m = VERSION_RE.search(vlabel if vlabel.lower().startswith("v") else ("v"+vlabel))
    if not m:
        return None
    major = int(m.group(1))
    minor = int(m.group(2))
    letter = (m.group(3) or "").lower()
    letter_i = 0
    if letter:
        letter_i = ord(letter) - ord("a") + 1
    return (major, minor, letter_i, letter or "")

def expected_next(vt):
    # vt: (major, minor, letter_i, letter)
    major, minor, li, _ = vt
    # next patch
    if li == 0:
        patch = (major, minor, 1, "a")
    else:
        patch = (major, minor, li + 1, chr(ord("a") + li))
    # next minor
    minor_next = (major, minor + 1, 1, "a")
    # next major
    major_next = (major + 1, 0, 1, "a")
    return [patch, minor_next, major_next]

def vt_to_label(vt):
    major, minor, li, letter = vt
    if li == 0 or not letter:
        return f"v{major}.{minor}"
    return f"v{major}.{minor}{letter}"

def validate_sequence(sorted_labels):
    # sorted_labels: unique version labels sorted ascending by tuple
    issues = []
    if not sorted_labels:
        return issues
    for i in range(1, len(sorted_labels)):
        prev = version_tuple(sorted_labels[i-1])
        cur = version_tuple(sorted_labels[i])
        if not prev or not cur:
            continue
        allowed = expected_next(prev)
        if cur not in allowed:
            issues.append({
                "type": "sequence_gap_or_jump",
                "prev": vt_to_label(prev),
                "cur": vt_to_label(cur),
                "allowed_next": [vt_to_label(x) for x in allowed],
            })
    return issues

def write_reports(project_root: Path, payload: dict):
    ts = time.strftime("%Y%m%d_%H%M%S", time.gmtime())
    out_json = project_root / "reports" / f"nyosig_state_audit_{ts}.json"
    out_txt  = project_root / "reports" / f"nyosig_state_audit_{ts}.txt"
    out_json.write_text(json.dumps(payload, indent=2, ensure_ascii=True), encoding="utf-8")

    lines = []
    lines.append("NyoSig state audit")
    lines.append(f"UTC: {payload.get('utc')}")
    lines.append(f"Project root: {payload.get('project_root')}")
    lines.append(f"State DB: {payload.get('state_db')}")
    lines.append("")
    lines.append(f"Files scanned: {payload.get('counts', {}).get('files_scanned')}")
    lines.append(f"Version scripts found: {payload.get('counts', {}).get('version_scripts_found')}")
    lines.append(f"Unique version labels: {payload.get('counts', {}).get('unique_versions')}")
    lines.append(f"Duplicate version labels (different hashes): {payload.get('counts', {}).get('duplicate_versions')}")
    lines.append("")
    latest = payload.get("latest_version") or {}
    lines.append(f"Latest version: {latest.get('version_label','')}")
    lines.append(f"Latest path: {latest.get('rel_path','')}")
    lines.append("")
    if payload.get("duplicate_details"):
        lines.append("Duplicate versions:")
        for d in payload["duplicate_details"]:
            lines.append(f"- {d['version_label']}: {len(d['items'])} variants")
            for it in d["items"]:
                lines.append(f"  - {it['rel_path']}  {it['sha256'][:12]}")
        lines.append("")
    if payload.get("sequence_issues"):
        lines.append("Sequence issues:")
        for s in payload["sequence_issues"]:
            lines.append(f"- prev {s['prev']} -> cur {s['cur']}  allowed {', '.join(s['allowed_next'])}")
        lines.append("")
    if payload.get("versions_desc"):
        lines.append("Versions (desc):")
        for v in payload["versions_desc"]:
            lines.append(f"- {v['version_label']}  {v['rel_path']}  {v['sha256'][:12]}")
        lines.append("")
    out_txt.write_text("\n".join(lines), encoding="utf-8")
    return str(out_txt), str(out_json)

def main():
    project_root = Path(os.getcwd()).resolve()
    ensure_dirs(project_root)
    state_db = db_path(project_root)
    con = db_connect(state_db)
    try:
        ensure_schema(con)
        set_state(con, "project_root", str(project_root))
        set_state(con, "last_audit_utc", now_utc_iso())
        set_state(con, "state_db_path", str(state_db))

        files = scan_project(project_root)
        utc = now_utc_iso()

        # Upsert artifacts
        for p, rel in files:
            kind = classify(rel)
            size = p.stat().st_size
            mtime = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(p.stat().st_mtime))
            h = sha256_file(p)
            head = read_head_text(p)
            version_label = extract_version_from_name(p.name) or extract_version_from_text(head)

            con.execute("""
            INSERT OR IGNORE INTO artifacts(rel_path, abs_path, kind, version_label, sha256, size_bytes, mtime_utc, first_seen_utc, last_seen_utc)
            VALUES(?,?,?,?,?,?,?,?,?)
            """, (rel, str(p), kind, version_label or None, h, int(size), mtime, utc, utc))

            con.execute("""
            UPDATE artifacts SET last_seen_utc=?, mtime_utc=?, size_bytes=? WHERE rel_path=? AND sha256=?
            """, (utc, mtime, int(size), rel, h))

        # Versions registry
        vers = parse_versions(files)
        for vlabel, p, rel in vers:
            h = sha256_file(p)
            con.execute("""
            INSERT OR IGNORE INTO versions(version_label, sha256, rel_path, abs_path, first_seen_utc, last_seen_utc)
            VALUES(?,?,?,?,?,?)
            """, (vlabel, h, rel, str(p), utc, utc))
            con.execute("""
            UPDATE versions SET last_seen_utc=?, rel_path=?, abs_path=? WHERE version_label=? AND sha256=?
            """, (utc, rel, str(p), vlabel, h))

        con.commit()

        # Build report from DB
        rows = con.execute("""
        SELECT version_label, sha256, rel_path FROM versions
        WHERE version_label IS NOT NULL AND version_label <> ''
        """).fetchall()

        by_label = {}
        for r in rows:
            by_label.setdefault(r["version_label"], []).append({
                "sha256": r["sha256"],
                "rel_path": r["rel_path"],
            })

        duplicates = []
        for vlabel, items in by_label.items():
            uniq_hash = {it["sha256"] for it in items}
            if len(uniq_hash) > 1:
                duplicates.append({"version_label": vlabel, "items": items})

        # Determine latest by tuple
        unique_labels = list(by_label.keys())
        unique_labels = [v for v in unique_labels if version_tuple(v)]
        unique_labels_sorted = sorted(unique_labels, key=lambda x: version_tuple(x))
        unique_labels_desc = list(reversed(unique_labels_sorted))

        latest = {}
        if unique_labels_desc:
            lv = unique_labels_desc[0]
            # pick most recently seen variant by last_seen_utc
            r = con.execute("""
            SELECT version_label, sha256, rel_path, last_seen_utc
            FROM versions WHERE version_label=? ORDER BY last_seen_utc DESC LIMIT 1
            """, (lv,)).fetchone()
            if r:
                latest = {"version_label": r["version_label"], "sha256": r["sha256"], "rel_path": r["rel_path"], "last_seen_utc": r["last_seen_utc"]}

        seq_issues = validate_sequence(unique_labels_sorted)

        # Mirror export (directory tree + artifacts)
        art_rows = con.execute("""
        SELECT rel_path, kind, version_label, sha256, size_bytes, mtime_utc
        FROM artifacts
        ORDER BY rel_path ASC
        """).fetchall()

        artifacts = []
        for r in art_rows:
            artifacts.append({
                "rel_path": r["rel_path"],
                "kind": r["kind"],
                "version_label": r["version_label"] or "",
                "sha256": r["sha256"],
                "size_bytes": int(r["size_bytes"]),
                "mtime_utc": r["mtime_utc"],
            })

        versions_desc = []
        for vlabel in unique_labels_desc:
            r = con.execute("""
            SELECT version_label, sha256, rel_path, last_seen_utc
            FROM versions WHERE version_label=? ORDER BY last_seen_utc DESC LIMIT 1
            """, (vlabel,)).fetchone()
            if r:
                versions_desc.append({
                    "version_label": r["version_label"],
                    "sha256": r["sha256"],
                    "rel_path": r["rel_path"],
                    "last_seen_utc": r["last_seen_utc"],
                })

        payload = {
            "utc": utc,
            "project_root": str(project_root),
            "state_db": str(state_db),
            "counts": {
                "files_scanned": len(files),
                "version_scripts_found": len(vers),
                "unique_versions": len(unique_labels_sorted),
                "duplicate_versions": len(duplicates),
            },
            "latest_version": latest,
            "sequence_issues": seq_issues,
            "duplicate_details": duplicates,
            "versions_desc": versions_desc,
            "artifacts": artifacts,
        }

        out_txt, out_json = write_reports(project_root, payload)
        set_state(con, "last_audit_txt", out_txt)
        set_state(con, "last_audit_json", out_json)
        con.commit()

        print(out_txt)
        print(out_json)

    finally:
        con.close()

if __name__ == "__main__":
    main()

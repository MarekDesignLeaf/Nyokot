#!/usr/bin/env python3
# migrate_analyza_trhu_to_nyosig_cryptolytix_v1.0a.py
# ASCII only.
# Migrates an existing project from:
#   /storage/emulated/0/Programy/analyza_trhu
# to:
#   /storage/emulated/0/NyoSig/NyoSig_Cryptolytix
#
# Rules:
# - Never modifies OLD project files.
# - Writes NEW project files into the new structure.
# - Copies versioned app scripts into app/versions and updates their internal paths/names.
# - Copies tools into tools/, reports into reports/, docs into docs/.
# - Copies DB into db/ and renames it to nyosig_cryptolytix.db.

import os
import re
import shutil
import sys
from datetime import datetime

OLD_ROOT = "/storage/emulated/0/Programy/analyza_trhu"
NEW_ROOT = "/storage/emulated/0/NyoSig/NyoSig_Cryptolytix"

NEW_DB_NAME = "nyosig_cryptolytix.db"
OLD_DB_NAME = "analyza_trhu.db"

DIRS = [
    "app",
    "app/versions",
    "db",
    "docs",
    "reports",
    "tools",
    "assets",
    "tmp",
]

DOC_TARGETS = {
    # old filename -> new filename
    "struktura_systemu_Analyza_Trhu.txt": "docs/struktura_systemu_cz_v1.0a.txt",
    "postup_vyroby_analyza_trhu-1.txt": "docs/postup_vyroby_cz_v1.0a.txt",
    "specifikace_datove_vrstvy_analyza_trhu-2.txt": "docs/specifikace_datove_vrstvy_cz_v1.0a.txt",
    "architektura_zdroju_analyza_trhu.docx": "docs/architektura_zdroju_cz_v1.0a.docx",
    "projektova_sprava_a_verzovani_cz_v1.0a.txt": "docs/projektova_sprava_a_verzovani_cz_v1.0a.txt",
}

REPL_TEXT = [
    (OLD_ROOT, NEW_ROOT),
    ("/storage/emulated/0/Programy/analyza_trhu", "/storage/emulated/0/NyoSig/NyoSig_Cryptolytix"),
    ("analyza_trhu_gui_", "nyosig_cryptolytix_gui_"),
    ("analyza_trhu_gui", "nyosig_cryptolytix_gui"),
    ("Analyza trhu", "NyoSig Cryptolytix"),
    ("analyza_trhu.db", NEW_DB_NAME),
    (OLD_DB_NAME, NEW_DB_NAME),
]

APP_VER_RE = re.compile(r"^analyza_trhu_gui_v(\d+)\.(\d+)([a-z])?\.py$", re.IGNORECASE)
TOOL_VER_RE = re.compile(r"^(project_audit|clipboard_deploy|init_.*|.*deploy.*)_v(\d+)\.(\d+)([a-z])?\.py$", re.IGNORECASE)
REPORT_RE = re.compile(r"^(project_audit|audit|report).*\.txt$", re.IGNORECASE)

def die(msg):
    print("ERROR: " + msg)
    sys.exit(1)

def mkdir_p(path):
    os.makedirs(path, exist_ok=True)

def ensure_structure():
    mkdir_p(NEW_ROOT)
    for d in DIRS:
        mkdir_p(os.path.join(NEW_ROOT, d))

def read_text_ascii_or_utf8(path):
    # prefer utf-8, but keep output ASCII safe by stripping non-ascii if needed
    with open(path, "rb") as f:
        b = f.read()
    # allow utf-8 bom
    if b.startswith(b"\xef\xbb\xbf"):
        b = b[3:]
    try:
        s = b.decode("utf-8", errors="strict")
    except Exception:
        s = b.decode("utf-8", errors="replace")
    # enforce ASCII only in executable .py outputs later; for docs allow UTF-8 in CZ files
    return s

def write_text(path, text, encoding="utf-8"):
    parent = os.path.dirname(path)
    if parent:
        mkdir_p(parent)
    with open(path, "w", encoding=encoding, errors="strict", newline="\n") as f:
        f.write(text)

def copy_file(src, dst):
    parent = os.path.dirname(dst)
    if parent:
        mkdir_p(parent)
    shutil.copy2(src, dst)

def is_probably_text(path):
    low = path.lower()
    return low.endswith(".py") or low.endswith(".txt") or low.endswith(".md") or low.endswith(".sql")

def apply_replacements(text):
    out = text
    for a, b in REPL_TEXT:
        out = out.replace(a, b)
    return out

def enforce_ascii_for_py(text, src_name):
    # strict: remove any non-ascii (should not exist, but prevents crashes)
    cleaned = []
    for ch in text:
        if ord(ch) <= 127:
            cleaned.append(ch)
        else:
            # replace with space to preserve layout a bit
            cleaned.append(" ")
    out = "".join(cleaned)

    # also ensure the header comment matches new name if present
    out = out.replace(src_name, src_name)  # no-op, just a placeholder
    return out

def migrate_app_versions():
    src_dir = OLD_ROOT
    dst_dir = os.path.join(NEW_ROOT, "app", "versions")
    mkdir_p(dst_dir)

    found = 0
    for name in sorted(os.listdir(src_dir)):
        m = APP_VER_RE.match(name)
        if not m:
            continue
        found += 1
        src = os.path.join(src_dir, name)
        new_name = "nyosig_cryptolytix_gui_v%s.%s%s.py" % (m.group(1), m.group(2), (m.group(3) or ""))
        dst = os.path.join(dst_dir, new_name)

        text = read_text_ascii_or_utf8(src)
        text = apply_replacements(text)
        text = enforce_ascii_for_py(text, new_name)

        # fix obvious header line if present (no assumptions beyond simple replace)
        text = text.replace("# analyza_trhu_gui_", "# nyosig_cryptolytix_gui_")
        text = text.replace('self.title("analyza_trhu_gui_', 'self.title("nyosig_cryptolytix_gui_')
        text = text.replace('self.title("Analyza trhu")', 'self.title("NyoSig Cryptolytix")')

        write_text(dst, text, encoding="ascii")

    if found == 0:
        print("WARN: No analyza_trhu_gui_vX.Y?.py found in OLD_ROOT")

def migrate_tools():
    src_dir = OLD_ROOT
    dst_dir = os.path.join(NEW_ROOT, "tools")
    mkdir_p(dst_dir)

    for name in sorted(os.listdir(src_dir)):
        if not name.lower().endswith(".py"):
            continue
        # avoid app gui files already handled
        if APP_VER_RE.match(name):
            continue
        # only migrate known tools by pattern, otherwise skip
        if not TOOL_VER_RE.match(name):
            continue

        src = os.path.join(src_dir, name)
        dst = os.path.join(dst_dir, name)

        if is_probably_text(src):
            text = read_text_ascii_or_utf8(src)
            text = apply_replacements(text)
            if dst.lower().endswith(".py"):
                text = enforce_ascii_for_py(text, name)
                write_text(dst, text, encoding="ascii")
            else:
                write_text(dst, text, encoding="utf-8")
        else:
            copy_file(src, dst)

def migrate_reports():
    # reports can be in OLD_ROOT or in OLD_ROOT/reports (if exists)
    dst_dir = os.path.join(NEW_ROOT, "reports")
    mkdir_p(dst_dir)

    candidates = []
    for base in [OLD_ROOT, os.path.join(OLD_ROOT, "reports")]:
        if os.path.isdir(base):
            for name in os.listdir(base):
                if REPORT_RE.match(name):
                    candidates.append(os.path.join(base, name))

    for src in sorted(set(candidates)):
        dst = os.path.join(dst_dir, os.path.basename(src))
        copy_file(src, dst)

def migrate_docs():
    dst_docs = os.path.join(NEW_ROOT, "docs")
    mkdir_p(dst_docs)

    # copy from OLD_ROOT if present, otherwise no-op
    for old_name, new_rel in DOC_TARGETS.items():
        src = os.path.join(OLD_ROOT, old_name)
        dst = os.path.join(NEW_ROOT, new_rel)

        if not os.path.exists(src):
            # keep whatever already exists in NEW (placeholders), but do not overwrite
            continue

        if src.lower().endswith(".docx"):
            # binary copy
            copy_file(src, dst)
            continue

        text = read_text_ascii_or_utf8(src)
        # docs are CZ, keep utf-8
        # but update project name/path references inside text for consistency
        text = apply_replacements(text)
        write_text(dst, text, encoding="utf-8")

def migrate_db():
    old_db = os.path.join(OLD_ROOT, "db", OLD_DB_NAME)
    new_db = os.path.join(NEW_ROOT, "db", NEW_DB_NAME)
    mkdir_p(os.path.dirname(new_db))

    if not os.path.exists(old_db):
        print("WARN: OLD DB not found: " + old_db)
        return

    if os.path.exists(new_db):
        # do not overwrite; create a timestamped copy
        stamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        alt = os.path.join(NEW_ROOT, "db", "nyosig_cryptolytix_%s.db" % stamp)
        copy_file(old_db, alt)
        print("OK: DB copied to: " + alt)
    else:
        copy_file(old_db, new_db)
        print("OK: DB copied to: " + new_db)

def write_minimal_launcher_if_missing():
    launcher = os.path.join(NEW_ROOT, "app", "launcher.py")
    if os.path.exists(launcher):
        return

    content = (
        "#!/usr/bin/env python3\n"
        "# launcher.py\n"
        "# Minimal launcher for NyoSig Cryptolytix.\n"
        "# Select a version in app/versions and run it.\n"
        "\n"
        "import os\n"
        "import sys\n"
        "import subprocess\n"
        "\n"
        "ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))\n"
        "VERS_DIR = os.path.join(ROOT, 'app', 'versions')\n"
        "\n"
        "def pick_latest():\n"
        "    items = []\n"
        "    for n in os.listdir(VERS_DIR):\n"
        "        if not n.lower().endswith('.py'):\n"
        "            continue\n"
        "        if '_v' not in n:\n"
        "            continue\n"
        "        items.append(n)\n"
        "    items.sort()\n"
        "    return items[-1] if items else None\n"
        "\n"
        "def main():\n"
        "    if not os.path.isdir(VERS_DIR):\n"
        "        print('ERROR: versions dir missing: ' + VERS_DIR)\n"
        "        sys.exit(1)\n"
        "    latest = pick_latest()\n"
        "    if not latest:\n"
        "        print('ERROR: no versions found in: ' + VERS_DIR)\n"
        "        sys.exit(1)\n"
        "    path = os.path.join(VERS_DIR, latest)\n"
        "    subprocess.run([sys.executable, path], check=False)\n"
        "\n"
        "if __name__ == '__main__':\n"
        "    main()\n"
    )
    write_text(launcher, content, encoding="ascii")
    os.chmod(launcher, 0o755)

def main():
    if not os.path.isdir(OLD_ROOT):
        die("OLD_ROOT missing: " + OLD_ROOT)

    ensure_structure()

    migrate_app_versions()
    migrate_tools()
    migrate_reports()
    migrate_docs()
    migrate_db()
    write_minimal_launcher_if_missing()

    print("OK")
    print("OLD: " + OLD_ROOT)
    print("NEW: " + NEW_ROOT)
    print("NEW DB: " + os.path.join(NEW_ROOT, "db", NEW_DB_NAME))
    print("NEXT: run app/launcher.py")

if __name__ == "__main__":
    main()
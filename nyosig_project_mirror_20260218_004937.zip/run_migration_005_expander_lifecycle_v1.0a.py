#!/usr/bin/env python3
from __future__ import annotations
import os
from core.config import get_project_root, make_paths
from core.db import db_connect
from core.util_time import utc_now_iso

MIGRATION_FILE = os.path.join(os.path.dirname(__file__), "db", "migrations", "db_migration_005_expander_lifecycle_v1.0a.sql")

def main() -> int:
    project_root = get_project_root()
    paths = make_paths(project_root)
    con = db_connect(paths.db_path)
    try:
        with open(MIGRATION_FILE, "r", encoding="utf-8") as f:
            sql = f.read()
        con.executescript(sql)
        con.commit()
        print("ok", utc_now_iso())
        return 0
    finally:
        con.close()

if __name__ == "__main__":
    raise SystemExit(main())

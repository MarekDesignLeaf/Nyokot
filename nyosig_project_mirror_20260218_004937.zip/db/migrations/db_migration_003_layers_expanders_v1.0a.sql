-- db_migration_003_layers_expanders_v1.0a
-- Adds: layer_results, expanders, version_registry + indices
-- Safe / idempotent where possible.

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS version_registry (
  version TEXT PRIMARY KEY,
  sha256 TEXT NOT NULL,
  created_utc TEXT NOT NULL,
  notes TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS layer_results (
  layer_result_id INTEGER PRIMARY KEY AUTOINCREMENT,
  run_id INTEGER NOT NULL,
  snapshot_ref INTEGER NOT NULL,
  timeframe TEXT NOT NULL,
  layer_name TEXT NOT NULL,
  layer_version TEXT NOT NULL DEFAULT 'v1',
  status TEXT NOT NULL, -- ok | warning | failed | skipped
  score REAL,           -- 0..100
  weight REAL,          -- 0..1 (copied at runtime from layer_weights)
  raw_json TEXT,        -- debug payload / metrics / reasons
  created_utc TEXT NOT NULL,
  UNIQUE(run_id, snapshot_ref, timeframe, layer_name),
  FOREIGN KEY(run_id) REFERENCES runs(run_id),
  FOREIGN KEY(snapshot_ref) REFERENCES snapshots(snapshot_ref)
);

CREATE INDEX IF NOT EXISTS idx_layer_results_run_snapshot ON layer_results(run_id, snapshot_ref);
CREATE INDEX IF NOT EXISTS idx_layer_results_snapshot_layer ON layer_results(snapshot_ref, layer_name);

CREATE TABLE IF NOT EXISTS expanders (
  expander_id INTEGER PRIMARY KEY AUTOINCREMENT,
  snapshot_ref INTEGER NOT NULL,
  unified_symbol TEXT NOT NULL,
  stage INTEGER NOT NULL DEFAULT 0,  -- 0 candidate,1 tracked,2 confirmed,3 final
  composite_score REAL,
  reasons_json TEXT,
  created_utc TEXT NOT NULL,
  updated_utc TEXT NOT NULL,
  UNIQUE(snapshot_ref, unified_symbol),
  FOREIGN KEY(snapshot_ref) REFERENCES snapshots(snapshot_ref)
);

CREATE INDEX IF NOT EXISTS idx_expanders_stage ON expanders(stage);
CREATE INDEX IF NOT EXISTS idx_expanders_snapshot ON expanders(snapshot_ref);


-- db_migration_005_expander_lifecycle_v1.0a
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS expander_events (
  expander_event_id INTEGER PRIMARY KEY AUTOINCREMENT,
  snapshot_ref INTEGER NOT NULL,
  unified_symbol TEXT NOT NULL,
  from_stage INTEGER,
  to_stage INTEGER NOT NULL,
  score REAL,
  reason_json TEXT,
  created_utc TEXT NOT NULL,
  FOREIGN KEY(snapshot_ref) REFERENCES snapshots(snapshot_ref)
);

CREATE INDEX IF NOT EXISTS idx_expander_events_symbol ON expander_events(unified_symbol);
CREATE INDEX IF NOT EXISTS idx_expander_events_snapshot ON expander_events(snapshot_ref);

-- Add lifecycle timestamps to expanders (idempotent best-effort)
-- SQLite: ALTER TABLE ADD COLUMN only if missing (handled in python ensure function)

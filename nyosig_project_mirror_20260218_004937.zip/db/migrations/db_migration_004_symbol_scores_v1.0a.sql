-- db_migration_004_symbol_scores_v1.0a
-- Adds per-symbol layer scores + composite scores.
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS layer_symbol_scores (
  layer_symbol_score_id INTEGER PRIMARY KEY AUTOINCREMENT,
  snapshot_ref INTEGER NOT NULL,
  timeframe TEXT NOT NULL,
  layer_name TEXT NOT NULL,
  unified_symbol TEXT NOT NULL,
  score REAL,            -- 0..100
  raw_json TEXT,
  created_utc TEXT NOT NULL,
  UNIQUE(snapshot_ref, timeframe, layer_name, unified_symbol),
  FOREIGN KEY(snapshot_ref) REFERENCES snapshots(snapshot_ref)
);

CREATE INDEX IF NOT EXISTS idx_layer_symbol_scores_snapshot_layer ON layer_symbol_scores(snapshot_ref, layer_name, timeframe);
CREATE INDEX IF NOT EXISTS idx_layer_symbol_scores_symbol ON layer_symbol_scores(unified_symbol);

CREATE TABLE IF NOT EXISTS composite_symbol_scores (
  composite_symbol_score_id INTEGER PRIMARY KEY AUTOINCREMENT,
  snapshot_ref INTEGER NOT NULL,
  timeframe TEXT NOT NULL,
  unified_symbol TEXT NOT NULL,
  composite_score REAL NOT NULL, -- 0..100
  meta_json TEXT,
  created_utc TEXT NOT NULL,
  UNIQUE(snapshot_ref, timeframe, unified_symbol),
  FOREIGN KEY(snapshot_ref) REFERENCES snapshots(snapshot_ref)
);

CREATE INDEX IF NOT EXISTS idx_composite_symbol_scores_snapshot ON composite_symbol_scores(snapshot_ref, timeframe);
CREATE INDEX IF NOT EXISTS idx_composite_symbol_scores_score ON composite_symbol_scores(composite_score);

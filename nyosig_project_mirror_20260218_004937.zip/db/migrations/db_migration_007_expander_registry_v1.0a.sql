-- db_migration_007_expander_registry_v1.0a
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS expander_registry (
  unified_symbol TEXT PRIMARY KEY,
  stage INTEGER NOT NULL DEFAULT 0,
  first_seen_utc TEXT NOT NULL,
  last_seen_utc TEXT NOT NULL,
  last_snapshot_ref INTEGER,
  composite_score REAL,
  reasons_json TEXT,
  FOREIGN KEY(last_snapshot_ref) REFERENCES snapshots(snapshot_ref)
);

CREATE INDEX IF NOT EXISTS idx_expander_registry_stage ON expander_registry(stage);

CREATE TABLE IF NOT EXISTS expander_observations (
  expander_observation_id INTEGER PRIMARY KEY AUTOINCREMENT,
  snapshot_ref INTEGER NOT NULL,
  timeframe TEXT NOT NULL,
  unified_symbol TEXT NOT NULL,
  stage INTEGER NOT NULL,
  score REAL,
  reasons_json TEXT,
  created_utc TEXT NOT NULL,
  UNIQUE(snapshot_ref, timeframe, unified_symbol),
  FOREIGN KEY(snapshot_ref) REFERENCES snapshots(snapshot_ref)
);

CREATE INDEX IF NOT EXISTS idx_expander_obs_snapshot ON expander_observations(snapshot_ref, timeframe);
CREATE INDEX IF NOT EXISTS idx_expander_obs_symbol ON expander_observations(unified_symbol);

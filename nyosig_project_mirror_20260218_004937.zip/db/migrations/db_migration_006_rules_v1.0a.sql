-- db_migration_006_rules_v1.0a
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS expander_rules (
  rule_key TEXT PRIMARY KEY,
  rule_value TEXT NOT NULL,
  rule_type TEXT NOT NULL DEFAULT 'float', -- float|int|str|json
  updated_utc TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_expander_rules_updated ON expander_rules(updated_utc);

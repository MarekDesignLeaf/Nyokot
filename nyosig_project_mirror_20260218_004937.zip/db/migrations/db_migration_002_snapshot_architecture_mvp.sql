-- NYOSIG_CRYPTOLYTIX
-- DB MIGRATION 002: Snapshot Architecture MVP Tables
-- Version: v3.0b baseline
-- Safe to run repeatedly (idempotent)
-- Target DB: nyosig_cryptolytix.db (SQLite)

BEGIN;

-- 0) Register migration (unique by name in migrations table)
INSERT OR IGNORE INTO migrations(name, applied_utc)
VALUES ('db_migration_002_snapshot_architecture_mvp', strftime('%Y-%m-%dT%H:%M:%fZ','now'));

-- 1) Run scope (avoids ALTER TABLE runs)
CREATE TABLE IF NOT EXISTS run_scope (
  run_id INTEGER PRIMARY KEY,
  scope TEXT NOT NULL,
  created_utc TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  FOREIGN KEY(run_id) REFERENCES runs(run_id)
);

CREATE INDEX IF NOT EXISTS idx_run_scope_scope ON run_scope(scope);

-- 2) Canonical snapshot rows (market_snapshots)
CREATE TABLE IF NOT EXISTS market_snapshots (
  snapshot_id TEXT NOT NULL,
  run_id INTEGER NOT NULL,
  timestamp_utc TEXT NOT NULL,
  scope TEXT NOT NULL,
  timeframe TEXT NOT NULL,
  unified_symbol TEXT NOT NULL,
  pair TEXT,
  price REAL,
  change_24h_pct REAL,
  vol24 REAL,
  mcap REAL,
  rank INTEGER,
  base_score REAL,
  source TEXT,
  PRIMARY KEY (snapshot_id, unified_symbol, timeframe),
  FOREIGN KEY(run_id) REFERENCES runs(run_id)
);

CREATE INDEX IF NOT EXISTS idx_market_snapshots_run ON market_snapshots(run_id);
CREATE INDEX IF NOT EXISTS idx_market_snapshots_symbol_tf ON market_snapshots(unified_symbol, timeframe);
CREATE INDEX IF NOT EXISTS idx_market_snapshots_time ON market_snapshots(timestamp_utc);
CREATE INDEX IF NOT EXISTS idx_market_snapshots_scope_tf ON market_snapshots(scope, timeframe);

-- 3) TopNow selection (ephemeral, audit only)
CREATE TABLE IF NOT EXISTS topnow_selection (
  selection_id INTEGER PRIMARY KEY AUTOINCREMENT,
  run_id INTEGER NOT NULL,
  snapshot_id TEXT NOT NULL,
  created_utc TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  params_json TEXT,
  FOREIGN KEY(run_id) REFERENCES runs(run_id)
);

CREATE TABLE IF NOT EXISTS topnow_selection_items (
  selection_id INTEGER NOT NULL,
  unified_symbol TEXT NOT NULL,
  rank_in_selection INTEGER,
  composite_preview REAL,
  PRIMARY KEY (selection_id, unified_symbol),
  FOREIGN KEY(selection_id) REFERENCES topnow_selection(selection_id)
);

CREATE INDEX IF NOT EXISTS idx_topnow_selection_run ON topnow_selection(run_id);
CREATE INDEX IF NOT EXISTS idx_topnow_items_symbol ON topnow_selection_items(unified_symbol);

-- 4) Watchlist (only long term persistent entity)
CREATE TABLE IF NOT EXISTS watchlist (
  watch_id INTEGER PRIMARY KEY AUTOINCREMENT,
  unified_symbol TEXT NOT NULL,
  entry_snapshot_id TEXT NOT NULL,
  entry_score REAL,
  stage INTEGER NOT NULL DEFAULT 0,
  tracking_since_utc TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  exit_timestamp_utc TEXT,
  exit_reason TEXT,
  UNIQUE(unified_symbol)
);

CREATE TABLE IF NOT EXISTS watchlist_events (
  event_id INTEGER PRIMARY KEY AUTOINCREMENT,
  watch_id INTEGER NOT NULL,
  event_utc TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  event_type TEXT NOT NULL,
  from_stage INTEGER,
  to_stage INTEGER,
  note TEXT,
  FOREIGN KEY(watch_id) REFERENCES watchlist(watch_id)
);

CREATE INDEX IF NOT EXISTS idx_watchlist_stage ON watchlist(stage);
CREATE INDEX IF NOT EXISTS idx_watchlist_events_watch ON watchlist_events(watch_id);

-- 5) Layer results (0..100 normalised)
CREATE TABLE IF NOT EXISTS layer_results (
  result_id INTEGER PRIMARY KEY AUTOINCREMENT,
  run_id INTEGER NOT NULL,
  snapshot_id TEXT NOT NULL,
  unified_symbol TEXT NOT NULL,
  layer_name TEXT NOT NULL,
  layer_score REAL NOT NULL,
  layer_status TEXT NOT NULL,
  confidence REAL,
  raw_data_json TEXT,
  created_utc TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  UNIQUE(run_id, snapshot_id, unified_symbol, layer_name),
  FOREIGN KEY(run_id) REFERENCES runs(run_id)
);

CREATE INDEX IF NOT EXISTS idx_layer_results_run ON layer_results(run_id);
CREATE INDEX IF NOT EXISTS idx_layer_results_symbol_layer ON layer_results(unified_symbol, layer_name);
CREATE INDEX IF NOT EXISTS idx_layer_results_status ON layer_results(layer_status);

-- 6) Version registry and state log (in main DB)
CREATE TABLE IF NOT EXISTS version_registry (
  version_label TEXT PRIMARY KEY,
  checksum TEXT NOT NULL,
  created_utc TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  note TEXT
);

CREATE TABLE IF NOT EXISTS state_log (
  log_id INTEGER PRIMARY KEY AUTOINCREMENT,
  run_id INTEGER NOT NULL,
  step_name TEXT NOT NULL,
  status TEXT NOT NULL,
  message TEXT,
  created_utc TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  FOREIGN KEY(run_id) REFERENCES runs(run_id)
);

CREATE INDEX IF NOT EXISTS idx_state_log_run ON state_log(run_id);
CREATE INDEX IF NOT EXISTS idx_state_log_step ON state_log(step_name);
CREATE INDEX IF NOT EXISTS idx_state_log_status ON state_log(status);

-- 7) Data backfill (idempotent)
-- 7.1 Ensure every existing run has a scope (default crypto_spot)
INSERT OR IGNORE INTO run_scope(run_id, scope, created_utc)
SELECT r.run_id, 'crypto_spot', r.created_utc
FROM runs r;

-- 7.2 Backfill market_snapshots from existing spot_markets
-- timeframe is set to 'spot' for MVP; scope pulled from run_scope
INSERT OR IGNORE INTO market_snapshots(
  snapshot_id, run_id, timestamp_utc, scope, timeframe,
  unified_symbol, pair, price, change_24h_pct, vol24, mcap, rank, base_score, source
)
SELECT
  'SN_' || sm.run_id AS snapshot_id,
  sm.run_id,
  sm.captured_utc AS timestamp_utc,
  rs.scope AS scope,
  'spot' AS timeframe,
  sm.unified_symbol,
  sm.pair,
  sm.price,
  sm.change_24h_pct,
  sm.volume_24h AS vol24,
  sm.market_cap AS mcap,
  sm.rank,
  sm.score AS base_score,
  sm.source
FROM spot_markets sm
JOIN run_scope rs ON rs.run_id = sm.run_id;

COMMIT;

-- Notes
-- top_sets and top_set_items remain in DB for backward compatibility but are deprecated.
-- In MVP, use market_snapshots + topnow_selection as the canonical flow.

#!/usr/bin/env python3
# run_migration_002_snapshot_architecture_mvp_v1.0a
# ASCII only
# Runs the migration SQL safely (idempotent) on Android project path

import os
import sys
import sqlite3
import shutil
import time

PROJECT_ROOT = "/storage/emulated/0/NyoSig/NyoSig_Cryptolytix"
DB_PATH = os.path.join(PROJECT_ROOT, "db", "nyosig_cryptolytix.db")
MIGRATIONS_DIR = os.path.join(PROJECT_ROOT, "db", "migrations")
MIGRATION_SQL = os.path.join(MIGRATIONS_DIR, "db_migration_002_snapshot_architecture_mvp.sql")

def utc_stamp():
    return time.strftime("%Y%m%d_%H%M%S", time.gmtime())

def die(msg, code=1):
    print(msg)
    sys.exit(code)

def ensure_paths():
    if not os.path.isdir(PROJECT_ROOT):
        die("Project root not found: " + PROJECT_ROOT)
    if not os.path.isfile(DB_PATH):
        die("DB not found: " + DB_PATH)
    if not os.path.isfile(MIGRATION_SQL):
        die("Migration SQL not found: " + MIGRATION_SQL)

def backup_db():
    backup_dir = os.path.join(PROJECT_ROOT, "db", "backups")
    os.makedirs(backup_dir, exist_ok=True)
    base = os.path.basename(DB_PATH)
    dst = os.path.join(backup_dir, base.replace(".db", "") + "_backup_" + utc_stamp() + ".db")
    shutil.copy2(DB_PATH, dst)
    return dst

def read_sql(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def main():
    ensure_paths()

    print("DB: " + DB_PATH)
    print("SQL: " + MIGRATION_SQL)

    bkp = backup_db()
    print("Backup created: " + bkp)

    sql = read_sql(MIGRATION_SQL).strip()
    if not sql:
        die("Migration SQL is empty")

    con = sqlite3.connect(DB_PATH)
    try:
        con.execute("PRAGMA foreign_keys = ON;")
        con.execute("PRAGMA journal_mode = WAL;")
        con.execute("BEGIN;")
        con.executescript(sql)
        con.commit()
        print("Migration applied OK")

        cur = con.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;")
        tables = [r[0] for r in cur.fetchall()]
        print("Tables now present (" + str(len(tables)) + "):")
        for t in tables:
            print("  " + t)

        must_have = ["runs", "market_snapshots", "watchlist", "layer_results"]
        missing = [t for t in must_have if t not in tables]
        if missing:
            print("Warning: missing expected tables: " + ", ".join(missing))
            sys.exit(2)

        print("Core MVP tables present")
        return 0
    except Exception as e:
        try:
            con.rollback()
        except Exception:
            pass
        print("Migration FAILED")
        print(str(e))
        return 1
    finally:
        con.close()

if __name__ == "__main__":
    raise SystemExit(main())

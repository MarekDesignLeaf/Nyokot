import sqlite3
from core.db import ensure_snapshot_schema, ensure_layer_schema, create_snapshot
from core.retention import prune_snapshots_keep_last

def test_retention_prunes(tmp_path):
    db = tmp_path / "t.db"
    con = sqlite3.connect(str(db))
    con.execute("PRAGMA foreign_keys = ON;")
    con.execute("CREATE TABLE runs(run_id INTEGER PRIMARY KEY AUTOINCREMENT);")
    con.execute("CREATE TABLE raw_snapshots(run_id INTEGER, source TEXT, endpoint TEXT, query_json TEXT, response_json TEXT, fetched_utc TEXT);")
    con.execute("INSERT INTO runs(run_id) VALUES (1);")
    ensure_snapshot_schema(con)
    ensure_layer_schema(con)
    # create 3 snapshots
    for i in range(3):
        create_snapshot(con, f"SN_1_{i}", 1, f"2026-02-15T00:00:0{i}Z", "coingecko", "crypto_spot", "spot")
    rep = prune_snapshots_keep_last(con, keep_last=1, per_timeframe=False)
    con.commit()
    assert rep["snapshots"] == 2
    left = con.execute("SELECT COUNT(*) FROM snapshots;").fetchone()[0]
    assert left == 1
    con.close()

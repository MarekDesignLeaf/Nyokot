import sqlite3
from core.rules import reset_rules, load_rules

def test_auto_cleanup_keys(tmp_path):
    con = sqlite3.connect(str(tmp_path/'t.db'))
    reset_rules(con)
    r = load_rules(con)
    assert 'auto_cleanup' in r
    assert 'cleanup_keep_days' in r
    con.close()

import sqlite3
from core.db import ensure_snapshot_schema, ensure_snapshot_ref_links, create_snapshot

def test_snapshot_ref_links_backfill(tmp_path):
    db = tmp_path / "t.db"
    con = sqlite3.connect(str(db))
    con.execute("PRAGMA foreign_keys = ON;")
    # minimal schema
    con.execute("CREATE TABLE runs(run_id INTEGER PRIMARY KEY AUTOINCREMENT);")
    con.execute("CREATE TABLE raw_snapshots(run_id INTEGER, source TEXT, endpoint TEXT, query_json TEXT, response_json TEXT, fetched_utc TEXT);")
    con.execute("CREATE TABLE market_snapshots(snapshot_id TEXT, run_id INTEGER, timestamp_utc TEXT, scope TEXT, timeframe TEXT, unified_symbol TEXT, pair TEXT, price REAL, change_24h_pct REAL, vol24 REAL, mcap REAL, rank INTEGER, base_score REAL, source TEXT);")
    con.execute("CREATE TABLE topnow_selection(selection_id INTEGER PRIMARY KEY AUTOINCREMENT, run_id INTEGER, snapshot_id TEXT, params_json TEXT);")
    ensure_snapshot_schema(con)

    # create run row for FK
    con.execute("INSERT INTO runs(run_id) VALUES (1);")
    snap_ref = create_snapshot(con, "SN_1_X", 1, "2026-02-15T00:00:00Z", "coingecko", "crypto_spot", "spot")
    # insert rows with snapshot_id key only
    con.execute("INSERT INTO market_snapshots(snapshot_id, run_id, timestamp_utc, scope, timeframe, unified_symbol, pair, price, change_24h_pct, vol24, mcap, rank, base_score, source) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?);",
                ("SN_1_X", 1, "2026-02-15T00:00:00Z", "crypto_spot", "spot", "BTC", None, 1.0, 0.0, 0.0, 0.0, 1, None, "coingecko"))
    con.execute("INSERT INTO topnow_selection(run_id, snapshot_id, params_json) VALUES (?,?,?);", (1, "SN_1_X", "{}"))

    ensure_snapshot_ref_links(con)

    # check new columns and backfill
    cols_ms = [r[1] for r in con.execute("PRAGMA table_info(market_snapshots);").fetchall()]
    cols_ts = [r[1] for r in con.execute("PRAGMA table_info(topnow_selection);").fetchall()]
    assert "snapshot_ref" in cols_ms
    assert "snapshot_ref" in cols_ts

    v1 = con.execute("SELECT snapshot_ref FROM market_snapshots WHERE snapshot_id='SN_1_X';").fetchone()[0]
    v2 = con.execute("SELECT snapshot_ref FROM topnow_selection WHERE snapshot_id='SN_1_X';").fetchone()[0]
    assert int(v1) == int(snap_ref)
    assert int(v2) == int(snap_ref)
    con.close()

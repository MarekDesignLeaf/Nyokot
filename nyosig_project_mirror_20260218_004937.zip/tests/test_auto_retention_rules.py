import sqlite3
from core.rules import reset_rules, load_rules

def test_auto_retention_keys(tmp_path):
    con = sqlite3.connect(str(tmp_path/'t.db'))
    reset_rules(con)
    r = load_rules(con)
    assert 'auto_retention' in r
    assert 'retention_keep' in r
    con.close()

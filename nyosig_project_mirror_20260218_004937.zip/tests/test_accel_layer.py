import sqlite3, json
from core.db import ensure_snapshot_schema, ensure_layer_schema, ensure_snapshot_ref_links, create_snapshot
from core.layers_accel_15m import Accel15mLayer
from core.layers_base import LayerContext

def test_accel_layer_skips_without_two_15m(tmp_path):
    con = sqlite3.connect(str(tmp_path/'t.db'))
    con.execute("PRAGMA foreign_keys = ON;")
    con.execute("CREATE TABLE runs(run_id INTEGER PRIMARY KEY AUTOINCREMENT);")
    con.execute("INSERT INTO runs(run_id) VALUES (1);")
    con.execute("CREATE TABLE raw_snapshots(run_id INTEGER, source TEXT, endpoint TEXT, query_json TEXT, response_json TEXT, fetched_utc TEXT);")
    con.execute("CREATE TABLE market_snapshots(snapshot_id TEXT, snapshot_ref INTEGER, run_id INTEGER, timestamp_utc TEXT, scope TEXT, timeframe TEXT, unified_symbol TEXT, pair TEXT, price REAL, change_24h_pct REAL, vol24 REAL, mcap REAL, rank INTEGER, base_score REAL, source TEXT);")
    ensure_snapshot_schema(con)
    ensure_layer_schema(con)

    # only one 15m snapshot
    sref = create_snapshot(con, "SN_1_A", 1, "2026-02-15T00:00:00Z", "coingecko", "crypto_spot", "15m")
    ctx = LayerContext(run_id=1, snapshot_ref=sref, snapshot_key="SN_1_A", timeframe="15m", vs_currency="usd", scope="crypto_spot")
    res = Accel15mLayer().run(con, ctx)
    assert res.status in ("skipped","ok","failed")
    con.close()

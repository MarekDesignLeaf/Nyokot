from core.config import parse_simple_yaml

def test_parse_simple_yaml_basic(tmp_path):
    p = tmp_path / "cfg.yaml"
    p.write_text("mvp:\n  coins_limit: 123\n  offline_mode: true\n", encoding="utf-8")
    d = parse_simple_yaml(str(p))
    assert d["mvp"]["coins_limit"] == 123
    assert d["mvp"]["offline_mode"] is True

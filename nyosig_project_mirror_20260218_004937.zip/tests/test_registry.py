import sqlite3, json
from core.db import ensure_snapshot_schema, ensure_layer_schema, create_snapshot, upsert_layer_symbol_score
from core.composite import compute_and_store_composite_symbol_scores
from core.expander import promote_expanders

def test_registry_updates(tmp_path):
    con = sqlite3.connect(str(tmp_path/'t.db'))
    con.execute("PRAGMA foreign_keys = ON;")
    con.execute("CREATE TABLE runs(run_id INTEGER PRIMARY KEY AUTOINCREMENT);")
    con.execute("INSERT INTO runs(run_id) VALUES (1);")
    con.execute("CREATE TABLE raw_snapshots(run_id INTEGER, source TEXT, endpoint TEXT, query_json TEXT, response_json TEXT, fetched_utc TEXT);")
    con.execute("CREATE TABLE market_snapshots(snapshot_id TEXT, snapshot_ref INTEGER, run_id INTEGER, timestamp_utc TEXT, scope TEXT, timeframe TEXT, unified_symbol TEXT, pair TEXT, price REAL, change_24h_pct REAL, vol24 REAL, mcap REAL, rank INTEGER, base_score REAL, source TEXT);")
    ensure_snapshot_schema(con)
    ensure_layer_schema(con)

    sref = create_snapshot(con, "SN_1_A", 1, "2026-02-15T00:00:00Z", "coingecko", "crypto_spot", "spot")
    upsert_layer_symbol_score(con, sref, "spot", "spot_basic", "BTC", 92.0, None, "2026-02-15T00:00:00Z")
    compute_and_store_composite_symbol_scores(con, sref, "spot", run_id=1)
    promote_expanders(con, sref, "spot")

    row = con.execute("SELECT stage FROM expander_registry WHERE unified_symbol='BTC';").fetchone()
    assert row is not None
    con.close()

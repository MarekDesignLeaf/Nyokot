import sqlite3
from core.db import ensure_snapshot_schema

def test_ensure_snapshot_schema_adds_table_and_columns(tmp_path):
    db = tmp_path / "t.db"
    con = sqlite3.connect(str(db))
    con.execute("PRAGMA foreign_keys = ON;")
    # minimal parent tables required by FK
    con.execute("CREATE TABLE runs(run_id INTEGER PRIMARY KEY AUTOINCREMENT);")
    con.execute("CREATE TABLE raw_snapshots(run_id INTEGER, source TEXT, endpoint TEXT, query_json TEXT, response_json TEXT, fetched_utc TEXT);")
    ensure_snapshot_schema(con)
    # snapshots table exists
    row = con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='snapshots';").fetchone()
    assert row is not None
    cols = [r[1] for r in con.execute("PRAGMA table_info(raw_snapshots);").fetchall()]
    assert "snapshot_key" in cols
    assert "snapshot_ref" in cols
    con.close()

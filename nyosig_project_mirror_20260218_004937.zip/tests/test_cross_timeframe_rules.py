import sqlite3
from core.rules import load_rules, reset_rules

def test_cross_tf_rule_defaults(tmp_path):
    con = sqlite3.connect(str(tmp_path/'t.db'))
    reset_rules(con)
    r = load_rules(con)
    assert 'stage3_require_1h' in r
    assert 'stage3_1h_min_score' in r
    con.close()

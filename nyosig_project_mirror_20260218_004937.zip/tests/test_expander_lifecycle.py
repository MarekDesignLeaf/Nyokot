import sqlite3
from core.db import ensure_snapshot_schema, ensure_layer_schema, create_snapshot
from core.composite import compute_and_store_composite_symbol_scores
from core.db import upsert_layer_symbol_score
from core.expander import promote_expanders

def test_expander_events_written(tmp_path):
    db = tmp_path / "t.db"
    con = sqlite3.connect(str(db))
    con.execute("PRAGMA foreign_keys = ON;")
    con.execute("CREATE TABLE runs(run_id INTEGER PRIMARY KEY AUTOINCREMENT);")
    con.execute("INSERT INTO runs(run_id) VALUES (1);")
    con.execute("CREATE TABLE raw_snapshots(run_id INTEGER, source TEXT, endpoint TEXT, query_json TEXT, response_json TEXT, fetched_utc TEXT);")
    ensure_snapshot_schema(con)
    ensure_layer_schema(con)
    snap_ref = create_snapshot(con, "SN_1_T", 1, "2026-02-15T00:00:00Z", "coingecko", "crypto_spot", "spot")

    upsert_layer_symbol_score(con, snap_ref, "spot", "spot_basic", "BTC", 95.0, None, "2026-02-15T00:00:00Z")
    compute_and_store_composite_symbol_scores(con, snap_ref, "spot", run_id=1)
    promote_expanders(con, snap_ref, "spot")

    n = con.execute("SELECT COUNT(*) FROM expander_events;").fetchone()[0]
    assert n >= 1
    con.close()

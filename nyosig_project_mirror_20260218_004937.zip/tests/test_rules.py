import sqlite3
from core.rules import load_rules, set_rule, reset_rules

def test_rules_roundtrip(tmp_path):
    con = sqlite3.connect(str(tmp_path/'t.db'))
    reset_rules(con)
    r = load_rules(con)
    assert 'stage1_min_score' in r
    set_rule(con, 'stage1_min_score', 77.0, typ='float')
    con.commit()
    r2 = load_rules(con)
    assert abs(r2['stage1_min_score'] - 77.0) < 1e-9
    con.close()

import sqlite3
from core.db import ensure_snapshot_schema, ensure_layer_schema, create_snapshot, upsert_layer_symbol_score
from core.composite import compute_and_store_composite_symbol_scores
from core.expander import promote_expanders
from core.registry import decay_registry_once
from core.export_stage3 import get_stage3

def test_export_and_decay(tmp_path):
    con = sqlite3.connect(str(tmp_path/'t.db'))
    con.execute("PRAGMA foreign_keys = ON;")
    con.execute("CREATE TABLE runs(run_id INTEGER PRIMARY KEY AUTOINCREMENT);")
    con.execute("INSERT INTO runs(run_id) VALUES (1);")
    con.execute("CREATE TABLE raw_snapshots(run_id INTEGER, source TEXT, endpoint TEXT, query_json TEXT, response_json TEXT, fetched_utc TEXT);")
    con.execute("CREATE TABLE market_snapshots(snapshot_id TEXT, snapshot_ref INTEGER, run_id INTEGER, timestamp_utc TEXT, scope TEXT, timeframe TEXT, unified_symbol TEXT, pair TEXT, price REAL, change_24h_pct REAL, vol24 REAL, mcap REAL, rank INTEGER, base_score REAL, source TEXT);")
    ensure_snapshot_schema(con)
    ensure_layer_schema(con)

    sref = create_snapshot(con, "SN_1_A", 1, "2026-02-15T00:00:00Z", "coingecko", "crypto_spot", "spot")
    upsert_layer_symbol_score(con, sref, "spot", "spot_basic", "BTC", 95.0, None, "2026-02-15T00:00:00Z")
    compute_and_store_composite_symbol_scores(con, sref, "spot", run_id=1)
    promote_expanders(con, sref, "spot")

    lst = get_stage3(con, min_stage=1, limit=10)
    assert lst and lst[0]["symbol"] == "BTC"

    rep = decay_registry_once(con, now_utc="2026-02-16T12:00:00Z", rules={"decay_step_hours": 6.0, "decay_max_drop": 1})
    assert "registry_updated" in rep
    con.close()

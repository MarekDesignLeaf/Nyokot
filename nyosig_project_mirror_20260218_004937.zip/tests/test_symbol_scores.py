import sqlite3
from core.db import ensure_snapshot_schema, ensure_layer_schema, ensure_symbol_score_schema, create_snapshot, upsert_layer_symbol_score
from core.composite import compute_and_store_composite_symbol_scores, load_layer_weights

def test_symbol_scores_and_composite(tmp_path):
    db = tmp_path / "t.db"
    con = sqlite3.connect(str(db))
    con.execute("PRAGMA foreign_keys = ON;")
    con.execute("CREATE TABLE runs(run_id INTEGER PRIMARY KEY AUTOINCREMENT);")
    con.execute("INSERT INTO runs(run_id) VALUES (1);")
    con.execute("CREATE TABLE raw_snapshots(run_id INTEGER, source TEXT, endpoint TEXT, query_json TEXT, response_json TEXT, fetched_utc TEXT);")
    ensure_snapshot_schema(con)
    ensure_layer_schema(con)  # calls ensure_symbol_score_schema
    snap_ref = create_snapshot(con, "SN_1_T", 1, "2026-02-15T00:00:00Z", "coingecko", "crypto_spot", "spot")

    upsert_layer_symbol_score(con, snap_ref, "spot", "spot_basic", "BTC", 80.0, None, "2026-02-15T00:00:00Z")
    upsert_layer_symbol_score(con, snap_ref, "spot", "spot_basic", "ETH", 60.0, None, "2026-02-15T00:00:00Z")

    n = compute_and_store_composite_symbol_scores(con, snap_ref, "spot", run_id=1)
    assert n == 2
    top = con.execute("SELECT unified_symbol, composite_score FROM composite_symbol_scores ORDER BY composite_score DESC;").fetchall()
    assert top[0][0] == "BTC"
    con.close()

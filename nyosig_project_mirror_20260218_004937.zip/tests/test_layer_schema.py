import sqlite3, json
from core.db import ensure_snapshot_schema, ensure_layer_schema, upsert_layer_result, upsert_expander, create_snapshot

def test_layer_schema_and_upserts(tmp_path):
    db = tmp_path / "t.db"
    con = sqlite3.connect(str(db))
    con.execute("PRAGMA foreign_keys = ON;")
    # minimal parent tables
    con.execute("CREATE TABLE runs(run_id INTEGER PRIMARY KEY AUTOINCREMENT);")
    con.execute("INSERT INTO runs(run_id) VALUES (1);")
    con.execute("CREATE TABLE raw_snapshots(run_id INTEGER, source TEXT, endpoint TEXT, query_json TEXT, response_json TEXT, fetched_utc TEXT);")
    ensure_snapshot_schema(con)
    ensure_layer_schema(con)
    snap_ref = create_snapshot(con, "SN_1_T", 1, "2026-02-15T00:00:00Z", "coingecko", "crypto_spot", "spot")
    upsert_layer_result(con, 1, snap_ref, "spot", "spot_basic", "v1", "ok", None, 1.0, json.dumps({"x":1}), "2026-02-15T00:00:00Z")
    upsert_expander(con, snap_ref, "BTC", 1, 75.0, json.dumps({"rule":"t"}), "2026-02-15T00:00:00Z", "2026-02-15T00:00:00Z")
    con.commit()
    assert con.execute("SELECT COUNT(*) FROM layer_results;").fetchone()[0] == 1
    assert con.execute("SELECT COUNT(*) FROM expanders;").fetchone()[0] == 1
    con.close()

#!/usr/bin/env python3
# diagnostics_nyosig.py
# Run: python diagnostics_nyosig.py
# Optional: python diagnostics_nyosig.py /path/to/NyoSig_Cryptolytix

from __future__ import annotations

import os
import sys
import json
import time
import traceback
import sqlite3
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

LOG_LINES: List[str] = []

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line)
    LOG_LINES.append(line)

def write_log_file(project_root: str, filename: str = "diagnostics_log.txt") -> str:
    path = os.path.join(project_root, "logs")
    os.makedirs(path, exist_ok=True)
    out = os.path.join(path, filename)
    with open(out, "w", encoding="utf-8") as f:
        f.write("\n".join(LOG_LINES) + "\n")
    return out

def find_project_root(start: str) -> str:
    # We define root as folder containing "core" and "app"
    cur = os.path.abspath(start)
    if os.path.isfile(cur):
        cur = os.path.dirname(cur)
    for _ in range(12):
        if os.path.isdir(os.path.join(cur, "core")) and os.path.isdir(os.path.join(cur, "app")):
            return cur
        parent = os.path.dirname(cur)
        if parent == cur:
            break
        cur = parent
    raise RuntimeError(f"Cannot find project root from: {start}")

def safe_import_project(project_root: str) -> None:
    if project_root not in sys.path:
        sys.path.insert(0, project_root)

def table_exists(con: sqlite3.Connection, name: str) -> bool:
    row = con.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name=?;",
        (name,),
    ).fetchone()
    return row is not None

def table_columns(con: sqlite3.Connection, name: str) -> List[str]:
    if not table_exists(con, name):
        return []
    cur = con.execute(f"PRAGMA table_info({name});")
    return [r[1] for r in cur.fetchall()]

def assert_has(obj: Any, attr: str) -> Tuple[bool, str]:
    ok = hasattr(obj, attr)
    return ok, f"{attr}: {'OK' if ok else 'MISSING'}"

def try_call(fn, *args, **kwargs):
    try:
        return True, fn(*args, **kwargs), None
    except Exception as e:
        return False, None, e

def short_exc(e: BaseException) -> str:
    return f"{type(e).__name__}: {e}"

@dataclass
class CheckResult:
    name: str
    ok: bool
    details: str

def main() -> int:
    start = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
    try:
        project_root = find_project_root(start)
    except Exception as e:
        print("FATAL:", e)
        return 2

    safe_import_project(project_root)

    log("=== Nyosig diagnostics start ===")
    log(f"python: {sys.version.split()[0]}")
    log(f"cwd: {os.getcwd()}")
    log(f"project_root: {project_root}")

    results: List[CheckResult] = []

    # --- Imports ---
    try:
        import core
        from core import config as core_config
        from core import db as core_db
        from core import pipeline as core_pipeline
        results.append(CheckResult("import core/config/db/pipeline", True, "OK"))
    except Exception as e:
        tb = traceback.format_exc()
        log("IMPORT FAILED:\n" + tb)
        results.append(CheckResult("import core/config/db/pipeline", False, short_exc(e)))
        out = write_log_file(project_root)
        log(f"log saved: {out}")
        return 3

    # --- Paths ---
    try:
        paths = core_config.make_paths(project_root)
        # Try to be robust if make_paths returns dataclass-like
        db_path = getattr(paths, "db_path", None)
        logs_dir = getattr(paths, "log_dir", None)
        cache_dir = getattr(paths, "cache_dir", None)
        samples_dir = getattr(paths, "samples_dir", None)
        log(f"db_path: {db_path}")
        log(f"logs_dir: {logs_dir}")
        log(f"cache_dir: {cache_dir}")
        log(f"samples_dir: {samples_dir}")
        results.append(CheckResult("config.make_paths", True, "OK"))
    except Exception as e:
        log("make_paths failed:\n" + traceback.format_exc())
        results.append(CheckResult("config.make_paths", False, short_exc(e)))
        db_path = os.path.join(project_root, "db", "nyosig_cryptolytix.db")

    # --- API surface expected by GUI/pipeline ---
    expected_db_symbols = [
        "db_connect",
        "require_schema",
        "ensure_core_schema",
        "ensure_snapshot_schema",
        "create_run",
        "set_run_status",
        "state_log",
    ]
    missing = []
    for s in expected_db_symbols:
        ok, detail = assert_has(core_db, s)
        results.append(CheckResult(f"core.db.{s}", ok, detail))
        if not ok:
            missing.append(s)

    if missing:
        log("DB API mismatch. Missing exports in core.db: " + ", ".join(missing))

    # --- DB bootstrap / heal ---
    con: Optional[sqlite3.Connection] = None
    try:
        # best effort connect: use db_connect if present
        if hasattr(core_db, "db_connect"):
            con = core_db.db_connect(db_path)  # type: ignore
        else:
            os.makedirs(os.path.dirname(db_path), exist_ok=True)
            con = sqlite3.connect(db_path)
            con.execute("PRAGMA foreign_keys = ON;")

        log("DB connected OK")

        # Call the "earliest-safe" boot sequence
        boot_steps = []

        if hasattr(core_db, "ensure_core_schema"):
            boot_steps.append(("ensure_core_schema", core_db.ensure_core_schema))
        if hasattr(core_db, "ensure_core_indexes"):
            boot_steps.append(("ensure_core_indexes", core_db.ensure_core_indexes))
        if hasattr(core_db, "ensure_snapshot_schema"):
            boot_steps.append(("ensure_snapshot_schema", core_db.ensure_snapshot_schema))
        if hasattr(core_db, "ensure_indexes"):
            boot_steps.append(("ensure_indexes", core_db.ensure_indexes))
        # always attempt require_schema at end if exists
        if hasattr(core_db, "require_schema"):
            boot_steps.append(("require_schema", core_db.require_schema))

        for name, fn in boot_steps:
            ok, _, err = try_call(fn, con)
            results.append(CheckResult(f"db_boot.{name}", ok, "OK" if ok else short_exc(err)))  # type: ignore
            log(f"boot {name}: {'OK' if ok else 'FAIL'}" + ("" if ok else f" -> {short_exc(err)}"))

        try:
            con.commit()
        except Exception:
            pass

        # --- Schema assertions ---
        required_tables = [
            "runs", "run_scope", "raw_snapshots", "market_snapshots",
            "topnow_selection", "topnow_selection_items", "state_log",
            "snapshots"
        ]
        for t in required_tables:
            ok = table_exists(con, t)
            results.append(CheckResult(f"table.{t}", ok, "exists" if ok else "missing"))
            log(f"table {t}: {'OK' if ok else 'MISSING'}")

        # column checks
        ms_cols = table_columns(con, "market_snapshots")
        rr_cols = table_columns(con, "raw_snapshots")
        runs_cols = table_columns(con, "runs")
        snaps_cols = table_columns(con, "snapshots")

        def col_check(table: str, cols: List[str], col: str) -> None:
            ok = col in cols
            results.append(CheckResult(f"col.{table}.{col}", ok, "OK" if ok else f"missing (have: {cols})"))
            log(f"col {table}.{col}: {'OK' if ok else 'MISSING'}")

        col_check("market_snapshots", ms_cols, "snapshot_ref")
        col_check("raw_snapshots", rr_cols, "snapshot_ref")
        col_check("runs", runs_cols, "status")
        col_check("snapshots", snaps_cols, "parent_snapshot_ref")

    except Exception as e:
        log("DB bootstrap failed:\n" + traceback.format_exc())
        results.append(CheckResult("db_bootstrap", False, short_exc(e)))

    finally:
        try:
            if con:
                con.close()
        except Exception:
            pass

    # --- Pipeline offline test (no network) ---
    # This tries to call a known entrypoint if present.
    # We keep it defensive because pipeline signatures changed between versions.
    try:
        log("=== Pipeline offline test ===")
        candidates = [
            ("run_snapshot_and_topnow", ["project_root", "app_version", "scope_text", "vs_currency", "coins_limit", "order", "topnow_limit", "offline_mode", "log_cb"]),
            ("run_pipeline", ["project_root", "scope", "vs_currency", "coins_limit", "order", "topnow_limit", "offline_mode", "log_cb"]),
        ]

        fn = None
        fn_name = None
        for name, _sig in candidates:
            if hasattr(core_pipeline, name):
                fn = getattr(core_pipeline, name)
                fn_name = name
                break

        if fn is None:
            results.append(CheckResult("pipeline.entrypoint", False, "No known pipeline entrypoint found"))
            log("No pipeline entrypoint found (expected run_snapshot_and_topnow or run_pipeline).")
        else:
            # minimal params (offline)
            def cb(m: str) -> None:
                log("pipeline: " + m)

            kwargs: Dict[str, Any] = {}
            # Try the most common signature we used
            if fn_name == "run_snapshot_and_topnow":
                kwargs = dict(
                    project_root=project_root,
                    app_version="diagnostics",
                    scope_text="crypto_spot",
                    vs_currency="usd",
                    coins_limit=25,
                    order="market_cap_desc",
                    topnow_limit=10,
                    offline_mode=True,
                    log_cb=cb,
                )
            else:
                kwargs = dict(
                    project_root=project_root,
                    scope="crypto_spot",
                    vs_currency="usd",
                    coins_limit=25,
                    order="market_cap_desc",
                    topnow_limit=10,
                    offline_mode=True,
                    log_cb=cb,
                )

            ok, out, err = try_call(fn, **kwargs)
            results.append(CheckResult(f"pipeline.{fn_name}", ok, "OK" if ok else short_exc(err)))
            if ok:
                log(f"pipeline {fn_name}: OK -> {out}")
            else:
                log(f"pipeline {fn_name}: FAIL -> {short_exc(err)}")
                log(traceback.format_exc())

    except Exception as e:
        log("Pipeline offline test crashed:\n" + traceback.format_exc())
        results.append(CheckResult("pipeline.offline_test", False, short_exc(e)))

    # --- Summary ---
    log("=== SUMMARY ===")
    ok_count = sum(1 for r in results if r.ok)
    fail = [r for r in results if not r.ok]
    log(f"checks: {ok_count}/{len(results)} ok")
    if fail:
        log("FAILED checks:")
        for r in fail:
            log(f" - {r.name}: {r.details}")
    else:
        log("All checks passed.")

    out = write_log_file(project_root)
    log(f"log saved: {out}")
    log("=== Nyosig diagnostics end ===")
    return 0 if not fail else 1


if __name__ == "__main__":
    raise SystemExit(main())
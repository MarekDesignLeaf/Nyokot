# NyoSig Cryptolytix

Project root.

Rules:
- Root contains only launcher + README.
- All versioned application files go to: app/versions/
- Tools go to: tools/
- Reports go to: reports/
- DB goes to: db/


## Core refactor (v3.5a)
- Core logic extracted to `core/` (db/cache/network/pipeline/scoring).
- New GUI version: `app/versions/nyosig_cryptolytix_gui_v3.5a.py`.
- Minimal tests in `tests/`.

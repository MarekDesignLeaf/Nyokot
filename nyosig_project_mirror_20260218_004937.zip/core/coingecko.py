from __future__ import annotations
import json, time, urllib.parse, urllib.request
from typing import Any, Callable, Dict, List, Tuple
from .cache import cache_key, cache_path, load_cache_if_fresh, save_cache, ensure_dir

COINGECKO_BASE_URL = "https://api.coingecko.com/api/v3"

def http_get_json(url: str, headers: Dict[str,str], timeout_s: int) -> Any:
    req = urllib.request.Request(url, headers=headers, method="GET")
    with urllib.request.urlopen(req, timeout=timeout_s) as resp:
        return json.loads(resp.read().decode("utf-8"))

def build_markets_url(vs_currency: str, order: str, per_page: int, page: int, price_change_percentage: str) -> Tuple[str, Dict[str,str]]:
    q = {
        "vs_currency": vs_currency,
        "order": order,
        "per_page": str(per_page),
        "page": str(page),
        "sparkline": "false",
        "price_change_percentage": price_change_percentage,
    }
    return COINGECKO_BASE_URL + "/coins/markets?" + urllib.parse.urlencode(q), q

def retry_fetch(url: str, headers: Dict[str,str], connect_timeout_s: int, read_timeout_s: int,
                max_attempts: int, backoff_s: List[int], on_429_sleep_s: int,
                log_cb: Callable[[str], None]) -> Any:
    last_err: Exception | None = None
    for attempt in range(1, max_attempts + 1):
        try:
            log_cb(f"FETCH attempt={attempt} url={url}")
            return http_get_json(url, headers=headers, timeout_s=connect_timeout_s + read_timeout_s)
        except Exception as e:
            last_err = e
            msg = str(e)
            if "HTTP Error 429" in msg:
                log_cb(f"RATE_LIMIT 429 sleep_s={on_429_sleep_s}")
                time.sleep(on_429_sleep_s)
            else:
                sleep_s = backoff_s[min(attempt - 1, len(backoff_s) - 1)]
                log_cb(f"RETRY sleep_s={sleep_s} err={msg}")
                time.sleep(sleep_s)
    if last_err:
        raise last_err
    raise RuntimeError("retry_fetch failed without exception")

def fetch_markets(vs_currency: str, order: str, coins_limit: int, headers: Dict[str,str],
                  cache_dir: str, ttl_s: int,
                  connect_timeout_s: int, read_timeout_s: int, max_attempts: int,
                  backoff_s: List[int], on_429_sleep_s: int,
                  log_cb: Callable[[str], None]) -> List[Dict[str, Any]]:
    ensure_dir(cache_dir)
    per_page = 250
    pages = (coins_limit + per_page - 1) // per_page
    all_markets: List[Dict[str, Any]] = []
    for page in range(1, pages + 1):
        url, q = build_markets_url(vs_currency, order, per_page, page, "24h")
        ck = cache_key({"source": "coingecko", "endpoint": "/coins/markets", **q})
        cp = cache_path(cache_dir, ck)
        cached = load_cache_if_fresh(cp, ttl_s)
        if cached is not None:
            log_cb(f"cache_hit page={page}")
            markets_page = cached
        else:
            markets_page = retry_fetch(url, headers, connect_timeout_s, read_timeout_s, max_attempts, backoff_s, on_429_sleep_s, log_cb)
            save_cache(cp, markets_page)
            log_cb(f"cache_save page={page}")

        if isinstance(markets_page, list):
            all_markets.extend(markets_page)
        else:
            raise RuntimeError("Unexpected response type from CoinGecko")

        if len(all_markets) >= coins_limit:
            break
    return all_markets[:coins_limit]

from __future__ import annotations
import os
from dataclasses import dataclass
from typing import Any, Dict

def read_text(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def parse_secrets_env(path: str) -> Dict[str, str]:
    out: Dict[str, str] = {}
    if not os.path.isfile(path):
        return out
    for line in read_text(path).splitlines():
        s = line.strip()
        if not s or s.startswith("#") or "=" not in s:
            continue
        k, v = s.split("=", 1)
        out[k.strip()] = v.strip()
    return out

def parse_simple_yaml(path: str) -> Dict[str, Any]:
    # tiny YAML subset: keys, nested dict by indentation (2 spaces), lists in [a,b], bool, int/float, strings
    if not os.path.isfile(path):
        return {}
    data: Dict[str, Any] = {}
    stack = [(0, data)]
    for raw in read_text(path).splitlines():
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        indent = len(raw) - len(raw.lstrip(" "))
        line = raw.strip()
        if ":" not in line:
            continue
        key, val = line.split(":", 1)
        key = key.strip()
        val = val.strip()

        while stack and indent < stack[-1][0]:
            stack.pop()
        cur = stack[-1][1] if stack else data

        if val == "":
            cur[key] = {}
            stack.append((indent + 2, cur[key]))
            continue

        if val.startswith("[") and val.endswith("]"):
            inner = val[1:-1].strip()
            cur[key] = [] if not inner else [x.strip() for x in inner.split(",")]
            continue

        if val.lower() in ("true", "false"):
            cur[key] = (val.lower() == "true")
            continue

        try:
            if "." in val:
                cur[key] = float(val)
            else:
                cur[key] = int(val)
            continue
        except Exception:
            pass

        cur[key] = val
    return data


DEFAULT_PROJECT_ROOT = "/storage/emulated/0/NyoSig/NyoSig_Cryptolytix"

def get_project_root(default: str = DEFAULT_PROJECT_ROOT) -> str:
    # Allows running the code outside Android by overriding NYOSIG_PROJECT_ROOT
    return os.environ.get("NYOSIG_PROJECT_ROOT", default).strip() or default


@dataclass(frozen=True)
class Paths:
    project_root: str
    db_path: str
    defaults_yaml: str
    secrets_env: str
    cache_dir: str
    log_dir: str
    samples_dir: str

def make_paths(project_root: str) -> Paths:
    return Paths(
        project_root=project_root,
        db_path=os.path.join(project_root, "db", "nyosig_cryptolytix.db"),
        defaults_yaml=os.path.join(project_root, "config", "defaults.yaml"),
        secrets_env=os.path.join(project_root, "config", "secrets.env"),
        cache_dir=os.path.join(project_root, "cache"),
        log_dir=os.path.join(project_root, "logs", "runs"),
        samples_dir=os.path.join(project_root, "samples", "raw_snapshots"),
    )

import time

def utc_now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

def utc_stamp_compact() -> str:
    return time.strftime("%Y%m%d_%H%M%S", time.gmtime())

from __future__ import annotations
import sqlite3
from typing import Dict, Any

from .db import resolve_snapshot, table_columns

def snapshot_diff_summary(con: sqlite3.Connection, a_snapshot: str | int, b_snapshot: str | int, timeframe: str = "spot", limit: int = 30) -> Dict[str, Any]:
    """Compare two snapshots (b - a). Returns movers and counts."""
    a_ref, a_key = resolve_snapshot(con, a_snapshot)
    b_ref, b_key = resolve_snapshot(con, b_snapshot)
    cols = table_columns(con, "market_snapshots")
    use_ref = (a_ref is not None and b_ref is not None and "snapshot_ref" in cols)

    where = ("a.snapshot_ref=? AND b.snapshot_ref=?" if use_ref else "a.snapshot_id=? AND b.snapshot_id=?")
    q = (
        "SELECT a.unified_symbol, "
        "a.rank, b.rank, "
        "a.price, b.price, "
        "a.mcap, b.mcap, "
        "a.vol24, b.vol24, "
        "a.change_24h_pct, b.change_24h_pct, "
        "a.base_score, b.base_score "
        "FROM market_snapshots a "
        "JOIN market_snapshots b ON b.unified_symbol=a.unified_symbol "
        f"WHERE {where} AND a.timeframe=? AND b.timeframe=?"
    )

    params = (a_ref, b_ref, timeframe, timeframe) if use_ref else (a_key or str(a_snapshot), b_key or str(b_snapshot), timeframe, timeframe)
    rows = con.execute(q, params).fetchall()

    def safe_delta(x, y):
        if x is None or y is None:
            return None
        try:
            return float(y) - float(x)
        except Exception:
            return None

    movers = []
    for r in rows:
        sym, ar, br, ap, bp, am, bm, av, bv, ac, bc, ascore, bscore = r
        d_rank = None
        if ar is not None and br is not None:
            try:
                d_rank = int(ar) - int(br)  # positive means improved rank
            except Exception:
                d_rank = None
        movers.append({
            "symbol": sym,
            "rank_a": ar, "rank_b": br, "rank_improve": d_rank,
            "price_a": ap, "price_b": bp, "d_price": safe_delta(ap, bp),
            "mcap_a": am, "mcap_b": bm, "d_mcap": safe_delta(am, bm),
            "vol24_a": av, "vol24_b": bv, "d_vol24": safe_delta(av, bv),
            "chg24_a": ac, "chg24_b": bc, "d_chg24": safe_delta(ac, bc),
            "score_a": ascore, "score_b": bscore, "d_score": safe_delta(ascore, bscore),
        })

    movers_sorted = sorted(
        movers,
        key=lambda x: (x["d_score"] is None, -(x["d_score"] or 0.0), x["d_price"] is None, -(x["d_price"] or 0.0))
    )
    top = movers_sorted[:max(1, int(limit))]

    return {
        "a_snapshot": a_key or str(a_snapshot),
        "b_snapshot": b_key or str(b_snapshot),
        "timeframe": timeframe,
        "symbols_compared": len(rows),
        "top_movers": top,
    }

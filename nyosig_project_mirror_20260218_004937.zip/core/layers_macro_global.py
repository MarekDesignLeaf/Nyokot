# ASCII only
# Macro layer: CoinGecko global market metrics (public JSON)

from __future__ import annotations

import json
import urllib.request


def fetch_coingecko_global(timeout_s: int = 10) -> dict:
    url = 'https://api.coingecko.com/api/v3/global'
    req = urllib.request.Request(url, headers={'User-Agent': 'NyoSig-Cryptolytix/1.0'})
    with urllib.request.urlopen(req, timeout=timeout_s) as r:
        raw = r.read().decode('utf-8', errors='strict')
    payload = json.loads(raw)
    if not isinstance(payload, dict) or 'data' not in payload or not isinstance(payload['data'], dict):
        raise RuntimeError('Unexpected response from CoinGecko /global')
    d = payload['data']
    return {
        'market_cap_change_percentage_24h_usd': float(d.get('market_cap_change_percentage_24h_usd') or 0.0),
        'active_cryptocurrencies': int(d.get('active_cryptocurrencies') or 0),
        'markets': int(d.get('markets') or 0),
        'btc_dominance': float((d.get('market_cap_percentage') or {}).get('btc') or 0.0),
        'eth_dominance': float((d.get('market_cap_percentage') or {}).get('eth') or 0.0),
        'source': 'coingecko/global'
    }


def score_from_global(market_cap_change_24h: float, btc_dominance: float) -> int:
    # Conservative proxy: positive 24h market cap change pushes up, extreme BTC dominance pushes down slightly.
    # This is not a claim of macro economy, it is a crypto market-wide proxy.
    x = market_cap_change_24h
    if x < -20:
        x = -20
    if x > 20:
        x = 20
    base = 50 + int((x / 20.0) * 40)  # -20..20 -> -40..40
    dom = btc_dominance
    if dom < 0:
        dom = 0
    if dom > 80:
        dom = 80
    dom_penalty = int((dom / 80.0) * 10)  # 0..80 -> 0..10
    s = base - dom_penalty
    if s < 0:
        s = 0
    if s > 100:
        s = 100
    return int(s)

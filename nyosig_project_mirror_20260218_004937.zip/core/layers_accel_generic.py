from __future__ import annotations
import sqlite3, json
from dataclasses import dataclass
from typing import Optional

from .db import upsert_layer_symbol_score
from .util_time import utc_now_iso

def _clamp(x: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, x))

@dataclass
class AccelConfig:
    timeframe: str
    layer_name: str
    scale: float = 5.0   # score = 50 + accel_pct*scale
    max_pct: float = 10.0

class AccelGeneric:
    """Compute accel_pct between last two snapshots for a timeframe using price pct change."""
    def __init__(self, cfg: AccelConfig):
        self.cfg = cfg
        self.layer_version = "v1"

    def run(self, con: sqlite3.Connection) -> dict:
        tf = self.cfg.timeframe
        snaps = con.execute(
            "SELECT snapshot_ref FROM snapshots WHERE timeframe=? ORDER BY created_utc DESC LIMIT 2;",
            (tf,),
        ).fetchall()
        if len(snaps) < 2:
            return {"status": "skipped", "reason": f"need_2_snapshots_{tf}"}
        b_ref = int(snaps[0][0]); a_ref = int(snaps[1][0])

        rows = con.execute(
            "SELECT a.unified_symbol, a.price, b.price "
            "FROM market_snapshots a JOIN market_snapshots b ON b.unified_symbol=a.unified_symbol "
            "WHERE a.snapshot_ref=? AND b.snapshot_ref=? AND a.timeframe=? AND b.timeframe=?;",
            (a_ref, b_ref, tf, tf),
        ).fetchall()

        now = utc_now_iso()
        n=0
        for sym, pa, pb in rows:
            if pa is None or pb is None:
                continue
            try:
                pa=float(pa); pb=float(pb)
                if pa<=0: 
                    continue
                accel_pct = (pb/pa - 1.0)*100.0
            except Exception:
                continue
            score = _clamp(50.0 + accel_pct * float(self.cfg.scale))
            upsert_layer_symbol_score(
                con, b_ref, tf, self.cfg.layer_name, str(sym),
                score, json.dumps({"accel_pct": accel_pct}, sort_keys=True), now
            )
            n += 1
        return {"status":"ok", "updated_symbols": n, "ref_a": a_ref, "ref_b": b_ref, "timeframe": tf}

from __future__ import annotations
import os, json, hashlib, sqlite3
from typing import Dict, Any, List, Tuple

STATE_FILE = ".export_state.json"  # legacy default

def _state_path(out_file: str) -> str:
    d = os.path.dirname(out_file) or "."
    import hashlib
    key = hashlib.md5(out_file.encode('utf-8', 'ignore')).hexdigest()[:12]
    return os.path.join(d, f".export_state_{key}.json")

def _load_state(out_file: str) -> Dict[str, Any]:
    p = _state_path(out_file)
    try:
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f) or {}
    except Exception:
        return {}

def _save_state(out_file: str, state: Dict[str, Any]) -> None:
    p = _state_path(out_file)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2)
    os.replace(tmp, p)

def registry_fingerprint(con: sqlite3.Connection, min_stage: int = 3, limit: int = 500) -> str:
    rows = con.execute(
        "SELECT unified_symbol, stage, COALESCE(composite_score,0), COALESCE(last_seen_utc,'') "
        "FROM expander_registry WHERE stage>=? "
        "ORDER BY stage DESC, COALESCE(composite_score,0) DESC, last_seen_utc DESC "
        "LIMIT ?;",
        (int(min_stage), int(limit)),
    ).fetchall()
    h = hashlib.sha256()
    for sym, st, sc, ls in rows:
        h.update(str(sym).encode("utf-8", "ignore"))
        h.update(b"|"); h.update(str(st).encode()); h.update(b"|")
        h.update(f"{float(sc):.6f}".encode()); h.update(b"|")
        h.update(str(ls).encode()); h.update(b"\n")
    return h.hexdigest()

def should_export(con: sqlite3.Connection, out_file: str, min_stage: int = 3, limit: int = 500) -> bool:
    state = _load_state(out_file)
    fp = registry_fingerprint(con, min_stage=min_stage, limit=limit)
    if state.get("fingerprint") == fp:
        return False
    state["fingerprint"] = fp
    _save_state(out_file, state)
    return True

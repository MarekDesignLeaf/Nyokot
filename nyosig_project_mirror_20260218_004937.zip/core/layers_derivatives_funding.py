# ASCII only
# Derivatives layer: Binance Futures funding rate proxy (public endpoint)

from __future__ import annotations

import json
import urllib.request


def fetch_binance_funding_rate(symbol_usdt: str, timeout_s: int = 10) -> float:
    # Endpoint returns lastFundingRate among other fields
    url = f'https://fapi.binance.com/fapi/v1/premiumIndex?symbol={symbol_usdt}'
    req = urllib.request.Request(url, headers={'User-Agent': 'NyoSig-Cryptolytix/1.0'})
    with urllib.request.urlopen(req, timeout=timeout_s) as r:
        raw = r.read().decode('utf-8', errors='strict')
    d = json.loads(raw)
    if not isinstance(d, dict) or 'lastFundingRate' not in d:
        raise RuntimeError('Unexpected response from Binance premiumIndex')
    return float(d['lastFundingRate'])


def to_binance_symbol(coin_symbol: str) -> str:
    # Conservative mapping: SYMBOL + USDT
    s = (coin_symbol or '').upper().strip()
    if not s:
        return ''
    # Common special cases
    if s == 'MATIC':
        return 'POLUSDT'  # Binance renamed, but still commonly POL. If this fails, caller should handle.
    return f'{s}USDT'


def score_from_funding_rate(fr: float) -> int:
    # fr around -0.01..0.01 typical. Map to 0..100 with 50 neutral.
    # Scale: 0.0001 -> 10 points shift.
    shift = int(fr * 100000)
    if shift < -50:
        shift = -50
    if shift > 50:
        shift = 50
    s = 50 + shift
    if s < 0:
        s = 0
    if s > 100:
        s = 100
    return int(s)

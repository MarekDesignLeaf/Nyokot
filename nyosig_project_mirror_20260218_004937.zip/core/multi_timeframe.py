from __future__ import annotations
from typing import Callable, List, Dict, Any
import sqlite3
import json

from .config import make_paths, parse_simple_yaml, parse_secrets_env
from .db import db_connect, require_schema, ensure_indexes, ensure_snapshot_schema
from .pipeline import run_snapshot_and_topnow
from .util_fs import ensure_dir

def run_multi_timeframe(
    project_root: str,
    app_version: str,
    scope_text: str,
    vs_currency: str,
    coins_limit: int,
    order: str,
    topnow_limit: int,
    offline_mode: bool,
    log_cb: Callable[[str], None],
    timeframes: List[str],
    do_selection: bool = True,
) -> List[Dict[str, Any]]:
    """Runs snapshot (and optional TopNow selection) for multiple timeframe labels.
    NOTE: These are labels; the caller/scheduler is responsible for actually invoking at the right cadence.
    """
    paths = make_paths(project_root)
    ensure_dir(paths.log_dir)
    ensure_dir(paths.cache_dir)

    out=[]
    for tf in timeframes:
        res = run_snapshot_and_topnow(
            project_root=project_root,
            app_version=app_version,
            scope_text=scope_text,
            vs_currency=vs_currency,
            coins_limit=coins_limit,
            order=order,
            topnow_limit=(topnow_limit if do_selection else 0),
            offline_mode=offline_mode,
            log_cb=log_cb,
            timeframe=tf,
        )
        out.append({"timeframe": tf, **res.__dict__})
    return out

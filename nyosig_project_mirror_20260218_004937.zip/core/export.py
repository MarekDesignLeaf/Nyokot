from __future__ import annotations
import csv
import os
import sqlite3
from typing import Optional
from .db import resolve_snapshot, table_columns

def export_selection_csv(con: sqlite3.Connection, selection_id: int, snapshot_id: str | int, timeframe: str, out_path: str) -> str:
    """
    Export selection items with latest market snapshot metrics and composite_preview to CSV.
    Returns out_path.
    """
    snap_ref, snap_key = resolve_snapshot(con, snapshot_id)
    cols = table_columns(con, 'market_snapshots')
    use_ref = (snap_ref is not None and 'snapshot_ref' in cols)

    q = (
        "SELECT i.rank_in_selection, i.unified_symbol, i.composite_preview, "
        "m.rank, m.mcap, m.vol24, m.change_24h_pct, m.price, m.timestamp_utc "
        "FROM topnow_selection_items i "
        "LEFT JOIN market_snapshots m "
        "ON m.snapshot_id=? AND m.timeframe=? AND m.unified_symbol=i.unified_symbol "
        "WHERE i.selection_id=? "
        "ORDER BY i.rank_in_selection ASC;"
    )
    rows = con.execute(q, (snapshot_id, timeframe, selection_id)).fetchall()
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["rank_in_selection","symbol","composite_preview","market_rank","mcap","vol24","chg24_pct","price","timestamp_utc"])
        for r in rows:
            w.writerow(list(r))
    return out_path

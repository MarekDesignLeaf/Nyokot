from __future__ import annotations
import sqlite3
from typing import Dict, Any
import json

from .layers_base import LayerAdapter, LayerContext, LayerResult
from .analysis import compute_and_store_spot_basic
from .db import upsert_layer_symbol_score
from .util_time import utc_now_iso

class SpotBasicLayer(LayerAdapter):
    layer_name = "spot_basic"
    layer_version = "v1"

    def run(self, con: sqlite3.Connection, ctx: LayerContext) -> LayerResult:
        try:
            n = compute_and_store_spot_basic(con, ctx.snapshot_ref, timeframe=ctx.timeframe)
            # Persist per-symbol scores from market_snapshots.base_score
            rows = con.execute(
                "SELECT unified_symbol, base_score FROM market_snapshots WHERE snapshot_ref=? AND timeframe=?;",
                (ctx.snapshot_ref, ctx.timeframe),
            ).fetchall()
            now = utc_now_iso()
            for sym, sc in rows:
                upsert_layer_symbol_score(con, ctx.snapshot_ref, ctx.timeframe, self.layer_name, sym, sc, None, now)
            return LayerResult(self.layer_name, self.layer_version, "ok", None, {"updated_rows": n})
        except Exception as e:
            return LayerResult(self.layer_name, self.layer_version, "failed", None, {"error": str(e)[:800]})

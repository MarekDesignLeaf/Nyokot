from __future__ import annotations
import json
import sqlite3
from typing import Dict, Any, Tuple
from .util_time import utc_now_iso

DEFAULT_RULES: Dict[str, Any] = {
    "stage0_min_score": 60.0,
    "stage1_min_score": 72.0,
    "stage2_min_score": 80.0,
    "stage3_min_score": 90.0,
    "demote_margin": 5.0,
    # acceleration gates (optional, MVP): if enabled, require positive accel_15m
    "use_accel_gate": 0,  # 0/1
    "accel_15m_min": 0.5, # percentage points
    # cross-timeframe confirmations
    "stage3_require_1h": 1,      # 0/1 require 1h composite confirm
    "stage3_1h_min_score": 70.0, # min composite on 1h for stage3
    "stage3_require_4h": 0,      # optional 4h confirm
    "stage3_4h_min_score": 65.0,
    # registry decay
    "decay_step_hours": 6.0,
    "decay_max_drop": 2,
    # scheduler hooks
    "auto_export_stage3": 0,
    "auto_export_min_stage": 3,
    "auto_export_format": "json",  # json|csv
    "auto_export_path": "exports/stage_export",
    "auto_alerts": 0,
    "auto_alert_min_to_stage": 2,
    "freeze_stage3_hours": 6.0,
    "log_rotate_max_mb": 10,
    "log_rotate_backups": 3,
    "export_rotate_max_mb": 5,
    "export_rotate_backups": 2,
    # auto retention (scheduler)
    "auto_retention": 1,
    "retention_keep": 300,
    "retention_global_keep": 0,
    # auto cleanup (scheduler)
    "auto_cleanup": 1,
    "cleanup_keep_days": 14,
    "cleanup_keep_last": 50,
    "export_only_on_change": 1,
}

def ensure_rules_schema(con: sqlite3.Connection) -> None:
    con.execute(
        "CREATE TABLE IF NOT EXISTS expander_rules ("
        " rule_key TEXT PRIMARY KEY,"
        " rule_value TEXT NOT NULL,"
        " rule_type TEXT NOT NULL DEFAULT 'float',"
        " updated_utc TEXT NOT NULL"
        ");"
    )
    con.execute("CREATE INDEX IF NOT EXISTS idx_expander_rules_updated ON expander_rules(updated_utc);")

def _coerce(val: str, typ: str) -> Any:
    if typ == "int":
        return int(float(val))
    if typ == "float":
        return float(val)
    if typ == "json":
        return json.loads(val)
    return val

def load_rules(con: sqlite3.Connection) -> Dict[str, Any]:
    ensure_rules_schema(con)
    rows = con.execute("SELECT rule_key, rule_value, rule_type FROM expander_rules;").fetchall()
    out = dict(DEFAULT_RULES)
    for k, v, t in rows:
        try:
            out[str(k)] = _coerce(str(v), str(t))
        except Exception:
            # keep default
            pass
    return out

def set_rule(con: sqlite3.Connection, key: str, value: Any, typ: str | None = None) -> None:
    ensure_rules_schema(con)
    if typ is None:
        if isinstance(value, int):
            typ = "int"
        elif isinstance(value, float):
            typ = "float"
        elif isinstance(value, (dict, list)):
            typ = "json"
        else:
            typ = "str"

    if typ == "json":
        v = json.dumps(value, sort_keys=True)
    else:
        v = str(value)

    con.execute(
        "INSERT INTO expander_rules(rule_key, rule_value, rule_type, updated_utc) VALUES (?,?,?,?) "
        "ON CONFLICT(rule_key) DO UPDATE SET rule_value=excluded.rule_value, rule_type=excluded.rule_type, updated_utc=excluded.updated_utc;",
        (key, v, typ, utc_now_iso()),
    )

def reset_rules(con: sqlite3.Connection) -> None:
    ensure_rules_schema(con)
    con.execute("DELETE FROM expander_rules;")
    for k, v in DEFAULT_RULES.items():
        set_rule(con, k, v)

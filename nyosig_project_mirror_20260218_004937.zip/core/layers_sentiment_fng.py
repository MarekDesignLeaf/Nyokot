# ASCII only
# Sentiment layer: Alternative.me Fear & Greed Index (public JSON)

from __future__ import annotations

import json
import time
import urllib.request


def fetch_fng_index(timeout_s: int = 10) -> dict:
    url = 'https://api.alternative.me/fng/?limit=1&format=json'
    req = urllib.request.Request(url, headers={'User-Agent': 'NyoSig-Cryptolytix/1.0'})
    with urllib.request.urlopen(req, timeout=timeout_s) as r:
        raw = r.read().decode('utf-8', errors='strict')
    data = json.loads(raw)
    if not isinstance(data, dict) or 'data' not in data or not data['data']:
        raise RuntimeError('Unexpected response from alternative.me')
    row = data['data'][0]
    value = int(row.get('value'))
    classification = str(row.get('value_classification', ''))
    ts = int(row.get('timestamp') or int(time.time()))
    return {
        'value': value,
        'classification': classification,
        'timestamp': ts,
        'source': 'alternative.me/fng'
    }


def score_from_fng_value(value: int) -> int:
    # FNG is already 0..100
    if value < 0:
        value = 0
    if value > 100:
        value = 100
    return int(value)

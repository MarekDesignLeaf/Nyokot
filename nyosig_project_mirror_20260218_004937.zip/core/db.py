from __future__ import annotations
import sqlite3
from typing import Iterable, List, Tuple

REQUIRED_TABLES = [
    "runs",
    "run_scope",
    "raw_snapshots",
    "market_snapshots",
    "topnow_selection",
    "topnow_selection_items",
    "state_log",
]

def db_connect(db_path: str) -> sqlite3.Connection:
    con = sqlite3.connect(db_path)
    con.execute("PRAGMA foreign_keys = ON;")
    return con

def table_columns(con: sqlite3.Connection, table: str) -> List[str]:
    cur = con.execute(f"PRAGMA table_info({table});")
    return [r[1] for r in cur.fetchall()]

def ensure_column(con: sqlite3.Connection, table: str, column_def_sql: str) -> None:
    # column_def_sql example: 'snapshot_id TEXT'
    col = column_def_sql.split()[0]
    cols = table_columns(con, table)
    if col not in cols:
        con.execute(f"ALTER TABLE {table} ADD COLUMN {column_def_sql};")

def db_table_exists(con: sqlite3.Connection, name: str) -> bool:
    cur = con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?;", (name,))
    return cur.fetchone() is not None

def require_schema(con: sqlite3.Connection, required_tables: List[str] | None = None) -> None:
    """Validate required tables exist.
    Also performs idempotent healing (ADD COLUMN) for evolving schema.
    """
    # Always run idempotent schema creation / healing.
    try:
        ensure_core_schema(con)
        ensure_core_indexes(con)
        # ensure snapshot_ref columns exist where newer code expects them
        if db_table_exists(con, 'market_snapshots'):
            ensure_column(con, 'market_snapshots', 'snapshot_ref INTEGER')
        if db_table_exists(con, 'raw_snapshots'):
            ensure_column(con, 'raw_snapshots', 'snapshot_ref INTEGER')
        # snapshots schema is safe to call repeatedly
        ensure_snapshot_schema(con)
        con.commit()
    except Exception:
        # Never block validation on healing; fall back to validation-only.
        pass

    req = required_tables or REQUIRED_TABLES
    missing = [t for t in req if not db_table_exists(con, t)]
    if missing:
        raise RuntimeError("Missing required tables: " + ", ".join(missing))



def ensure_core_schema(con: sqlite3.Connection) -> None:
    """Create (or extend) core tables so GUI works without manual DB deletion."""
    # runs: must include columns used by create_run/set_run_status
    con.execute(
        "CREATE TABLE IF NOT EXISTS runs ("
        " run_id INTEGER PRIMARY KEY AUTOINCREMENT,"
        " created_utc TEXT NOT NULL,"
        " app_version TEXT,"
        " status TEXT,"
        " vs_currency TEXT,"
        " coins_limit INTEGER,"
        " timeframes_json TEXT,"
        " sort_mode TEXT,"
        " source TEXT,"
        " params_json TEXT,"
        " note TEXT"
        ");"
    )
    # If runs existed from older version, add missing columns
    for coldef in [
        "app_version TEXT", "status TEXT", "vs_currency TEXT", "coins_limit INTEGER",
        "timeframes_json TEXT", "sort_mode TEXT", "source TEXT", "params_json TEXT", "note TEXT"
    ]:
        ensure_column(con, "runs", coldef)

    con.execute(
        "CREATE TABLE IF NOT EXISTS run_scope ("
        " run_id INTEGER PRIMARY KEY,"
        " scope TEXT NOT NULL,"
        " created_utc TEXT,"
        " FOREIGN KEY(run_id) REFERENCES runs(run_id)"
        ");"
    )
    for coldef in ["created_utc TEXT"]:
        ensure_column(con, "run_scope", coldef)

    con.execute(
        "CREATE TABLE IF NOT EXISTS raw_snapshots ("
        " raw_id INTEGER PRIMARY KEY AUTOINCREMENT,"
        " run_id INTEGER NOT NULL,"
        " source TEXT NOT NULL,"
        " endpoint TEXT NOT NULL,"
        " query_json TEXT,"
        " response_json TEXT,"
        " fetched_utc TEXT NOT NULL,"
        " snapshot_key TEXT,"
        " snapshot_ref INTEGER,"
        " FOREIGN KEY(run_id) REFERENCES runs(run_id)"
        ");"
    )
    for coldef in ["snapshot_key TEXT", "snapshot_ref INTEGER"]:
        ensure_column(con, "raw_snapshots", coldef)

    con.execute(
        "CREATE TABLE IF NOT EXISTS market_snapshots ("
        " snapshot_id TEXT,"
        " snapshot_ref INTEGER,"
        " run_id INTEGER NOT NULL,"
        " timestamp_utc TEXT,"
        " scope TEXT,"
        " timeframe TEXT,"
        " unified_symbol TEXT,"
        " pair TEXT,"
        " price REAL,"
        " change_24h_pct REAL,"
        " vol24 REAL,"
        " mcap REAL,"
        " rank INTEGER,"
        " base_score REAL,"
        " source TEXT,"
        " FOREIGN KEY(run_id) REFERENCES runs(run_id)"
        ");"
    )
    # Ensure snapshot_ref exists for modern queries
    ensure_column(con, "market_snapshots", "snapshot_ref INTEGER")

    con.execute(
        "CREATE TABLE IF NOT EXISTS topnow_selection ("
        " selection_id INTEGER PRIMARY KEY AUTOINCREMENT,"
        " run_id INTEGER,"
        " snapshot_id TEXT,"
        " snapshot_ref INTEGER,"
        " params_json TEXT,"
        " created_utc TEXT"
        ");"
    )
    for coldef in ["run_id INTEGER", "snapshot_ref INTEGER", "params_json TEXT", "created_utc TEXT"]:
        ensure_column(con, "topnow_selection", coldef)

    con.execute(
        "CREATE TABLE IF NOT EXISTS topnow_selection_items ("
        " selection_id INTEGER NOT NULL,"
        " unified_symbol TEXT NOT NULL,"
        " score REAL,"
        " reason_json TEXT,"
        " PRIMARY KEY(selection_id, unified_symbol),"
        " FOREIGN KEY(selection_id) REFERENCES topnow_selection(selection_id)"
        ");"
    )
    for coldef in ["score REAL", "reason_json TEXT", "rank_in_selection INTEGER", "composite_preview REAL"]:
        ensure_column(con, "topnow_selection_items", coldef)

    con.execute(
        "CREATE TABLE IF NOT EXISTS state_log ("
        " state_log_id INTEGER PRIMARY KEY AUTOINCREMENT,"
        " run_id INTEGER NOT NULL,"
        " from_status TEXT,"
        " to_status TEXT,"
        " severity TEXT,"
        " message TEXT NOT NULL,"
        " timestamp_utc TEXT NOT NULL,"
        " FOREIGN KEY(run_id) REFERENCES runs(run_id)"
        ");"
    )
    for coldef in ["from_status TEXT", "to_status TEXT", "severity TEXT", "message TEXT", "timestamp_utc TEXT"]:
        ensure_column(con, "state_log", coldef)

def ensure_core_indexes(con: sqlite3.Connection) -> None:
    con.execute("CREATE INDEX IF NOT EXISTS idx_raw_snapshots_run ON raw_snapshots(run_id);")
    con.execute("CREATE INDEX IF NOT EXISTS idx_market_snapshots_ref ON market_snapshots(snapshot_ref);")
    con.execute("CREATE INDEX IF NOT EXISTS idx_market_snapshots_symbol ON market_snapshots(unified_symbol);")
    con.execute("CREATE INDEX IF NOT EXISTS idx_topnow_selection_ref ON topnow_selection(snapshot_ref);")

def ensure_snapshot_schema(con: sqlite3.Connection) -> None:
    # Ensure core tables exist first (runs etc.)
    ensure_core_schema(con)
    ensure_core_indexes(con)

    # If an older 'snapshots' table exists without snapshot_ref, migrate it once.
    if db_table_exists(con, "snapshots"):
        cols = table_columns(con, "snapshots")
        if "snapshot_ref" not in cols:
            # Preserve legacy data, create new table with proper PK, then backfill refs.
            con.execute("ALTER TABLE snapshots RENAME TO snapshots_legacy;")

            con.execute(
                "CREATE TABLE IF NOT EXISTS snapshots ("
                " snapshot_ref INTEGER PRIMARY KEY AUTOINCREMENT,"
                " snapshot_key TEXT UNIQUE NOT NULL,"
                " run_id INTEGER,"
                " created_utc TEXT,"
                " source TEXT,"
                " scope TEXT,"
                " timeframe TEXT,"
                " meta_json TEXT,"
                " parent_snapshot_ref INTEGER,"
                " refresh_reason TEXT"
                ");"
            )

            legacy_cols = table_columns(con, "snapshots_legacy")
            # pick best-effort column names from legacy
            key_col = "snapshot_key" if "snapshot_key" in legacy_cols else ("snapshot_id" if "snapshot_id" in legacy_cols else None)
            created_col = "created_utc" if "created_utc" in legacy_cols else ("timestamp_utc" if "timestamp_utc" in legacy_cols else None)
            source_col = "source" if "source" in legacy_cols else None
            scope_col = "scope" if "scope" in legacy_cols else None
            timeframe_col = "timeframe" if "timeframe" in legacy_cols else None
            meta_col = "meta_json" if "meta_json" in legacy_cols else None
            runid_col = "run_id" if "run_id" in legacy_cols else None

            if key_col is not None:
                sel_parts = [f"{key_col} AS snapshot_key"]
                if runid_col: sel_parts.append(f"{runid_col} AS run_id")
                else: sel_parts.append("NULL AS run_id")
                if created_col: sel_parts.append(f"{created_col} AS created_utc")
                else: sel_parts.append("NULL AS created_utc")
                if source_col: sel_parts.append(f"{source_col} AS source")
                else: sel_parts.append("NULL AS source")
                if scope_col: sel_parts.append(f"{scope_col} AS scope")
                else: sel_parts.append("NULL AS scope")
                if timeframe_col: sel_parts.append(f"{timeframe_col} AS timeframe")
                else: sel_parts.append("NULL AS timeframe")
                if meta_col: sel_parts.append(f"{meta_col} AS meta_json")
                else: sel_parts.append("NULL AS meta_json")

                con.execute(
                    "INSERT OR IGNORE INTO snapshots (snapshot_key, run_id, created_utc, source, scope, timeframe, meta_json) "
                    "SELECT " + ", ".join(sel_parts) + " FROM snapshots_legacy;"
                )

            # Backfill snapshot_ref into newer tables if they have the column
            if db_table_exists(con, "market_snapshots") and "snapshot_ref" in table_columns(con, "market_snapshots"):
                con.execute(
                    "UPDATE market_snapshots "
                    "SET snapshot_ref = (SELECT s.snapshot_ref FROM snapshots s WHERE s.snapshot_key = market_snapshots.snapshot_id) "
                    "WHERE snapshot_ref IS NULL AND snapshot_id IS NOT NULL;"
                )
            if db_table_exists(con, "raw_snapshots") and "snapshot_ref" in table_columns(con, "raw_snapshots"):
                # raw_snapshots may have snapshot_key
                if "snapshot_key" in table_columns(con, "raw_snapshots"):
                    con.execute(
                        "UPDATE raw_snapshots "
                        "SET snapshot_ref = (SELECT s.snapshot_ref FROM snapshots s WHERE s.snapshot_key = raw_snapshots.snapshot_key) "
                        "WHERE snapshot_ref IS NULL AND snapshot_key IS NOT NULL;"
                    )

            # keep legacy table for inspection; it can be deleted manually later
            con.commit()

    # Create snapshots with correct parent_snapshot_ref column BEFORE FK (idempotent for new installs)
    con.execute(
        "CREATE TABLE IF NOT EXISTS snapshots ("
        " snapshot_ref INTEGER PRIMARY KEY AUTOINCREMENT,"
        " snapshot_key TEXT UNIQUE NOT NULL,"
        " run_id INTEGER NOT NULL,"
        " created_utc TEXT NOT NULL,"
        " source TEXT NOT NULL,"
        " scope TEXT,"
        " timeframe TEXT,"
        " meta_json TEXT,"
        " parent_snapshot_ref INTEGER,"
        " refresh_reason TEXT,"
        " FOREIGN KEY(run_id) REFERENCES runs(run_id),"
        " FOREIGN KEY(parent_snapshot_ref) REFERENCES snapshots(snapshot_ref)"
        ");"
    )
    # Ensure lineage columns exist for older DBs (safe even if migration ran)
    ensure_column(con, "snapshots", "parent_snapshot_ref INTEGER")
    ensure_column(con, "snapshots", "refresh_reason TEXT")

    # Link raw snapshots to snapshot_key/ref for traceability
    if db_table_exists(con, "raw_snapshots"):
        ensure_column(con, "raw_snapshots", "snapshot_key TEXT")
        ensure_column(con, "raw_snapshots", "snapshot_ref INTEGER")

    # Add snapshot_ref columns to other tables; DO NOT run backfill queries that can fail on legacy schemas here
    if db_table_exists(con, "market_snapshots"):
        ensure_column(con, "market_snapshots", "snapshot_ref INTEGER")
    if db_table_exists(con, "topnow_selection"):
        ensure_column(con, "topnow_selection", "snapshot_ref INTEGER")

    ensure_layer_schema(con)


    # Create snapshots with correct parent_snapshot_ref column BEFORE FK
    con.execute(
        "CREATE TABLE IF NOT EXISTS snapshots ("
        " snapshot_ref INTEGER PRIMARY KEY AUTOINCREMENT,"
        " snapshot_key TEXT UNIQUE NOT NULL,"
        " run_id INTEGER NOT NULL,"
        " created_utc TEXT NOT NULL,"
        " source TEXT NOT NULL,"
        " scope TEXT,"
        " timeframe TEXT,"
        " meta_json TEXT,"
        " parent_snapshot_ref INTEGER,"
        " refresh_reason TEXT,"
        " FOREIGN KEY(run_id) REFERENCES runs(run_id),"
        " FOREIGN KEY(parent_snapshot_ref) REFERENCES snapshots(snapshot_ref)"
        ");"
    )
    # Ensure lineage columns exist for older DBs
    ensure_column(con, "snapshots", "parent_snapshot_ref INTEGER")
    ensure_column(con, "snapshots", "refresh_reason TEXT")

    # Link raw snapshots to snapshot_key/ref for traceability
    if db_table_exists(con, "raw_snapshots"):
        ensure_column(con, "raw_snapshots", "snapshot_key TEXT")
        ensure_column(con, "raw_snapshots", "snapshot_ref INTEGER")

    ensure_snapshot_ref_links(con)
    ensure_layer_schema(con)

def create_snapshot(con: sqlite3.Connection, snapshot_key: str, run_id: int, created_utc: str,
                    source: str, scope: str, timeframe: str, meta_json: str | None = None,
                    parent_snapshot_ref: int | None = None, refresh_reason: str | None = None) -> int:
    con.execute(
        "INSERT OR IGNORE INTO snapshots(snapshot_key, run_id, created_utc, source, scope, timeframe, parent_snapshot_ref, refresh_reason, meta_json) "
        "VALUES (?,?,?,?,?,?,?,?,?);",
        (snapshot_key, run_id, created_utc, source, scope, timeframe, parent_snapshot_ref, refresh_reason, meta_json),
    )
    row = con.execute("SELECT snapshot_ref FROM snapshots WHERE snapshot_key=?;", (snapshot_key,)).fetchone()
    return int(row[0]) if row else 0


def ensure_indexes(con: sqlite3.Connection) -> None:
    # Safe, idempotent indexes for common queries
    con.execute("CREATE INDEX IF NOT EXISTS idx_market_snapshots_snapshot_timeframe ON market_snapshots(snapshot_id, timeframe);")
    con.execute("CREATE INDEX IF NOT EXISTS idx_market_snapshots_rank ON market_snapshots(rank);")
    con.execute("CREATE INDEX IF NOT EXISTS idx_market_snapshots_mcap ON market_snapshots(mcap);")

def state_log(
    con: sqlite3.Connection,
    run_id: int,
    from_status: str,
    to_status: str,
    severity: str,
    message: str,
    timestamp_utc: str,
    step_name: str = "pipeline",
) -> None:
    """Insert a state_log row.

    The project has seen multiple schema variants for state_log.
    Some versions include NOT NULL columns like step_name and status.
    This function adapts to the actual columns present in the DB.
    """
    step = (step_name or "").strip() or "pipeline"

    cols = set(table_columns(con, "state_log"))

    fields = ["run_id"]
    values = [int(run_id)]

    if "step_name" in cols:
        fields.append("step_name")
        values.append(step)

    # Legacy schema had `status` NOT NULL. Use `to_status` as the most relevant status.
    if "status" in cols:
        fields.append("status")
        values.append(to_status)

    if "from_status" in cols:
        fields.append("from_status")
        values.append(from_status)

    if "to_status" in cols:
        fields.append("to_status")
        values.append(to_status)

    if "severity" in cols:
        fields.append("severity")
        values.append(severity)

    if "message" in cols:
        fields.append("message")
        values.append(message)

    if "timestamp_utc" in cols:
        fields.append("timestamp_utc")
        values.append(timestamp_utc)

    placeholders = ",".join(["?"] * len(fields))
    sql = f"INSERT INTO state_log({', '.join(fields)}) VALUES ({placeholders});"
    con.execute(sql, tuple(values))


def set_run_status(con: sqlite3.Connection, run_id: int, status: str) -> None:
    con.execute("UPDATE runs SET status=? WHERE run_id=?;", (status, run_id))

def create_run(con: sqlite3.Connection, created_utc: str, app_version: str, status: str, vs_currency: str, coins_limit: int,
               timeframes: list, sort_mode: str, source: str, params: dict) -> int:
    import json
    con.execute(
        "INSERT INTO runs(created_utc, app_version, status, vs_currency, coins_limit, timeframes_json, sort_mode, source, params_json) "
        "VALUES (?,?,?,?,?,?,?,?,?);",
        (created_utc, app_version, status, vs_currency, coins_limit, json.dumps(timeframes), sort_mode, source, json.dumps(params)),
    )
    return con.execute("SELECT last_insert_rowid();").fetchone()[0]

def upsert_run_scope(con: sqlite3.Connection, run_id: int, scope_text: str) -> None:
    con.execute("INSERT OR REPLACE INTO run_scope(run_id, scope) VALUES (?,?);", (run_id, scope_text))

def insert_raw_snapshot(con: sqlite3.Connection, run_id: int, source: str, endpoint: str, query_json: str, response_json: str, fetched_utc: str, snapshot_key: str | None = None, snapshot_ref: int | None = None) -> None:
    # snapshot_key/ref optional for backward compatibility
    if 'snapshot_key' in table_columns(con, 'raw_snapshots'):
        con.execute(
            "INSERT INTO raw_snapshots(run_id, source, endpoint, query_json, response_json, fetched_utc, snapshot_key, snapshot_ref) VALUES (?,?,?,?,?,?,?,?);",
            (run_id, source, endpoint, query_json, response_json, fetched_utc, snapshot_key, snapshot_ref),
        )
    else:
        con.execute(
        "INSERT INTO raw_snapshots(run_id, source, endpoint, query_json, response_json, fetched_utc) VALUES (?,?,?,?,?,?);",
        (run_id, source, endpoint, query_json, response_json, fetched_utc),
    )

def insert_market_snapshots(con: sqlite3.Connection, rows: Iterable[Tuple]) -> None:
    # rows may include snapshot_ref as last field after snapshot_id depending on caller
    cols = table_columns(con, 'market_snapshots')
    if 'snapshot_ref' in cols:
        con.executemany(
            "INSERT OR IGNORE INTO market_snapshots(snapshot_id, snapshot_ref, run_id, timestamp_utc, scope, timeframe, unified_symbol, pair, price, change_24h_pct, vol24, mcap, rank, base_score, source) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);",
            rows,
        )
    else:
        con.executemany(
            "INSERT OR IGNORE INTO market_snapshots(snapshot_id, run_id, timestamp_utc, scope, timeframe, unified_symbol, pair, price, change_24h_pct, vol24, mcap, rank, base_score, source) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?);",
            rows,
        )

def select_candidates(con: sqlite3.Connection, snapshot_id: str | int, timeframe: str, limit_n: int):
    snap_ref, snap_key = resolve_snapshot(con, snapshot_id)
    cols = table_columns(con, 'market_snapshots')
    if snap_ref is not None and 'snapshot_ref' in cols:
        cur = con.execute(
            "SELECT unified_symbol, rank, mcap, vol24, change_24h_pct "
            "FROM market_snapshots "
            "WHERE snapshot_ref=? AND timeframe=? "
            "ORDER BY CASE WHEN rank IS NULL THEN 1 ELSE 0 END, rank ASC, "
            "CASE WHEN mcap IS NULL THEN 1 ELSE 0 END, mcap DESC "
            "LIMIT ?;",
            (snap_ref, timeframe, int(limit_n)),
        )
        return cur.fetchall()
    if snap_key is None:
        snap_key = str(snapshot_id)
    cur = con.execute(
        "SELECT unified_symbol, rank, mcap, vol24, change_24h_pct "
        "FROM market_snapshots "
        "WHERE snapshot_id=? AND timeframe=? "
        "ORDER BY CASE WHEN rank IS NULL THEN 1 ELSE 0 END, rank ASC, "
        "CASE WHEN mcap IS NULL THEN 1 ELSE 0 END, mcap DESC "
        "LIMIT ?;",
        (snap_key, timeframe, int(limit_n)),
    )
    return cur.fetchall()

def create_topnow_selection(con: sqlite3.Connection, run_id: int, snapshot_id: str | int, params_json: dict) -> int:
    import json
    snap_ref, snap_key = resolve_snapshot(con, snapshot_id)
    cols = table_columns(con, 'topnow_selection')
    if snap_key is None:
        snap_key = str(snapshot_id)
    if 'snapshot_ref' in cols:
        con.execute(
            "INSERT INTO topnow_selection(run_id, snapshot_id, snapshot_ref, params_json) VALUES (?,?,?,?);",
            (run_id, snap_key, snap_ref, json.dumps(params_json, sort_keys=True)),
        )
    else:
        con.execute(
            "INSERT INTO topnow_selection(run_id, snapshot_id, params_json) VALUES (?,?,?);",
            (run_id, snap_key, json.dumps(params_json, sort_keys=True)),
        )
    return con.execute("SELECT last_insert_rowid();").fetchone()[0]

def insert_topnow_items(con: sqlite3.Connection, selection_id: int, candidates) -> int:
    items = []
    for i, row in enumerate(candidates, start=1):
        items.append((selection_id, row[0], i, None))
    con.executemany(
        "INSERT OR REPLACE INTO topnow_selection_items(selection_id, unified_symbol, rank_in_selection, composite_preview) VALUES (?,?,?,?);",
        items,
    )
    return len(items)


def get_snapshot_ref(con: sqlite3.Connection, snapshot_key: str) -> int | None:
    row = con.execute("SELECT snapshot_ref FROM snapshots WHERE snapshot_key=?;", (snapshot_key,)).fetchone()
    return int(row[0]) if row else None


def resolve_snapshot(con: sqlite3.Connection, snapshot_identifier: str | int) -> tuple[int | None, str | None]:
    """Resolve snapshot_identifier (snapshot_key or snapshot_ref) to (snapshot_ref, snapshot_key).

    Supports legacy snapshots tables that may not have snapshot_ref (will return (None, key)).
    """
    if not db_table_exists(con, "snapshots"):
        return None, None
    cols = table_columns(con, "snapshots")
    has_ref = "snapshot_ref" in cols
    has_key = "snapshot_key" in cols or "snapshot_id" in cols

    # helper to fetch key by ref
    def _key_by_ref(ref: int) -> str | None:
        if not has_ref:
            return None
        row = con.execute("SELECT snapshot_key FROM snapshots WHERE snapshot_ref=?;", (ref,)).fetchone()
        return (row[0] if row else None)

    if isinstance(snapshot_identifier, int):
        ref = snapshot_identifier
        return (ref if has_ref else None), _key_by_ref(ref)

    s = str(snapshot_identifier).strip()
    if has_ref and s.isdigit():
        ref = int(s)
        return ref, _key_by_ref(ref)

    # treat as key
    key = s
    if "snapshot_key" in cols:
        row = con.execute("SELECT snapshot_ref, snapshot_key FROM snapshots WHERE snapshot_key=?;", (key,)).fetchone() if has_ref else               con.execute("SELECT snapshot_key FROM snapshots WHERE snapshot_key=?;", (key,)).fetchone()
        if not row:
            return None, None
        if has_ref:
            return int(row[0]), str(row[1])
        return None, str(row[0])
    if "snapshot_id" in cols:
        # legacy key column name
        row = con.execute("SELECT snapshot_id FROM snapshots WHERE snapshot_id=?;", (key,)).fetchone()
        return None, (str(row[0]) if row else None)

    return None, None


def ensure_snapshot_ref_links(con: sqlite3.Connection) -> None:
    """Ensure snapshot_ref columns exist. Backfills are handled by migration in ensure_snapshot_schema."""
    if db_table_exists(con, "market_snapshots"):
        ensure_column(con, "market_snapshots", "snapshot_ref INTEGER")
    if db_table_exists(con, "raw_snapshots"):
        ensure_column(con, "raw_snapshots", "snapshot_ref INTEGER")
    if db_table_exists(con, "topnow_selection"):
        ensure_column(con, "topnow_selection", "snapshot_ref INTEGER")


    # topnow_selection
    if db_table_exists(con, "topnow_selection"):
        ensure_column(con, "topnow_selection", "snapshot_ref INTEGER")
        con.execute(
            "UPDATE topnow_selection SET snapshot_ref = (SELECT snapshot_ref FROM snapshots s WHERE s.snapshot_key = topnow_selection.snapshot_id) "
            "WHERE snapshot_ref IS NULL AND snapshot_id IS NOT NULL;"
        )
        con.execute("CREATE INDEX IF NOT EXISTS idx_topnow_selection_snapshotref ON topnow_selection(snapshot_ref);")


def ensure_layer_schema(con: sqlite3.Connection) -> None:
    con.execute(
        "CREATE TABLE IF NOT EXISTS version_registry ("
        " version TEXT PRIMARY KEY,"
        " sha256 TEXT NOT NULL,"
        " created_utc TEXT NOT NULL,"
        " notes TEXT DEFAULT ''"
        ");"
    )
    con.execute(
        "CREATE TABLE IF NOT EXISTS layer_results ("
        " layer_result_id INTEGER PRIMARY KEY AUTOINCREMENT,"
        " run_id INTEGER NOT NULL,"
        " snapshot_ref INTEGER NOT NULL,"
        " timeframe TEXT NOT NULL,"
        " layer_name TEXT NOT NULL,"
        " layer_version TEXT NOT NULL DEFAULT 'v1',"
        " status TEXT NOT NULL,"
        " score REAL,"
        " weight REAL,"
        " raw_json TEXT,"
        " created_utc TEXT NOT NULL,"
        " UNIQUE(run_id, snapshot_ref, timeframe, layer_name),"
        " FOREIGN KEY(run_id) REFERENCES runs(run_id),"
        " FOREIGN KEY(snapshot_ref) REFERENCES snapshots(snapshot_ref)"
        ");"
    )
    # Heal legacy layer_results missing columns (SQLite CREATE TABLE IF NOT EXISTS does not upgrade)
    ensure_column(con, "layer_results", "snapshot_ref INTEGER")
    ensure_column(con, "layer_results", "timeframe TEXT")
    ensure_column(con, "layer_results", "layer_name TEXT")
    ensure_column(con, "layer_results", "layer_version TEXT")
    ensure_column(con, "layer_results", "status TEXT")
    ensure_column(con, "layer_results", "score REAL")
    ensure_column(con, "layer_results", "weight REAL")
    ensure_column(con, "layer_results", "raw_json TEXT")
    ensure_column(con, "layer_results", "created_utc TEXT")
    con.execute("CREATE INDEX IF NOT EXISTS idx_layer_results_run_snapshot ON layer_results(run_id, snapshot_ref);")
    con.execute("CREATE INDEX IF NOT EXISTS idx_layer_results_snapshot_layer ON layer_results(snapshot_ref, layer_name);")

    con.execute(
        "CREATE TABLE IF NOT EXISTS expanders ("
        " expander_id INTEGER PRIMARY KEY AUTOINCREMENT,"
        " snapshot_ref INTEGER NOT NULL,"
        " unified_symbol TEXT NOT NULL,"
        " stage INTEGER NOT NULL DEFAULT 0,"
        " composite_score REAL,"
        " reasons_json TEXT,"
        " created_utc TEXT NOT NULL,"
        " updated_utc TEXT NOT NULL,"
        " UNIQUE(snapshot_ref, unified_symbol),"
        " FOREIGN KEY(snapshot_ref) REFERENCES snapshots(snapshot_ref)"
        ");"
    )
    con.execute("CREATE INDEX IF NOT EXISTS idx_expanders_stage ON expanders(stage);")
    con.execute("CREATE INDEX IF NOT EXISTS idx_expanders_snapshot ON expanders(snapshot_ref);")
    ensure_symbol_score_schema(con)
    ensure_expander_lifecycle_schema(con)
    ensure_rules_schema(con)
    ensure_expander_registry_schema(con)

def upsert_version_registry(con: sqlite3.Connection, version: str, sha256: str, created_utc: str, notes: str = "") -> None:
    con.execute(
        "INSERT OR REPLACE INTO version_registry(version, sha256, created_utc, notes) VALUES (?,?,?,?);",
        (version, sha256, created_utc, notes),
    )

def get_version_sha(con: sqlite3.Connection, version: str) -> str | None:
    row = con.execute("SELECT sha256 FROM version_registry WHERE version=?;", (version,)).fetchone()
    return row[0] if row else None

def upsert_layer_result(con: sqlite3.Connection, run_id: int, snapshot_ref: int, timeframe: str, layer_name: str,
                        layer_version: str, status: str, score: float | None, weight: float | None, raw_json: str | None, created_utc: str) -> None:
    con.execute(
        "INSERT OR REPLACE INTO layer_results(run_id, snapshot_ref, timeframe, layer_name, layer_version, status, score, weight, raw_json, created_utc) "
        "VALUES (?,?,?,?,?,?,?,?,?,?);",
        (run_id, snapshot_ref, timeframe, layer_name, layer_version, status, score, weight, raw_json, created_utc),
    )

def upsert_expander(con: sqlite3.Connection, snapshot_ref: int, unified_symbol: str, stage: int,
                    composite_score: float | None, reasons_json: str | None, created_utc: str, updated_utc: str) -> None:
    con.execute(
        "INSERT INTO expanders(snapshot_ref, unified_symbol, stage, composite_score, reasons_json, created_utc, updated_utc) "
        "VALUES (?,?,?,?,?,?,?) "
        "ON CONFLICT(snapshot_ref, unified_symbol) DO UPDATE SET "
        " stage=excluded.stage, composite_score=excluded.composite_score, reasons_json=excluded.reasons_json, updated_utc=excluded.updated_utc;",
        (snapshot_ref, unified_symbol, int(stage), composite_score, reasons_json, created_utc, updated_utc),
    )


def ensure_symbol_score_schema(con: sqlite3.Connection) -> None:
    con.execute(
        "CREATE TABLE IF NOT EXISTS layer_symbol_scores ("
        " layer_symbol_score_id INTEGER PRIMARY KEY AUTOINCREMENT,"
        " snapshot_ref INTEGER NOT NULL,"
        " timeframe TEXT NOT NULL,"
        " layer_name TEXT NOT NULL,"
        " unified_symbol TEXT NOT NULL,"
        " score REAL,"
        " raw_json TEXT,"
        " created_utc TEXT NOT NULL,"
        " UNIQUE(snapshot_ref, timeframe, layer_name, unified_symbol),"
        " FOREIGN KEY(snapshot_ref) REFERENCES snapshots(snapshot_ref)"
        ");"
    )
    con.execute("CREATE INDEX IF NOT EXISTS idx_layer_symbol_scores_snapshot_layer ON layer_symbol_scores(snapshot_ref, layer_name, timeframe);")
    con.execute("CREATE INDEX IF NOT EXISTS idx_layer_symbol_scores_symbol ON layer_symbol_scores(unified_symbol);")

    con.execute(
        "CREATE TABLE IF NOT EXISTS composite_symbol_scores ("
        " composite_symbol_score_id INTEGER PRIMARY KEY AUTOINCREMENT,"
        " snapshot_ref INTEGER NOT NULL,"
        " timeframe TEXT NOT NULL,"
        " unified_symbol TEXT NOT NULL,"
        " composite_score REAL NOT NULL,"
        " meta_json TEXT,"
        " created_utc TEXT NOT NULL,"
        " UNIQUE(snapshot_ref, timeframe, unified_symbol),"
        " FOREIGN KEY(snapshot_ref) REFERENCES snapshots(snapshot_ref)"
        ");"
    )
    con.execute("CREATE INDEX IF NOT EXISTS idx_composite_symbol_scores_snapshot ON composite_symbol_scores(snapshot_ref, timeframe);")
    con.execute("CREATE INDEX IF NOT EXISTS idx_composite_symbol_scores_score ON composite_symbol_scores(composite_score);")

def upsert_layer_symbol_score(con: sqlite3.Connection, snapshot_ref: int, timeframe: str, layer_name: str, unified_symbol: str,
                             score: float | None, raw_json: str | None, created_utc: str) -> None:
    con.execute(
        "INSERT INTO layer_symbol_scores(snapshot_ref, timeframe, layer_name, unified_symbol, score, raw_json, created_utc) "
        "VALUES (?,?,?,?,?,?,?) "
        "ON CONFLICT(snapshot_ref, timeframe, layer_name, unified_symbol) DO UPDATE SET "
        " score=excluded.score, raw_json=excluded.raw_json, created_utc=excluded.created_utc;",
        (snapshot_ref, timeframe, layer_name, unified_symbol, score, raw_json, created_utc),
    )

def upsert_composite_symbol_score(con: sqlite3.Connection, snapshot_ref: int, timeframe: str, unified_symbol: str,
                                 composite_score: float, meta_json: str | None, created_utc: str) -> None:
    con.execute(
        "INSERT INTO composite_symbol_scores(snapshot_ref, timeframe, unified_symbol, composite_score, meta_json, created_utc) "
        "VALUES (?,?,?,?,?,?) "
        "ON CONFLICT(snapshot_ref, timeframe, unified_symbol) DO UPDATE SET "
        " composite_score=excluded.composite_score, meta_json=excluded.meta_json, created_utc=excluded.created_utc;",
        (snapshot_ref, timeframe, unified_symbol, float(composite_score), meta_json, created_utc),
    )


def ensure_expander_lifecycle_schema(con: sqlite3.Connection) -> None:
    con.execute(
        "CREATE TABLE IF NOT EXISTS expander_events ("
        " expander_event_id INTEGER PRIMARY KEY AUTOINCREMENT,"
        " snapshot_ref INTEGER NOT NULL,"
        " unified_symbol TEXT NOT NULL,"
        " from_stage INTEGER,"
        " to_stage INTEGER NOT NULL,"
        " score REAL,"
        " reason_json TEXT,"
        " created_utc TEXT NOT NULL,"
        " FOREIGN KEY(snapshot_ref) REFERENCES snapshots(snapshot_ref)"
        ");"
    )
    con.execute("CREATE INDEX IF NOT EXISTS idx_expander_events_symbol ON expander_events(unified_symbol);")
    con.execute("CREATE INDEX IF NOT EXISTS idx_expander_events_snapshot ON expander_events(snapshot_ref);")

    # Add lifecycle timestamps to expanders table
    if db_table_exists(con, "expanders"):
        ensure_column(con, "expanders", "first_seen_utc TEXT")
        ensure_column(con, "expanders", "last_seen_utc TEXT")

def insert_expander_event(con: sqlite3.Connection, snapshot_ref: int, unified_symbol: str, from_stage: int | None, to_stage: int,
                         score: float | None, reason_json: str | None, created_utc: str) -> None:
    con.execute(
        "INSERT INTO expander_events(snapshot_ref, unified_symbol, from_stage, to_stage, score, reason_json, created_utc) "
        "VALUES (?,?,?,?,?,?,?);",
        (snapshot_ref, unified_symbol, from_stage, int(to_stage), score, reason_json, created_utc),
    )


def ensure_rules_schema(con: sqlite3.Connection) -> None:
    con.execute(
        "CREATE TABLE IF NOT EXISTS expander_rules ("
        " rule_key TEXT PRIMARY KEY,"
        " rule_value TEXT NOT NULL,"
        " rule_type TEXT NOT NULL DEFAULT 'float',"
        " updated_utc TEXT NOT NULL"
        ");"
    )
    con.execute("CREATE INDEX IF NOT EXISTS idx_expander_rules_updated ON expander_rules(updated_utc);")


def ensure_expander_registry_schema(con: sqlite3.Connection) -> None:
    con.execute(
        "CREATE TABLE IF NOT EXISTS expander_registry ("
        " unified_symbol TEXT PRIMARY KEY,"
        " stage INTEGER NOT NULL DEFAULT 0,"
        " first_seen_utc TEXT NOT NULL,"
        " last_seen_utc TEXT NOT NULL,"
        " last_snapshot_ref INTEGER,"
        " composite_score REAL,"
        " reasons_json TEXT,"
        " FOREIGN KEY(last_snapshot_ref) REFERENCES snapshots(snapshot_ref)"
        ");"
    )
    con.execute("CREATE INDEX IF NOT EXISTS idx_expander_registry_stage ON expander_registry(stage);")

    con.execute(
        "CREATE TABLE IF NOT EXISTS expander_observations ("
        " expander_observation_id INTEGER PRIMARY KEY AUTOINCREMENT,"
        " snapshot_ref INTEGER NOT NULL,"
        " timeframe TEXT NOT NULL,"
        " unified_symbol TEXT NOT NULL,"
        " stage INTEGER NOT NULL,"
        " score REAL,"
        " reasons_json TEXT,"
        " created_utc TEXT NOT NULL,"
        " UNIQUE(snapshot_ref, timeframe, unified_symbol),"
        " FOREIGN KEY(snapshot_ref) REFERENCES snapshots(snapshot_ref)"
        ");"
    )
    con.execute("CREATE INDEX IF NOT EXISTS idx_expander_obs_snapshot ON expander_observations(snapshot_ref, timeframe);")
    con.execute("CREATE INDEX IF NOT EXISTS idx_expander_obs_symbol ON expander_observations(unified_symbol);")

def get_registry_stage(con: sqlite3.Connection, unified_symbol: str) -> int | None:
    row = con.execute("SELECT stage FROM expander_registry WHERE unified_symbol=?;", (unified_symbol,)).fetchone()
    return int(row[0]) if row and row[0] is not None else None

def upsert_expander_registry(con: sqlite3.Connection, unified_symbol: str, stage: int, first_seen_utc: str, last_seen_utc: str,
                            last_snapshot_ref: int | None, composite_score: float | None, reasons_json: str | None) -> None:
    con.execute(
        "INSERT INTO expander_registry(unified_symbol, stage, first_seen_utc, last_seen_utc, last_snapshot_ref, composite_score, reasons_json) "
        "VALUES (?,?,?,?,?,?,?) "
        "ON CONFLICT(unified_symbol) DO UPDATE SET "
        " stage=excluded.stage, last_seen_utc=excluded.last_seen_utc, last_snapshot_ref=excluded.last_snapshot_ref, "
        " composite_score=excluded.composite_score, reasons_json=excluded.reasons_json;",
        (unified_symbol, int(stage), first_seen_utc, last_seen_utc, last_snapshot_ref, composite_score, reasons_json),
    )

def insert_expander_observation(con: sqlite3.Connection, snapshot_ref: int, timeframe: str, unified_symbol: str, stage: int,
                               score: float | None, reasons_json: str | None, created_utc: str) -> None:
    con.execute(
        "INSERT INTO expander_observations(snapshot_ref, timeframe, unified_symbol, stage, score, reasons_json, created_utc) "
        "VALUES (?,?,?,?,?,?,?) "
        "ON CONFLICT(snapshot_ref, timeframe, unified_symbol) DO UPDATE SET "
        " stage=excluded.stage, score=excluded.score, reasons_json=excluded.reasons_json, created_utc=excluded.created_utc;",
        (snapshot_ref, timeframe, unified_symbol, int(stage), score, reasons_json, created_utc),
    )

from __future__ import annotations
import os, json, sqlite3
from .logrotate import rotate_if_needed
from typing import Dict, Any, Optional

def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)

def _state_path(out_dir: str) -> str:
    return os.path.join(out_dir, ".alerts_state.json")

def _load_state(out_dir: str) -> Dict[str, Any]:
    p = _state_path(out_dir)
    try:
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f) or {}
    except Exception:
        return {}

def _save_state(out_dir: str, state: Dict[str, Any]) -> None:
    p = _state_path(out_dir)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2)
    os.replace(tmp, p)

def write_alerts_for_snapshot(
    con: sqlite3.Connection,
    snapshot_ref: int,
    out_dir: str,
    min_to_stage: int = 2,
    rotate_mb: int = 10,
    rotate_backups: int = 3,
) -> int:
    """Write alert lines for expander_events of a snapshot with dedup.
    Dedup strategy (minimal, file-based):
      - keep last written expander_event_id in logs/.alerts_state.json
      - only write events with expander_event_id > last_event_id
    Outputs:
      - logs/alerts.jsonl (machine)
      - logs/alerts.log (human)
    Returns number of alerts written.
    """
    ensure_dir(out_dir)
    state = _load_state(out_dir)
    last_id = int(state.get("last_event_id", 0) or 0)

    rows = con.execute(
        "SELECT expander_event_id, unified_symbol, from_stage, to_stage, score, reason_json, created_utc "
        "FROM expander_events "
        "WHERE snapshot_ref=? AND to_stage>=? AND expander_event_id>? "
        "ORDER BY expander_event_id ASC;",
        (int(snapshot_ref), int(min_to_stage), int(last_id)),
    ).fetchall()

    if not rows:
        return 0

    jsonl_path = os.path.join(out_dir, "alerts.jsonl")
    log_path = os.path.join(out_dir, "alerts.log")
    # minimal log rotation
    max_bytes = max(1, int(rotate_mb)) * 1_000_000
    backups = max(1, int(rotate_backups))
    rotate_if_needed(jsonl_path, max_bytes=max_bytes, backups=backups)
    rotate_if_needed(log_path, max_bytes=max_bytes, backups=backups)

    n = 0
    max_id = last_id
    with open(jsonl_path, "a", encoding="utf-8") as fj, open(log_path, "a", encoding="utf-8") as fl:
        for eid, sym, fr, to, score, reason, utc in rows:
            max_id = max(max_id, int(eid))
            rec = {
                "utc": utc,
                "event_id": eid,
                "snapshot_ref": snapshot_ref,
                "symbol": sym,
                "from_stage": fr,
                "to_stage": to,
                "score": score,
                "reason_json": reason,
            }
            fj.write(json.dumps(rec, ensure_ascii=False) + "\n")
            fl.write(f"{utc} event={eid} snapshot={snapshot_ref} {sym} stage {fr}->{to} score={score}\n")
            n += 1

    state["last_event_id"] = max_id
    _save_state(out_dir, state)
    return n

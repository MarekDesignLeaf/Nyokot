from __future__ import annotations
import os
from typing import Optional

def rotate_if_needed(path: str, max_bytes: int = 10_000_000, backups: int = 3) -> bool:
    """If file exceeds max_bytes, rotate: .1, .2 ... up to backups.
    Returns True if rotated.
    """
    try:
        if not os.path.exists(path):
            return False
        if os.path.getsize(path) <= int(max_bytes):
            return False
        backups = max(1, int(backups))
        # shift
        for i in range(backups, 0, -1):
            src = f"{path}.{i}"
            dst = f"{path}.{i+1}"
            if os.path.exists(dst):
                try: os.remove(dst)
                except Exception: pass
            if os.path.exists(src):
                os.replace(src, dst)
        os.replace(path, f"{path}.1")
        return True
    except Exception:
        return False

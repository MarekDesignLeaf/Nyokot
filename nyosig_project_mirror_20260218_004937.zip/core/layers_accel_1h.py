from __future__ import annotations
import sqlite3, json
from .layers_base import LayerAdapter, LayerContext, LayerResult
from .layers_accel_generic import AccelGeneric, AccelConfig

class Accel1HLayer(LayerAdapter):
    layer_name = "accel_1h"
    layer_version = "v1"

    def run(self, con: sqlite3.Connection, ctx: LayerContext) -> LayerResult:
        try:
            gen = AccelGeneric(AccelConfig(timeframe="1h", layer_name=self.layer_name))
            rep = gen.run(con)
            status = rep.get("status","ok")
            return LayerResult(self.layer_name, self.layer_version, status, None, rep)
        except Exception as e:
            return LayerResult(self.layer_name, self.layer_version, "failed", None, {"error": str(e)[:800]})

from __future__ import annotations
import sqlite3, json, csv
from typing import List, Dict, Any

def get_stage3(con: sqlite3.Connection, min_stage: int = 3, limit: int = 500) -> List[Dict[str, Any]]:
    rows = con.execute(
        "SELECT unified_symbol, stage, first_seen_utc, last_seen_utc, composite_score, reasons_json "
        "FROM expander_registry WHERE stage>=? "
        "ORDER BY stage DESC, composite_score DESC, last_seen_utc DESC "
        "LIMIT ?;",
        (int(min_stage), int(limit)),
    ).fetchall()
    return [
        {
            "symbol": r[0],
            "stage": r[1],
            "first_seen_utc": r[2],
            "last_seen_utc": r[3],
            "composite_score": r[4],
            "reasons": r[5],
        }
        for r in rows
    ]

def export_stage3_json(con: sqlite3.Connection, out_path: str, min_stage: int = 3, limit: int = 500) -> str:
    data = get_stage3(con, min_stage=min_stage, limit=limit)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    return out_path

def export_stage3_csv(con: sqlite3.Connection, out_path: str, min_stage: int = 3, limit: int = 500) -> str:
    data = get_stage3(con, min_stage=min_stage, limit=limit)
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(
            f,
            fieldnames=["symbol", "stage", "first_seen_utc", "last_seen_utc", "composite_score", "reasons"],
        )
        w.writeheader()
        for row in data:
            w.writerow(row)
    return out_path

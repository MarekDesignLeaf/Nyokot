from __future__ import annotations
import os, json, sqlite3
from typing import Dict, Any, List

def health_report(con: sqlite3.Connection, project_root: str) -> Dict[str, Any]:
    out: Dict[str, Any] = {}

    # latest snapshots per timeframe
    tfs = [r[0] for r in con.execute("SELECT DISTINCT timeframe FROM snapshots ORDER BY timeframe;").fetchall()]
    latest = {}
    for tf in tfs:
        row = con.execute(
            "SELECT snapshot_ref, snapshot_key, created_utc FROM snapshots WHERE timeframe=? ORDER BY created_utc DESC LIMIT 1;",
            (tf,),
        ).fetchone()
        if row:
            latest[tf] = {"snapshot_ref": row[0], "snapshot_key": row[1], "created_utc": row[2]}
    out["latest_snapshots"] = latest

    # registry counts by stage
    try:
        rows = con.execute("SELECT stage, COUNT(*) FROM expander_registry GROUP BY stage ORDER BY stage;").fetchall()
        out["registry_counts_by_stage"] = {str(s): int(n) for s, n in rows}
    except Exception:
        out["registry_counts_by_stage"] = {}

    # alerts dedup state
    alerts_state = os.path.join(project_root, "logs", ".alerts_state.json")
    try:
        with open(alerts_state, "r", encoding="utf-8") as f:
            out["alerts_state"] = json.load(f)
    except Exception:
        out["alerts_state"] = {}

    # export state
    export_state = os.path.join(project_root, "exports", ".export_state.json")
    try:
        with open(export_state, "r", encoding="utf-8") as f:
            out["export_state"] = json.load(f)
    except Exception:
        out["export_state"] = {}


    def _stat(p: str) -> Dict[str, Any]:
        try:
            st = os.stat(p)
            return {"path": p, "size": st.st_size, "mtime": st.st_mtime}
        except Exception:
            return {"path": p, "size": None, "mtime": None}

    out["files"] = {
        "alerts_log": _stat(os.path.join(project_root, "logs", "alerts.log")),
        "alerts_jsonl": _stat(os.path.join(project_root, "logs", "alerts.jsonl")),
        "stage_export_json": _stat(os.path.join(project_root, "exports", "stage_export.json")),
        "stage_export_csv": _stat(os.path.join(project_root, "exports", "stage_export.csv")),
    }

    return out

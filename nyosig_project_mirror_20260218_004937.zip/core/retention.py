from __future__ import annotations
import sqlite3
from typing import Dict, Any, List, Tuple

def prune_snapshots_keep_last(con: sqlite3.Connection, keep_last: int = 200, per_timeframe: bool = True) -> Dict[str, Any]:
    """Delete old snapshots + dependent rows, keeping last N snapshots (optionally per timeframe).
    Safe best-effort: deletes in child-first order to avoid FK issues.
    Returns counts.
    """
    keep_last = int(keep_last)
    if keep_last < 1:
        keep_last = 1

    # determine groups
    if per_timeframe:
        tfs = [r[0] for r in con.execute("SELECT DISTINCT timeframe FROM snapshots WHERE timeframe IS NOT NULL;").fetchall()]
        groups = [(tf,) for tf in tfs] if tfs else [(None,)]
    else:
        groups = [(None,)]

    total_deleted = {"snapshots": 0, "market_snapshots": 0, "raw_snapshots": 0, "layer_results": 0, "layer_symbol_scores": 0,
                     "composite_symbol_scores": 0, "expanders": 0, "expander_events": 0, "expander_observations": 0, "topnow_selection": 0}

    for (tf,) in groups:
        if tf:
            ids = [r[0] for r in con.execute(
                "SELECT snapshot_ref FROM snapshots WHERE timeframe=? ORDER BY created_utc DESC;",
                (tf,),
            ).fetchall()]
        else:
            ids = [r[0] for r in con.execute(
                "SELECT snapshot_ref FROM snapshots ORDER BY created_utc DESC;"
            ).fetchall()]

        if len(ids) <= keep_last:
            continue
        to_delete = ids[keep_last:]

        # delete in batches
        for snap_ref in to_delete:
            # child tables first
            for table, where_sql in [
                ("market_snapshots", "snapshot_ref=?"),
                ("raw_snapshots", "snapshot_ref=?"),
                ("layer_results", "snapshot_ref=?"),
                ("layer_symbol_scores", "snapshot_ref=?"),
                ("composite_symbol_scores", "snapshot_ref=?"),
                ("expander_events", "snapshot_ref=?"),
                ("expander_observations", "snapshot_ref=?"),
                ("expanders", "snapshot_ref=?"),
                ("topnow_selection", "snapshot_ref=?"),
            ]:
                try:
                    cur = con.execute(f"DELETE FROM {table} WHERE {where_sql};", (snap_ref,))
                    total_deleted[table] += cur.rowcount if cur.rowcount is not None else 0
                except Exception:
                    # table might not exist in older DBs
                    pass
            # finally snapshots
            cur = con.execute("DELETE FROM snapshots WHERE snapshot_ref=?;", (snap_ref,))
            total_deleted["snapshots"] += cur.rowcount if cur.rowcount is not None else 0

    return total_deleted

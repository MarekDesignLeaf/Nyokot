from __future__ import annotations
from typing import Callable, Dict, Any, List, Tuple
import time
import os

from .pipeline import run_snapshot_and_topnow
from .engine import run_layers, run_composite_and_expanders
from .layers_spot_basic import SpotBasicLayer
from .layers_accel_15m import Accel15mLayer
from .alerts import write_alerts_for_snapshot
from .export_stage3 import export_stage3_json, export_stage3_csv
from .export_on_change import should_export
from .logrotate import rotate_if_needed
from .rules import load_rules
from .retention import prune_snapshots_keep_last
from .cleanup import cleanup_dir
from .db import db_connect, require_schema, ensure_indexes, ensure_snapshot_schema, resolve_snapshot
from .config import make_paths
from .layers_base import LayerContext

PERIODS = {
    "15m": 15 * 60,
    "1h": 60 * 60,
    "4h": 4 * 60 * 60,
    "spot": 60 * 60,  # treat spot as hourly by default for scheduler
}

def _parse_utc_iso_to_epoch(iso: str) -> float | None:
    # naive parser for 'YYYY-MM-DDTHH:MM:SSZ'
    try:
        import datetime
        dt = datetime.datetime.strptime(iso, "%Y-%m-%dT%H:%M:%SZ")
        return dt.replace(tzinfo=datetime.timezone.utc).timestamp()
    except Exception:
        return None

def due_timeframes(con, now_epoch: float, timeframes: List[str]) -> List[str]:
    due=[]
    for tf in timeframes:
        period = PERIODS.get(tf, 60*60)
        row = con.execute("SELECT created_utc FROM snapshots WHERE timeframe=? ORDER BY created_utc DESC LIMIT 1;", (tf,)).fetchone()
        if not row or not row[0]:
            due.append(tf)
            continue
        last_epoch = _parse_utc_iso_to_epoch(row[0])
        if last_epoch is None:
            due.append(tf)
            continue
        if (now_epoch - last_epoch) >= period:
            due.append(tf)
    return due

def run_due_once(
    project_root: str,
    app_version: str,
    scope_text: str,
    vs_currency: str,
    coins_limit: int,
    order: str,
    topnow_limit: int,
    offline_mode: bool,
    log_cb: Callable[[str], None],
    timeframes: List[str],
    run_layers_after: bool = True,
) -> List[Dict[str, Any]]:
    paths = make_paths(project_root)
    con = db_connect(paths.db_path)
    try:
        require_schema(con); ensure_indexes(con); ensure_snapshot_schema(con)
        now = time.time()
        due = due_timeframes(con, now, timeframes)
    finally:
        con.close()

    results=[]
    for tf in due:
        res = run_snapshot_and_topnow(
            project_root=project_root,
            app_version=app_version,
            scope_text=scope_text,
            vs_currency=vs_currency,
            coins_limit=coins_limit,
            order=order,
            topnow_limit=topnow_limit,
            offline_mode=offline_mode,
            log_cb=log_cb,
            timeframe=tf,
        )
        results.append({"timeframe": tf, **res.__dict__})

        if run_layers_after:
            # run layers/composite/expanders for this snapshot
            con = db_connect(paths.db_path)
            try:
                require_schema(con); ensure_indexes(con); ensure_snapshot_schema(con)
                snap_ref, snap_key = resolve_snapshot(con, res.snapshot_id)
                if snap_ref is None:
                    continue
                ctx = LayerContext(run_id=res.run_id, snapshot_ref=snap_ref, snapshot_key=snap_key or res.snapshot_id, timeframe=tf, vs_currency=vs_currency, scope=scope_text)
                layers = [SpotBasicLayer()]
                if tf == "15m":
                    layers.append(Accel15mLayer())
                run_layers(con, ctx, layers)
                post = run_composite_and_expanders(con, ctx, selection_id=(res.selection_id if res.selection_id else None))
                # Optional hooks: auto-export stage list + alerts
                r = load_rules(con)
                try:
                    if int(r.get('auto_export_stage3', 0)) == 1:
                        base = str(r.get('auto_export_path', 'exports/stage_export'))
                        fmt = str(r.get('auto_export_format', 'json')).lower()
                        min_stage = int(r.get('auto_export_min_stage', 3))
                        out_dir = os.path.join(project_root, os.path.dirname(base)) if os.path.dirname(base) else project_root
                        os.makedirs(out_dir, exist_ok=True)
                        out_file = os.path.join(project_root, base + ('.csv' if fmt=='csv' else '.json'))
                        only_change = int(r.get('export_only_on_change', 1)) == 1
                        if (not only_change) or should_export(con, out_file, min_stage=min_stage):
                            # rotate export if it somehow grows too large (rare)
                            rotate_if_needed(out_file, max_bytes=max(1,int(r.get('export_rotate_max_mb',5)))*1_000_000, backups=max(1,int(r.get('export_rotate_backups',2))))
                            if fmt == 'csv':
                                export_stage3_csv(con, out_file, min_stage=min_stage)
                            else:
                                export_stage3_json(con, out_file, min_stage=min_stage)
                except Exception:
                    pass
                try:
                    if int(r.get('auto_alerts', 0)) == 1:
                        out_dir = os.path.join(project_root, 'logs')
                        os.makedirs(out_dir, exist_ok=True)
                        write_alerts_for_snapshot(
                            con,
                            ctx.snapshot_ref,
                            out_dir=out_dir,
                            min_to_stage=int(r.get('auto_alert_min_to_stage', 2)),
                            rotate_mb=int(r.get('log_rotate_max_mb', 10)),
                            rotate_backups=int(r.get('log_rotate_backups', 3)),
                        )
                except Exception:
                    pass
                con.commit()
            finally:
                con.close()

    # AUTO_RETENTION: keep DB bounded
    try:
        con = db_connect(paths.db_path)
        try:
            require_schema(con); ensure_indexes(con); ensure_snapshot_schema(con)
            r = load_rules(con)
            if int(r.get('auto_retention', 1)) == 1:
                keep = int(r.get('retention_keep', 300))
                global_keep = int(r.get('retention_global_keep', 0)) == 1
                rep = prune_snapshots_keep_last(con, keep_last=keep, per_timeframe=(not global_keep))
                con.commit()
            # AUTO_CLEANUP: keep logs/exports bounded
            if int(r.get('auto_cleanup', 1)) == 1:
                keep_days = int(r.get('cleanup_keep_days', 14))
                keep_last = int(r.get('cleanup_keep_last', 50))
                cleanup_dir(os.path.join(project_root, 'logs'), patterns=['alerts.log.*','alerts.jsonl.*'], keep_days=keep_days, keep_last=keep_last)
                cleanup_dir(os.path.join(project_root, 'exports'), patterns=['stage_export.*.*','stage_export.*','*.export_state_*.json','*.export_state.json'], keep_days=keep_days, keep_last=keep_last)
        finally:
            con.close()
    except Exception:
        pass

    return results



def run_loop(
    project_root: str,
    app_version: str,
    scope_text: str,
    vs_currency: str,
    coins_limit: int,
    order: str,
    topnow_limit: int,
    offline_mode: bool,
    log_cb: Callable[[str], None],
    timeframes: List[str],
    tick_s: int = 30,
    run_layers_after: bool = True,
) -> None:
    """Looping scheduler: every tick checks due timeframes and runs once."""
    import time as _t
    while True:
        try:
            res = run_due_once(
                project_root=project_root,
                app_version=app_version,
                scope_text=scope_text,
                vs_currency=vs_currency,
                coins_limit=coins_limit,
                order=order,
                topnow_limit=topnow_limit,
                offline_mode=offline_mode,
                log_cb=log_cb,
                timeframes=timeframes,
                run_layers_after=run_layers_after,
            )
            if res:
                log_cb(f"SCHED_TICK ran={len(res)}")
        except Exception as e:
            log_cb("SCHED_ERROR " + str(e))
        _t.sleep(max(5, int(tick_s)))

from __future__ import annotations
from typing import Dict, Any, Iterable, Tuple, List
import math

def normalise_rows(markets: List[Dict[str, Any]], run_id: int, snapshot_id: str, scope_text: str, timeframe: str, timestamp_utc: str, source: str, snapshot_ref: int | None = None):
    rows = []
    for it in markets:
        sym = (it.get("symbol") or "").strip()
        if not sym:
            continue
        unified_symbol = sym.upper()
        rows.append((
            snapshot_id,
            snapshot_ref,
            run_id,
            timestamp_utc,
            scope_text,
            timeframe,
            unified_symbol,
            None,
            it.get("current_price"),
            it.get("price_change_percentage_24h"),
            it.get("total_volume"),
            it.get("market_cap"),
            it.get("market_cap_rank"),
            None,
            source,
        ))
    return rows

def spot_basic_score(rank: float | None, mcap: float | None, vol24: float | None, chg24: float | None) -> float:
    # simple, deterministic, bounded-ish score for preview (0..100)
    score = 0.0
    if rank is not None and rank > 0:
        score += max(0.0, 40.0 - min(40.0, math.log(rank+1, 1.6)*8.0))
    if mcap is not None and mcap > 0:
        score += min(30.0, math.log(mcap, 10) * 3.0)
    if vol24 is not None and vol24 > 0:
        score += min(20.0, math.log(vol24, 10) * 2.0)
    if chg24 is not None:
        score += max(-10.0, min(10.0, chg24/3.0))
    return max(0.0, min(100.0, score))

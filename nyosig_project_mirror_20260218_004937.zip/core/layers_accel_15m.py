from __future__ import annotations
import sqlite3, json, math
from typing import Dict, Any, Optional

from .layers_base import LayerAdapter, LayerContext, LayerResult
from .db import upsert_layer_symbol_score
from .util_time import utc_now_iso

def _clamp(x: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, x))

class Accel15mLayer(LayerAdapter):
    """Computes short-term acceleration from the last two 15m snapshots (price pct change).
    Stores:
      - raw_json: {accel_pct: float}
      - score: mapped 0..100 for composite (center 50).
    """
    layer_name = "accel_15m"
    layer_version = "v1"

    def run(self, con: sqlite3.Connection, ctx: LayerContext) -> LayerResult:
        try:
            # Determine last two snapshot_refs for timeframe 15m
            snaps = con.execute(
                "SELECT snapshot_ref FROM snapshots WHERE timeframe=? ORDER BY created_utc DESC LIMIT 2;",
                ("15m",),
            ).fetchall()
            if len(snaps) < 2:
                return LayerResult(self.layer_name, self.layer_version, "skipped", None, {"reason": "need_2_snapshots_15m"})
            b_ref = int(snaps[0][0])
            a_ref = int(snaps[1][0])

            # Join prices for symbols
            rows = con.execute(
                "SELECT a.unified_symbol, a.price, b.price "
                "FROM market_snapshots a JOIN market_snapshots b ON b.unified_symbol=a.unified_symbol "
                "WHERE a.snapshot_ref=? AND b.snapshot_ref=? AND a.timeframe=? AND b.timeframe=?;",
                (a_ref, b_ref, "15m", "15m"),
            ).fetchall()

            now = utc_now_iso()
            n = 0
            for sym, pa, pb in rows:
                if pa is None or pb is None:
                    continue
                try:
                    pa = float(pa); pb = float(pb)
                    if pa <= 0:
                        continue
                    accel_pct = (pb / pa - 1.0) * 100.0
                except Exception:
                    continue

                # map accel_pct to 0..100 (50 neutral, 10% => 100, -10% => 0)
                score = _clamp(50.0 + accel_pct * 5.0)
                upsert_layer_symbol_score(
                    con, b_ref, "15m", self.layer_name, str(sym),
                    score, json.dumps({"accel_pct": accel_pct}, sort_keys=True), now
                )
                n += 1

            return LayerResult(self.layer_name, self.layer_version, "ok", None, {"updated_symbols": n, "ref_a": a_ref, "ref_b": b_ref})
        except Exception as e:
            return LayerResult(self.layer_name, self.layer_version, "failed", None, {"error": str(e)[:800]})

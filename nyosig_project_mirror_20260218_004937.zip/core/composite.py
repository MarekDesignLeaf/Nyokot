from __future__ import annotations
import sqlite3, json
from typing import Dict, Any
from .db import upsert_composite_symbol_score

def load_layer_weights(con: sqlite3.Connection) -> Dict[str, float]:
    # Prefer DB table if exists
    try:
        rows = con.execute("SELECT layer_name, weight FROM layer_weights;").fetchall()
        if rows:
            return {r[0]: float(r[1]) for r in rows if r[0] is not None and r[1] is not None}
    except Exception:
        pass
    # default weights
    return {"spot_basic": 1.0}

def compute_composite_for_snapshot(con: sqlite3.Connection, run_id: int, snapshot_ref: int, timeframe: str) -> Dict[str, Any]:
    weights = load_layer_weights(con)
    # Pull layer_results
    rows = con.execute(
        "SELECT layer_name, status, score, weight, raw_json FROM layer_results WHERE run_id=? AND snapshot_ref=? AND timeframe=?;",
        (run_id, snapshot_ref, timeframe),
    ).fetchall()

    # if a layer doesn't provide a score, attempt to derive it:
    # - spot_basic stores per-row base_score, but layer result score can be None. We'll compute symbol composite using market_snapshots.base_score weighted.
    # This function returns snapshot-level composite metadata.
    ok = [r for r in rows if r[1] in ("ok","warning")]
    failed = [r for r in rows if r[1] == "failed"]

    used_weights = {}
    for name, status, score, w, raw_json in rows:
        used_weights[name] = float(w) if w is not None else float(weights.get(name, 0.0))

    return {
        "layers_total": len(rows),
        "layers_ok": len(ok),
        "layers_failed": len(failed),
        "used_weights": used_weights,
    }

def update_selection_composite_preview(con: sqlite3.Connection, selection_id: int, snapshot_ref: int, timeframe: str, weights: Dict[str, float]) -> int:
    # Prefer composite_symbol_scores if available; fallback to market_snapshots.base_score
    # Convert base_score (0..100) to composite with weight normalization.
    w = float(weights.get("spot_basic", 1.0))
    denom = w if w > 0 else 1.0
    # Update topnow_selection_items.composite_preview with weighted score for symbol
    con.execute(
        "UPDATE topnow_selection_items SET composite_preview = ("
        " SELECT ROUND(COALESCE(m.base_score,0) * (? / ?), 3) "
        " FROM market_snapshots m "
        " JOIN topnow_selection ts ON ts.selection_id=topnow_selection_items.selection_id "
        " WHERE m.unified_symbol=topnow_selection_items.unified_symbol "
        "   AND m.timeframe=? "
        "   AND ((m.snapshot_ref=? ) OR (m.snapshot_id = (SELECT snapshot_key FROM snapshots WHERE snapshot_ref=?))) "
        " LIMIT 1"
        ") "
        "WHERE selection_id=?;",
        (w, denom, timeframe, snapshot_ref, snapshot_ref, selection_id),
    )
    return con.total_changes


def compute_and_store_composite_symbol_scores(con: sqlite3.Connection, snapshot_ref: int, timeframe: str, run_id: int | None = None) -> int:
    """Compute composite score per symbol from layer_symbol_scores and layer_weights. Stores to composite_symbol_scores."""
    weights = load_layer_weights(con)
    # Get set of symbols present in any layer for this snapshot
    syms = [r[0] for r in con.execute(
        "SELECT DISTINCT unified_symbol FROM layer_symbol_scores WHERE snapshot_ref=? AND timeframe=?;",
        (snapshot_ref, timeframe),
    ).fetchall()]
    if not syms:
        return 0

    now = __import__("time").strftime("%Y-%m-%dT%H:%M:%SZ", __import__("time").gmtime())
    changes = 0
    for sym in syms:
        rows = con.execute(
            "SELECT layer_name, score FROM layer_symbol_scores WHERE snapshot_ref=? AND timeframe=? AND unified_symbol=?;",
            (snapshot_ref, timeframe, sym),
        ).fetchall()
        # weighted average over available layers (ignore missing/None)
        num = 0.0
        den = 0.0
        used = {}
        for lname, sc in rows:
            w = float(weights.get(lname, 0.0))
            if sc is None or w <= 0:
                continue
            num += float(sc) * w
            den += w
            used[lname] = w
        if den <= 0:
            continue
        comp_score = num / den
        meta = {"weights_used": used, "run_id": run_id}
        upsert_composite_symbol_score(con, snapshot_ref, timeframe, sym, comp_score, json.dumps(meta, sort_keys=True), now)
        changes += 1
    return changes

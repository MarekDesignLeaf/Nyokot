from __future__ import annotations
import json
import sqlite3
from typing import List, Dict, Any

from .layers_base import LayerAdapter, LayerContext
from .layers_accel_15m import Accel15mLayer
from .layers_accel_1h import Accel1hLayer
from .layers_accel_4h import Accel4hLayer
from .db import upsert_layer_result
from .util_time import utc_now_iso
from .composite import load_layer_weights, compute_composite_for_snapshot, update_selection_composite_preview, compute_and_store_composite_symbol_scores
from .expander import promote_expanders

def run_layers(con: sqlite3.Connection, ctx: LayerContext, layers: List[LayerAdapter]) -> List[Dict[str, Any]]:
    weights = load_layer_weights(con)
    out = []
    for layer in layers:
        res = layer.run(con, ctx)
        weight = float(weights.get(res.layer_name, 0.0))
        upsert_layer_result(
            con,
            run_id=ctx.run_id,
            snapshot_ref=ctx.snapshot_ref,
            timeframe=ctx.timeframe,
            layer_name=res.layer_name,
            layer_version=res.layer_version,
            status=res.status,
            score=res.score,
            weight=weight,
            raw_json=json.dumps(res.raw, sort_keys=True),
            created_utc=utc_now_iso(),
        )
        out.append({"layer": res.layer_name, "status": res.status, "score": res.score})
    return out

def run_composite_and_expanders(con: sqlite3.Connection, ctx: LayerContext, selection_id: int | None = None) -> Dict[str, Any]:
    weights = load_layer_weights(con)
    composite_written = compute_and_store_composite_symbol_scores(con, ctx.snapshot_ref, ctx.timeframe, run_id=ctx.run_id)
    meta = compute_composite_for_snapshot(con, ctx.run_id, ctx.snapshot_ref, ctx.timeframe)
    updated_preview = None
    if selection_id is not None:
        updated_preview = update_selection_composite_preview(con, selection_id, ctx.snapshot_ref, ctx.timeframe, weights)
    promoted = promote_expanders(con, ctx.snapshot_ref, ctx.timeframe)
    return {"composite_meta": meta, "composite_symbols_written": composite_written, "selection_preview_changes": updated_preview, "expanders_promoted": promoted}

from __future__ import annotations
import hashlib, json, os, time
from typing import Any, Optional

def ensure_dir(p: str) -> None:
    os.makedirs(p, exist_ok=True)

def cache_key(obj: Any) -> str:
    b = json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(b).hexdigest()

def cache_path(cache_dir: str, key: str) -> str:
    return os.path.join(cache_dir, key + ".json")

def load_cache_if_fresh(path: str, ttl_s: int) -> Optional[Any]:
    if not os.path.isfile(path):
        return None
    age = time.time() - os.path.getmtime(path)
    if age > ttl_s:
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None

def save_cache(path: str, obj: Any) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f)

from __future__ import annotations
import sqlite3, json
from typing import Dict, Any

from .util_time import utc_now_iso
from .db import insert_expander_event

def _parse_iso(iso: str) -> float | None:
    try:
        import datetime
        dt = datetime.datetime.strptime(iso, "%Y-%m-%dT%H:%M:%SZ")
        return dt.replace(tzinfo=datetime.timezone.utc).timestamp()
    except Exception:
        return None

DEFAULT_DECAY = {
    # If not seen for N hours, drop stage by 1 (repeatable).
    "decay_step_hours": 6.0,
    # Max stage drop per run (safety)
    "decay_max_drop": 2,
}

def decay_registry_once(
    con: sqlite3.Connection,
    now_utc: str | None = None,
    rules: Dict[str, Any] | None = None,
) -> Dict[str, int]:
    """Minimal decay: if symbol hasn't been seen, reduce stage gradually.
    Writes an expander_event when possible (requires last_snapshot_ref).
    """
    rules = rules or DEFAULT_DECAY
    now_utc = now_utc or utc_now_iso()
    now_epoch = _parse_iso(now_utc) or 0.0

    step_h = float(rules.get("decay_step_hours", 6.0))
    max_drop = int(rules.get("decay_max_drop", 2))

    updated = 0
    events = 0

    rows = con.execute(
        "SELECT unified_symbol, stage, last_seen_utc, last_snapshot_ref FROM expander_registry;"
    ).fetchall()

    for sym, stage, last_seen, last_snap in rows:
        if sym is None or stage is None or not last_seen:
            continue
        last_epoch = _parse_iso(str(last_seen))
        if last_epoch is None:
            continue

        age_h = (now_epoch - last_epoch) / 3600.0
        if age_h < step_h:
            continue

        drops = int(age_h // step_h)
        if drops <= 0:
            continue
        drops = min(drops, max_drop)

        old = int(stage)
        new = max(0, old - drops)
        if new == old:
            continue

        reason = json.dumps({"rule": "decay", "age_h": round(age_h, 3), "drops": drops}, sort_keys=True)

        con.execute(
            "UPDATE expander_registry SET stage=?, reasons_json=? WHERE unified_symbol=?;",
            (new, reason, str(sym)),
        )
        updated += 1

        if last_snap:
            insert_expander_event(
                con,
                snapshot_ref=int(last_snap),
                unified_symbol=str(sym),
                from_stage=old,
                to_stage=new,
                score=None,
                reason_json=reason,
                created_utc=now_utc,
            )
            events += 1

    return {"registry_updated": updated, "events_written": events}

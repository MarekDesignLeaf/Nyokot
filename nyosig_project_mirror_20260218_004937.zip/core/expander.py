from __future__ import annotations
import sqlite3, json
from typing import Dict, Any, List
from .util_time import utc_now_iso
from .rules import load_rules


def _parse_iso(iso: str) -> float | None:
    try:
        import datetime
        dt = datetime.datetime.strptime(iso, '%Y-%m-%dT%H:%M:%SZ')
        return dt.replace(tzinfo=datetime.timezone.utc).timestamp()
    except Exception:
        return None

from .db import upsert_expander, insert_expander_event, get_registry_stage, upsert_expander_registry, insert_expander_observation

DEFAULT_RULES = {
    "stage0_min_score": 60.0,
    "stage1_min_score": 72.0,
    "stage2_min_score": 80.0,
    "stage3_min_score": 90.0,
    "demote_margin": 5.0,
}

def promote_expanders(con: sqlite3.Connection, snapshot_ref: int, timeframe: str, rules: Dict[str, float] | None = None, limit: int = 500) -> int:
    rules = rules or load_rules(con)
    now = utc_now_iso()    # Optional accel gate: use latest 15m accel_15m layer (raw accel_pct)
    use_accel_gate = int(rules.get('use_accel_gate', 0)) == 1
    accel_min = float(rules.get('accel_15m_min', 0.5))
    accel_map = {}
    if use_accel_gate:
        try:
            snap15 = con.execute("SELECT snapshot_ref FROM snapshots WHERE timeframe=? ORDER BY created_utc DESC LIMIT 1;", ('15m',)).fetchone()
            if snap15:
                s15 = int(snap15[0])
                rows_acc = con.execute(
                    "SELECT unified_symbol, raw_json FROM layer_symbol_scores WHERE snapshot_ref=? AND timeframe=? AND layer_name=?;",
                    (s15, '15m', 'accel_15m'),
                ).fetchall()
                for sym, rj in rows_acc:
                    if not rj:
                        continue
                    try:
                        d = json.loads(rj)
                        if 'accel_pct' in d:
                            accel_map[str(sym)] = float(d['accel_pct'])
                    except Exception:
                        pass
        except Exception:
            accel_map = {}
    if use_accel_gate:
        try:
            snaps = con.execute("SELECT snapshot_ref FROM snapshots WHERE timeframe=? ORDER BY created_utc DESC LIMIT 2;", (timeframe,)).fetchall()
            if len(snaps) == 2:
                b_ref = int(snaps[0][0])
                a_ref = int(snaps[1][0])
                rows_acc = con.execute(
                    "SELECT a.unified_symbol, a.change_24h_pct, b.change_24h_pct "
                    "FROM market_snapshots a JOIN market_snapshots b ON b.unified_symbol=a.unified_symbol "
                    "WHERE a.snapshot_ref=? AND b.snapshot_ref=? AND a.timeframe=? AND b.timeframe=?;",
                    (a_ref, b_ref, timeframe, timeframe),
                ).fetchall()
                for sym, ac, bc in rows_acc:
                    if ac is None or bc is None:
                        continue
                    try:
                        accel_map[sym] = float(bc) - float(ac)
                    except Exception:
                        pass
        except Exception:
            accel_map = {}

    # Prefer composite_symbol_scores ordered by composite_score desc; fallback to market_snapshots.base_score
    use_composite = False
    try:
        rows = con.execute(
            "SELECT unified_symbol, composite_score FROM composite_symbol_scores WHERE snapshot_ref=? AND timeframe=? ORDER BY composite_score DESC LIMIT ?;",
            (snapshot_ref, timeframe, int(limit)),
        ).fetchall()
        use_composite = True
    except Exception:
        cols = [r[1] for r in con.execute("PRAGMA table_info(market_snapshots);").fetchall()]
        use_ref = "snapshot_ref" in cols
        if use_ref:
            rows = con.execute(
                "SELECT unified_symbol, base_score FROM market_snapshots WHERE snapshot_ref=? AND timeframe=? ORDER BY COALESCE(base_score,0) DESC LIMIT ?;",
                (snapshot_ref, timeframe, int(limit)),
            ).fetchall()
        else:
            snap_key = con.execute("SELECT snapshot_key FROM snapshots WHERE snapshot_ref=?;", (snapshot_ref,)).fetchone()
            snap_key = snap_key[0] if snap_key else ""
            rows = con.execute(
                "SELECT unified_symbol, base_score FROM market_snapshots WHERE snapshot_id=? AND timeframe=? ORDER BY COALESCE(base_score,0) DESC LIMIT ?;",
                (snap_key, timeframe, int(limit)),
            ).fetchall()

    promoted = 0
    demote_margin = float(rules.get("demote_margin", 5.0))

    for sym, score in rows:
        s = float(score) if score is not None else 0.0

        # accel gate
        if use_accel_gate:
            a15 = accel_map.get(sym)
            if a15 is None or a15 < accel_min:
                continue

        # desired stage based on thresholds
        if s >= float(rules["stage3_min_score"]):
            desired = 3
        elif s >= float(rules["stage2_min_score"]):
            desired = 2
        elif s >= float(rules["stage1_min_score"]):
            desired = 1
        elif s >= float(rules["stage0_min_score"]):
            desired = 0
        else:
            desired = -1

        # cross-timeframe confirm for stage3 (optional)
        if desired == 3:
            req1h = int(rules.get('stage3_require_1h', 1)) == 1
            req4h = int(rules.get('stage3_require_4h', 0)) == 1
            if req1h or req4h:
                ok = True
                if req1h:
                    min1 = float(rules.get('stage3_1h_min_score', 70.0))
                    row1 = con.execute("SELECT composite_score FROM composite_symbol_scores c JOIN snapshots s ON s.snapshot_ref=c.snapshot_ref WHERE s.timeframe=? AND c.timeframe=? AND c.unified_symbol=? ORDER BY s.created_utc DESC LIMIT 1;", ('1h','1h',sym)).fetchone()
                    if not row1 or row1[0] is None or float(row1[0]) < min1:
                        ok = False
                if ok and req4h:
                    min4 = float(rules.get('stage3_4h_min_score', 65.0))
                    row4 = con.execute("SELECT composite_score FROM composite_symbol_scores c JOIN snapshots s ON s.snapshot_ref=c.snapshot_ref WHERE s.timeframe=? AND c.timeframe=? AND c.unified_symbol=? ORDER BY s.created_utc DESC LIMIT 1;", ('4h','4h',sym)).fetchone()
                    if not row4 or row4[0] is None or float(row4[0]) < min4:
                        ok = False
                if not ok:
                    # downgrade to stage2 if not confirmed
                    desired = 2        # fetch existing stage from global registry (symbol lifecycle across snapshots)
        cur_stage = get_registry_stage(con, str(sym))
        if cur_stage is None:
            first_seen = now
        else:
            row_fs = con.execute("SELECT first_seen_utc FROM expander_registry WHERE unified_symbol=?;", (str(sym),)).fetchone()
            first_seen = (row_fs[0] if row_fs and row_fs[0] else now)

        # stage3 freeze: if recently promoted to stage3, do not demote
        freeze_h = float(rules.get('freeze_stage3_hours', 0.0))
        if freeze_h > 0 and cur_stage == 3 and desired < 3:
            try:
                rowp = con.execute(
                    "SELECT created_utc FROM expander_events WHERE unified_symbol=? AND to_stage=3 ORDER BY expander_event_id DESC LIMIT 1;",
                    (str(sym),),
                ).fetchone()
                if rowp and rowp[0]:
                    now_ep = _parse_iso(now) or 0.0
                    prom_ep = _parse_iso(str(rowp[0])) or 0.0
                    if now_ep and prom_ep and (now_ep - prom_ep) < (freeze_h * 3600.0):
                        desired = 3
            except Exception:
                pass

        # hysteresis for demotion: only demote if score is well below the min for current stage
        new_stage = desired
        if cur_stage is not None and desired < cur_stage:
            # compute demote threshold for current stage
            stage_mins = {
                0: float(rules["stage0_min_score"]),
                1: float(rules["stage1_min_score"]),
                2: float(rules["stage2_min_score"]),
                3: float(rules["stage3_min_score"]),
            }
            cur_min = stage_mins.get(cur_stage, 0.0)
            if s > (cur_min - demote_margin):
                # keep stage, do not demote yet
                new_stage = cur_stage

        if new_stage < 0:
            continue

        reason = {"rule": ("composite_threshold" if use_composite else "spot_basic_threshold"), "score": s, "desired": desired, "final": new_stage}
        reason_json = json.dumps(reason, sort_keys=True)

        # write per-snapshot expander row (legacy) + new observation + global registry
        upsert_expander(con, snapshot_ref, sym, new_stage, s, reason_json, first_seen, now)
        insert_expander_observation(con, snapshot_ref, timeframe, str(sym), new_stage, s, reason_json, now)
        upsert_expander_registry(con, str(sym), new_stage, first_seen, now, snapshot_ref, s, reason_json)
        # if changed stage (global), write event
        if cur_stage is None or new_stage != cur_stage:
            insert_expander_event(con, snapshot_ref, str(sym), cur_stage, new_stage, s, reason_json, now)
        promoted += 1

    return promoted


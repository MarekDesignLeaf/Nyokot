from __future__ import annotations
import json, os
from dataclasses import dataclass
from typing import Callable, Dict, Any, List, Optional

from .config import make_paths, parse_simple_yaml, parse_secrets_env
from .cache import ensure_dir
from .db import (
    db_connect, require_schema, ensure_indexes, ensure_snapshot_schema, ensure_core_schema, ensure_core_indexes, create_snapshot, get_snapshot_ref,
    create_run, upsert_run_scope, state_log, set_run_status,
    insert_raw_snapshot, insert_market_snapshots,
    select_candidates, create_topnow_selection, insert_topnow_items
)
from .coingecko import fetch_markets
from .scoring import normalise_rows
from .util_time import utc_now_iso

SOURCE = "coingecko"
ENDPOINT = "/coins/markets"

@dataclass
class PipelineResult:
    run_id: int
    snapshot_id: str
    selection_id: int
    candidates_n: int


def refresh_snapshot(
    project_root: str,
    app_version: str,
    parent_snapshot_key: str,
    scope_text: str,
    vs_currency: str,
    coins_limit: int,
    order: str,
    offline_mode: bool,
    log_cb: Callable[[str], None],
    reason: str = "manual_refresh",
    timeframe: str = "spot",
) -> tuple[int, str]:
    """Create a new run + snapshot linked to parent snapshot. Returns (run_id, new_snapshot_key)."""
    paths = make_paths(project_root)
    ensure_dir(paths.cache_dir)
    ensure_dir(paths.log_dir)

    cfg = parse_simple_yaml(paths.defaults_yaml)
    secrets = parse_secrets_env(paths.secrets_env)

    connect_timeout_s = int(cfg.get("network", {}).get("connect_timeout_s", 10))
    read_timeout_s = int(cfg.get("network", {}).get("read_timeout_s", 30))
    max_attempts = int(cfg.get("retry", {}).get("max_attempts", 4))
    backoff_s = cfg.get("retry", {}).get("backoff_s", [1, 2, 4, 8])
    on_429_sleep_s = int(cfg.get("rate_limit", {}).get("on_429_sleep_s", 20))
    ttl_s = int(cfg.get("cache", {}).get("ttl_s", 120))

    con = db_connect(paths.db_path)
    try:
        # ---- HARD BOOTSTRAP (schema must exist before any query uses snapshot_ref) ----
        ensure_core_schema(con)
        ensure_core_indexes(con)
        ensure_snapshot_schema(con)
        ensure_indexes(con)
        con.commit()
        # ------------------------------------------------------------------------------

        require_schema(con)
        parent_ref = get_snapshot_ref(con, parent_snapshot_key)
        if parent_ref is None:
            raise RuntimeError(f"Parent snapshot not found: {parent_snapshot_key}")

        con.execute("BEGIN;")
        params = {"scope": scope_text, "offline_mode": offline_mode, "order": order, "coins_limit": coins_limit, "parent_snapshot_key": parent_snapshot_key}
        created_utc = utc_now_iso()
        # new run for refresh, but linked via snapshot parent_ref
        run_id = create_run(con, created_utc, app_version, "created", vs_currency, coins_limit, ["spot"], "by_mcap_rank", SOURCE, params)
        upsert_run_scope(con, run_id, scope_text)

        fetched_utc = utc_now_iso()
        timeframe = "spot"
        snapshot_key = f"SN_{run_id}_{fetched_utc.replace(':','').replace('-','').replace('T','_').replace('Z','')}"
        snapshot_ref = create_snapshot(con, snapshot_key, run_id, fetched_utc, SOURCE, scope_text, timeframe, meta_json=None, parent_snapshot_ref=parent_ref, refresh_reason=reason)

        query = {"vs_currency": vs_currency, "order": order, "coins_limit": coins_limit, "price_change_percentage": "24h"}

        if offline_mode:
            markets = load_offline_sample(paths.samples_dir)
            insert_raw_snapshot(con, run_id, SOURCE, ENDPOINT, json.dumps(query, sort_keys=True), json.dumps(markets), fetched_utc, snapshot_key=snapshot_key, snapshot_ref=snapshot_ref)
            log_cb(f"offline sample loaded count={len(markets)}")
        else:
            headers = {"Accept": "application/json"}
            api_key = secrets.get("COINGECKO_API_KEY", "").strip()
            if api_key:
                headers["x-cg-pro-api-key"] = api_key
            markets = fetch_markets(vs_currency, order, coins_limit, headers, paths.cache_dir, ttl_s,
                                    connect_timeout_s, read_timeout_s, max_attempts, backoff_s, on_429_sleep_s, log_cb)
            insert_raw_snapshot(con, run_id, SOURCE, ENDPOINT, json.dumps(query, sort_keys=True), json.dumps(markets), fetched_utc, snapshot_key=snapshot_key, snapshot_ref=snapshot_ref)
            log_cb(f"fetched count={len(markets)}")

        rows = normalise_rows(markets, run_id, snapshot_key, scope_text, timeframe, fetched_utc, SOURCE, snapshot_ref=snapshot_ref)
        insert_market_snapshots(con, rows)
        con.commit()
        return run_id, snapshot_key
    except Exception:
        try:
            con.rollback()
        except Exception:
            pass
        raise
    finally:
        con.close()


def load_offline_sample(samples_dir: str) -> list:
    p = os.path.join(samples_dir, "coingecko_markets_sample_v1.0a.json")
    if not os.path.isfile(p):
        raise FileNotFoundError("Offline sample not found: " + p)
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)

def run_snapshot_and_topnow(
    project_root: str,
    app_version: str,
    scope_text: str,
    vs_currency: str,
    coins_limit: int,
    order: str,
    topnow_limit: int,
    offline_mode: bool,
    log_cb: Callable[[str], None],
) -> PipelineResult:
    paths = make_paths(project_root)
    ensure_dir(paths.cache_dir)
    ensure_dir(paths.log_dir)

    cfg = parse_simple_yaml(paths.defaults_yaml)
    secrets = parse_secrets_env(paths.secrets_env)

    timeframes = cfg.get("mvp", {}).get("timeframes", ["15m", "1h"])

    connect_timeout_s = int(cfg.get("network", {}).get("connect_timeout_s", 10))
    read_timeout_s = int(cfg.get("network", {}).get("read_timeout_s", 30))
    max_attempts = int(cfg.get("retry", {}).get("max_attempts", 4))
    backoff_s = cfg.get("retry", {}).get("backoff_s", [1, 2, 4, 8])
    on_429_sleep_s = int(cfg.get("rate_limit", {}).get("on_429_sleep_s", 20))
    ttl_s = int(cfg.get("cache", {}).get("ttl_s", 120))

    con = db_connect(paths.db_path)
    try:
        # ---- HARD BOOTSTRAP (schema must exist before any query uses snapshot_ref) ----
        ensure_core_schema(con)
        ensure_core_indexes(con)
        ensure_snapshot_schema(con)
        ensure_indexes(con)
        con.commit()
        # ------------------------------------------------------------------------------

        require_schema(con)
        con.execute("BEGIN;")

        params = {
            "scope": scope_text,
            "offline_mode": offline_mode,
            "order": order,
            "topnow_limit": topnow_limit,
        }

        created_utc = utc_now_iso()
        run_id = create_run(con, created_utc, app_version, "created", vs_currency, coins_limit, timeframes, "by_mcap_rank", SOURCE, params)
        upsert_run_scope(con, run_id, scope_text)

        def slog(step, fr, to, sev, msg):
            # step_name is required by state_log schema; normalize empty to 'pipeline'
            step_name = (step or '').strip() or 'pipeline'
            state_log(con, run_id, fr, to, sev, msg, utc_now_iso(), step_name=step_name)

        slog("run", "", "created", "info", "run created")
        set_run_status(con, run_id, "created")
        slog("run", "created", "scope_selected", "info", "scope stored")
        set_run_status(con, run_id, "scope_selected")
        slog("run", "scope_selected", "sources_ready", "info", "source ready coingecko")
        set_run_status(con, run_id, "sources_ready")
        slog("run", "sources_ready", "data_collecting", "info", "starting data collection")
        set_run_status(con, run_id, "data_collecting")

        fetched_utc = utc_now_iso()
        timeframe = "spot"
        snapshot_key = f"SN_{run_id}_{fetched_utc.replace(':', '').replace('-', '').replace('T', '_').replace('Z', '')}"
        snapshot_ref = create_snapshot(con, snapshot_key, run_id, fetched_utc, SOURCE, scope_text, timeframe, meta_json=None)
        query = {"vs_currency": vs_currency, "order": order, "coins_limit": coins_limit, "price_change_percentage": "24h"}

        if offline_mode:
            markets = load_offline_sample(paths.samples_dir)
            insert_raw_snapshot(con, run_id, SOURCE, ENDPOINT, json.dumps(query, sort_keys=True), json.dumps(markets), fetched_utc, snapshot_key=snapshot_key, snapshot_ref=snapshot_ref)
            slog("run", "data_collecting", "data_collected", "warning", "offline mode used sample raw payload")
            set_run_status(con, run_id, "data_collected")
            log_cb(f"offline sample loaded count={len(markets)}")
        else:
            headers = {"Accept": "application/json"}
            api_key = secrets.get("COINGECKO_API_KEY", "").strip()
            if api_key:
                headers["x-cg-pro-api-key"] = api_key

            markets = fetch_markets(vs_currency, order, coins_limit, headers, paths.cache_dir, ttl_s,
                                    connect_timeout_s, read_timeout_s, max_attempts, backoff_s, on_429_sleep_s, log_cb)
            insert_raw_snapshot(con, run_id, SOURCE, ENDPOINT, json.dumps(query, sort_keys=True), json.dumps(markets), fetched_utc, snapshot_key=snapshot_key, snapshot_ref=snapshot_ref)
            slog("run", "data_collecting", "data_collected", "info", f"fetched markets count={len(markets)}")
            set_run_status(con, run_id, "data_collected")
            log_cb(f"fetched count={len(markets)}")

        slog("run", "data_collected", "raw_saved", "info", "raw snapshot stored")
        set_run_status(con, run_id, "raw_saved")

        rows = normalise_rows(markets, run_id, snapshot_key, scope_text, timeframe, fetched_utc, SOURCE, snapshot_ref=snapshot_ref)
        insert_market_snapshots(con, rows)
        slog("run", "raw_saved", "normalized", "info", f"normalized rows={len(rows)}")
        set_run_status(con, run_id, "normalized")

        candidates = select_candidates(con, snapshot_key, timeframe, topnow_limit)
        sel_params = {"limit": topnow_limit, "order": "rank_asc_mcap_desc"}
        selection_id = create_topnow_selection(con, run_id, snapshot_key, sel_params)
        n_items = insert_topnow_items(con, selection_id, candidates)

        slog("run", "normalized", "topnow_built", "info", f"topnow selection items={n_items}")
        set_run_status(con, run_id, "topnow_built")

        slog("run", "topnow_built", "completed", "info", "phase completed up to candidates")
        set_run_status(con, run_id, "completed")

        con.commit()
        return PipelineResult(run_id=run_id, snapshot_id=snapshot_key, selection_id=selection_id, candidates_n=n_items)
    except Exception:
        try:
            con.rollback()
        except Exception:
            pass
        raise
    finally:
        try:
            con.close()
        except Exception:
            pass

from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, Optional
import sqlite3

@dataclass
class LayerContext:
    run_id: int
    snapshot_ref: int
    snapshot_key: str
    timeframe: str
    vs_currency: str
    scope: str

@dataclass
class LayerResult:
    layer_name: str
    layer_version: str
    status: str  # ok|warning|failed|skipped
    score: Optional[float]
    raw: Dict[str, Any]

class LayerAdapter:
    layer_name: str = "base"
    layer_version: str = "v1"

    def run(self, con: sqlite3.Connection, ctx: LayerContext) -> LayerResult:
        raise NotImplementedError

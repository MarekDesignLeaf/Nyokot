from __future__ import annotations
from typing import Dict, Tuple
import sqlite3

from .util_time import utc_now_iso
from .scoring import spot_basic_score
from .db import resolve_snapshot, table_columns

def compute_and_store_spot_basic(con: sqlite3.Connection, snapshot_id: str | int, timeframe: str = "spot") -> int:
    """
    Compute a lightweight 'spot_basic' score for each row in market_snapshots for a snapshot+timeframe.
    Stores to market_snapshots.base_score.
    Returns number of rows updated.
    """
    cur = con.execute(
        "SELECT unified_symbol, rank, mcap, vol24, change_24h_pct "
        "FROM market_snapshots WHERE snapshot_id=? AND timeframe=?;",
        (snapshot_id, timeframe),
    )
    rows = cur.fetchall()
    scores: Dict[str, float] = {}
    for sym, rank, mcap, vol24, chg24 in rows:
        scores[str(sym)] = float(spot_basic_score(rank, mcap, vol24, chg24))
    con.executemany(
        "UPDATE market_snapshots SET base_score=? WHERE snapshot_id=? AND timeframe=? AND unified_symbol=?;",
        [(scores[sym], snapshot_id, timeframe, sym) for sym in scores.keys()],
    )
    return len(scores)

def apply_scores_to_selection(con: sqlite3.Connection, selection_id: int, snapshot_id: str, timeframe: str = "spot") -> int:
    """
    Copy market_snapshots.base_score (computed) into topnow_selection_items.composite_preview for items in selection.
    Returns number of items updated.
    """
    cur = con.execute(
        "SELECT i.unified_symbol, m.base_score "
        "FROM topnow_selection_items i "
        "LEFT JOIN market_snapshots m "
        "ON m.snapshot_id=? AND m.timeframe=? AND m.unified_symbol=i.unified_symbol "
        "WHERE i.selection_id=?;",
        (snapshot_id, timeframe, selection_id),
    )
    rows = cur.fetchall()
    payload = []
    n = 0
    for sym, sc in rows:
        if sc is None:
            sc = 0.0
        payload.append((float(sc), selection_id, sym))
        n += 1
    con.executemany(
        "UPDATE topnow_selection_items SET composite_preview=? WHERE selection_id=? AND unified_symbol=?;",
        payload,
    )
    return n

def prepare_analysis(con: sqlite3.Connection, selection_id: int, snapshot_id: str, timeframe: str = "spot") -> Tuple[int, int]:
    """
    Convenience: compute scores in market_snapshots and apply into selection preview.
    Returns (market_rows_scored, selection_items_updated).
    """
    m = compute_and_store_spot_basic(con, snapshot_id, timeframe)
    s = apply_scores_to_selection(con, selection_id, snapshot_id, timeframe)
    return m, s


# ---- Multi-layer composite preview (selection table) ----

from .layers_sentiment_fng import fetch_fng_index, score_from_fng_value
from .layers_macro_global import fetch_coingecko_global, score_from_global
from .layers_derivatives_funding import fetch_binance_funding_rate, to_binance_symbol, score_from_funding_rate


def prepare_and_store_composite_preview(con: sqlite3.Connection, selection_id: int, scopes: list[str], timeframe: str = '24h') -> dict:
    """Update topnow_selection_items.composite_preview and reason_json for the given selection.

    scopes are UI scopes: crypto_spot, crypto_derivatives, macro, sentiment, institutions.
    We only use public endpoints that do not require keys. Institutions is recorded as not_implemented.
    """

    scopes_set = set([s.strip() for s in (scopes or []) if s and str(s).strip()])

    # Resolve snapshot_ref from selection
    row = con.execute('SELECT snapshot_ref FROM topnow_selections WHERE selection_id=?;', (selection_id,)).fetchone()
    if not row:
        raise ValueError(f'selection_id not found: {selection_id}')
    snapshot_ref = row[0]

    # Ensure spot base_score exists if crypto_spot requested
    spot_ok = False
    if 'crypto_spot' in scopes_set:
        compute_and_store_spot_basic(con, snapshot_ref, timeframe=timeframe)
        spot_ok = True

    # Global layers
    sentiment = None
    macro = None

    if 'sentiment' in scopes_set:
        try:
            fng = fetch_fng_index()
            sentiment = {
                'fng_value': int(fng['value']),
                'fng_classification': fng.get('classification', ''),
                'score': score_from_fng_value(int(fng['value'])),
                'timestamp': int(fng.get('timestamp') or 0),
                'source': fng.get('source')
            }
        except Exception as e:
            sentiment = {'error': str(e)[:300], 'score': None}

    if 'macro' in scopes_set:
        try:
            g = fetch_coingecko_global()
            macro = {
                'market_cap_change_percentage_24h_usd': float(g['market_cap_change_percentage_24h_usd']),
                'btc_dominance': float(g['btc_dominance']),
                'eth_dominance': float(g['eth_dominance']),
                'score': score_from_global(float(g['market_cap_change_percentage_24h_usd']), float(g['btc_dominance'])),
                'source': g.get('source')
            }
        except Exception as e:
            macro = {'error': str(e)[:300], 'score': None}

    # Per-symbol layer: derivatives funding rate
    funding_scores: dict[str, dict] = {}
    if 'crypto_derivatives' in scopes_set:
        syms = con.execute('SELECT unified_symbol FROM topnow_selection_items WHERE selection_id=? ORDER BY rank ASC;', (selection_id,)).fetchall()
        for (sym,) in syms:
            bsym = to_binance_symbol(sym)
            if not bsym:
                funding_scores[sym] = {'error': 'empty_symbol', 'score': None}
                continue
            try:
                fr = fetch_binance_funding_rate(bsym)
                funding_scores[sym] = {'funding_rate': fr, 'binance_symbol': bsym, 'score': score_from_funding_rate(fr)}
            except Exception as e:
                # Keep error but do not fail whole analysis
                funding_scores[sym] = {'error': str(e)[:240], 'binance_symbol': bsym, 'score': None}

    # Compute composite per symbol
    rows = con.execute('SELECT rank, unified_symbol FROM topnow_selection_items WHERE selection_id=? ORDER BY rank ASC;', (selection_id,)).fetchall()

    updated = 0
    for rank, sym in rows:
        parts = []
        reason = {'scopes': sorted(list(scopes_set))}

        if spot_ok:
            r2 = con.execute('SELECT base_score FROM market_snapshots WHERE snapshot_ref=? AND timeframe=? AND unified_symbol=?;', (snapshot_ref, timeframe, sym)).fetchone()
            if r2 and r2[0] is not None:
                parts.append(float(r2[0]))
                reason['spot_basic'] = float(r2[0])

        if sentiment and sentiment.get('score') is not None:
            parts.append(float(sentiment['score']))
            reason['sentiment_fng'] = sentiment
        elif sentiment:
            reason['sentiment_fng'] = sentiment

        if macro and macro.get('score') is not None:
            parts.append(float(macro['score']))
            reason['macro_global'] = macro
        elif macro:
            reason['macro_global'] = macro

        if sym in funding_scores:
            fs = funding_scores[sym]
            if fs.get('score') is not None:
                parts.append(float(fs['score']))
            reason['derivatives_funding'] = fs

        if 'institutions' in scopes_set:
            reason['institutions'] = {'status': 'not_implemented'}

        if parts:
            comp = sum(parts) / float(len(parts))
        else:
            comp = None

        con.execute(
            'UPDATE topnow_selection_items SET composite_preview=?, reason_json=? WHERE selection_id=? AND unified_symbol=?;',
            (comp, json.dumps(reason, ensure_ascii=True), selection_id, sym)
        )
        updated += 1

    con.commit()

    return {
        'selection_id': selection_id,
        'snapshot_ref': snapshot_ref,
        'updated_items': updated,
        'scopes': sorted(list(scopes_set)),
        'sentiment_ok': bool(sentiment and sentiment.get('score') is not None),
        'macro_ok': bool(macro and macro.get('score') is not None),
        'funding_symbols': len(funding_scores),
    }

from __future__ import annotations
import os, time
from typing import Dict, Any, List, Tuple

def _now() -> float:
    return time.time()

def _safe_remove(path: str) -> bool:
    try:
        os.remove(path)
        return True
    except Exception:
        return False

def cleanup_dir(
    directory: str,
    patterns: List[str],
    keep_days: int = 14,
    keep_last: int = 20,
) -> Dict[str, Any]:
    """Delete old files in directory matching any suffix/patterns.
    Minimal policy:
      - keep all files modified within keep_days
      - among the rest, keep newest keep_last, delete older
    patterns are glob patterns relative to directory.
    """
    rep = {"directory": directory, "matched": 0, "deleted": 0, "kept": 0}
    if not directory:
        return rep
    if not os.path.exists(directory):
        return rep

    # collect
    files: List[Tuple[float, str]] = []
    for pat in patterns:
        for p in glob_glob(os.path.join(directory, pat)):
            if os.path.isfile(p):
                try:
                    m = os.path.getmtime(p)
                except Exception:
                    continue
                files.append((m, p))

    if not files:
        return rep

    files.sort(reverse=True)  # newest first
    rep["matched"] = len(files)

    now = _now()
    cutoff = now - max(0, int(keep_days)) * 86400

    keep = []
    rest = []
    for m, p in files:
        if m >= cutoff:
            keep.append((m, p))
        else:
            rest.append((m, p))

    # keep newest keep_last of rest
    keep_last = max(0, int(keep_last))
    keep.extend(rest[:keep_last])
    delete = rest[keep_last:]

    for _, p in delete:
        if _safe_remove(p):
            rep["deleted"] += 1
    rep["kept"] = rep["matched"] - rep["deleted"]
    return rep

# local glob without importing glob in top-level (avoid name collision)
def glob_glob(pattern: str):
    import glob
    return glob.glob(pattern)

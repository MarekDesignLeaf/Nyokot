from __future__ import annotations
import sqlite3
from typing import List, Tuple, Optional, Dict
from .scoring import spot_basic_score
from .db import resolve_snapshot, table_columns

def ensure_watchlist_schema(con: sqlite3.Connection) -> None:
    con.execute(
        "CREATE TABLE IF NOT EXISTS watchlist ("
        "watch_id INTEGER PRIMARY KEY AUTOINCREMENT, "
        "unified_symbol TEXT NOT NULL UNIQUE, "
        "tag TEXT DEFAULT '', "
        "stage TEXT DEFAULT 'new', "
        "tracking_since_utc TEXT NOT NULL, "
        "entry_snapshot_id TEXT DEFAULT '', "
        "entry_score REAL DEFAULT 0.0"
        ");"
    )
    con.execute(
        "CREATE TABLE IF NOT EXISTS watchlist_metrics ("
        "watch_id INTEGER PRIMARY KEY, "
        "last_refreshed_utc TEXT, "
        "last_price REAL, "
        "last_chg24_pct REAL, "
        "last_score REAL, "
        "FOREIGN KEY(watch_id) REFERENCES watchlist(watch_id) ON DELETE CASCADE"
        ");"
    )
    con.execute(
        "CREATE TABLE IF NOT EXISTS watchlist_alerts ("
        "alert_id INTEGER PRIMARY KEY AUTOINCREMENT, "
        "watch_id INTEGER NOT NULL, "
        "created_utc TEXT NOT NULL, "
        "severity TEXT NOT NULL, "
        "message TEXT NOT NULL, "
        "FOREIGN KEY(watch_id) REFERENCES watchlist(watch_id) ON DELETE CASCADE"
        ");"
    )

def add_watch(con: sqlite3.Connection, symbol: str, tag: str, stage: str, now_utc: str,
              entry_snapshot_id: str = "", entry_score: float = 0.0) -> int:
    sym = symbol.strip().upper()
    con.execute(
        "INSERT OR IGNORE INTO watchlist(unified_symbol, tag, stage, tracking_since_utc, entry_snapshot_id, entry_score) "
        "VALUES (?,?,?,?,?,?);",
        (sym, tag or "", stage or "new", now_utc, entry_snapshot_id or "", float(entry_score or 0.0)),
    )
    row = con.execute("SELECT watch_id FROM watchlist WHERE unified_symbol=?;", (sym,)).fetchone()
    if not row:
        raise RuntimeError("Failed to add to watchlist")
    wid = int(row[0])
    con.execute("INSERT OR IGNORE INTO watchlist_metrics(watch_id) VALUES (?);", (wid,))
    return wid

def remove_watch(con: sqlite3.Connection, watch_id: int) -> None:
    con.execute("DELETE FROM watchlist WHERE watch_id=?;", (int(watch_id),))

def list_watch(con: sqlite3.Connection) -> List[Tuple]:
    q = (
        "SELECT w.watch_id, w.unified_symbol, w.tag, w.stage, w.tracking_since_utc, "
        "w.entry_snapshot_id, w.entry_score, "
        "m.last_refreshed_utc, m.last_price, m.last_chg24_pct, m.last_score "
        "FROM watchlist w "
        "LEFT JOIN watchlist_metrics m ON m.watch_id=w.watch_id "
        "ORDER BY w.tracking_since_utc DESC;"
    )
    return con.execute(q).fetchall()

def refresh_watch(con: sqlite3.Connection, snapshot_id: str, timeframe: str, now_utc: str,
                  alert_drop_points: float = 15.0) -> int:
    """
    Refresh metrics for each watchlist symbol by looking up current market_snapshots for snapshot_id+timeframe.
    Creates an alert if score drops by >= alert_drop_points since last refresh.
    Returns number refreshed.
    """
    ensure_watchlist_schema(con)
    items = con.execute("SELECT watch_id, unified_symbol FROM watchlist;").fetchall()
    n = 0
    for wid, sym in items:
        row = con.execute(
            "SELECT rank, mcap, vol24, change_24h_pct, price "
            "FROM market_snapshots WHERE snapshot_id=? AND timeframe=? AND unified_symbol=?;",
            (snapshot_id, timeframe, sym),
        ).fetchone()
        if not row:
            continue
        rank, mcap, vol24, chg24, price = row
        new_score = float(spot_basic_score(rank, mcap, vol24, chg24))
        old = con.execute("SELECT last_score FROM watchlist_metrics WHERE watch_id=?;", (wid,)).fetchone()
        old_score = float(old[0]) if old and old[0] is not None else None
        con.execute(
            "INSERT OR REPLACE INTO watchlist_metrics(watch_id, last_refreshed_utc, last_price, last_chg24_pct, last_score) "
            "VALUES (?,?,?,?,?);",
            (wid, now_utc, price, chg24, new_score),
        )
        if old_score is not None and (old_score - new_score) >= float(alert_drop_points):
            con.execute(
                "INSERT INTO watchlist_alerts(watch_id, created_utc, severity, message) VALUES (?,?,?,?);",
                (wid, now_utc, "warning", f"Score drop {old_score:.1f} -> {new_score:.1f} (>= {alert_drop_points:.1f})"),
            )
        n += 1
    return n

def list_alerts(con: sqlite3.Connection, limit: int = 100) -> List[Tuple]:
    q = (
        "SELECT a.alert_id, a.created_utc, a.severity, w.unified_symbol, a.message "
        "FROM watchlist_alerts a "
        "JOIN watchlist w ON w.watch_id=a.watch_id "
        "ORDER BY a.alert_id DESC LIMIT ?;"
    )
    return con.execute(q, (int(limit),)).fetchall()

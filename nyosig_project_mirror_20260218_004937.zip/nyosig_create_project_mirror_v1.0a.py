#!/usr/bin/env python3
# nyosig_create_project_mirror_v1.0a
# Creates a portable mirror of the entire project directory including files.
# Output is a ZIP plus a manifest (sha256) so the mirror can be verified and reused later.

import os
import sys
import time
import json
import hashlib
import zipfile
from pathlib import Path

PROJECT_ROOT_DEFAULT = "/storage/emulated/0/NyoSig/NyoSig_Cryptolytix"

EXCLUDE_DIR_NAMES = {
    "__pycache__",
    ".git",
    ".idea",
    ".vscode",
}

EXCLUDE_FILE_SUFFIXES = {
    ".pyc",
    ".pyo",
    ".tmp",
    ".log",
}

def utc_stamp():
    return time.strftime("%Y%m%d_%H%M%S", time.gmtime())

def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            b = f.read(chunk_size)
            if not b:
                break
            h.update(b)
    return h.hexdigest()

def should_skip_dir(dir_name: str) -> bool:
    return dir_name in EXCLUDE_DIR_NAMES

def should_skip_file(path: Path) -> bool:
    if path.name.startswith(".DS_Store"):
        return True
    suf = path.suffix.lower()
    if suf in EXCLUDE_FILE_SUFFIXES:
        return True
    return False

def die(msg: str, code: int = 1):
    print(msg)
    sys.exit(code)

def main():
    project_root = os.environ.get("NYOSIG_PROJECT_ROOT", PROJECT_ROOT_DEFAULT)
    if len(sys.argv) > 1 and sys.argv[1].strip():
        project_root = sys.argv[1].strip()

    root = Path(project_root)
    if not root.is_dir():
        die("Project root not found: " + str(root))

    mirror_dir = root / "mirrors"
    mirror_dir.mkdir(parents=True, exist_ok=True)

    stamp = utc_stamp()
    zip_name = f"nyosig_project_mirror_{stamp}.zip"
    manifest_name = f"nyosig_project_mirror_{stamp}_manifest.json"

    zip_path = mirror_dir / zip_name
    manifest_path = mirror_dir / manifest_name

    file_entries = []
    total_files = 0
    total_bytes = 0

    # Collect files first to get stable ordering
    all_files = []
    for dirpath, dirnames, filenames in os.walk(root):
        dp = Path(dirpath)

        # Skip mirror output folder itself to prevent recursion
        if dp == mirror_dir or mirror_dir in dp.parents:
            dirnames[:] = []
            continue

        # Skip excluded dirs
        dirnames[:] = [d for d in dirnames if not should_skip_dir(d)]

        for fn in filenames:
            p = dp / fn
            if should_skip_file(p):
                continue
            if not p.is_file():
                continue
            all_files.append(p)

    all_files.sort(key=lambda p: str(p).lower())

    print("Project root: " + str(root))
    print("Files to mirror: " + str(len(all_files)))
    print("Output ZIP: " + str(zip_path))
    print("Output manifest: " + str(manifest_path))

    # Create ZIP
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in all_files:
            rel = p.relative_to(root).as_posix()
            size = p.stat().st_size
            h = sha256_file(p)
            z.write(p, arcname=rel)

            file_entries.append({
                "path": rel,
                "bytes": size,
                "sha256": h,
                "mtime_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(p.stat().st_mtime)),
            })
            total_files += 1
            total_bytes += size

    # Hash the ZIP itself
    zip_sha = sha256_file(zip_path)

    manifest = {
        "format": "nyosig_project_mirror_manifest",
        "version": "1.0a",
        "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "project_root": str(root),
        "zip_file": zip_path.name,
        "zip_sha256": zip_sha,
        "total_files": total_files,
        "total_bytes": total_bytes,
        "excluded_dir_names": sorted(list(EXCLUDE_DIR_NAMES)),
        "excluded_file_suffixes": sorted(list(EXCLUDE_FILE_SUFFIXES)),
        "files": file_entries,
    }

    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    print("OK")
    print("ZIP sha256: " + zip_sha)
    print("Mirror created in: " + str(mirror_dir))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())

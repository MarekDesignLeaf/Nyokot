#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# nyosig_cryptolytix_gui_v1.1d.py
# Tkinter only. No PySimpleGUI.
# ASCII only guard.
# Works with multiple DB schema variants by column introspection.
#
# Controls
# Load N = how many rows to load from DB (ordered by Vol24 desc)
# Top N = how many from loaded set to compute and export
# Mode = Conservative Balanced Aggressive
# TF = 1m 5m 15m 30m 1h 4h 1d 1w (used for OHLCV checks and simple trend)
# Export TOP to DB only (no Export DB button)
#
# DB root must be exactly:
# /storage/emulated/0/NyoSig/NyoSig_Cryptolytix/

import json
import math
import os
import sqlite3
import sys
import time
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime, timezone

PROJECT_ROOT = "/storage/emulated/0/NyoSig/NyoSig_Cryptolytix"
DB_PATH = os.path.join(PROJECT_ROOT, "db", "nyosig_cryptolytix.db")

DEFAULT_FONT_SIZE = 4

TIMEFRAMES = ["1m", "5m", "15m", "30m", "1h", "4h", "1d", "1w"]
MODES = ["Conservative", "Balanced", "Aggressive"]

STABLES = {
    "USDT", "USDC", "DAI", "TUSD", "FDUSD", "USDP", "BUSD", "EURC", "USDE", "USD1"
}

def ascii_guard():
    try:
        with open(__file__, "rb") as f:
            b = f.read()
        for i, ch in enumerate(b):
            if ch >= 128:
                raise RuntimeError("Non ASCII byte found in script at offset: %d" % i)
    except Exception as e:
        messagebox.showerror("Error", "ASCII guard failed: %s" % str(e))
        raise

def utc_now_iso():
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()

def safe_float(x, default=0.0):
    try:
        if x is None:
            return default
        return float(x)
    except Exception:
        return default

def safe_int(x, default=None):
    try:
        if x is None:
            return default
        return int(x)
    except Exception:
        return default

def clamp(v, lo, hi):
    return max(lo, min(hi, v))

def db_connect():
    if not os.path.exists(DB_PATH):
        raise RuntimeError("DB not found: %s" % DB_PATH)
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def table_columns(con, table):
    cur = con.execute("PRAGMA table_info(%s)" % table)
    cols = []
    for r in cur.fetchall():
        cols.append(r["name"])
    return cols

def has_table(con, table):
    cur = con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?;", (table,))
    return cur.fetchone() is not None

def pick_first(existing_cols, candidates):
    for c in candidates:
        if c in existing_cols:
            return c
    return None

def build_spot_select(con):
    cols = table_columns(con, "spot_markets")

    col_symbol = pick_first(cols, ["symbol", "base", "base_symbol", "coin_symbol", "unified_symbol"])
    col_pair = pick_first(cols, ["pair", "trading_pair", "market", "symbol_pair"])
    col_price = pick_first(cols, ["price", "current_price", "last_price"])
    col_chg24 = pick_first(cols, ["chg_24h_pct", "change_24h_pct", "price_change_percentage_24h", "price_change_percentage_24h_in_currency"])
    col_vol24 = pick_first(cols, ["volume_24h", "vol_24h", "total_volume", "vol24"])
    col_mcap = pick_first(cols, ["market_cap", "mcap"])
    col_rank = pick_first(cols, ["rank", "market_cap_rank"])
    col_spot_score = pick_first(cols, ["spot_score", "score"])

    missing = []
    if col_symbol is None:
        missing.append("symbol")
    if col_vol24 is None:
        missing.append("volume_24h")

    if missing:
        raise RuntimeError(
            "spot_markets missing required columns: %s. Found columns: %s"
            % (", ".join(missing), ", ".join(cols))
        )

    select_parts = []
    select_parts.append("%s AS symbol" % col_symbol)
    if col_pair:
        select_parts.append("%s AS pair" % col_pair)
    else:
        select_parts.append("NULL AS pair")
    if col_rank:
        select_parts.append("%s AS rank" % col_rank)
    else:
        select_parts.append("NULL AS rank")
    if col_spot_score:
        select_parts.append("%s AS spot_score" % col_spot_score)
    else:
        select_parts.append("NULL AS spot_score")
    if col_price:
        select_parts.append("%s AS price" % col_price)
    else:
        select_parts.append("NULL AS price")
    if col_chg24:
        select_parts.append("%s AS chg24" % col_chg24)
    else:
        select_parts.append("NULL AS chg24")
    select_parts.append("%s AS vol24" % col_vol24)
    if col_mcap:
        select_parts.append("%s AS mcap" % col_mcap)
    else:
        select_parts.append("NULL AS mcap")

    # Run id link if exists
    col_run_id = pick_first(cols, ["run_id", "run_tag", "run"])
    if col_run_id:
        select_parts.append("%s AS run_id" % col_run_id)
    else:
        select_parts.append("NULL AS run_id")

    select_sql = "SELECT %s FROM spot_markets" % (", ".join(select_parts))
    return select_sql

def latest_run_meta(con):
    if not has_table(con, "runs"):
        return None

    cols = table_columns(con, "runs")
    col_run_id = pick_first(cols, ["run_id", "id"])
    col_created = pick_first(cols, ["created_utc", "created_at", "timestamp", "created"])
    col_status = pick_first(cols, ["status", "state"])
    col_vs = pick_first(cols, ["vs_currency", "vs"])
    col_coins = pick_first(cols, ["coins_limit", "coins", "universe_size"])
    col_sort = pick_first(cols, ["sort_mode", "sort"])
    col_source = pick_first(cols, ["source", "sources"])

    if not col_run_id:
        return None

    order_col = col_created if col_created else col_run_id
    sql = "SELECT * FROM runs ORDER BY %s DESC LIMIT 1" % order_col
    r = con.execute(sql).fetchone()
    if not r:
        return None

    meta = {
        "run_id": r[col_run_id],
        "created": r[col_created] if col_created and col_created in r.keys() else None,
        "status": r[col_status] if col_status and col_status in r.keys() else None,
        "vs": r[col_vs] if col_vs and col_vs in r.keys() else None,
        "coins": r[col_coins] if col_coins and col_coins in r.keys() else None,
        "sort": r[col_sort] if col_sort and col_sort in r.keys() else None,
        "source": r[col_source] if col_source and col_source in r.keys() else None,
    }
    return meta

def ohlcv_has_symbol_tf(con, symbol, tf):
    if not has_table(con, "ohlcv"):
        return False
    cols = table_columns(con, "ohlcv")
    col_symbol = pick_first(cols, ["symbol", "base", "base_symbol", "unified_symbol"])
    col_tf = pick_first(cols, ["timeframe", "tf", "interval"])
    if not col_symbol or not col_tf:
        return False
    sql = "SELECT 1 FROM ohlcv WHERE %s=? AND %s=? LIMIT 1" % (col_symbol, col_tf)
    r = con.execute(sql, (symbol, tf)).fetchone()
    return r is not None

def ohlcv_simple_trend_score(con, symbol, tf):
    # Return 0..100 based on last close vs first close in a recent window
    if not has_table(con, "ohlcv"):
        return 50.0
    cols = table_columns(con, "ohlcv")
    col_symbol = pick_first(cols, ["symbol", "base", "base_symbol", "unified_symbol"])
    col_tf = pick_first(cols, ["timeframe", "tf", "interval"])
    col_ts = pick_first(cols, ["ts_ms", "open_time", "timestamp"])
    col_c = pick_first(cols, ["c", "close", "close_price"])
    if not col_symbol or not col_tf or not col_ts or not col_c:
        return 50.0

    sql = "SELECT %s AS ts, %s AS close FROM ohlcv WHERE %s=? AND %s=? ORDER BY %s DESC LIMIT 120" % (
        col_ts, col_c, col_symbol, col_tf, col_ts
    )
    rows = con.execute(sql, (symbol, tf)).fetchall()
    if not rows or len(rows) < 10:
        return 50.0
    closes = [safe_float(r["close"], 0.0) for r in rows][::-1]
    first_c = closes[0]
    last_c = closes[-1]
    if first_c <= 0:
        return 50.0
    ret = (last_c / first_c) - 1.0
    # map -10%..+10% to 0..100, clamp outside
    v = (ret + 0.10) / 0.20
    return clamp(100.0 * v, 0.0, 100.0)

def compute_top_score(row, mode, tf, trend_score):
    # Must prefer Vol24 first in selection, but TopScore is for ordering within top list.
    # All outputs 1..100.
    vol = safe_float(row.get("vol24"), 0.0)
    mcap = safe_float(row.get("mcap"), 0.0)
    rank = safe_int(row.get("rank"), None)
    chg24 = safe_float(row.get("chg24"), 0.0)
    spot_score = safe_float(row.get("spot_score"), 50.0)

    vol_s = 0.0
    if vol > 0:
        vol_s = clamp(20.0 * math.log10(vol), 1.0, 100.0)
    else:
        vol_s = 1.0

    mcap_s = 0.0
    if mcap > 0:
        mcap_s = clamp(18.0 * math.log10(mcap), 1.0, 100.0)
    else:
        mcap_s = 1.0

    if rank is None:
        rank_s = 50.0
    else:
        rank_s = 100.0 * math.exp(-0.02 * max(float(rank) - 1.0, 0.0))
        rank_s = clamp(rank_s, 1.0, 100.0)

    move = abs(chg24)
    if move <= 3.0:
        move_s = 95.0
    elif move <= 8.0:
        move_s = 80.0
    elif move <= 15.0:
        move_s = 60.0
    elif move <= 30.0:
        move_s = 35.0
    else:
        move_s = 15.0

    t = clamp(trend_score, 0.0, 100.0)

    if mode == "Conservative":
        # Favor big, liquid, stable
        score = 0.40 * rank_s + 0.30 * vol_s + 0.20 * move_s + 0.10 * mcap_s
    elif mode == "Aggressive":
        # Favor liquidity + trend, accept more movement
        score = 0.35 * vol_s + 0.35 * t + 0.15 * spot_score + 0.15 * mcap_s
    else:
        # Balanced
        score = 0.35 * vol_s + 0.25 * rank_s + 0.20 * t + 0.20 * move_s

    return int(round(clamp(score, 1.0, 100.0)))

def ensure_export_table(con):
    con.execute(
        """
        CREATE TABLE IF NOT EXISTS top_exports (
            export_id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_utc TEXT NOT NULL,
            run_id TEXT,
            mode TEXT NOT NULL,
            timeframe TEXT NOT NULL,
            load_n INTEGER NOT NULL,
            top_n INTEGER NOT NULL,
            filters_json TEXT NOT NULL
        );
        """
    )
    con.execute(
        """
        CREATE TABLE IF NOT EXISTS top_export_items (
            export_id INTEGER NOT NULL,
            rank_in_export INTEGER NOT NULL,
            symbol TEXT NOT NULL,
            pair TEXT,
            top_score INTEGER,
            spot_score INTEGER,
            price REAL,
            chg24 REAL,
            vol24 REAL,
            mcap REAL,
            mcap_rank INTEGER,
            trend_score REAL,
            PRIMARY KEY (export_id, rank_in_export)
        );
        """
    )

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("NyoSig Cryptolytix GUI v1.1d")
        self.geometry("1200x720")

        self.loaded_rows = []
        self.filtered_rows = []
        self.top_rows = []
        self.run_meta = None

        self.font_size = tk.IntVar(value=DEFAULT_FONT_SIZE)
        self.load_n = tk.IntVar(value=300)
        self.top_n = tk.IntVar(value=50)
        self.mode = tk.StringVar(value="Balanced")
        self.tf = tk.StringVar(value="4h")

        self.exclude_stable = tk.BooleanVar(value=True)
        self.require_ohlcv = tk.BooleanVar(value=False)
        self.min_mcap = tk.DoubleVar(value=0.0)
        self.min_vol24 = tk.DoubleVar(value=0.0)
        self.max_move = tk.DoubleVar(value=0.0)

        self._build_ui()
        self._apply_font()

        self._log("Ready")

    def _build_ui(self):
        top = ttk.Frame(self)
        top.pack(side=tk.TOP, fill=tk.X, padx=6, pady=6)

        row0 = ttk.Frame(top)
        row0.pack(side=tk.TOP, fill=tk.X)

        self.btn_refresh = ttk.Button(row0, text="Refresh", command=self.on_refresh)
        self.btn_refresh.grid(row=0, column=0, padx=3, pady=2)

        ttk.Label(row0, text="Load").grid(row=0, column=1, padx=3, pady=2, sticky="e")
        self.ent_load = ttk.Entry(row0, textvariable=self.load_n, width=6)
        self.ent_load.grid(row=0, column=2, padx=3, pady=2)

        self.btn_load = ttk.Button(row0, text="Apply", command=self.on_load_apply)
        self.btn_load.grid(row=0, column=3, padx=3, pady=2)

        ttk.Label(row0, text="Top").grid(row=0, column=4, padx=3, pady=2, sticky="e")
        self.ent_top = ttk.Entry(row0, textvariable=self.top_n, width=6)
        self.ent_top.grid(row=0, column=5, padx=3, pady=2)

        self.btn_recalc = ttk.Button(row0, text="Recalc TOP", command=self.on_recalc_top)
        self.btn_recalc.grid(row=0, column=6, padx=3, pady=2)

        ttk.Label(row0, text="Mode").grid(row=0, column=7, padx=3, pady=2, sticky="e")
        self.cmb_mode = ttk.Combobox(row0, textvariable=self.mode, values=MODES, width=12, state="readonly")
        self.cmb_mode.grid(row=0, column=8, padx=3, pady=2)

        ttk.Label(row0, text="TF").grid(row=0, column=9, padx=3, pady=2, sticky="e")
        self.cmb_tf = ttk.Combobox(row0, textvariable=self.tf, values=TIMEFRAMES, width=6, state="readonly")
        self.cmb_tf.grid(row=0, column=10, padx=3, pady=2)

        ttk.Label(row0, text="Font").grid(row=0, column=11, padx=3, pady=2, sticky="e")
        self.spin_font = ttk.Spinbox(row0, from_=3, to=20, textvariable=self.font_size, width=4)
        self.spin_font.grid(row=0, column=12, padx=3, pady=2)

        self.btn_font = ttk.Button(row0, text="Apply", command=self._apply_font)
        self.btn_font.grid(row=0, column=13, padx=3, pady=2)

        self.btn_export = ttk.Button(row0, text="Export TOP to DB", command=self.on_export_top)
        self.btn_export.grid(row=0, column=14, padx=6, pady=2)

        row1 = ttk.Frame(top)
        row1.pack(side=tk.TOP, fill=tk.X)

        self.chk_stable = ttk.Checkbutton(row1, text="Exclude stable", variable=self.exclude_stable)
        self.chk_stable.grid(row=0, column=0, padx=3, pady=2, sticky="w")

        self.chk_ohlcv = ttk.Checkbutton(row1, text="Require OHLCV", variable=self.require_ohlcv)
        self.chk_ohlcv.grid(row=0, column=1, padx=3, pady=2, sticky="w")

        ttk.Label(row1, text="Min mcap").grid(row=0, column=2, padx=3, pady=2, sticky="e")
        self.ent_min_mcap = ttk.Entry(row1, textvariable=self.min_mcap, width=10)
        self.ent_min_mcap.grid(row=0, column=3, padx=3, pady=2)

        ttk.Label(row1, text="Min vol24").grid(row=0, column=4, padx=3, pady=2, sticky="e")
        self.ent_min_vol = ttk.Entry(row1, textvariable=self.min_vol24, width=10)
        self.ent_min_vol.grid(row=0, column=5, padx=3, pady=2)

        ttk.Label(row1, text="Max 24h move pct").grid(row=0, column=6, padx=3, pady=2, sticky="e")
        self.ent_max_move = ttk.Entry(row1, textvariable=self.max_move, width=8)
        self.ent_max_move.grid(row=0, column=7, padx=3, pady=2)

        self.btn_filters = ttk.Button(row1, text="Apply filters", command=self.on_apply_filters)
        self.btn_filters.grid(row=0, column=8, padx=6, pady=2)

        # Meta
        self.lbl_db = ttk.Label(top, text="DB: %s" % DB_PATH)
        self.lbl_db.pack(side=tk.TOP, anchor="w")

        self.lbl_run = ttk.Label(top, text="Run: (none)")
        self.lbl_run.pack(side=tk.TOP, anchor="w")

        # Table
        mid = ttk.Frame(self)
        mid.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=6, pady=6)

        cols = ["Symbol", "Pair", "Rank", "SpotS", "TopS", "Price", "24h%", "Vol24", "MCap", "Trend"]
        self.tree = ttk.Treeview(mid, columns=cols, show="headings", height=18)
        for c in cols:
            self.tree.heading(c, text=c)
            self.tree.column(c, width=90, anchor="w")
        self.tree.column("Symbol", width=90)
        self.tree.column("Pair", width=110)
        self.tree.column("MCap", width=140)
        self.tree.column("Vol24", width=140)

        yscroll = ttk.Scrollbar(mid, orient=tk.VERTICAL, command=self.tree.yview)
        xscroll = ttk.Scrollbar(mid, orient=tk.HORIZONTAL, command=self.tree.xview)
        self.tree.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")
        mid.grid_rowconfigure(0, weight=1)
        mid.grid_columnconfigure(0, weight=1)

        # Log
        bot = ttk.Frame(self)
        bot.pack(side=tk.BOTTOM, fill=tk.BOTH, padx=6, pady=6)
        self.txt = tk.Text(bot, height=7, wrap="word")
        self.txt.pack(side=tk.TOP, fill=tk.BOTH, expand=True)

    def _apply_font(self):
        try:
            fs = int(self.font_size.get())
        except Exception:
            fs = DEFAULT_FONT_SIZE
            self.font_size.set(fs)

        style = ttk.Style()
        style.configure("Treeview", font=("TkDefaultFont", fs))
        style.configure("Treeview.Heading", font=("TkDefaultFont", fs))
        self.txt.configure(font=("TkDefaultFont", fs))
        self._log("Font set to %d" % fs)

    def _log(self, s):
        self.txt.insert("end", s + "\n")
        self.txt.see("end")

    def _clear_table(self):
        for iid in self.tree.get_children():
            self.tree.delete(iid)

    def on_refresh(self):
        try:
            con = db_connect()
            try:
                self.run_meta = latest_run_meta(con)
            finally:
                con.close()

            if self.run_meta:
                self.lbl_run.config(
                    text="run_id: %s  created: %s  status: %s  vs: %s  coins: %s  sort: %s  source: %s"
                    % (
                        str(self.run_meta.get("run_id")),
                        str(self.run_meta.get("created")),
                        str(self.run_meta.get("status")),
                        str(self.run_meta.get("vs")),
                        str(self.run_meta.get("coins")),
                        str(self.run_meta.get("sort")),
                        str(self.run_meta.get("source")),
                    )
                )
            else:
                self.lbl_run.config(text="Run: (no runs table or empty)")

            self._log("Refreshed")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def on_load_apply(self):
        try:
            n = int(self.load_n.get())
            if n <= 0:
                raise RuntimeError("Load must be > 0")
            self.load_from_db(n)
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def load_from_db(self, n):
        con = db_connect()
        try:
            if not has_table(con, "spot_markets"):
                raise RuntimeError("Table spot_markets not found in DB")

            select_sql = build_spot_select(con)

            # Always load ordered by Vol24 desc
            sql = "%s ORDER BY vol24 DESC LIMIT %d" % (select_sql, int(n))
            rows = con.execute(sql).fetchall()

            out = []
            for r in rows:
                sym = (r["symbol"] or "").upper().strip()
                pair = r["pair"]
                if not pair:
                    pair = "%s/USD" % sym if sym else None

                out.append(
                    {
                        "symbol": sym,
                        "pair": pair,
                        "rank": safe_int(r["rank"], None),
                        "spot_score": safe_int(r["spot_score"], None),
                        "price": safe_float(r["price"], 0.0),
                        "chg24": safe_float(r["chg24"], 0.0),
                        "vol24": safe_float(r["vol24"], 0.0),
                        "mcap": safe_float(r["mcap"], 0.0),
                        "run_id": r["run_id"],
                    }
                )

            self.loaded_rows = out
            self.filtered_rows = []
            self.top_rows = []

            self._log("Loaded %d rows ordered by Vol24 desc" % len(out))
            self.on_apply_filters()
        finally:
            con.close()

    def on_apply_filters(self):
        try:
            rows = list(self.loaded_rows)
            if not rows:
                self._clear_table()
                return

            excl = bool(self.exclude_stable.get())
            req_ohlcv = bool(self.require_ohlcv.get())
            min_mcap = safe_float(self.min_mcap.get(), 0.0)
            min_vol = safe_float(self.min_vol24.get(), 0.0)
            max_move = safe_float(self.max_move.get(), 0.0)
            tf = self.tf.get().strip()

            con = db_connect()
            try:
                filtered = []
                for r in rows:
                    sym = r["symbol"]
                    if not sym:
                        continue
                    if excl and sym in STABLES:
                        continue
                    if min_mcap > 0 and r["mcap"] < min_mcap:
                        continue
                    if min_vol > 0 and r["vol24"] < min_vol:
                        continue
                    if max_move > 0 and abs(r["chg24"]) > max_move:
                        continue
                    if req_ohlcv:
                        if not ohlcv_has_symbol_tf(con, sym, tf):
                            continue
                    filtered.append(r)
            finally:
                con.close()

            self.filtered_rows = filtered
            self._log("Filtered: %d" % len(filtered))

            # Auto compute top after filters
            self.on_recalc_top()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def on_recalc_top(self):
        try:
            top_n = int(self.top_n.get())
            if top_n <= 0:
                raise RuntimeError("Top must be > 0")

            mode = self.mode.get().strip()
            tf = self.tf.get().strip()

            base = list(self.filtered_rows) if self.filtered_rows else list(self.loaded_rows)
            if not base:
                self._clear_table()
                return

            # Selection must be by Vol24 first
            base_sorted = sorted(base, key=lambda x: safe_float(x.get("vol24"), 0.0), reverse=True)

            # Compute trend only for candidates we might keep (cap at 200 to avoid slow DB queries)
            cap = min(len(base_sorted), max(200, top_n * 4))
            candidates = base_sorted[:cap]

            con = db_connect()
            try:
                for r in candidates:
                    sym = r["symbol"]
                    tr = ohlcv_simple_trend_score(con, sym, tf)
                    r["trend"] = tr
                    r["top_score"] = compute_top_score(r, mode, tf, tr)
            finally:
                con.close()

            # Now order top list by TopScore desc, tie break by Vol24 desc, then Rank asc if available
            def rank_key(v):
                rr = v.get("rank")
                return rr if rr is not None else 999999

            ordered = sorted(
                candidates,
                key=lambda x: (safe_int(x.get("top_score"), 0), safe_float(x.get("vol24"), 0.0), -rank_key(x)),
                reverse=True,
            )

            self.top_rows = ordered[:top_n]
            self._render_table(self.top_rows)
            self._log("Recalc TOP done: %d" % len(self.top_rows))
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _render_table(self, rows):
        self._clear_table()
        for r in rows:
            sym = r.get("symbol", "")
            pair = r.get("pair", "")
            rank = r.get("rank", "")
            spot_s = r.get("spot_score", "")
            top_s = r.get("top_score", "")
            price = r.get("price", 0.0)
            chg24 = r.get("chg24", 0.0)
            vol24 = r.get("vol24", 0.0)
            mcap = r.get("mcap", 0.0)
            trend = r.get("trend", "")

            self.tree.insert(
                "",
                "end",
                values=(
                    sym,
                    pair,
                    rank if rank is not None else "",
                    spot_s if spot_s is not None else "",
                    top_s if top_s is not None else "",
                    ("%.8f" % price) if price is not None else "",
                    ("%.2f" % chg24) if chg24 is not None else "",
                    ("%.0f" % vol24) if vol24 is not None else "",
                    ("%.0f" % mcap) if mcap is not None else "",
                    ("%.1f" % trend) if isinstance(trend, (int, float)) else "",
                ),
            )

    def on_export_top(self):
        try:
            if not self.top_rows:
                raise RuntimeError("No TOP computed yet")

            mode = self.mode.get().strip()
            tf = self.tf.get().strip()
            load_n = int(self.load_n.get())
            top_n = int(self.top_n.get())

            filters = {
                "exclude_stable": bool(self.exclude_stable.get()),
                "require_ohlcv": bool(self.require_ohlcv.get()),
                "min_mcap": safe_float(self.min_mcap.get(), 0.0),
                "min_vol24": safe_float(self.min_vol24.get(), 0.0),
                "max_move": safe_float(self.max_move.get(), 0.0),
            }

            run_id = None
            # Try take from rows
            for r in self.top_rows:
                if r.get("run_id"):
                    run_id = r.get("run_id")
                    break
            if self.run_meta and self.run_meta.get("run_id"):
                run_id = self.run_meta.get("run_id")

            con = db_connect()
            try:
                con.execute("BEGIN;")
                ensure_export_table(con)

                cur = con.execute(
                    "INSERT INTO top_exports (created_utc, run_id, mode, timeframe, load_n, top_n, filters_json) VALUES (?, ?, ?, ?, ?, ?, ?);",
                    (utc_now_iso(), str(run_id) if run_id is not None else None, mode, tf, load_n, top_n, json.dumps(filters, separators=(",", ":"))),
                )
                export_id = cur.lastrowid

                idx = 1
                for r in self.top_rows:
                    con.execute(
                        """
                        INSERT INTO top_export_items
                        (export_id, rank_in_export, symbol, pair, top_score, spot_score, price, chg24, vol24, mcap, mcap_rank, trend_score)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
                        """,
                        (
                            export_id,
                            idx,
                            r.get("symbol"),
                            r.get("pair"),
                            safe_int(r.get("top_score"), None),
                            safe_int(r.get("spot_score"), None),
                            safe_float(r.get("price"), None),
                            safe_float(r.get("chg24"), None),
                            safe_float(r.get("vol24"), None),
                            safe_float(r.get("mcap"), None),
                            safe_int(r.get("rank"), None),
                            safe_float(r.get("trend"), None),
                        ),
                    )
                    idx += 1

                con.commit()
            except Exception:
                con.rollback()
                raise
            finally:
                con.close()

            self._log("Exported TOP to DB. export_id: %d" % int(export_id))
            messagebox.showinfo("OK", "Exported TOP to DB\nexport_id: %d" % int(export_id))
        except Exception as e:
            messagebox.showerror("Error", str(e))

def main():
    ascii_guard()
    app = App()
    app.mainloop()

if __name__ == "__main__":
    main()
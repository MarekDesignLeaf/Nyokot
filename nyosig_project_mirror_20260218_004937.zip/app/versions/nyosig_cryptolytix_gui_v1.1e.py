#!/usr/bin/env python3
# nyosig_cryptolytix_gui_v1.1e
# Tkinter only, no external GUI libs
# ASCII only, hard fail if any non ASCII char exists in this file

import os
import sys
import json
import math
import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime, timezone

PROJECT_ROOT = "/storage/emulated/0/NyoSig/NyoSig_Cryptolytix"
DB_PATH = os.path.join(PROJECT_ROOT, "db", "nyosig_cryptolytix.db")

DEFAULT_FONT_SIZE = 4
FONT_MIN = 2
FONT_MAX = 30

TIMEFRAMES = ["1m", "5m", "15m", "30m", "1h", "4h", "1d", "1w"]

STABLE_BASE = {
    "USDT", "USDC", "DAI", "TUSD", "FDUSD", "USDP", "BUSD", "EURC", "USDE", "USD1"
}

def hard_fail_non_ascii():
    try:
        p = os.path.abspath(__file__)
        with open(p, "rb") as f:
            data = f.read()

        # allow UTF-8 BOM at start
        if data.startswith(b"\xef\xbb\xbf"):
            data = data[3:]

        for b in data:
            if b > 127:
                raise RuntimeError("FATAL: non ASCII byte found in this file. Remove any non ASCII chars and save without BOM.")
    except Exception as e:
        # raise so you SEE the error in console
        raise

def utc_now_iso():
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()

def safe_float(x, default=0.0):
    try:
        if x is None:
            return default
        return float(x)
    except Exception:
        return default

def clamp(v, lo, hi):
    return max(lo, min(hi, v))

def connect_db():
    if not os.path.exists(DB_PATH):
        raise RuntimeError("DB not found: " + DB_PATH)
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def table_exists(con, name):
    cur = con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?;", (name,))
    return cur.fetchone() is not None

def columns_of(con, table):
    cur = con.execute("PRAGMA table_info(%s);" % table)
    return [r[1] for r in cur.fetchall()]

def pick_col(cols, preferred):
    for c in preferred:
        if c in cols:
            return c
    return None

def get_latest_run(con):
    if not table_exists(con, "runs"):
        return None

    cols = columns_of(con, "runs")
    id_col = pick_col(cols, ["run_id", "id"])
    tag_col = pick_col(cols, ["run_tag", "tag"])
    created_col = pick_col(cols, ["created_utc", "created_at", "created"])
    status_col = pick_col(cols, ["status"])
    vs_col = pick_col(cols, ["vs_currency"])
    coins_col = pick_col(cols, ["coins_limit", "coins_limt", "coins", "limit"])
    sort_col = pick_col(cols, ["sort_mode", "sort"])
    src_col = pick_col(cols, ["source"])

    if id_col is None:
        return None

    sql = "SELECT * FROM runs ORDER BY %s DESC LIMIT 1;" % id_col
    row = con.execute(sql).fetchone()
    if row is None:
        return None

    out = {
        "run_id": row[id_col] if id_col in row.keys() else None,
        "run_tag": row[tag_col] if tag_col and tag_col in row.keys() else None,
        "created": row[created_col] if created_col and created_col in row.keys() else None,
        "status": row[status_col] if status_col and status_col in row.keys() else None,
        "vs": row[vs_col] if vs_col and vs_col in row.keys() else None,
        "coins": row[coins_col] if coins_col and coins_col in row.keys() else None,
        "sort": row[sort_col] if sort_col and sort_col in row.keys() else None,
        "source": row[src_col] if src_col and src_col in row.keys() else None,
    }
    return out

def get_ohlcv_symbols_for_tf(con, tf):
    if not table_exists(con, "ohlcv"):
        return set()
    cols = columns_of(con, "ohlcv")
    sym_col = pick_col(cols, ["symbol", "base_symbol"])
    tf_col = pick_col(cols, ["timeframe", "tf", "interval"])
    if sym_col is None or tf_col is None:
        return set()
    sql = "SELECT DISTINCT %s AS s FROM ohlcv WHERE %s=?;" % (sym_col, tf_col)
    rows = con.execute(sql, (tf,)).fetchall()
    return set([str(r["s"]).upper() for r in rows if r["s"] is not None])

def ensure_export_tables(con):
    con.execute(
        """
        CREATE TABLE IF NOT EXISTS top_exports (
            export_id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_utc TEXT NOT NULL,
            run_id TEXT,
            run_tag TEXT,
            mode TEXT NOT NULL,
            timeframe TEXT NOT NULL,
            load_n INTEGER NOT NULL,
            top_n INTEGER NOT NULL,
            filters_json TEXT NOT NULL
        );
        """
    )
    con.execute(
        """
        CREATE TABLE IF NOT EXISTS top_export_items (
            export_id INTEGER NOT NULL,
            symbol TEXT NOT NULL,
            pair TEXT,
            rank INTEGER,
            spot_score INTEGER,
            top_score INTEGER,
            price REAL,
            chg24 REAL,
            vol24 REAL,
            mcap REAL,
            PRIMARY KEY (export_id, symbol)
        );
        """
    )

def compute_top_score(mode, row):
    # Inputs
    rank = safe_float(row.get("rank"), 999999.0)
    spot = safe_float(row.get("spot_score"), 0.0)
    price = safe_float(row.get("price"), 0.0)
    chg24 = safe_float(row.get("chg24"), 0.0)
    vol24 = safe_float(row.get("vol24"), 0.0)
    mcap = safe_float(row.get("mcap"), 0.0)

    # Liquidity proxy: prefer big vol and sane vol/mcap
    vol_ratio = (vol24 / mcap) if mcap > 0 else 0.0
    liq = 100.0 * (1.0 - math.exp(-10.0 * clamp(vol_ratio, 0.0, 2.0)))
    liq = clamp(liq, 1.0, 100.0)

    # Trend proxy from 24h move (penalize extreme spikes)
    move = abs(chg24)
    if move <= 2.0:
        trend = 80.0
    elif move <= 6.0:
        trend = 90.0
    elif move <= 12.0:
        trend = 70.0
    elif move <= 25.0:
        trend = 45.0
    else:
        trend = 20.0

    # Rank score
    rank_score = 100.0 * math.exp(-0.02 * max(rank - 1.0, 0.0))
    rank_score = clamp(rank_score, 1.0, 100.0)

    # Mode weights
    mode = (mode or "Balanced").strip()
    if mode == "Conservative":
        w_rank, w_spot, w_liq, w_trend = 0.40, 0.35, 0.20, 0.05
    elif mode == "Aggressive":
        w_rank, w_spot, w_liq, w_trend = 0.20, 0.30, 0.20, 0.30
    else:
        # Balanced
        w_rank, w_spot, w_liq, w_trend = 0.30, 0.35, 0.25, 0.10

    score = (w_rank * rank_score) + (w_spot * spot) + (w_liq * liq) + (w_trend * trend)
    return int(round(clamp(score, 1.0, 100.0)))

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("NyoSig Cryptolytix GUI v1.1e")
        self.geometry("1200x750")

        self.font_size = tk.IntVar(value=DEFAULT_FONT_SIZE)
        self.load_n = tk.IntVar(value=300)
        self.top_n = tk.IntVar(value=50)
        self.mode = tk.StringVar(value="Balanced")
        self.tf = tk.StringVar(value="4h")

        self.exclude_stable = tk.IntVar(value=1)
        self.require_ohlcv = tk.IntVar(value=0)
        self.min_mcap = tk.DoubleVar(value=0.0)
        self.min_vol24 = tk.DoubleVar(value=0.0)
        self.max_move24 = tk.DoubleVar(value=0.0)

        self.run_info = None
        self.rows_loaded = []
        self.rows_top = []

        self._build_ui()
        self._refresh_header()

    def _build_ui(self):
        topbar = ttk.Frame(self)
        topbar.pack(side=tk.TOP, fill=tk.X, padx=6, pady=6)

        btn_refresh = ttk.Button(topbar, text="Refresh", command=self.on_refresh)
        btn_refresh.grid(row=0, column=0, padx=4)

        ttk.Label(topbar, text="Load").grid(row=0, column=1, padx=(10,2))
        self.ent_load = ttk.Entry(topbar, width=6, textvariable=self.load_n)
        self.ent_load.grid(row=0, column=2, padx=2)

        ttk.Label(topbar, text="Top").grid(row=0, column=3, padx=(10,2))
        self.ent_top = ttk.Entry(topbar, width=6, textvariable=self.top_n)
        self.ent_top.grid(row=0, column=4, padx=2)

        btn_recalc = ttk.Button(topbar, text="Recalc TOP", command=self.on_recalc_top)
        btn_recalc.grid(row=0, column=5, padx=(6,12))

        ttk.Label(topbar, text="Mode").grid(row=0, column=6, padx=(10,2))
        self.cmb_mode = ttk.Combobox(topbar, width=12, state="readonly", textvariable=self.mode,
                                     values=["Conservative", "Balanced", "Aggressive"])
        self.cmb_mode.grid(row=0, column=7, padx=2)

        ttk.Label(topbar, text="TF").grid(row=0, column=8, padx=(10,2))
        self.cmb_tf = ttk.Combobox(topbar, width=6, state="readonly", textvariable=self.tf, values=TIMEFRAMES)
        self.cmb_tf.grid(row=0, column=9, padx=2)

        ttk.Label(topbar, text="Font").grid(row=0, column=10, padx=(10,2))
        self.spn_font = ttk.Spinbox(topbar, from_=FONT_MIN, to=FONT_MAX, width=4, textvariable=self.font_size)
        self.spn_font.grid(row=0, column=11, padx=2)
        btn_apply_font = ttk.Button(topbar, text="Apply", command=self.on_apply_font)
        btn_apply_font.grid(row=0, column=12, padx=4)

        btn_export = ttk.Button(topbar, text="Export TOP to DB", command=self.on_export_top)
        btn_export.grid(row=0, column=13, padx=(16,4))

        # Second row controls
        filters = ttk.Frame(self)
        filters.pack(side=tk.TOP, fill=tk.X, padx=6, pady=(0,6))

        chk_stable = ttk.Checkbutton(filters, text="Exclude stable", variable=self.exclude_stable, command=self.on_recalc_top)
        chk_stable.grid(row=0, column=0, padx=4)

        chk_ohlcv = ttk.Checkbutton(filters, text="Require OHLCV", variable=self.require_ohlcv, command=self.on_recalc_top)
        chk_ohlcv.grid(row=0, column=1, padx=4)

        ttk.Label(filters, text="Min mcap").grid(row=0, column=2, padx=(12,2))
        ttk.Entry(filters, width=10, textvariable=self.min_mcap).grid(row=0, column=3, padx=2)

        ttk.Label(filters, text="Min vol24").grid(row=0, column=4, padx=(12,2))
        ttk.Entry(filters, width=10, textvariable=self.min_vol24).grid(row=0, column=5, padx=2)

        ttk.Label(filters, text="Max 24h move pct").grid(row=0, column=6, padx=(12,2))
        ttk.Entry(filters, width=10, textvariable=self.max_move24).grid(row=0, column=7, padx=2)

        btn_apply_filters = ttk.Button(filters, text="Apply filters", command=self.on_recalc_top)
        btn_apply_filters.grid(row=0, column=8, padx=(12,2))

        # Header info
        self.lbl_info = ttk.Label(self, text="", justify=tk.LEFT)
        self.lbl_info.pack(side=tk.TOP, fill=tk.X, padx=6)

        # Table
        table_frame = ttk.Frame(self)
        table_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=6, pady=6)

        cols = [
            ("symbol", "Symbol", 90),
            ("pair", "Pair", 110),
            ("rank", "Rank", 60),
            ("spot_score", "SpotS", 70),
            ("top_score", "TopS", 70),
            ("price", "Price", 110),
            ("chg24", "24h%", 80),
            ("vol24", "Vol24", 140),
            ("mcap", "MCap", 140),
        ]

        self.tree = ttk.Treeview(table_frame, columns=[c[0] for c in cols], show="headings", height=20)
        for key, title, w in cols:
            self.tree.heading(key, text=title, command=lambda k=key: self.sort_by(k))
            self.tree.column(key, width=w, anchor=tk.W)

        vsb = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(table_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")

        table_frame.grid_rowconfigure(0, weight=1)
        table_frame.grid_columnconfigure(0, weight=1)

        # Log box
        self.txt_log = tk.Text(self, height=6)
        self.txt_log.pack(side=tk.BOTTOM, fill=tk.X, padx=6, pady=6)
        self.log("Ready")

        self.on_apply_font()

    def log(self, msg):
        try:
            self.txt_log.insert("end", msg + "\n")
            self.txt_log.see("end")
        except Exception:
            pass

    def on_apply_font(self):
        fs = int(self.font_size.get())
        fs = max(FONT_MIN, min(FONT_MAX, fs))
        style = ttk.Style()
        style.configure("Treeview", font=("TkDefaultFont", fs))
        style.configure("Treeview.Heading", font=("TkDefaultFont", fs))
        self.log("Font set to %d" % fs)

    def _refresh_header(self):
        try:
            con = connect_db()
            self.run_info = get_latest_run(con)
            con.close()
        except Exception as e:
            self.run_info = None
            self.log("DB error: %s" % str(e))

        if self.run_info is None:
            self.lbl_info.config(text="DB: %s\nRun: none" % DB_PATH)
            return

        r = self.run_info
        line1 = "DB: %s" % DB_PATH
        line2 = "run_id: %s  run_tag: %s  created: %s  status: %s" % (
            str(r.get("run_id")), str(r.get("run_tag")), str(r.get("created")), str(r.get("status"))
        )
        line3 = "vs: %s  coins: %s  sort: %s  source: %s" % (
            str(r.get("vs")), str(r.get("coins")), str(r.get("sort")), str(r.get("source"))
        )
        self.lbl_info.config(text=line1 + "\n" + line2 + "\n" + line3)

    def on_refresh(self):
        self._refresh_header()
        self.load_candidates()
        self.on_recalc_top()

    def load_candidates(self):
        self.rows_loaded = []
        self.rows_top = []
        self.tree.delete(*self.tree.get_children())

        n = int(self.load_n.get())
        if n <= 0:
            messagebox.showerror("Error", "Load must be > 0")
            return

        try:
            con = connect_db()
            if not table_exists(con, "spot_markets"):
                con.close()
                messagebox.showerror("Error", "Table spot_markets not found in DB")
                return

            cols = columns_of(con, "spot_markets")
            # Flexible mapping
            run_col = pick_col(cols, ["run_id", "run_tag"])
            sym_col = pick_col(cols, ["symbol"])
            pair_col = pick_col(cols, ["pair"])
            rank_col = pick_col(cols, ["market_cap_rank", "rank"])
            spot_col = pick_col(cols, ["score", "spot_score"])
            price_col = pick_col(cols, ["price", "current_price"])
            chg_col = pick_col(cols, ["change_24h_pct", "chg24", "price_change_percentage_24h"])
            vol_col = pick_col(cols, ["volume_24h", "vol24", "total_volume"])
            mcap_col = pick_col(cols, ["market_cap", "mcap"])

            if sym_col is None:
                con.close()
                messagebox.showerror("Error", "spot_markets missing symbol column")
                return

            order_col = vol_col if vol_col else sym_col

            where = ""
            params = []
            if self.run_info is not None and run_col is not None:
                # Prefer run_id if spot_markets stores it
                rid = self.run_info.get("run_id")
                rtag = self.run_info.get("run_tag")
                if run_col == "run_id" and rid is not None:
                    where = "WHERE %s=?" % run_col
                    params = [rid]
                elif run_col == "run_tag" and rtag is not None:
                    where = "WHERE %s=?" % run_col
                    params = [rtag]

            sql = (
                "SELECT "
                + ", ".join([
                    "%s AS symbol" % sym_col,
                    ("%s AS pair" % pair_col) if pair_col else "NULL AS pair",
                    ("%s AS rank" % rank_col) if rank_col else "NULL AS rank",
                    ("%s AS spot_score" % spot_col) if spot_col else "NULL AS spot_score",
                    ("%s AS price" % price_col) if price_col else "NULL AS price",
                    ("%s AS chg24" % chg_col) if chg_col else "NULL AS chg24",
                    ("%s AS vol24" % vol_col) if vol_col else "NULL AS vol24",
                    ("%s AS mcap" % mcap_col) if mcap_col else "NULL AS mcap",
                ])
                + " FROM spot_markets "
                + where
                + " ORDER BY %s DESC LIMIT ?;" % order_col
            )
            params.append(int(n))
            rows = con.execute(sql, tuple(params)).fetchall()
            con.close()

            for rr in rows:
                sym = str(rr["symbol"]).upper().strip() if rr["symbol"] is not None else ""
                if not sym:
                    continue
                pair = rr["pair"] if rr["pair"] is not None else (sym + "/USD")
                row = {
                    "symbol": sym,
                    "pair": str(pair),
                    "rank": int(rr["rank"]) if rr["rank"] is not None else None,
                    "spot_score": int(rr["spot_score"]) if rr["spot_score"] is not None else 0,
                    "price": safe_float(rr["price"], 0.0),
                    "chg24": safe_float(rr["chg24"], 0.0),
                    "vol24": safe_float(rr["vol24"], 0.0),
                    "mcap": safe_float(rr["mcap"], 0.0),
                    "top_score": 0,
                }
                self.rows_loaded.append(row)

            self.log("Loaded %d candidates by Vol24 desc (limit=%d)" % (len(self.rows_loaded), n))

        except Exception as e:
            messagebox.showerror("Error", str(e))
            self.log("Error: %s" % str(e))

    def apply_filters(self, rows):
        out = []
        tf = self.tf.get()
        need_ohlcv = int(self.require_ohlcv.get()) == 1

        have_ohlcv = set()
        try:
            if need_ohlcv:
                con = connect_db()
                have_ohlcv = get_ohlcv_symbols_for_tf(con, tf)
                con.close()
        except Exception:
            have_ohlcv = set()

        min_mcap = safe_float(self.min_mcap.get(), 0.0)
        min_vol24 = safe_float(self.min_vol24.get(), 0.0)
        max_move24 = safe_float(self.max_move24.get(), 0.0)
        excl_stable = int(self.exclude_stable.get()) == 1

        for r in rows:
            sym = r["symbol"]
            if excl_stable and sym in STABLE_BASE:
                continue
            if min_mcap > 0.0 and r["mcap"] < min_mcap:
                continue
            if min_vol24 > 0.0 and r["vol24"] < min_vol24:
                continue
            if max_move24 > 0.0 and abs(r["chg24"]) > max_move24:
                continue
            if need_ohlcv and sym not in have_ohlcv:
                continue
            out.append(r)
        return out

    def on_recalc_top(self):
        try:
            if not self.rows_loaded:
                self.load_candidates()

            mode = self.mode.get()
            tf = self.tf.get()
            top_n = int(self.top_n.get())
            if top_n <= 0:
                messagebox.showerror("Error", "Top must be > 0")
                return

            filtered = self.apply_filters(self.rows_loaded)

            # Compute top score
            for r in filtered:
                r["top_score"] = compute_top_score(mode, r)

            # Sort by top_score desc, tie break by vol24 then mcap
            filtered_sorted = sorted(
                filtered,
                key=lambda x: (int(x.get("top_score", 0)), float(x.get("vol24", 0.0)), float(x.get("mcap", 0.0))),
                reverse=True
            )

            self.rows_top = filtered_sorted[:top_n]

            # Display: show TOP first, then rest (optional)
            display = filtered_sorted

            self.tree.delete(*self.tree.get_children())
            for r in display:
                self.tree.insert("", "end", values=(
                    r["symbol"],
                    r["pair"],
                    "" if r["rank"] is None else str(r["rank"]),
                    str(int(r["spot_score"])),
                    str(int(r["top_score"])),
                    self.fmt_num(r["price"]),
                    self.fmt_num(r["chg24"]),
                    self.fmt_num(r["vol24"]),
                    self.fmt_num(r["mcap"]),
                ))

            self.log("Recalc TOP done. filtered=%d  top=%d  tf=%s  mode=%s" % (len(filtered), len(self.rows_top), tf, mode))

        except Exception as e:
            messagebox.showerror("Error", str(e))
            self.log("Error: %s" % str(e))

    def fmt_num(self, x):
        try:
            xf = float(x)
            if abs(xf) >= 1e9:
                return "%.0f" % xf
            if abs(xf) >= 1e6:
                return "%.0f" % xf
            if abs(xf) >= 1000:
                return "%.0f" % xf
            if abs(xf) >= 1:
                return "%.6f" % xf
            return "%.8f" % xf
        except Exception:
            return str(x)

    def sort_by(self, key):
        # Minimal sort for UI, sort current tree values as strings/numbers
        items = [(self.tree.set(k, key), k) for k in self.tree.get_children("")]
        def to_num(v):
            try:
                return float(v)
            except Exception:
                return v
        items.sort(key=lambda t: to_num(t[0]), reverse=True)
        for idx, (_, iid) in enumerate(items):
            self.tree.move(iid, "", idx)

    def on_export_top(self):
        if not self.rows_top:
            messagebox.showerror("Error", "Nothing to export. Press Recalc TOP first.")
            return

        try:
            con = connect_db()
            ensure_export_tables(con)

            run_id = None
            run_tag = None
            if self.run_info is not None:
                run_id = self.run_info.get("run_id")
                run_tag = self.run_info.get("run_tag")

            filters = {
                "exclude_stable": int(self.exclude_stable.get()),
                "require_ohlcv": int(self.require_ohlcv.get()),
                "min_mcap": float(self.min_mcap.get()),
                "min_vol24": float(self.min_vol24.get()),
                "max_move24": float(self.max_move24.get()),
            }

            con.execute("BEGIN;")
            con.execute(
                """
                INSERT INTO top_exports
                (created_utc, run_id, run_tag, mode, timeframe, load_n, top_n, filters_json)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?);
                """,
                (
                    utc_now_iso(),
                    None if run_id is None else str(run_id),
                    None if run_tag is None else str(run_tag),
                    str(self.mode.get()),
                    str(self.tf.get()),
                    int(self.load_n.get()),
                    int(self.top_n.get()),
                    json.dumps(filters, separators=(",", ":")),
                )
            )
            export_id = con.execute("SELECT last_insert_rowid();").fetchone()[0]

            for r in self.rows_top:
                con.execute(
                    """
                    INSERT OR REPLACE INTO top_export_items
                    (export_id, symbol, pair, rank, spot_score, top_score, price, chg24, vol24, mcap)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
                    """,
                    (
                        int(export_id),
                        r["symbol"],
                        r["pair"],
                        None if r["rank"] is None else int(r["rank"]),
                        int(r["spot_score"]),
                        int(r["top_score"]),
                        float(r["price"]),
                        float(r["chg24"]),
                        float(r["vol24"]),
                        float(r["mcap"]),
                    )
                )

            con.commit()
            con.close()

            messagebox.showinfo("OK", "Exported TOP into DB. export_id: %s" % str(export_id))
            self.log("Exported TOP to DB export_id=%s" % str(export_id))

        except Exception as e:
            try:
                con.rollback()
            except Exception:
                pass
            try:
                con.close()
            except Exception:
                pass
            messagebox.showerror("Error", str(e))
            self.log("Export error: %s" % str(e))

def main():
    hard_fail_non_ascii()
    app = App()
    app.on_refresh()
    app.mainloop()

if __name__ == "__main__":
    main()
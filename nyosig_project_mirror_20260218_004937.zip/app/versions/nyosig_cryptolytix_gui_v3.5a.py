#!/usr/bin/env python3
# nyosig_cryptolytix_gui_v3.5a
# Refactor: core pipeline extracted into /core package (db/network/cache/scoring/pipeline)
# ASCII only, Tkinter GUI

import os
import sys
import tkinter as tk
from tkinter import ttk, messagebox

from core.config import make_paths, parse_simple_yaml, parse_secrets_env
from core.cache import ensure_dir
from core.util_time import utc_now_iso, utc_stamp_compact
from core.pipeline import run_snapshot_and_topnow

PROJECT_ROOT = "/storage/emulated/0/NyoSig/NyoSig_Cryptolytix"
APP_VERSION = "v3.5a"

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"NyoSig Cryptolytix GUI {APP_VERSION}")
        self.geometry("860x760")
        self.minsize(720, 560)

        self.paths = make_paths(PROJECT_ROOT)
        ensure_dir(self.paths.cache_dir)
        ensure_dir(self.paths.log_dir)

        self.cfg = parse_simple_yaml(self.paths.defaults_yaml)
        self.secrets = parse_secrets_env(self.paths.secrets_env)

        mvp = self.cfg.get("mvp", {})
        self.scope = tk.StringVar(value="crypto_spot")
        self.vs_currency = tk.StringVar(value=str(mvp.get("vs_currency", "usd")).lower())
        self.coins_limit = tk.IntVar(value=int(mvp.get("coins_limit", 250)))
        self.order = tk.StringVar(value=str(mvp.get("order", "market_cap_desc")))
        self.topnow_limit = tk.IntVar(value=int(mvp.get("topnow_limit", 100)))
        self.offline_mode = tk.BooleanVar(value=bool(mvp.get("offline_mode", False)))

        self.status_var = tk.StringVar(value="Ready")
        self.last_run_var = tk.StringVar(value="-")
        self.last_snapshot_var = tk.StringVar(value="-")
        self.last_selection_var = tk.StringVar(value="-")

        self.last_log_path = None
        self._build_ui()

    def _build_ui(self):
        root = ttk.Frame(self, padding=10)
        root.pack(fill="both", expand=True)

        hdr = ttk.Frame(root)
        hdr.pack(fill="x")

        ttk.Label(hdr, text="Project root").grid(row=0, column=0, sticky="w")
        ttk.Label(hdr, text=self.paths.project_root).grid(row=0, column=1, sticky="w")

        ttk.Label(hdr, text="DB").grid(row=1, column=0, sticky="w")
        ttk.Label(hdr, text=self.paths.db_path).grid(row=1, column=1, sticky="w")

        ttk.Separator(root).pack(fill="x", pady=10)

        form = ttk.Frame(root)
        form.pack(fill="x")

        ttk.Label(form, text="Scope").grid(row=0, column=0, sticky="w", padx=(0, 8), pady=4)
        ttk.Combobox(form, textvariable=self.scope, state="readonly",
                     values=["crypto_spot", "crypto_derivatives", "macro", "institutions", "sentiment"]).grid(row=0, column=1, sticky="w", pady=4)

        ttk.Label(form, text="vs_currency").grid(row=1, column=0, sticky="w", padx=(0, 8), pady=4)
        ttk.Entry(form, textvariable=self.vs_currency, width=12).grid(row=1, column=1, sticky="w", pady=4)

        ttk.Label(form, text="coins_limit").grid(row=2, column=0, sticky="w", padx=(0, 8), pady=4)
        ttk.Entry(form, textvariable=self.coins_limit, width=12).grid(row=2, column=1, sticky="w", pady=4)

        ttk.Label(form, text="order").grid(row=3, column=0, sticky="w", padx=(0, 8), pady=4)
        ttk.Entry(form, textvariable=self.order, width=24).grid(row=3, column=1, sticky="w", pady=4)

        ttk.Label(form, text="TopNow candidates").grid(row=4, column=0, sticky="w", padx=(0, 8), pady=4)
        ttk.Entry(form, textvariable=self.topnow_limit, width=12).grid(row=4, column=1, sticky="w", pady=4)

        ttk.Checkbutton(form, text="offline_mode", variable=self.offline_mode).grid(row=5, column=1, sticky="w", pady=6)

        btns = ttk.Frame(root)
        btns.pack(fill="x", pady=10)
        ttk.Button(btns, text="Run Snapshot and Build TopNow", command=self.run_pipeline).pack(side="left")
        ttk.Button(btns, text="Open last run log", command=self.open_last_log).pack(side="left", padx=8)

        ttk.Separator(root).pack(fill="x", pady=10)

        info = ttk.Frame(root)
        info.pack(fill="x")

        ttk.Label(info, text="Status").grid(row=0, column=0, sticky="w")
        ttk.Label(info, textvariable=self.status_var).grid(row=0, column=1, sticky="w")

        ttk.Label(info, text="Last run_id").grid(row=1, column=0, sticky="w")
        ttk.Label(info, textvariable=self.last_run_var).grid(row=1, column=1, sticky="w")

        ttk.Label(info, text="Last snapshot_id").grid(row=2, column=0, sticky="w")
        ttk.Label(info, textvariable=self.last_snapshot_var).grid(row=2, column=1, sticky="w")

        ttk.Label(info, text="Last selection_id").grid(row=3, column=0, sticky="w")
        ttk.Label(info, textvariable=self.last_selection_var).grid(row=3, column=1, sticky="w")

        ttk.Separator(root).pack(fill="x", pady=10)

        self.log = tk.Text(root, height=18)
        self.log.pack(fill="both", expand=True)
        self.log.insert("end", "Log\n")

    def log_cb(self, msg: str):
        self.log.insert("end", utc_now_iso() + " " + msg + "\n")
        self.log.see("end")
        self.update_idletasks()

    def open_last_log(self):
        if not self.last_log_path or not os.path.isfile(self.last_log_path):
            messagebox.showinfo("Info", "No log file yet")
            return
        try:
            if sys.platform.startswith("linux"):
                os.system(f'xdg-open "{self.last_log_path}"')
            else:
                os.system(f'open "{self.last_log_path}"')
        except Exception:
            messagebox.showinfo("Log path", self.last_log_path)

    def run_pipeline(self):
        scope_text = self.scope.get().strip() or "crypto_spot"
        if scope_text != "crypto_spot":
            messagebox.showwarning("Not implemented",
                                   "Only crypto_spot is implemented in MVP pipeline. Scope will be stored, but data source stays CoinGecko spot.")

        vs_currency = (self.vs_currency.get().strip().lower() or "usd")
        coins_limit = int(self.coins_limit.get())
        order = (self.order.get().strip() or "market_cap_desc")
        topnow_limit = int(self.topnow_limit.get())
        offline_mode = bool(self.offline_mode.get())

        ensure_dir(self.paths.log_dir)
        self.last_log_path = os.path.join(self.paths.log_dir, f"run_{utc_stamp_compact()}_{APP_VERSION}.log")

        self.status_var.set("Running")
        self.log_cb("START pipeline (core)")
        self.log_cb(f"scope={scope_text} vs_currency={vs_currency} coins_limit={coins_limit} order={order} topnow={topnow_limit} offline={int(offline_mode)}")

        try:
            res = run_snapshot_and_topnow(
                project_root=self.paths.project_root,
                app_version=APP_VERSION,
                scope_text=scope_text,
                vs_currency=vs_currency,
                coins_limit=coins_limit,
                order=order,
                topnow_limit=topnow_limit,
                offline_mode=offline_mode,
                log_cb=self.log_cb,
            )
            self.last_run_var.set(str(res.run_id))
            self.last_snapshot_var.set(res.snapshot_id)
            self.last_selection_var.set(str(res.selection_id))
            self.status_var.set("Done")

            with open(self.last_log_path, "w", encoding="utf-8") as fp:
                fp.write(f"run_id {res.run_id}\n")
                fp.write(f"snapshot_id {res.snapshot_id}\n")
                fp.write(f"selection_id {res.selection_id}\n")
                fp.write(f"candidates {res.candidates_n}\n")

            self.log_cb(f"DONE run_id={res.run_id} snapshot_id={res.snapshot_id} selection_id={res.selection_id} candidates={res.candidates_n}")
        except Exception as e:
            self.status_var.set("Failed")
            self.log_cb("FAILED " + str(e))
            messagebox.showerror("Error", str(e)[:1200])

if __name__ == "__main__":
    app = App()
    app.mainloop()

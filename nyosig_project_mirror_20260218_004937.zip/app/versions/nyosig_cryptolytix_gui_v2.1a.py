#!/usr/bin/env python3
# nyosig_cryptolytix_gui_v2.1a
# ASCII only, Tkinter, MANUAL workflow
# Fixed project root: /storage/emulated/0/NyoSig/NyoSig_Cryptolytix
#
# Core fix:
# Generate TOP always creates a fresh SPOT snapshot from CoinGecko, writes a new run,
# stores raw + normalized spot, then builds a candidate pool (liquidity + momentum + volume spike)
# so "TOP" stays relevant to the current market, not stale DB rows.

import os
import json
import time
import math
import uuid
import sqlite3
import urllib.request
import urllib.parse
import tkinter as tk
from tkinter import ttk, messagebox

APP_VERSION = "2.1a"
APP_FILE_TAG = "nyosig_cryptolytix_gui_v" + APP_VERSION

PROJECT_ROOT = "/storage/emulated/0/NyoSig/NyoSig_Cryptolytix"
DB_PATH = os.path.join(PROJECT_ROOT, "db", "nyosig_cryptolytix.db")
DATA_DIR = os.path.join(PROJECT_ROOT, "data")
RAW_DIR = os.path.join(DATA_DIR, "raw")
RUNS_DIR = os.path.join(DATA_DIR, "runs")

TIMEFRAMES = ["1h", "4h", "1d"]
MODES = ["conservative", "balanced", "aggressive"]

EXCLUDE_STABLE_BASE = {
    "USDT", "USDC", "DAI", "TUSD", "FDUSD", "USDP", "BUSD", "EURC", "USDE", "USD1", "PYUSD", "USDS", "FRAX", "LUSD", "GUSD"
}

DEFAULT_VS_CURRENCY = "usd"
DEFAULT_LOAD_N = 250
DEFAULT_TOP_N = 15

FONT_MIN = 4
FONT_MAX = 30
FONT_DEFAULT = 12

COINGECKO_ENDPOINT = "https://api.coingecko.com/api/v3/coins/markets"


def ascii_guard():
    with open(__file__, "rb") as f:
        b = f.read()
    start = 3 if b.startswith(b"\xef\xbb\xbf") else 0
    for i in range(start, len(b)):
        if b[i] > 127:
            raise RuntimeError("Non ASCII byte found at offset %d" % i)


def ensure_dirs():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    os.makedirs(DATA_DIR, exist_ok=True)
    os.makedirs(RAW_DIR, exist_ok=True)
    os.makedirs(RUNS_DIR, exist_ok=True)


def utc_now_iso():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def now_tag():
    return time.strftime("%Y%m%d_%H%M%S", time.gmtime())


def safe_int(x, default=0):
    try:
        return int(x)
    except Exception:
        return default


def safe_float(x, default=None):
    try:
        if x is None:
            return default
        return float(x)
    except Exception:
        return default


def fmt_price(v):
    v = safe_float(v, None)
    if v is None:
        return ""
    if abs(v) >= 1:
        return f"{v:,.4f}"
    return f"{v:.8f}"


def fmt_pct(v):
    v = safe_float(v, None)
    if v is None:
        return ""
    return f"{v:.2f}"


def fmt_int(v):
    v = safe_float(v, None)
    if v is None:
        return ""
    try:
        return f"{int(round(v)):,d}"
    except Exception:
        return ""


def db_connect():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON;")
    return con


def table_exists(con, name):
    row = con.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
        (name,),
    ).fetchone()
    return row is not None


def col_exists(con, table, col):
    rows = con.execute(f"PRAGMA table_info({table})").fetchall()
    for r in rows:
        if r["name"] == col:
            return True
    return False


def ensure_schema(con):
    con.execute(
        """
        CREATE TABLE IF NOT EXISTS migrations (
          name TEXT PRIMARY KEY,
          applied_utc TEXT NOT NULL
        );
        """
    )

    con.execute(
        """
        CREATE TABLE IF NOT EXISTS runs (
          run_id TEXT PRIMARY KEY,
          created_utc TEXT NOT NULL,
          app_version TEXT NOT NULL,
          vs_currency TEXT NOT NULL,
          load_n INTEGER NOT NULL,
          mode TEXT NOT NULL,
          timeframes_json TEXT NOT NULL,
          status TEXT NOT NULL,
          notes TEXT
        );
        """
    )

    con.execute(
        """
        CREATE TABLE IF NOT EXISTS raw_snapshots (
          snapshot_id TEXT PRIMARY KEY,
          run_id TEXT NOT NULL,
          source TEXT NOT NULL,
          endpoint TEXT NOT NULL,
          params_json TEXT NOT NULL,
          captured_utc TEXT NOT NULL,
          payload_json TEXT NOT NULL,
          FOREIGN KEY (run_id) REFERENCES runs(run_id) ON DELETE CASCADE
        );
        """
    )

    con.execute(
        """
        CREATE TABLE IF NOT EXISTS spot_markets (
          spot_id INTEGER PRIMARY KEY AUTOINCREMENT,
          run_id TEXT NOT NULL,
          coingecko_id TEXT,
          unified_symbol TEXT NOT NULL,
          pair TEXT NOT NULL,
          price REAL,
          market_cap REAL,
          volume_24h REAL,
          change_1h_pct REAL,
          change_24h_pct REAL,
          change_7d_pct REAL,
          cg_rank INTEGER,
          source TEXT NOT NULL,
          captured_utc TEXT NOT NULL,
          FOREIGN KEY (run_id) REFERENCES runs(run_id) ON DELETE CASCADE
        );
        """
    )
    con.execute("CREATE INDEX IF NOT EXISTS idx_spot_markets_run ON spot_markets(run_id);")
    con.execute("CREATE INDEX IF NOT EXISTS idx_spot_markets_symbol ON spot_markets(unified_symbol);")
    con.execute("CREATE INDEX IF NOT EXISTS idx_spot_markets_rank ON spot_markets(cg_rank);")

    con.execute(
        """
        CREATE TABLE IF NOT EXISTS spot_features (
          feature_id INTEGER PRIMARY KEY AUTOINCREMENT,
          run_id TEXT NOT NULL,
          unified_symbol TEXT NOT NULL,
          liquidity_score REAL,
          momentum_score REAL,
          volume_spike_score REAL,
          spot_score INTEGER,
          created_utc TEXT NOT NULL,
          UNIQUE(run_id, unified_symbol),
          FOREIGN KEY (run_id) REFERENCES runs(run_id) ON DELETE CASCADE
        );
        """
    )
    con.execute("CREATE INDEX IF NOT EXISTS idx_spot_features_run ON spot_features(run_id);")

    con.execute(
        """
        CREATE TABLE IF NOT EXISTS top_sets (
          top_set_id TEXT PRIMARY KEY,
          created_utc TEXT NOT NULL,
          source_run_id TEXT NOT NULL,
          vs_currency TEXT NOT NULL,
          load_n INTEGER NOT NULL,
          mode TEXT NOT NULL,
          top_n INTEGER NOT NULL,
          filters_json TEXT,
          notes TEXT,
          FOREIGN KEY (source_run_id) REFERENCES runs(run_id) ON DELETE CASCADE
        );
        """
    )

    con.execute(
        """
        CREATE TABLE IF NOT EXISTS top_set_items (
          top_set_id TEXT NOT NULL,
          rank_in_top INTEGER NOT NULL,
          unified_symbol TEXT NOT NULL,
          pair TEXT,
          price REAL,
          market_cap REAL,
          volume_24h REAL,
          change_1h_pct REAL,
          change_24h_pct REAL,
          cg_rank INTEGER,
          spot_score INTEGER,
          created_utc TEXT NOT NULL,
          PRIMARY KEY (top_set_id, rank_in_top),
          FOREIGN KEY (top_set_id) REFERENCES top_sets(top_set_id) ON DELETE CASCADE
        );
        """
    )
    con.execute("CREATE INDEX IF NOT EXISTS idx_top_items_top ON top_set_items(top_set_id);")

    con.execute(
        """
        CREATE TABLE IF NOT EXISTS tracked_assets (
          track_id TEXT PRIMARY KEY,
          created_utc TEXT NOT NULL,
          unified_symbol TEXT NOT NULL,
          status TEXT NOT NULL,
          notes TEXT
        );
        """
    )
    con.execute("CREATE UNIQUE INDEX IF NOT EXISTS ux_tracked_assets_symbol ON tracked_assets(unified_symbol);")

    con.execute(
        """
        CREATE TABLE IF NOT EXISTS tracked_events (
          event_id TEXT PRIMARY KEY,
          created_utc TEXT NOT NULL,
          track_id TEXT NOT NULL,
          run_id TEXT NOT NULL,
          layer TEXT NOT NULL,
          payload_json TEXT NOT NULL,
          FOREIGN KEY (track_id) REFERENCES tracked_assets(track_id) ON DELETE CASCADE,
          FOREIGN KEY (run_id) REFERENCES runs(run_id) ON DELETE CASCADE
        );
        """
    )
    con.execute("CREATE INDEX IF NOT EXISTS idx_tracked_events_track ON tracked_events(track_id);")

    con.commit()


def http_get_json(url, headers=None, timeout=30):
    req = urllib.request.Request(url)
    req.add_header("User-Agent", "NyoSigCryptolytix/" + APP_VERSION)
    if headers:
        for k, v in headers.items():
            req.add_header(k, v)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read().decode("utf-8")
    return json.loads(data)


def coingecko_fetch_markets(vs_currency, per_page, page):
    params = {
        "vs_currency": vs_currency,
        "order": "market_cap_desc",
        "per_page": str(int(per_page)),
        "page": str(int(page)),
        "sparkline": "false",
        "price_change_percentage": "1h,24h,7d",
        "locale": "en",
    }
    url = COINGECKO_ENDPOINT + "?" + urllib.parse.urlencode(params)
    payload = http_get_json(url)
    return params, payload


def normalize_symbol(sym):
    if sym is None:
        return ""
    s = str(sym).strip().upper()
    s = s.replace("-", "")
    s = s.replace("_", "")
    return s


def build_candidate_pool(rows, mode):
    # rows: list of dict from spot_markets join features
    # output: list of unified_symbol
    #
    # Goal: include all needed candidates:
    # 1) core liquid universe
    # 2) momentum risers
    # 3) volume spike risers
    #
    # conservative: tighter
    # aggressive: wider

    if mode == "conservative":
        core_cap_min = 1_000_000_000
        core_vol_min = 50_000_000
        spike_cap_min = 300_000_000
        spike_vol_min = 20_000_000
        core_take = 60
        momentum_take = 40
        spike_take = 40
    elif mode == "aggressive":
        core_cap_min = 150_000_000
        core_vol_min = 5_000_000
        spike_cap_min = 80_000_000
        spike_vol_min = 3_000_000
        core_take = 80
        momentum_take = 80
        spike_take = 80
    else:
        core_cap_min = 300_000_000
        core_vol_min = 20_000_000
        spike_cap_min = 150_000_000
        spike_vol_min = 10_000_000
        core_take = 70
        momentum_take = 60
        spike_take = 60

    eligible = []
    for r in rows:
        sym = r.get("unified_symbol", "")
        if not sym:
            continue
        if sym in EXCLUDE_STABLE_BASE:
            continue
        mc = safe_float(r.get("market_cap"), 0.0) or 0.0
        vol = safe_float(r.get("volume_24h"), 0.0) or 0.0
        if mc <= 0 or vol <= 0:
            continue
        eligible.append(r)

    core = []
    for r in eligible:
        mc = safe_float(r.get("market_cap"), 0.0) or 0.0
        vol = safe_float(r.get("volume_24h"), 0.0) or 0.0
        if mc >= core_cap_min and vol >= core_vol_min:
            core.append(r)
    core.sort(key=lambda x: (safe_int(x.get("cg_rank"), 10**9)))

    momentum = []
    for r in eligible:
        mc = safe_float(r.get("market_cap"), 0.0) or 0.0
        vol = safe_float(r.get("volume_24h"), 0.0) or 0.0
        if mc < spike_cap_min or vol < spike_vol_min:
            continue
        ch1 = safe_float(r.get("change_1h_pct"), 0.0) or 0.0
        ch24 = safe_float(r.get("change_24h_pct"), 0.0) or 0.0
        # prioritize early movers and sustained strength
        score = (ch1 * 1.2) + (ch24 * 0.8)
        momentum.append((score, r))
    momentum.sort(key=lambda t: t[0], reverse=True)

    spikes = []
    for r in eligible:
        mc = safe_float(r.get("market_cap"), 0.0) or 0.0
        vol = safe_float(r.get("volume_24h"), 0.0) or 0.0
        if mc < spike_cap_min or vol < spike_vol_min:
            continue
        # volume to cap ratio as a crude "attention" proxy
        ratio = vol / max(mc, 1.0)
        ch1 = safe_float(r.get("change_1h_pct"), 0.0) or 0.0
        # reward volume ratio even if price just started moving
        score = (ratio * 100.0) + max(0.0, ch1 * 0.2)
        spikes.append((score, r))
    spikes.sort(key=lambda t: t[0], reverse=True)

    pool = []
    seen = set()

    def add_sym(sym):
        if not sym:
            return
        if sym in seen:
            return
        seen.add(sym)
        pool.append(sym)

    for r in core[:core_take]:
        add_sym(r.get("unified_symbol"))

    for score, r in momentum[:momentum_take]:
        add_sym(r.get("unified_symbol"))

    for score, r in spikes[:spike_take]:
        add_sym(r.get("unified_symbol"))

    return pool


def compute_spot_features(con, run_id, mode):
    # Build features for each spot row in this run, then compute spot_score in 1..100
    rows = con.execute(
        """
        SELECT
          unified_symbol,
          market_cap,
          volume_24h,
          change_1h_pct,
          change_24h_pct,
          cg_rank
        FROM spot_markets
        WHERE run_id = ?
        """,
        (run_id,),
    ).fetchall()

    items = []
    for r in rows:
        sym = r["unified_symbol"]
        if sym in EXCLUDE_STABLE_BASE:
            continue
        mc = safe_float(r["market_cap"], 0.0) or 0.0
        vol = safe_float(r["volume_24h"], 0.0) or 0.0
        ch1 = safe_float(r["change_1h_pct"], 0.0) or 0.0
        ch24 = safe_float(r["change_24h_pct"], 0.0) or 0.0
        rank = safe_int(r["cg_rank"], 10**9)

        if mc <= 0 or vol <= 0:
            continue

        # Liquidity score
        # scaled log with soft caps
        liq = math.log10(1.0 + vol)
        cap = math.log10(1.0 + mc)
        liquidity_score = (liq * 0.65) + (cap * 0.35)

        # Momentum score
        momentum_score = (ch1 * 1.2) + (ch24 * 0.8)

        # Volume spike proxy
        ratio = vol / max(mc, 1.0)
        volume_spike_score = ratio * 100.0

        items.append(
            {
                "sym": sym,
                "liquidity_score": liquidity_score,
                "momentum_score": momentum_score,
                "volume_spike_score": volume_spike_score,
                "rank": rank,
            }
        )

    if not items:
        return

    # Normalize to 0..1
    def norm(vals, v):
        if not vals:
            return 0.0
        lo = min(vals)
        hi = max(vals)
        if hi <= lo:
            return 0.5
        return (v - lo) / (hi - lo)

    liqs = [it["liquidity_score"] for it in items]
    moms = [it["momentum_score"] for it in items]
    vss = [it["volume_spike_score"] for it in items]

    # Weights per mode
    if mode == "conservative":
        w_liq = 0.55
        w_mom = 0.25
        w_vs = 0.20
    elif mode == "aggressive":
        w_liq = 0.35
        w_mom = 0.40
        w_vs = 0.25
    else:
        w_liq = 0.45
        w_mom = 0.30
        w_vs = 0.25

    created_utc = utc_now_iso()

    for it in items:
        n_liq = norm(liqs, it["liquidity_score"])
        n_mom = norm(moms, it["momentum_score"])
        n_vs = norm(vss, it["volume_spike_score"])

        raw = (n_liq * w_liq) + (n_mom * w_mom) + (n_vs * w_vs)

        # Convert to 1..100
        spot_score = int(round(1 + raw * 99))
        if spot_score < 1:
            spot_score = 1
        if spot_score > 100:
            spot_score = 100

        con.execute(
            """
            INSERT OR REPLACE INTO spot_features (
              run_id, unified_symbol,
              liquidity_score, momentum_score, volume_spike_score,
              spot_score, created_utc
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                run_id,
                it["sym"],
                float(it["liquidity_score"]),
                float(it["momentum_score"]),
                float(it["volume_spike_score"]),
                int(spot_score),
                created_utc,
            ),
        )
    con.commit()


def generate_top_fresh(con, vs_currency, load_n, mode, top_n, selected_timeframes):
    # 1) create run
    run_id = "run_" + now_tag() + "_" + uuid.uuid4().hex[:6]
    created_utc = utc_now_iso()
    con.execute(
        """
        INSERT INTO runs (
          run_id, created_utc, app_version, vs_currency, load_n, mode,
          timeframes_json, status, notes
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            run_id,
            created_utc,
            APP_VERSION,
            vs_currency,
            int(load_n),
            mode,
            json.dumps(selected_timeframes),
            "running",
            "Fresh SPOT snapshot from CoinGecko",
        ),
    )
    con.commit()

    # 2) fetch CoinGecko markets in pages (max per_page 250)
    per_page = 250
    total = int(load_n)
    pages = int(math.ceil(total / float(per_page)))
    all_rows = []
    all_payloads = []

    for p in range(1, pages + 1):
        params, payload = coingecko_fetch_markets(vs_currency, per_page, p)
        all_payloads.append({"params": params, "payload": payload})
        if isinstance(payload, list):
            all_rows.extend(payload)
        time.sleep(1.2)

    # 3) store raw snapshot to file and DB
    snapshot_id = "snap_" + now_tag() + "_" + uuid.uuid4().hex[:6]
    captured_utc = utc_now_iso()
    raw_file = os.path.join(RAW_DIR, snapshot_id + "_coingecko_spot.json")
    with open(raw_file, "w", encoding="utf-8") as f:
        json.dump(all_rows, f, ensure_ascii=True, indent=2)

    con.execute(
        """
        INSERT INTO raw_snapshots (
          snapshot_id, run_id, source, endpoint, params_json, captured_utc, payload_json
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (
            snapshot_id,
            run_id,
            "coingecko",
            COINGECKO_ENDPOINT,
            json.dumps({"vs_currency": vs_currency, "load_n": int(load_n)}),
            captured_utc,
            json.dumps(all_rows),
        ),
    )
    con.commit()

    # 4) normalize spot rows into spot_markets
    # CoinGecko fields: id, symbol, current_price, market_cap, total_volume, market_cap_rank, price_change_percentage_1h_in_currency, ...
    con.execute("DELETE FROM spot_markets WHERE run_id = ?", (run_id,))
    inserted = 0

    for r in all_rows[:total]:
        cg_id = r.get("id")
        sym = normalize_symbol(r.get("symbol"))
        if not sym:
            continue
        pair = sym + "/" + "USDT"
        price = safe_float(r.get("current_price"), None)
        mc = safe_float(r.get("market_cap"), None)
        vol = safe_float(r.get("total_volume"), None)
        rank = safe_int(r.get("market_cap_rank"), None)

        ch1 = safe_float(r.get("price_change_percentage_1h_in_currency"), None)
        ch24 = safe_float(r.get("price_change_percentage_24h_in_currency"), None)
        ch7 = safe_float(r.get("price_change_percentage_7d_in_currency"), None)

        con.execute(
            """
            INSERT INTO spot_markets (
              run_id, coingecko_id, unified_symbol, pair,
              price, market_cap, volume_24h,
              change_1h_pct, change_24h_pct, change_7d_pct,
              cg_rank, source, captured_utc
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                run_id,
                cg_id,
                sym,
                pair,
                price,
                mc,
                vol,
                ch1,
                ch24,
                ch7,
                rank,
                "coingecko",
                captured_utc,
            ),
        )
        inserted += 1

    con.commit()

    # 5) compute features and spot_score
    compute_spot_features(con, run_id, mode)

    # 6) build candidate pool
    joined = con.execute(
        """
        SELECT
          m.unified_symbol,
          m.pair,
          m.price,
          m.market_cap,
          m.volume_24h,
          m.change_1h_pct,
          m.change_24h_pct,
          m.cg_rank,
          f.spot_score
        FROM spot_markets m
        LEFT JOIN spot_features f
          ON f.run_id = m.run_id AND f.unified_symbol = m.unified_symbol
        WHERE m.run_id = ?
        """,
        (run_id,),
    ).fetchall()

    rows = []
    for j in joined:
        rows.append(
            {
                "unified_symbol": j["unified_symbol"],
                "pair": j["pair"],
                "price": j["price"],
                "market_cap": j["market_cap"],
                "volume_24h": j["volume_24h"],
                "change_1h_pct": j["change_1h_pct"],
                "change_24h_pct": j["change_24h_pct"],
                "cg_rank": j["cg_rank"],
                "spot_score": j["spot_score"],
            }
        )

    pool = build_candidate_pool(rows, mode)

    # 7) select TOP N from pool using spot_score then rank tie break
    pool_rows = []
    row_map = {r["unified_symbol"]: r for r in rows}
    for sym in pool:
        r = row_map.get(sym)
        if not r:
            continue
        if sym in EXCLUDE_STABLE_BASE:
            continue
        sc = safe_int(r.get("spot_score"), 0)
        rk = safe_int(r.get("cg_rank"), 10**9)
        pool_rows.append((sc, -rk, r))

    pool_rows.sort(key=lambda t: (t[0], t[1]), reverse=True)
    top = [t[2] for t in pool_rows[: int(top_n)]]

    # 8) store top_set and items
    top_set_id = "top_" + now_tag() + "_" + uuid.uuid4().hex[:6]
    con.execute(
        """
        INSERT INTO top_sets (
          top_set_id, created_utc, source_run_id,
          vs_currency, load_n, mode, top_n, filters_json, notes
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            top_set_id,
            utc_now_iso(),
            run_id,
            vs_currency,
            int(load_n),
            mode,
            int(top_n),
            json.dumps(
                {
                    "candidate_pool": "core_liquidity + momentum + volume_spike",
                    "exclude_stables": True,
                }
            ),
            "Fresh TOP built from current market snapshot",
        ),
    )
    con.execute("DELETE FROM top_set_items WHERE top_set_id = ?", (top_set_id,))
    created_items_utc = utc_now_iso()
    for idx, r in enumerate(top, start=1):
        con.execute(
            """
            INSERT INTO top_set_items (
              top_set_id, rank_in_top, unified_symbol, pair,
              price, market_cap, volume_24h,
              change_1h_pct, change_24h_pct,
              cg_rank, spot_score, created_utc
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                top_set_id,
                int(idx),
                r.get("unified_symbol"),
                r.get("pair"),
                r.get("price"),
                r.get("market_cap"),
                r.get("volume_24h"),
                r.get("change_1h_pct"),
                r.get("change_24h_pct"),
                r.get("cg_rank"),
                r.get("spot_score"),
                created_items_utc,
            ),
        )
    con.execute("UPDATE runs SET status=? WHERE run_id=?", ("ok", run_id))
    con.commit()

    # 9) write run file for audit
    run_file = os.path.join(RUNS_DIR, run_id + ".json")
    with open(run_file, "w", encoding="utf-8") as f:
        json.dump(
            {
                "run_id": run_id,
                "created_utc": created_utc,
                "app_version": APP_VERSION,
                "vs_currency": vs_currency,
                "load_n": int(load_n),
                "mode": mode,
                "timeframes": selected_timeframes,
                "status": "ok",
                "snapshot_id": snapshot_id,
                "top_set_id": top_set_id,
            },
            f,
            ensure_ascii=True,
            indent=2,
        )

    return run_id, top_set_id


class App:
    def __init__(self, root):
        self.root = root
        self.root.title("NyoSig Cryptolytix")
        self.font_size = FONT_DEFAULT

        self.vs_currency = tk.StringVar(value=DEFAULT_VS_CURRENCY)
        self.load_n = tk.StringVar(value=str(DEFAULT_LOAD_N))
        self.mode = tk.StringVar(value="balanced")
        self.top_n = tk.StringVar(value=str(DEFAULT_TOP_N))

        self.tf_vars = {}
        for tf in TIMEFRAMES:
            self.tf_vars[tf] = tk.BooleanVar(value=(tf in ["1h", "4h"]))

        self.status_var = tk.StringVar(value="Ready")
        self.current_top_set = None
        self.current_run_id = None

        self._build_ui()
        self._apply_font()

    def _build_ui(self):
        outer = ttk.Frame(self.root, padding=8)
        outer.pack(fill="both", expand=True)

        header = ttk.Frame(outer)
        header.pack(fill="x")

        title = ttk.Label(header, text="NyoSig Cryptolytix", font=("TkDefaultFont", 14, "bold"))
        title.pack(side="left", anchor="w")

        ver = ttk.Label(header, text="v" + APP_VERSION)
        ver.pack(side="right", anchor="e")

        cfg = ttk.LabelFrame(outer, text="TOP generator", padding=8)
        cfg.pack(fill="x", pady=6)

        r1 = ttk.Frame(cfg)
        r1.pack(fill="x")
        ttk.Label(r1, text="VS currency").pack(side="left")
        ttk.Entry(r1, textvariable=self.vs_currency, width=10).pack(side="left", padx=6)
        ttk.Label(r1, text="Load N").pack(side="left", padx=(12, 0))
        ttk.Entry(r1, textvariable=self.load_n, width=8).pack(side="left", padx=6)
        ttk.Label(r1, text="Mode").pack(side="left", padx=(12, 0))
        ttk.Combobox(r1, textvariable=self.mode, values=MODES, state="readonly", width=14).pack(side="left", padx=6)
        ttk.Label(r1, text="Top N").pack(side="left", padx=(12, 0))
        ttk.Entry(r1, textvariable=self.top_n, width=6).pack(side="left", padx=6)

        r2 = ttk.Frame(cfg)
        r2.pack(fill="x", pady=(6, 0))
        ttk.Label(r2, text="Timeframes for next layers").pack(side="left")
        for tf in TIMEFRAMES:
            ttk.Checkbutton(r2, text=tf, variable=self.tf_vars[tf]).pack(side="left", padx=6)

        actions = ttk.Frame(outer)
        actions.pack(fill="x", pady=6)

        self.btn_generate = ttk.Button(actions, text="Generate TOP (fresh)", command=self.on_generate_top)
        self.btn_generate.pack(side="left")

        self.btn_to_db = ttk.Button(actions, text="To DB", command=self.on_to_db)
        self.btn_to_db.pack(side="left", padx=6)

        self.btn_analyse = ttk.Button(actions, text="Analyse", command=self.on_analyse)
        self.btn_analyse.pack(side="left", padx=6)

        self.btn_exit = ttk.Button(actions, text="Exit", command=self.root.destroy)
        self.btn_exit.pack(side="right")

        table_frame = ttk.LabelFrame(outer, text="TOP set", padding=6)
        table_frame.pack(fill="both", expand=True)

        cols = ("Sel", "Rank", "Symbol", "Price", "MCap", "Vol24h", "Chg1h", "Chg24h", "Score")
        self.tree = ttk.Treeview(table_frame, columns=cols, show="headings", height=12)
        for c in cols:
            self.tree.heading(c, text=c)
            self.tree.column(c, width=90, anchor="w")
        self.tree.column("Sel", width=40, anchor="center")
        self.tree.column("Rank", width=50, anchor="e")
        self.tree.column("Symbol", width=90, anchor="w")

        self.tree.pack(side="left", fill="both", expand=True)
        sb = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")

        self.tree.bind("<Button-1>", self.on_tree_click)

        status = ttk.Frame(outer)
        status.pack(fill="x", pady=(6, 0))
        ttk.Label(status, textvariable=self.status_var).pack(side="left")

        fontbar = ttk.Frame(outer)
        fontbar.pack(fill="x", pady=(6, 0))
        ttk.Button(fontbar, text="A-", command=self.font_dec).pack(side="left")
        ttk.Button(fontbar, text="A+", command=self.font_inc).pack(side="left", padx=6)

    def _apply_font(self):
        try:
            style = ttk.Style()
            style.configure(".", font=("TkDefaultFont", int(self.font_size)))
            self.root.update_idletasks()
        except Exception:
            pass

    def font_inc(self):
        self.font_size = min(FONT_MAX, self.font_size + 1)
        self._apply_font()

    def font_dec(self):
        self.font_size = max(FONT_MIN, self.font_size - 1)
        self._apply_font()

    def set_status(self, s):
        self.status_var.set(s)
        self.root.update_idletasks()

    def selected_timeframes(self):
        tfs = []
        for tf in TIMEFRAMES:
            if self.tf_vars[tf].get():
                tfs.append(tf)
        if not tfs:
            tfs = ["1h"]
        return tfs

    def clear_table(self):
        for it in self.tree.get_children():
            self.tree.delete(it)

    def load_top_set(self, con, top_set_id):
        self.clear_table()
        rows = con.execute(
            """
            SELECT
              rank_in_top, unified_symbol, price, market_cap, volume_24h,
              change_1h_pct, change_24h_pct, spot_score
            FROM top_set_items
            WHERE top_set_id = ?
            ORDER BY rank_in_top ASC
            """,
            (top_set_id,),
        ).fetchall()

        for r in rows:
            self.tree.insert(
                "",
                "end",
                values=(
                    "1",
                    str(r["rank_in_top"]),
                    r["unified_symbol"],
                    fmt_price(r["price"]),
                    fmt_int(r["market_cap"]),
                    fmt_int(r["volume_24h"]),
                    fmt_pct(r["change_1h_pct"]),
                    fmt_pct(r["change_24h_pct"]),
                    str(r["spot_score"] if r["spot_score"] is not None else ""),
                ),
            )

    def on_tree_click(self, event):
        # Toggle selection in first column
        region = self.tree.identify("region", event.x, event.y)
        if region != "cell":
            return
        col = self.tree.identify_column(event.x)
        if col != "#1":
            return
        row_id = self.tree.identify_row(event.y)
        if not row_id:
            return
        vals = list(self.tree.item(row_id, "values"))
        if not vals:
            return
        vals[0] = "0" if vals[0] == "1" else "1"
        self.tree.item(row_id, values=tuple(vals))

    def on_generate_top(self):
        vs = (self.vs_currency.get() or DEFAULT_VS_CURRENCY).strip().lower()
        load_n = safe_int(self.load_n.get(), DEFAULT_LOAD_N)
        mode = (self.mode.get() or "balanced").strip().lower()
        top_n = safe_int(self.top_n.get(), DEFAULT_TOP_N)
        tfs = self.selected_timeframes()

        if load_n < 50:
            load_n = 50
        if top_n < 5:
            top_n = 5
        if top_n > 100:
            top_n = 100

        try:
            self.set_status("Generating fresh TOP from CoinGecko...")
            con = db_connect()
            ensure_schema(con)
            run_id, top_set_id = generate_top_fresh(con, vs, load_n, mode, top_n, tfs)
            self.current_run_id = run_id
            self.current_top_set = top_set_id
            self.load_top_set(con, top_set_id)
            con.close()
            self.set_status("OK: TOP generated fresh. run_id=" + run_id + " top_set_id=" + top_set_id)
        except Exception as e:
            self.set_status("ERROR: " + str(e))
            messagebox.showerror("Error", str(e))

    def on_to_db(self):
        # In this version, Generate TOP already writes to DB.
        if not self.current_top_set:
            messagebox.showinfo("Info", "No TOP set yet. Use Generate TOP first.")
            return
        messagebox.showinfo("Info", "Already stored. TOP set id: " + self.current_top_set)

    def on_analyse(self):
        # Stub for next layers window.
        if not self.current_top_set:
            messagebox.showinfo("Info", "Generate TOP first.")
            return

        win = tk.Toplevel(self.root)
        win.title("Analyse")
        win.geometry(self.root.winfo_screenwidth().__str__() + "x" + self.root.winfo_screenheight().__str__())

        header = ttk.Frame(win, padding=8)
        header.pack(fill="x")
        ttk.Label(header, text="Analyse pipeline", font=("TkDefaultFont", 14, "bold")).pack(side="left")
        ttk.Label(header, text="v" + APP_VERSION).pack(side="right")

        body = ttk.Frame(win, padding=8)
        body.pack(fill="both", expand=True)

        ttk.Label(body, text="Selected TOP set: " + self.current_top_set).pack(anchor="w", pady=(0, 6))
        ttk.Label(body, text="Mode: " + (self.mode.get() or "")).pack(anchor="w")
        ttk.Label(body, text="Timeframes: " + ", ".join(self.selected_timeframes())).pack(anchor="w", pady=(0, 10))

        ttk.Label(body, text="Next layers are not implemented here yet. This window confirms wiring only.").pack(anchor="w")

        ttk.Button(body, text="Close", command=win.destroy).pack(anchor="e", pady=12)


def main():
    ascii_guard()
    ensure_dirs()

    root = tk.Tk()

    # Fullscreen by default (fix for tiny windows)
    try:
        root.state("zoomed")
    except Exception:
        try:
            w = root.winfo_screenwidth()
            h = root.winfo_screenheight()
            root.geometry(str(w) + "x" + str(h))
        except Exception:
            pass

    app = App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
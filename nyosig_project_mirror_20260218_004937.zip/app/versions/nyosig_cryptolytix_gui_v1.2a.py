#!/usr/bin/env python3
# nyosig_cryptolytix_gui_v1.2a
# ASCII only (no BOM, no non-ascii chars)

import os
import sqlite3
import time
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import datetime

PROJECT_ROOT = "/storage/emulated/0/NyoSig/NyoSig_Cryptolytix"
DB_PATH = os.path.join(PROJECT_ROOT, "db", "nyosig_cryptolytix.db")

EXCLUDE_STABLE_BASE = {
    "USDT", "USDC", "DAI", "TUSD", "FDUSD", "USDP", "BUSD", "EURC", "USDE", "USD1"
}

TIMEFRAMES = ["1m", "5m", "15m", "30m", "1h", "4h", "1d", "1w"]

FONT_SIZE_DEFAULT = 4
FONT_SIZE_MIN = 4
FONT_SIZE_MAX = 30


def utc_now_iso():
    return datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def safe_int(x, default=0):
    try:
        return int(x)
    except Exception:
        return default


def safe_float(x, default=None):
    try:
        if x is None:
            return default
        return float(x)
    except Exception:
        return default


def fmt_num(x, digits=2):
    if x is None:
        return ""
    v = safe_float(x, None)
    if v is None:
        return ""
    if abs(v) >= 1000:
        return f"{v:,.0f}"
    return f"{v:.{digits}f}"


def fmt_price(x):
    if x is None:
        return ""
    v = safe_float(x, None)
    if v is None:
        return ""
    if abs(v) >= 1:
        return f"{v:,.4f}"
    return f"{v:.8f}"


def fmt_pct(x):
    if x is None:
        return ""
    v = safe_float(x, None)
    if v is None:
        return ""
    return f"{v:.2f}"


def db_connect():
    if not os.path.exists(DB_PATH):
        raise RuntimeError("DB not found at: " + DB_PATH)
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON;")
    return con


def ensure_spot_features_table(con):
    con.execute(
        """
        CREATE TABLE IF NOT EXISTS spot_features (
          run_id TEXT NOT NULL,
          unified_symbol TEXT NOT NULL,
          score INTEGER NOT NULL,
          created_at TEXT,
          mode TEXT,
          timeframe TEXT,
          PRIMARY KEY (run_id, unified_symbol)
        );
        """
    )
    con.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_spot_features_run_score
        ON spot_features (run_id, score DESC);
        """
    )


class App(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("NyoSig Cryptolytix")
        self._set_big_window()

        self.current_run_id = None
        self.current_run_meta = None

        self.rows_all = []
        self.rows_view = []
        self.top_rows = []

        self.loading = False

        self.font_size_var = tk.IntVar(value=FONT_SIZE_DEFAULT)
        self.timeframe_var = tk.StringVar(value="4h")

        self.load_n_var = tk.IntVar(value=300)
        self.top_n_var = tk.IntVar(value=15)

        self.mode_var = tk.StringVar(value="standard")  # aggressive / standard / conservative

        self.status_var = tk.StringVar(value="Ready")

        self._build_ui()
        self._apply_tree_font()
        self.refresh_from_db()

    def _set_big_window(self):
        try:
            w = self.winfo_screenwidth()
            h = self.winfo_screenheight()
            self.geometry(f"{w}x{h}")
        except Exception:
            self.geometry("1040x790")

    def _apply_tree_font(self):
        fs = safe_int(self.font_size_var.get(), FONT_SIZE_DEFAULT)
        if fs < FONT_SIZE_MIN:
            fs = FONT_SIZE_MIN
        if fs > FONT_SIZE_MAX:
            fs = FONT_SIZE_MAX
        style = ttk.Style(self)
        try:
            style.theme_use("default")
        except Exception:
            pass
        style.configure("Treeview", font=("TkDefaultFont", fs))
        style.configure("Treeview.Heading", font=("TkDefaultFont", fs))

    def _build_ui(self):
        top = ttk.Frame(self, padding=6)
        top.pack(fill=tk.X)

        # Row 1
        row1 = ttk.Frame(top)
        row1.pack(fill=tk.X)

        self.btn_refresh = ttk.Button(row1, text="Refresh DB", command=self.refresh_from_db)
        self.btn_refresh.pack(side=tk.LEFT)

        ttk.Label(row1, text="  Load N:").pack(side=tk.LEFT)
        self.load_spin = ttk.Spinbox(row1, from_=50, to=5000, increment=50, textvariable=self.load_n_var, width=7)
        self.load_spin.pack(side=tk.LEFT)

        ttk.Label(row1, text="  Top N:").pack(side=tk.LEFT)
        self.top_spin = ttk.Spinbox(row1, from_=5, to=500, increment=5, textvariable=self.top_n_var, width=6)
        self.top_spin.pack(side=tk.LEFT)

        self.btn_recalc = ttk.Button(row1, text="Recalc Top", command=self.recalc_top)
        self.btn_recalc.pack(side=tk.LEFT, padx=(6, 0))

        ttk.Label(row1, text="  Mode:").pack(side=tk.LEFT)
        self.mode_combo = ttk.Combobox(
            row1, textvariable=self.mode_var, values=["aggressive", "standard", "conservative"], state="readonly", width=12
        )
        self.mode_combo.pack(side=tk.LEFT)
        self.mode_combo.bind("<<ComboboxSelected>>", lambda _e: self.recalc_top())

        self.btn_export_top = ttk.Button(row1, text="Export Top to DB", command=self.export_top_to_db)
        self.btn_export_top.pack(side=tk.LEFT, padx=(10, 0))

        self.progress = ttk.Progressbar(row1, mode="indeterminate", length=140)
        self.progress.pack(side=tk.RIGHT)

        # Row 2 (moved controls here so they are visible on mobile)
        row2 = ttk.Frame(top)
        row2.pack(fill=tk.X, pady=(6, 0))

        ttk.Label(row2, text="Timeframe:").pack(side=tk.LEFT)
        self.tf_combo = ttk.Combobox(row2, textvariable=self.timeframe_var, values=TIMEFRAMES, state="readonly", width=6)
        self.tf_combo.pack(side=tk.LEFT)
        self.tf_combo.bind("<<ComboboxSelected>>", lambda _e: self.recalc_top())

        ttk.Label(row2, text="  Font:").pack(side=tk.LEFT)
        self.font_spin = ttk.Spinbox(
            row2, from_=FONT_SIZE_MIN, to=FONT_SIZE_MAX, increment=1, textvariable=self.font_size_var, width=4
        )
        self.font_spin.pack(side=tk.LEFT)
        self.font_spin.bind("<FocusOut>", lambda _e: self.on_font_change())
        self.font_spin.bind("<Return>", lambda _e: self.on_font_change())

        self.btn_font_apply = ttk.Button(row2, text="Apply Font", command=self.on_font_change)
        self.btn_font_apply.pack(side=tk.LEFT, padx=(6, 0))

        self.btn_show_report = ttk.Button(row2, text="Show Report", command=lambda: self.nb.select(self.tab_report))
        self.btn_show_report.pack(side=tk.LEFT, padx=(10, 0))

        self.btn_show_table = ttk.Button(row2, text="Show Table", command=lambda: self.nb.select(self.tab_table))
        self.btn_show_table.pack(side=tk.LEFT, padx=(6, 0))

        ttk.Label(row2, text="  Status:").pack(side=tk.LEFT, padx=(12, 0))
        ttk.Label(row2, textvariable=self.status_var).pack(side=tk.LEFT)

        # Notebook (two screens, mobile friendly)
        self.nb = ttk.Notebook(self)
        self.nb.pack(fill=tk.BOTH, expand=True)

        self.tab_table = ttk.Frame(self.nb)
        self.tab_report = ttk.Frame(self.nb)

        self.nb.add(self.tab_table, text="Table")
        self.nb.add(self.tab_report, text="Report")

        # Table area
        table_wrap = ttk.Frame(self.tab_table, padding=6)
        table_wrap.pack(fill=tk.BOTH, expand=True)

        cols = ["rank", "pair", "price", "chg24", "vol24", "mcap", "score"]
        self.tree = ttk.Treeview(table_wrap, columns=cols, show="headings", height=18)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self._tree_sort_state = {"col": None, "desc": True}

        self.tree.heading("rank", text="Rank", command=lambda: self.sort_by("rank"))
        self.tree.heading("pair", text="Pair", command=lambda: self.sort_by("pair"))
        self.tree.heading("price", text="Price", command=lambda: self.sort_by("price"))
        self.tree.heading("chg24", text="Chg24%", command=lambda: self.sort_by("chg24"))
        self.tree.heading("vol24", text="Vol24", command=lambda: self.sort_by("vol24"))
        self.tree.heading("mcap", text="MCap", command=lambda: self.sort_by("mcap"))
        self.tree.heading("score", text="Score", command=lambda: self.sort_by("score"))

        self.tree.column("rank", width=70, anchor=tk.E)
        self.tree.column("pair", width=120, anchor=tk.W)
        self.tree.column("price", width=110, anchor=tk.E)
        self.tree.column("chg24", width=90, anchor=tk.E)
        self.tree.column("vol24", width=120, anchor=tk.E)
        self.tree.column("mcap", width=140, anchor=tk.E)
        self.tree.column("score", width=80, anchor=tk.E)

        ysb = ttk.Scrollbar(table_wrap, orient="vertical", command=self.tree.yview)
        xsb = ttk.Scrollbar(table_wrap, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscroll=ysb.set, xscroll=xsb.set)
        ysb.pack(side=tk.RIGHT, fill=tk.Y)
        xsb.pack(side=tk.BOTTOM, fill=tk.X)

        # Report area
        rep_wrap = ttk.Frame(self.tab_report, padding=6)
        rep_wrap.pack(fill=tk.BOTH, expand=True)

        self.report_text = tk.Text(rep_wrap, wrap="word")
        self.report_text.pack(fill=tk.BOTH, expand=True)

        rep_bottom = ttk.Frame(rep_wrap, padding=(0, 6, 0, 0))
        rep_bottom.pack(fill=tk.X)

        self.btn_save_report = ttk.Button(rep_bottom, text="Save Report TXT", command=self.save_report_txt)
        self.btn_save_report.pack(side=tk.RIGHT)

    def set_loading(self, on, msg):
        self.loading = on
        self.status_var.set(msg)
        if on:
            self.progress.start(12)
            self.btn_refresh.config(state=tk.DISABLED)
            self.btn_recalc.config(state=tk.DISABLED)
            self.btn_export_top.config(state=tk.DISABLED)
        else:
            self.progress.stop()
            self.btn_refresh.config(state=tk.NORMAL)
            self.btn_recalc.config(state=tk.NORMAL)
            self.btn_export_top.config(state=tk.NORMAL)

    def on_font_change(self):
        self._apply_tree_font()

    def refresh_from_db(self):
        try:
            self.set_loading(True, "Loading DB...")
            con = db_connect()
            try:
                # last run
                run = con.execute(
                    """
                    SELECT run_id, created_utc, status, vs_currency, coins_limit, sort_mode, source
                    FROM runs
                    ORDER BY run_id DESC
                    LIMIT 1
                    """
                ).fetchone()

                if not run:
                    self.current_run_id = None
                    self.current_run_meta = None
                    self.rows_all = []
                    self.rows_view = []
                    self.top_rows = []
                    self._refresh_tree([])
                    self._set_report("")
                    self.set_loading(False, "No runs in DB")
                    return

                self.current_run_id = str(run["run_id"])
                self.current_run_meta = dict(run)

                # load spot rows
                limit_n = safe_int(self.load_n_var.get(), 300)
                if limit_n <= 0:
                    limit_n = 300

                rows = con.execute(
                    """
                    SELECT unified_symbol, pair, price, change_24h_pct, volume_24h, market_cap, rank, score, source, captured_utc
                    FROM spot_markets
                    WHERE run_id = ?
                    ORDER BY rank ASC
                    LIMIT ?
                    """,
                    (self.current_run_id, limit_n),
                ).fetchall()

                out = []
                for r in rows:
                    sym = (r["unified_symbol"] or "").upper().strip()
                    if not sym:
                        continue
                    if sym in EXCLUDE_STABLE_BASE:
                        continue
                    out.append(
                        {
                            "symbol": sym,
                            "pair": r["pair"] or (sym + "/USD"),
                            "price": safe_float(r["price"], None),
                            "chg24": safe_float(r["change_24h_pct"], None),
                            "vol24": safe_float(r["volume_24h"], None),
                            "mcap": safe_float(r["market_cap"], None),
                            "rank": safe_int(r["rank"], 999999),
                            "score": safe_int(r["score"], 0),
                        }
                    )

                self.rows_all = out
                self.rows_view = list(out)

                self._refresh_tree(self.rows_view)
                self.recalc_top(silent=True)

                self.set_loading(False, "Ready")
            finally:
                con.close()
        except Exception as e:
            self.set_loading(False, "Error")
            messagebox.showerror("Error", str(e)[:800])

    def _refresh_tree(self, rows):
        self.tree.delete(*self.tree.get_children())
        for r in rows:
            self.tree.insert(
                "",
                "end",
                values=(
                    r.get("rank", ""),
                    r.get("pair", ""),
                    fmt_price(r.get("price")),
                    fmt_pct(r.get("chg24")),
                    fmt_num(r.get("vol24"), 0),
                    fmt_num(r.get("mcap"), 0),
                    r.get("score", ""),
                ),
            )

    def sort_by(self, col):
        if not self.rows_view:
            return
        desc = True
        if self._tree_sort_state["col"] == col:
            desc = not self._tree_sort_state["desc"]

        def keyf(r):
            v = r.get(col)
            if col in ("pair",):
                return (str(v or "")).upper()
            if v is None:
                return -1e99
            return float(v) if isinstance(v, (int, float)) else safe_float(v, -1e99)

        self.rows_view = sorted(self.rows_view, key=keyf, reverse=desc)
        self._tree_sort_state = {"col": col, "desc": desc}
        self._refresh_tree(self.rows_view)

    def _top_score_aggressive(self, r):
        vol = safe_float(r.get("vol24"), 0.0) or 0.0
        chg = abs(safe_float(r.get("chg24"), 0.0) or 0.0)
        rank = safe_float(r.get("rank"), 999999.0) or 999999.0
        base = safe_float(r.get("score"), 0.0) or 0.0
        return (base * 1.0) + (math_log1p(vol) * 8.0) + (chg * 2.0) - (rank * 0.01)

    def _top_score_standard(self, r):
        vol = safe_float(r.get("vol24"), 0.0) or 0.0
        chg = abs(safe_float(r.get("chg24"), 0.0) or 0.0)
        rank = safe_float(r.get("rank"), 999999.0) or 999999.0
        base = safe_float(r.get("score"), 0.0) or 0.0
        return (base * 1.2) + (math_log1p(vol) * 6.0) + (chg * 1.0) - (rank * 0.015)

    def _top_score_conservative(self, r):
        vol = safe_float(r.get("vol24"), 0.0) or 0.0
        chg = abs(safe_float(r.get("chg24"), 0.0) or 0.0)
        rank = safe_float(r.get("rank"), 999999.0) or 999999.0
        base = safe_float(r.get("score"), 0.0) or 0.0
        # punish big daily moves for conservative
        return (base * 1.4) + (math_log1p(vol) * 5.0) - (chg * 1.5) - (rank * 0.02)

    def recalc_top(self, silent=False):
        if not self.rows_all:
            self.top_rows = []
            self._set_report("")
            return

        try:
            self.set_loading(True, "Recalc Top...")
            top_n = safe_int(self.top_n_var.get(), 15)
            if top_n <= 0:
                top_n = 15

            mode = (self.mode_var.get() or "standard").strip().lower()
            tf = (self.timeframe_var.get() or "4h").strip()

            # requirement: first selection by vol24
            base_sorted = sorted(
                self.rows_all,
                key=lambda r: (
                    safe_float(r.get("vol24"), 0.0) or 0.0,
                    -(safe_float(r.get("mcap"), 0.0) or 0.0),
                    -(safe_float(r.get("rank"), 999999.0) or 999999.0),
                ),
                reverse=True,
            )

            scored = []
            for r in base_sorted:
                sym = (r.get("symbol") or "").upper().strip()
                if not sym:
                    continue
                if sym in EXCLUDE_STABLE_BASE:
                    continue
                rr = dict(r)
                if mode == "aggressive":
                    rr["_top_score"] = self._top_score_aggressive(rr)
                elif mode == "conservative":
                    rr["_top_score"] = self._top_score_conservative(rr)
                else:
                    rr["_top_score"] = self._top_score_standard(rr)
                scored.append(rr)

            scored = sorted(scored, key=lambda r: (r.get("_top_score", 0.0), r.get("vol24", 0.0)), reverse=True)
            self.top_rows = scored[:top_n]

            self._set_report(self._build_report(tf=tf, mode=mode, top_rows=self.top_rows))

            if not silent:
                self.nb.select(self.tab_report)

            self.set_loading(False, "Ready")
        except Exception as e:
            self.set_loading(False, "Error")
            messagebox.showerror("Error", str(e)[:800])

    def _build_report(self, tf, mode, top_rows):
        lines = []
        run_id = self.current_run_id or "?"
        lines.append("TA TOP report")
        lines.append(f"run_id: {run_id}")
        lines.append(f"mode: {mode}   timeframe: {tf}")
        lines.append("")

        for i, r in enumerate(top_rows, start=1):
            sym = r.get("symbol", "")
            pair = f"{sym}/USD"
            price = r.get("price", None)
            chg24 = r.get("chg24", None)
            vol24 = r.get("vol24", None)
            mcap = r.get("mcap", None)
            rank = r.get("rank", None)
            score = r.get("score", None)

            one = (
                f"{i}. {pair}  price={fmt_price(price)}  chg24={fmt_pct(chg24)}%  "
                f"vol24={fmt_num(vol24,0)}  mcap={fmt_num(mcap,0)}  rank={rank}  score={score}"
            )
            lines.append(one)

        lines.append("")
        lines.append("Note: This is SPOT selection only. Next layers (ohlcv, features, plans) are separate.")
        return "\n".join(lines).strip() + "\n"

    def _set_report(self, txt):
        self.report_text.delete("1.0", "end")
        self.report_text.insert("1.0", txt or "")
        self.report_text.see("1.0")

    def save_report_txt(self):
        try:
            default_name = f"top_report_{time.strftime('%Y%m%d_%H%M%S')}.txt"
            path = filedialog.asksaveasfilename(
                title="Save report",
                defaultextension=".txt",
                initialfile=default_name,
                filetypes=[("Text", "*.txt"), ("All", "*.*")],
            )
            if not path:
                return
            content = self.report_text.get("1.0", "end").strip() + "\n"
            with open(path, "w", encoding="utf-8") as f:
                f.write(content)
            messagebox.showinfo("OK", "Saved:\n" + path)
        except Exception as e:
            messagebox.showerror("Error", str(e)[:800])

    def export_top_to_db(self):
        if not self.current_run_id:
            messagebox.showerror("Error", "No run loaded")
            return
        if not self.top_rows:
            messagebox.showerror("Error", "Top is empty, press Recalc Top")
            return

        try:
            self.set_loading(True, "Export Top to DB...")
            con = db_connect()
            try:
                ensure_spot_features_table(con)
                con.execute("BEGIN;")
                mode = (self.mode_var.get() or "standard").strip().lower()
                tf = (self.timeframe_var.get() or "4h").strip()

                for r in self.top_rows:
                    sym = (r.get("symbol") or "").upper().strip()
                    if not sym:
                        continue
                    # store _top_score as integer 1..100-ish is not required yet, keep existing score if present
                    s = safe_int(r.get("score"), 0)
                    con.execute(
                        """
                        INSERT OR REPLACE INTO spot_features (run_id, unified_symbol, score, created_at, mode, timeframe)
                        VALUES (?, ?, ?, ?, ?, ?)
                        """,
                        (self.current_run_id, sym, int(s), utc_now_iso(), mode, tf),
                    )

                con.commit()
                self.set_loading(False, "Ready")
                messagebox.showinfo("OK", f"Exported {len(self.top_rows)} rows to spot_features for run_id {self.current_run_id}")
            except Exception:
                con.rollback()
                raise
            finally:
                con.close()
        except Exception as e:
            self.set_loading(False, "Error")
            messagebox.showerror("Error", str(e)[:800])


def math_log1p(x):
    # avoid importing math to keep it simple, safe for large numbers
    try:
        import math
        return math.log1p(max(0.0, float(x)))
    except Exception:
        return 0.0


if __name__ == "__main__":
    # hard rule: fixed root path only
    if not os.path.isdir(PROJECT_ROOT):
        messagebox.showerror("Error", "Project root not found:\n" + PROJECT_ROOT)
        raise SystemExit(1)

    app = App()
    app.mainloop()
#!/usr/bin/env python3
# nyosig_cryptolytix_gui_v3.8d
# Refactor continuation: watchlist + analysis + export moved into /core (thin GUI)
# ASCII only, Tkinter GUI

import os
import sys
import tkinter as tk
from tkinter import ttk, messagebox

from core.config import make_paths, parse_simple_yaml, parse_secrets_env, get_project_root
from core.cache import ensure_dir
from core.util_time import utc_now_iso, utc_stamp_compact
from core.pipeline import run_snapshot_and_topnow, refresh_snapshot
from core.db import db_connect, require_schema, ensure_indexes, ensure_snapshot_schema
from core.analysis import prepare_analysis
from core.export import export_selection_csv
from core.watchlist import ensure_watchlist_schema, add_watch, remove_watch, list_watch, refresh_watch, list_alerts
from core.diff import snapshot_diff_summary

PROJECT_ROOT = get_project_root()
APP_VERSION = "v3.8d"

class ResultWindow(tk.Toplevel):
    def __init__(self, master, paths, selection_id: int, snapshot_id: str):
        super().__init__(master)
        self.title(f"TopNow Results sel={selection_id}")
        self.geometry("920x620")
        self.paths = paths
        self.selection_id = int(selection_id)
        self.snapshot_id = snapshot_id
        self.timeframe = "spot"
        self._build_ui()
        self._load()

    def _build_ui(self):
        top = ttk.Frame(self, padding=8)
        top.pack(fill="x")
        ttk.Label(top, text=f"snapshot_id: {self.snapshot_id}").pack(side="left")
        ttk.Label(top, text=f"selection_id: {self.selection_id}").pack(side="left", padx=10)

        cols = ("rank", "symbol", "preview", "mrank", "mcap", "vol24", "chg24", "price", "ts")
        self.tree = ttk.Treeview(self, columns=cols, show="headings")
        for c in cols:
            self.tree.heading(c, text=c)
            self.tree.column(c, width=110, anchor="w")
        self.tree.column("symbol", width=90)
        self.tree.pack(fill="both", expand=True, padx=8, pady=8)

        btns = ttk.Frame(self, padding=8)
        btns.pack(fill="x")
        ttk.Button(btns, text="Refresh view", command=self._load).pack(side="left")
        ttk.Button(btns, text="Close", command=self.destroy).pack(side="right")

    def _load(self):
        for i in self.tree.get_children():
            self.tree.delete(i)
        con = None
        try:
            con = db_connect(self.paths.db_path)
            require_schema(con)
            q = (
                "SELECT i.rank_in_selection, i.unified_symbol, i.composite_preview, "
                "m.rank, m.mcap, m.vol24, m.change_24h_pct, m.price, m.timestamp_utc "
                "FROM topnow_selection_items i "
                "LEFT JOIN market_snapshots m "
                "ON m.snapshot_id=? AND m.timeframe=? AND m.unified_symbol=i.unified_symbol "
                "WHERE i.selection_id=? "
                "ORDER BY i.rank_in_selection ASC;"
            )
            rows = con.execute(q, (self.snapshot_id, self.timeframe, self.selection_id)).fetchall()
            for r in rows:
                self.tree.insert("", "end", values=r)
        except Exception as e:
            messagebox.showerror("Error", str(e)[:1200])
        finally:
            if con:
                con.close()

class WatchlistWindow(tk.Toplevel):
    def __init__(self, master, paths, snapshot_id_getter):
        super().__init__(master)
        self.title("Watchlist")
        self.geometry("980x620")
        self.paths = paths
        self.snapshot_id_getter = snapshot_id_getter
        self._build_ui()
        self._load()

    def _build_ui(self):
        top = ttk.Frame(self, padding=8)
        top.pack(fill="x")

        ttk.Label(top, text="Symbol").pack(side="left")
        self.sym = tk.StringVar(value="")
        ttk.Entry(top, textvariable=self.sym, width=12).pack(side="left", padx=6)

        ttk.Label(top, text="Tag").pack(side="left")
        self.tag = tk.StringVar(value="")
        ttk.Entry(top, textvariable=self.tag, width=14).pack(side="left", padx=6)

        ttk.Label(top, text="Stage").pack(side="left")
        self.stage = tk.StringVar(value="new")
        ttk.Entry(top, textvariable=self.stage, width=10).pack(side="left", padx=6)

        ttk.Button(top, text="Add", command=self._add).pack(side="left", padx=6)
        ttk.Button(top, text="Remove selected", command=self._remove_selected).pack(side="left", padx=6)
        ttk.Button(top, text="Refresh metrics (from last snapshot)", command=self._refresh_metrics).pack(side="left", padx=6)

        cols = ("watch_id","symbol","tag","stage","since","entry_snapshot","entry_score","last_ref_utc","last_price","last_chg24","last_score")
        self.tree = ttk.Treeview(self, columns=cols, show="headings")
        for c in cols:
            self.tree.heading(c, text=c)
            self.tree.column(c, width=120, anchor="w")
        self.tree.column("watch_id", width=70)
        self.tree.column("symbol", width=80)
        self.tree.pack(fill="both", expand=True, padx=8, pady=8)

        bottom = ttk.Frame(self, padding=8)
        bottom.pack(fill="x")
        ttk.Button(bottom, text="Show alerts", command=self._show_alerts).pack(side="left")
        ttk.Button(bottom, text="Close", command=self.destroy).pack(side="right")

    def _db(self):
        con = db_connect(self.paths.db_path)
        ensure_watchlist_schema(con)
        return con

    def _load(self):
        for i in self.tree.get_children():
            self.tree.delete(i)
        con = None
        try:
            con = self._db()
            rows = list_watch(con)
            for r in rows:
                self.tree.insert("", "end", values=r)
        except Exception as e:
            messagebox.showerror("Error", str(e)[:1200])
        finally:
            if con:
                con.close()

    def _add(self):
        sym = self.sym.get().strip().upper()
        if not sym:
            return
        con = None
        try:
            con = self._db()
            add_watch(con, sym, self.tag.get().strip(), self.stage.get().strip(), utc_now_iso(),
                      entry_snapshot_id=self.snapshot_id_getter() or "", entry_score=0.0)
            con.commit()
            self.sym.set("")
            self._load()
        except Exception as e:
            if con:
                con.rollback()
            messagebox.showerror("Error", str(e)[:1200])
        finally:
            if con:
                con.close()

    def _remove_selected(self):
        sel = self.tree.selection()
        if not sel:
            return
        con = None
        try:
            con = self._db()
            for item in sel:
                wid = int(self.tree.item(item, "values")[0])
                remove_watch(con, wid)
            con.commit()
            self._load()
        except Exception as e:
            if con:
                con.rollback()
            messagebox.showerror("Error", str(e)[:1200])
        finally:
            if con:
                con.close()

    def _refresh_metrics(self):
        snap = self.snapshot_id_getter()
        if not snap or snap == "-":
            messagebox.showinfo("Info", "No snapshot_id available yet. Run pipeline first.")
            return
        con = None
        try:
            con = self._db()
            n = refresh_watch(con, snap, "spot", utc_now_iso())
            con.commit()
            messagebox.showinfo("Watchlist", f"Refreshed {n} items from snapshot {snap}")
            self._load()
        except Exception as e:
            if con:
                con.rollback()
            messagebox.showerror("Error", str(e)[:1200])
        finally:
            if con:
                con.close()

    def _show_alerts(self):
        con = None
        try:
            con = self._db()
            rows = list_alerts(con, 200)
        except Exception as e:
            messagebox.showerror("Error", str(e)[:1200])
            return
        finally:
            if con:
                con.close()

        win = tk.Toplevel(self)
        win.title("Watchlist alerts")
        win.geometry("980x420")
        cols = ("alert_id","created_utc","severity","symbol","message")
        tree = ttk.Treeview(win, columns=cols, show="headings")
        for c in cols:
            tree.heading(c, text=c)
            tree.column(c, width=160, anchor="w")
        tree.column("alert_id", width=70)
        tree.column("severity", width=90)
        tree.column("symbol", width=90)
        tree.pack(fill="both", expand=True, padx=8, pady=8)
        for r in rows:
            tree.insert("", "end", values=r)

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"NyoSig Cryptolytix GUI {APP_VERSION}")
        self.geometry("900x820")
        self.minsize(760, 620)

        self.paths = make_paths(PROJECT_ROOT)
        ensure_dir(self.paths.cache_dir)
        ensure_dir(self.paths.log_dir)
        ensure_dir(os.path.join(self.paths.project_root, "exports"))

        self.cfg = parse_simple_yaml(self.paths.defaults_yaml)
        self.secrets = parse_secrets_env(self.paths.secrets_env)

        mvp = self.cfg.get("mvp", {})
        self.scope = tk.StringVar(value="crypto_spot")
        self.vs_currency = tk.StringVar(value=str(mvp.get("vs_currency", "usd")).lower())
        self.coins_limit = tk.IntVar(value=int(mvp.get("coins_limit", 250)))
        self.order = tk.StringVar(value=str(mvp.get("order", "market_cap_desc")))
        self.topnow_limit = tk.IntVar(value=int(mvp.get("topnow_limit", 100)))
        self.offline_mode = tk.BooleanVar(value=bool(mvp.get("offline_mode", False)))

        self.status_var = tk.StringVar(value="Ready")
        self.last_run_var = tk.StringVar(value="-")
        self.last_snapshot_var = tk.StringVar(value="-")
        self.last_selection_var = tk.StringVar(value="-")

        self.last_log_path = None
        self._build_ui()

    def _build_ui(self):
        root = ttk.Frame(self, padding=10)
        root.pack(fill="both", expand=True)

        hdr = ttk.Frame(root)
        hdr.pack(fill="x")

        ttk.Label(hdr, text="Project root").grid(row=0, column=0, sticky="w")
        ttk.Label(hdr, text=self.paths.project_root).grid(row=0, column=1, sticky="w")

        ttk.Label(hdr, text="DB").grid(row=1, column=0, sticky="w")
        ttk.Label(hdr, text=self.paths.db_path).grid(row=1, column=1, sticky="w")

        ttk.Separator(root).pack(fill="x", pady=10)

        form = ttk.Frame(root)
        form.pack(fill="x")

        ttk.Label(form, text="Scope").grid(row=0, column=0, sticky="w", padx=(0, 8), pady=4)
        ttk.Combobox(form, textvariable=self.scope, state="readonly",
                     values=["crypto_spot", "crypto_derivatives", "macro", "institutions", "sentiment"]).grid(row=0, column=1, sticky="w", pady=4)

        ttk.Label(form, text="vs_currency").grid(row=1, column=0, sticky="w", padx=(0, 8), pady=4)
        ttk.Entry(form, textvariable=self.vs_currency, width=12).grid(row=1, column=1, sticky="w", pady=4)

        ttk.Label(form, text="coins_limit").grid(row=2, column=0, sticky="w", padx=(0, 8), pady=4)
        ttk.Entry(form, textvariable=self.coins_limit, width=12).grid(row=2, column=1, sticky="w", pady=4)

        ttk.Label(form, text="order").grid(row=3, column=0, sticky="w", padx=(0, 8), pady=4)
        ttk.Entry(form, textvariable=self.order, width=24).grid(row=3, column=1, sticky="w", pady=4)

        ttk.Label(form, text="TopNow candidates").grid(row=4, column=0, sticky="w", padx=(0, 8), pady=4)
        ttk.Entry(form, textvariable=self.topnow_limit, width=12).grid(row=4, column=1, sticky="w", pady=4)

        ttk.Checkbutton(form, text="offline_mode", variable=self.offline_mode).grid(row=5, column=1, sticky="w", pady=6)

        btns = ttk.Frame(root)
        btns.pack(fill="x", pady=10)
        ttk.Button(btns, text="Run Snapshot + TopNow", command=self.run_pipeline).pack(side="left")
        ttk.Button(btns, text="Prepare Analysis (spot_basic)", command=self.do_analysis).pack(side="left", padx=6)
        ttk.Button(btns, text="Open Results", command=self.open_results).pack(side="left", padx=6)
        ttk.Button(btns, text="Export CSV", command=self.export_csv).pack(side="left", padx=6)
        ttk.Button(btns, text="Watchlist", command=self.open_watchlist).pack(side="left", padx=6)
        ttk.Button(btns, text="Open last run log", command=self.open_last_log).pack(side="right")

        ttk.Separator(root).pack(fill="x", pady=10)

        info = ttk.Frame(root)
        info.pack(fill="x")

        ttk.Label(info, text="Status").grid(row=0, column=0, sticky="w")
        ttk.Label(info, textvariable=self.status_var).grid(row=0, column=1, sticky="w")

        ttk.Label(info, text="Last run_id").grid(row=1, column=0, sticky="w")
        ttk.Label(info, textvariable=self.last_run_var).grid(row=1, column=1, sticky="w")

        ttk.Label(info, text="Last snapshot_id").grid(row=2, column=0, sticky="w")
        ttk.Label(info, textvariable=self.last_snapshot_var).grid(row=2, column=1, sticky="w")

        ttk.Label(info, text="Last selection_id").grid(row=3, column=0, sticky="w")
        ttk.Label(info, textvariable=self.last_selection_var).grid(row=3, column=1, sticky="w")

        ttk.Separator(root).pack(fill="x", pady=10)

        self.log = tk.Text(root, height=18)
        self.log.pack(fill="both", expand=True)
        self.log.insert("end", "Log\n")

    def log_cb(self, msg: str):
        self.log.insert("end", utc_now_iso() + " " + msg + "\n")
        self.log.see("end")
        self.update_idletasks()

    def _last_snapshot_id(self) -> str:
        return self.last_snapshot_var.get().strip()

    def _last_selection_id(self) -> str:
        s = self.last_selection_var.get().strip()
        return s

    def open_results(self):
        sid = self._last_selection_id()
        snap = self._last_snapshot_id()
        if not sid or sid == "-" or not snap or snap == "-":
            messagebox.showinfo("Info", "No results yet. Run pipeline first.")
            return
        ResultWindow(self, self.paths, int(sid), snap)

    def open_watchlist(self):
        WatchlistWindow(self, self.paths, self._last_snapshot_id)

    def open_last_log(self):
        if not self.last_log_path or not os.path.isfile(self.last_log_path):
            messagebox.showinfo("Info", "No log file yet")
            return
        try:
            if sys.platform.startswith("linux"):
                os.system(f'xdg-open "{self.last_log_path}"')
            else:
                os.system(f'open "{self.last_log_path}"')
        except Exception:
            messagebox.showinfo("Log path", self.last_log_path)

    def refresh_snapshot(self):
        parent_snapshot = self.last_snapshot_var.get().strip()
        if not parent_snapshot or parent_snapshot == "-":
            messagebox.showinfo("Info", "No last snapshot to refresh")
            return
        scope_text = self.scope.get().strip()
        vs_currency = self.vs_currency.get().strip().lower() or "usd"
        coins_limit = int(self.coins_limit.get())
        order = self.order.get().strip() or "market_cap_desc"
        offline_mode = bool(self.offline_mode.get())
        try:
            self.status_var.set("Refreshing")
            run_id, snap = refresh_snapshot(PROJECT_ROOT, APP_VERSION, parent_snapshot, scope_text, vs_currency, coins_limit, order, offline_mode, self.log_cb, reason="gui_refresh")
            self.last_run_var.set(str(run_id))
            self.last_snapshot_var.set(snap)
            self.status_var.set("Done")
            self.log_cb(f"REFRESH_DONE run_id={run_id} snapshot_id={snap} parent={parent_snapshot}")
        except Exception as e:
            self.status_var.set("Failed")
            self.log_cb("REFRESH_FAILED " + str(e))
            messagebox.showerror("Error", str(e)[:1200])

    def diff_last_two(self):
        # best-effort: get last two snapshots by created_utc
        try:
            from core.config import make_paths
            paths = make_paths(PROJECT_ROOT)
            con = db_connect(paths.db_path)
            require_schema(con)
            ensure_indexes(con)
            ensure_snapshot_schema(con)
            rows = con.execute("SELECT snapshot_key FROM snapshots ORDER BY created_utc DESC LIMIT 2;").fetchall()
            con.close()
            if len(rows) < 2:
                messagebox.showinfo("Info", "Need at least 2 snapshots")
                return
            b = rows[0][0]
            a = rows[1][0]
            con = db_connect(paths.db_path)
            rep = snapshot_diff_summary(con, a, b, timeframe="spot", limit=20)
            con.close()
            # show summary in log
            self.log_cb(f"DIFF a={a} b={b} symbols={rep['symbols_compared']}")
            for it in rep['top_movers'][:10]:
                self.log_cb(f"{it['symbol']} d_score={it['d_score']} d_price={it['d_price']} rank_improve={it['rank_improve']}")
        except Exception as e:
            self.log_cb("DIFF_FAILED " + str(e))
            messagebox.showerror("Error", str(e)[:1200])

    def run_pipeline(self):
        scope_text = self.scope.get().strip() or "crypto_spot"
        if scope_text != "crypto_spot":
            messagebox.showwarning("Not implemented",
                                   "Only crypto_spot is implemented in MVP pipeline. Scope will be stored, but data source stays CoinGecko spot.")

        vs_currency = (self.vs_currency.get().strip().lower() or "usd")
        coins_limit = int(self.coins_limit.get())
        order = (self.order.get().strip() or "market_cap_desc")
        topnow_limit = int(self.topnow_limit.get())
        offline_mode = bool(self.offline_mode.get())

        ensure_dir(self.paths.log_dir)
        self.last_log_path = os.path.join(self.paths.log_dir, f"run_{utc_stamp_compact()}_{APP_VERSION}.log")

        self.status_var.set("Running")
        self.log_cb("START pipeline (core)")
        self.log_cb(f"scope={scope_text} vs_currency={vs_currency} coins_limit={coins_limit} order={order} topnow={topnow_limit} offline={int(offline_mode)}")

        try:
            res = run_snapshot_and_topnow(
                project_root=self.paths.project_root,
                app_version=APP_VERSION,
                scope_text=scope_text,
                vs_currency=vs_currency,
                coins_limit=coins_limit,
                order=order,
                topnow_limit=topnow_limit,
                offline_mode=offline_mode,
                log_cb=self.log_cb,
            )
            self.last_run_var.set(str(res.run_id))
            self.last_snapshot_var.set(res.snapshot_id)
            self.last_selection_var.set(str(res.selection_id))
            self.status_var.set("Done")

            with open(self.last_log_path, "w", encoding="utf-8") as fp:
                fp.write(f"run_id {res.run_id}\n")
                fp.write(f"snapshot_id {res.snapshot_id}\n")
                fp.write(f"selection_id {res.selection_id}\n")
                fp.write(f"candidates {res.candidates_n}\n")

            self.log_cb(f"DONE run_id={res.run_id} snapshot_id={res.snapshot_id} selection_id={res.selection_id} candidates={res.candidates_n}")
        except Exception as e:
            self.status_var.set("Failed")
            self.log_cb("FAILED " + str(e))
            messagebox.showerror("Error", str(e)[:1200])

    def do_analysis(self):
        sid = self._last_selection_id()
        snap = self._last_snapshot_id()
        if not sid or sid == "-" or not snap or snap == "-":
            messagebox.showinfo("Info", "No selection available. Run pipeline first.")
            return
        con = None
        try:
            con = db_connect(self.paths.db_path)
            require_schema(con)
            ensure_indexes(con)
            ensure_snapshot_schema(con)
            con.execute("BEGIN;")
            m, s = prepare_analysis(con, int(sid), snap, "spot")
            con.commit()
            self.log_cb(f"ANALYSIS prepared: scored_rows={m} selection_items_updated={s}")
            messagebox.showinfo("Analysis", f"Prepared analysis. Scored {m} rows; updated {s} selection items.")
        except Exception as e:
            if con:
                con.rollback()
            messagebox.showerror("Error", str(e)[:1200])
        finally:
            if con:
                con.close()

    def export_csv(self):
        sid = self._last_selection_id()
        snap = self._last_snapshot_id()
        if not sid or sid == "-" or not snap or snap == "-":
            messagebox.showinfo("Info", "No selection available. Run pipeline first.")
            return
        con = None
        try:
            con = db_connect(self.paths.db_path)
            require_schema(con)
            out_dir = os.path.join(self.paths.project_root, "exports")
            out_path = os.path.join(out_dir, f"topnow_sel{sid}_{utc_stamp_compact()}_{APP_VERSION}.csv")
            export_selection_csv(con, int(sid), snap, "spot", out_path)
            messagebox.showinfo("Export", f"Exported CSV:\n{out_path}")
        except Exception as e:
            messagebox.showerror("Error", str(e)[:1200])
        finally:
            if con:
                con.close()

if __name__ == "__main__":
    app = App()
    app.mainloop()

#!/usr/bin/env python3
# nyosig_cryptolytix_gui_v2.0e
# ASCII only, Tkinter, MANUAL workflow
# Fixed project root: /storage/emulated/0/NyoSig/NyoSig_Cryptolytix

import os
import sqlite3
import time
import tkinter as tk
from tkinter import ttk, messagebox

APP_VERSION = "2.0f"
APP_FILE_TAG = "nyosig_cryptolytix_gui_v" + APP_VERSION
PROJECT_ROOT = "/storage/emulated/0/NyoSig/NyoSig_Cryptolytix"
DB_PATH = os.path.join(PROJECT_ROOT, "db", "nyosig_cryptolytix.db")

TIMEFRAMES = ["1m", "5m", "15m", "30m", "1h", "4h", "1d", "1w"]
MODES = ["conservative", "balanced", "aggressive"]

EXCLUDE_STABLE_BASE = {
    "USDT", "USDC", "DAI", "TUSD", "FDUSD", "USDP", "BUSD", "EURC", "USDE", "USD1"
}

FONT_SIZE_DEFAULT = 4


def ascii_guard():
    with open(__file__, "rb") as f:
        b = f.read()
    start = 3 if b.startswith(b"\xef\xbb\xbf") else 0
    for i in range(start, len(b)):
        if b[i] > 127:
            raise RuntimeError("Non ASCII byte found at offset %d" % i)


def utc_now_iso():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def safe_int(x, default=0):
    try:
        return int(x)
    except Exception:
        return default


def safe_float(x, default=None):
    try:
        if x is None:
            return default
        return float(x)
    except Exception:
        return default


def fmt_price(v):
    v = safe_float(v, None)
    if v is None:
        return ""
    if abs(v) >= 1:
        return f"{v:,.4f}"
    return f"{v:.8f}"


def fmt_pct(v):
    v = safe_float(v, None)
    if v is None:
        return ""
    return f"{v:.2f}"


def fmt_int(v):
    v = safe_float(v, None)
    if v is None:
        return ""
    try:
        return f"{int(round(v)):,d}"
    except Exception:
        return ""


def db_connect():
    if not os.path.exists(DB_PATH):
        raise RuntimeError("DB not found at: " + DB_PATH)
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON;")
    return con


def ensure_top_tables(con):
    con.execute(
        """
        CREATE TABLE IF NOT EXISTS top_sets (
          top_set_id TEXT PRIMARY KEY,
          created_utc TEXT NOT NULL,
          source_run_id TEXT NOT NULL,
          vs_currency TEXT,
          load_n INTEGER,
          filters_json TEXT,
          timeframe TEXT,
          mode TEXT,
          top_n INTEGER,
          notes TEXT
        );
        """
    )
    con.execute(
        """
        CREATE TABLE IF NOT EXISTS top_set_items (
          top_set_id TEXT NOT NULL,
          rank_in_top INTEGER NOT NULL,
          unified_symbol TEXT NOT NULL,
          pair TEXT,
          price REAL,
          change_24h_pct REAL,
          volume_24h REAL,
          market_cap REAL,
          cg_rank INTEGER,
          spot_score INTEGER,
          top_score REAL,
          PRIMARY KEY (top_set_id, unified_symbol),
          FOREIGN KEY (top_set_id) REFERENCES top_sets(top_set_id) ON DELETE CASCADE
        );
        """
    )
    con.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_top_set_items_rank
        ON top_set_items (top_set_id, rank_in_top);
        """
    )


def make_saved_top_set_id():
    return (
        "TS_"
        + time.strftime("%Y%m%d_%H%M%S", time.gmtime())
        + "_"
        + str(int(time.time() * 1000) % 1000).zfill(3)
    )


def filters_to_jsonlike(exclude_stable, min_vol24, min_mcap, max_abs_chg24):
    return (
        "{"
        + f"exclude_stable:{int(bool(exclude_stable))},"
        + f"min_vol24:{min_vol24},"
        + f"min_mcap:{min_mcap},"
        + f"max_abs_chg24:{max_abs_chg24}"
        + "}"
    )


def top_score(mode, row):
    vol = safe_float(row.get("vol24"), 0.0) or 0.0
    mcap = safe_float(row.get("mcap"), 0.0) or 0.0
    chg = abs(safe_float(row.get("chg24"), 0.0) or 0.0)
    rank = safe_float(row.get("rank"), 999999.0) or 999999.0
    base = safe_float(row.get("score"), 0.0) or 0.0

    try:
        import math
        lv = math.log1p(max(0.0, float(vol)))
        lm = math.log1p(max(0.0, float(mcap)))
    except Exception:
        lv = 0.0
        lm = 0.0

    if mode == "aggressive":
        return (base * 1.0) + (lv * 9.0) + (chg * 2.2) - (rank * 0.01)
    if mode == "conservative":
        return (base * 1.3) + (lv * 5.5) + (lm * 2.5) - (chg * 1.6) - (rank * 0.02)
    return (base * 1.15) + (lv * 7.0) + (lm * 1.2) + (chg * 0.6) - (rank * 0.015)


class App(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title(APP_FILE_TAG)
        self._set_big_window()

        self.current_run = None
        self.rows_loaded = []
        self.rows_filtered = []
        self.cand_view = []
        self.top_view = []

        self.top_library = {}
        self.mem_top_counter = 0
        self.selected_mem_top_id = None

        self.load_n_var = tk.IntVar(value=300)

        self.exclude_stable_var = tk.BooleanVar(value=True)
        self.min_vol24_var = tk.StringVar(value="")
        self.min_mcap_var = tk.StringVar(value="")
        self.max_abs_chg24_var = tk.StringVar(value="")

        self.top_n_var = tk.IntVar(value=15)
        self.mode_var = tk.StringVar(value="balanced")
        self.tf_var = tk.StringVar(value="4h")

        self.top_sets_var = tk.StringVar(value="")

        self.status_var = tk.StringVar(value="Ready")

        self._cand_sort = {"col": None, "desc": True}
        self._top_sort = {"col": None, "desc": True}

        self._build_ui()
        self._apply_fonts_fixed()
        self._refresh_run_meta()
        self.apply_load()

    def _set_big_window(self):
        try:
            w = self.winfo_screenwidth()
            h = self.winfo_screenheight()
            self.geometry(f"{w}x{h}")
        except Exception:
            self.geometry("1040x790")

    def _apply_fonts_fixed(self):
        fs = FONT_SIZE_DEFAULT
        style = ttk.Style(self)
        try:
            style.theme_use("default")
        except Exception:
            pass
        style.configure("Treeview", font=("TkDefaultFont", fs))
        style.configure("Treeview.Heading", font=("TkDefaultFont", fs))

    def set_status(self, txt):
        self.status_var.set(txt)

    def _build_ui(self):
        self.grid_rowconfigure(1, weight=1)
        self.grid_columnconfigure(0, weight=1)

        style = ttk.Style()
        try:
            style.configure("TButton", padding=(4, 2))
            style.configure("TLabel", padding=(2, 0))
            style.configure("TCheckbutton", padding=(2, 0))
        except Exception:
            pass

        top = ttk.Frame(self, padding=6)
        top.grid(row=0, column=0, sticky="ew")
        top.grid_columnconfigure(0, weight=1)
        top.grid_columnconfigure(1, weight=0)

        self.lbl_version = ttk.Label(top, text="v" + APP_VERSION)
        self.lbl_version.grid(row=0, column=1, sticky="ne", padx=(10, 0), pady=(0, 6))

        left = ttk.Frame(top)
        left.grid(row=0, column=0, sticky="ew")
        left.grid_columnconfigure(0, weight=1)

        # First row: Run (left) + Actions (right), each taking ~50% width.
        row0 = ttk.Frame(left)
        row0.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        row0.grid_columnconfigure(0, weight=1)
        row0.grid_columnconfigure(1, weight=1)

        self.grp_run = ttk.Labelframe(row0, text="Run", padding=6)
        self.grp_actions = ttk.Labelframe(row0, text="Actions", padding=6)
        self.grp_filters = ttk.Labelframe(left, text="Filters", padding=6)
        self.grp_top = ttk.Labelframe(left, text="TOP", padding=6)

        self.grp_run.grid(row=0, column=0, sticky="ew", padx=(0, 6))
        self.grp_actions.grid(row=0, column=1, sticky="ew")

        self.grp_filters.grid(row=1, column=0, sticky="ew", pady=(0, 6))
        self.grp_top.grid(row=2, column=0, sticky="ew", pady=(0, 0))

        self.grp_actions.grid_columnconfigure(0, weight=1)

        ttk.Label(self.grp_run, text="Load N:").grid(row=0, column=0, pady=2, sticky="e")
        self.spin_load = ttk.Spinbox(
            self.grp_run,
            from_=50,
            to=5000,
            increment=50,
            textvariable=self.load_n_var,
            width=7
        )
        self.spin_load.grid(row=0, column=1, padx=(4, 10), pady=2, sticky="w")

        self.btn_apply_load = ttk.Button(self.grp_run, text="Apply", command=self.apply_load)
        self.btn_apply_load.grid(row=0, column=2, padx=(0, 10), pady=2, sticky="w")

        self.grp_run.grid_columnconfigure(3, weight=1)

        self.chk_stable = ttk.Checkbutton(self.grp_filters, text="Exclude stable", variable=self.exclude_stable_var)
        self.chk_stable.grid(row=0, column=0, padx=(0, 10), pady=2, sticky="w")

        ttk.Label(self.grp_filters, text="Min vol24:").grid(row=0, column=1, pady=2, sticky="e")
        self.ent_min_vol = ttk.Combobox(
            self.grp_filters,
            textvariable=self.min_vol24_var,
            width=12,
            values=["off", "1000000", "5000000", "10000000", "25000000", "50000000", "100000000"]
        )
        self.ent_min_vol.grid(row=0, column=2, padx=(4, 10), pady=2, sticky="w")

        ttk.Label(self.grp_filters, text="Min mcap:").grid(row=0, column=3, pady=2, sticky="e")
        self.ent_min_mcap = ttk.Combobox(
            self.grp_filters,
            textvariable=self.min_mcap_var,
            width=12,
            values=["off", "10000000", "25000000", "50000000", "100000000", "250000000", "500000000", "1000000000"]
        )
        self.ent_min_mcap.grid(row=0, column=4, padx=(4, 10), pady=2, sticky="w")

        ttk.Label(self.grp_filters, text="Max abs chg24%:").grid(row=0, column=5, pady=2, sticky="e")
        self.ent_max_chg = ttk.Combobox(
            self.grp_filters,
            textvariable=self.max_abs_chg24_var,
            width=8,
            values=["off", "5", "10", "15", "20", "25", "30", "40", "50", "75", "100", "150", "200"]
        )
        self.ent_max_chg.grid(row=0, column=6, padx=(4, 10), pady=2, sticky="w")

        self.btn_apply_filters = ttk.Button(self.grp_filters, text="Apply filters", command=self.apply_filters)
        self.btn_apply_filters.grid(row=0, column=7, padx=(0, 10), pady=2, sticky="w")

        self.grp_filters.grid_columnconfigure(8, weight=1)

        ttk.Label(self.grp_top, text="Top N:").grid(row=0, column=0, pady=2, sticky="e")
        self.spin_top_n = ttk.Spinbox(self.grp_top, from_=5, to=500, increment=5, textvariable=self.top_n_var, width=6)
        self.spin_top_n.grid(row=0, column=1, padx=(4, 10), pady=2, sticky="w")

        ttk.Label(self.grp_top, text="Mode:").grid(row=0, column=2, pady=2, sticky="e")
        self.cmb_mode = ttk.Combobox(self.grp_top, textvariable=self.mode_var, values=MODES, state="readonly", width=12)
        self.cmb_mode.grid(row=0, column=3, padx=(4, 10), pady=2, sticky="w")

        ttk.Label(self.grp_top, text="TF:").grid(row=0, column=4, pady=2, sticky="e")
        self.cmb_tf = ttk.Combobox(self.grp_top, textvariable=self.tf_var, values=TIMEFRAMES, state="readonly", width=6)
        self.cmb_tf.grid(row=0, column=5, padx=(4, 10), pady=2, sticky="w")

        self.btn_build_top = ttk.Button(self.grp_top, text="Build TOP", command=self.build_top)
        self.btn_build_top.grid(row=0, column=6, padx=(0, 14), pady=2, sticky="w")

        ttk.Label(self.grp_top, text="TOP set:").grid(row=0, column=7, pady=2, sticky="e")
        self.cmb_top_sets = ttk.Combobox(self.grp_top, textvariable=self.top_sets_var, values=[], state="readonly", width=18)
        self.cmb_top_sets.grid(row=0, column=8, padx=(4, 10), pady=2, sticky="ew")
        self.cmb_top_sets.bind("<<ComboboxSelected>>", lambda _e: self.on_select_top_set())

        # Let the TOP set field expand so the full label is visible.
        self.grp_top.grid_columnconfigure(8, weight=1)

        self.btn_to_db = tk.Button(
            self.grp_actions,
            text="To DB",
            command=self.commit_top_to_db,
            bg="#cc0000",
            fg="white",
            activebackground="#ff3333",
            relief="raised",
            padx=10,
            pady=2
        )
        self.btn_to_db.grid(row=0, column=0, padx=(0, 10), pady=2, sticky="w")

        self.btn_analyse = ttk.Button(self.grp_actions, text="Analyse", command=self.analyse_top)
        self.btn_analyse.grid(row=0, column=1, padx=(0, 10), pady=2, sticky="w")

        main = ttk.PanedWindow(self, orient=tk.VERTICAL)
        main.grid(row=1, column=0, sticky="nsew", padx=6, pady=(0, 6))

        cand_frame = ttk.Labelframe(main, text="Candidates (from DB)", padding=6)
        top_frame = ttk.Labelframe(main, text="TOP (in memory)", padding=6)

        main.add(cand_frame, weight=1)
        main.add(top_frame, weight=1)

        self.cand_tree = self._make_tree(
            parent=cand_frame,
            cols=("rank", "pair", "price", "chg24", "vol24", "mcap", "score"),
            headings=("Rank", "Pair", "Price", "Chg24%", "Vol24", "MCap", "Score"),
            sort_handler=self.sort_candidates_by,
        )

        self.top_tree = self._make_tree(
            parent=top_frame,
            cols=("top_rank", "pair", "price", "chg24", "vol24", "mcap", "rank", "score", "top_score"),
            headings=("Top", "Pair", "Price", "Chg24%", "Vol24", "MCap", "CgRank", "SpotScore", "TopScore"),
            sort_handler=self.sort_top_by,
        )

        status = ttk.Frame(self, padding=(6, 0, 6, 6))
        status.grid(row=2, column=0, sticky="ew")
        status.grid_columnconfigure(0, weight=1)
        ttk.Label(status, textvariable=self.status_var).grid(row=0, column=0, sticky="w")

    def _make_tree(self, parent, cols, headings, sort_handler):
        parent.grid_rowconfigure(0, weight=1)
        parent.grid_columnconfigure(0, weight=1)

        wrap = ttk.Frame(parent)
        wrap.grid(row=0, column=0, sticky="nsew")
        wrap.grid_rowconfigure(0, weight=1)
        wrap.grid_columnconfigure(0, weight=1)

        tree = ttk.Treeview(wrap, columns=cols, show="headings")
        tree.grid(row=0, column=0, sticky="nsew")

        ysb = ttk.Scrollbar(wrap, orient="vertical", command=tree.yview)
        xsb = ttk.Scrollbar(wrap, orient="horizontal", command=tree.xview)
        tree.configure(yscroll=ysb.set, xscroll=xsb.set)
        ysb.grid(row=0, column=1, sticky="ns")
        xsb.grid(row=1, column=0, sticky="ew")

        for c, h in zip(cols, headings):
            tree.heading(c, text=h, command=lambda cc=c: sort_handler(cc))

        for c in cols:
            if c == "pair":
                tree.column(c, width=140, anchor=tk.W, stretch=True)
            else:
                tree.column(c, width=100, anchor=tk.E, stretch=False)

        return tree

    def _set_run_header(self, text):
        try:
            self.grp_run.configure(text=text)
        except Exception:
            pass

    def _set_top_header(self, cand_n, filt_n, sets_n):
        try:
            self.grp_top.configure(text=f"TOP  Cand {cand_n}  Filt {filt_n}  Sets {sets_n}")
        except Exception:
            pass

    def _refresh_run_meta(self):
        if not os.path.isdir(PROJECT_ROOT):
            self.current_run = None
            self._set_run_header("Run  DB missing")
            return

        try:
            con = db_connect()
            try:
                run = con.execute(
                    """
                    SELECT run_id, created_utc, status, vs_currency, coins_limit, sort_mode, source
                    FROM runs
                    ORDER BY run_id DESC
                    LIMIT 1
                    """
                ).fetchone()
                if not run:
                    self.current_run = None
                    self._set_run_header("Run  DB OK  Run none")
                    return

                self.current_run = dict(run)
                rid = str(run["run_id"])
                created = str(run["created_utc"] or "")
                self._set_run_header(f"Run  DB OK  Run {rid}  {created}")
            finally:
                con.close()
        except Exception:
            self.current_run = None
            self._set_run_header("Run  DB error")

    def _autofit_topset_width(self):
        try:
            vals = list(self.cmb_top_sets["values"])
        except Exception:
            vals = []
        if not vals:
            try:
                self.cmb_top_sets.configure(width=18)
            except Exception:
                pass
            return

        max_len = 0
        for v in vals:
            try:
                n = len(str(v))
                if n > max_len:
                    max_len = n
            except Exception:
                pass

        width = max_len + 2
        if width < 18:
            width = 18
        if width > 60:
            width = 60

        try:
            self.cmb_top_sets.configure(width=width)
        except Exception:
            pass

    def apply_load(self):
        self._refresh_run_meta()

        try:
            if not self.current_run:
                self.set_status("No run in DB")
                self.rows_loaded = []
                self.rows_filtered = []
                self.cand_view = []
                self._render_candidates([])
                self._render_top([])
                self._update_counts()
                return

            load_n = safe_int(self.load_n_var.get(), 300)
            if load_n <= 0:
                load_n = 300

            run_id = str(self.current_run["run_id"])

            con = db_connect()
            try:
                rows = con.execute(
                    """
                    SELECT unified_symbol, pair, price, change_24h_pct, volume_24h, market_cap, rank, score
                    FROM spot_markets
                    WHERE run_id = ?
                    ORDER BY rank ASC
                    LIMIT ?
                    """,
                    (run_id, load_n),
                ).fetchall()

                out = []
                for r in rows:
                    sym = (r["unified_symbol"] or "").upper().strip()
                    if not sym:
                        continue
                    out.append(
                        {
                            "symbol": sym,
                            "pair": r["pair"] or (sym + "/USD"),
                            "price": safe_float(r["price"], None),
                            "chg24": safe_float(r["change_24h_pct"], None),
                            "vol24": safe_float(r["volume_24h"], None),
                            "mcap": safe_float(r["market_cap"], None),
                            "rank": safe_int(r["rank"], 999999),
                            "score": safe_int(r["score"], 0),
                        }
                    )

                self.rows_loaded = out
                self.apply_filters()
                self.set_status(f"Loaded {len(self.rows_loaded)} candidates from run {run_id}")
            finally:
                con.close()
        except Exception as e:
            messagebox.showerror("Error", str(e)[:800])
            self.set_status("Error")

    def apply_filters(self):
        ex_stable = bool(self.exclude_stable_var.get())

        min_vol24 = safe_float((self.min_vol24_var.get() or "").strip(), None)
        min_mcap = safe_float((self.min_mcap_var.get() or "").strip(), None)
        max_abs_chg = safe_float((self.max_abs_chg24_var.get() or "").strip(), None)

        filtered = []
        for r in self.rows_loaded:
            sym = (r.get("symbol") or "").upper().strip()
            if not sym:
                continue
            if ex_stable and sym in EXCLUDE_STABLE_BASE:
                continue

            vol24 = safe_float(r.get("vol24"), None)
            mcap = safe_float(r.get("mcap"), None)
            chg24 = safe_float(r.get("chg24"), None)

            if min_vol24 is not None and (vol24 is None or vol24 < min_vol24):
                continue
            if min_mcap is not None and (mcap is None or mcap < min_mcap):
                continue
            if max_abs_chg is not None and (chg24 is None or abs(chg24) > max_abs_chg):
                continue

            filtered.append(r)

        self.rows_filtered = filtered
        self.cand_view = list(filtered)

        self.cand_view.sort(key=lambda x: safe_int(x.get("rank"), 999999))
        self._cand_sort = {"col": "rank", "desc": False}

        self._render_candidates(self.cand_view)
        self._update_counts()
        self.set_status("Filters applied")

    def _render_candidates(self, rows):
        self.cand_tree.delete(*self.cand_tree.get_children())
        for r in rows:
            self.cand_tree.insert(
                "",
                "end",
                values=(
                    r.get("rank", ""),
                    r.get("pair", ""),
                    fmt_price(r.get("price")),
                    fmt_pct(r.get("chg24")),
                    fmt_int(r.get("vol24")),
                    fmt_int(r.get("mcap")),
                    r.get("score", ""),
                ),
            )

    def _render_top(self, items):
        self.top_tree.delete(*self.top_tree.get_children())
        for r in items:
            self.top_tree.insert(
                "",
                "end",
                values=(
                    r.get("top_rank", ""),
                    r.get("pair", ""),
                    fmt_price(r.get("price")),
                    fmt_pct(r.get("chg24")),
                    fmt_int(r.get("vol24")),
                    fmt_int(r.get("mcap")),
                    r.get("rank", ""),
                    r.get("score", ""),
                    f"{safe_float(r.get('top_score'), 0.0):.4f}" if r.get("top_score") is not None else "",
                ),
            )

    def _update_counts(self):
        cand_n = len(self.rows_loaded)
        filt_n = len(self.rows_filtered)
        sets_n = len(self.top_library)
        self._set_top_header(cand_n, filt_n, sets_n)

    def sort_candidates_by(self, col):
        if not self.cand_view:
            return

        desc = True
        if self._cand_sort["col"] == col:
            desc = not bool(self._cand_sort["desc"])

        def keyf(r):
            if col == "pair":
                return (str(r.get("pair") or "")).upper()
            if col == "rank":
                return safe_int(r.get("rank"), 999999)
            if col == "score":
                return safe_int(r.get("score"), 0)
            if col == "price":
                return safe_float(r.get("price"), -1e99)
            if col == "chg24":
                return safe_float(r.get("chg24"), -1e99)
            if col == "vol24":
                return safe_float(r.get("vol24"), -1e99)
            if col == "mcap":
                return safe_float(r.get("mcap"), -1e99)
            return 0

        self.cand_view = sorted(self.cand_view, key=keyf, reverse=desc)
        self._cand_sort = {"col": col, "desc": desc}
        self._render_candidates(self.cand_view)

    def sort_top_by(self, col):
        if not self.top_view:
            return

        desc = True
        if self._top_sort["col"] == col:
            desc = not bool(self._top_sort["desc"])

        def keyf(r):
            if col == "pair":
                return (str(r.get("pair") or "")).upper()
            if col == "top_rank":
                return safe_int(r.get("top_rank"), 999999)
            if col == "rank":
                return safe_int(r.get("rank"), 999999)
            if col == "score":
                return safe_int(r.get("score"), 0)
            if col == "top_score":
                return safe_float(r.get("top_score"), -1e99)
            if col == "price":
                return safe_float(r.get("price"), -1e99)
            if col == "chg24":
                return safe_float(r.get("chg24"), -1e99)
            if col == "vol24":
                return safe_float(r.get("vol24"), -1e99)
            if col == "mcap":
                return safe_float(r.get("mcap"), -1e99)
            return 0

        self.top_view = sorted(self.top_view, key=keyf, reverse=desc)
        self._top_sort = {"col": col, "desc": desc}
        self._render_top(self.top_view)

    def build_top(self):
        if not self.rows_filtered:
            messagebox.showerror("Error", "No filtered candidates. Load and apply filters first.")
            return
        if not self.current_run:
            messagebox.showerror("Error", "No run loaded.")
            return

        top_n = safe_int(self.top_n_var.get(), 15)
        if top_n <= 0:
            top_n = 15

        mode = (self.mode_var.get() or "balanced").strip().lower()
        if mode not in MODES:
            mode = "balanced"

        tf = (self.tf_var.get() or "4h").strip()
        if tf not in TIMEFRAMES:
            tf = "4h"

        base_sorted = sorted(
            self.rows_filtered,
            key=lambda r: (
                safe_float(r.get("vol24"), 0.0) or 0.0,
                safe_float(r.get("mcap"), 0.0) or 0.0,
                -safe_float(r.get("rank"), 999999.0) if safe_float(r.get("rank"), None) is not None else 0.0,
            ),
            reverse=True,
        )

        scored = []
        for r in base_sorted:
            sym = (r.get("symbol") or "").upper().strip()
            if not sym:
                continue
            rr = dict(r)
            rr["top_score"] = float(top_score(mode, rr))
            scored.append(rr)

        scored.sort(
            key=lambda r: (
                safe_float(r.get("top_score"), 0.0) or 0.0,
                safe_float(r.get("vol24"), 0.0) or 0.0,
            ),
            reverse=True,
        )
        picked = scored[:top_n]

        items = []
        for i, r in enumerate(picked, start=1):
            items.append(
                {
                    "top_rank": i,
                    "symbol": r.get("symbol"),
                    "pair": r.get("pair"),
                    "price": r.get("price"),
                    "chg24": r.get("chg24"),
                    "vol24": r.get("vol24"),
                    "mcap": r.get("mcap"),
                    "rank": r.get("rank"),
                    "score": r.get("score"),
                    "top_score": r.get("top_score"),
                }
            )

        self.mem_top_counter += 1
        mem_id = f"TOP_{self.mem_top_counter:03d}  {mode}  {tf}  n={top_n}"
        self.top_library[mem_id] = {
            "meta": {
                "created_utc": utc_now_iso(),
                "run_id": str(self.current_run["run_id"]),
                "mode": mode,
                "timeframe": tf,
                "top_n": top_n,
                "load_n": safe_int(self.load_n_var.get(), 300),
                "filters": {
                    "exclude_stable": int(bool(self.exclude_stable_var.get())),
                    "min_vol24": (self.min_vol24_var.get() or "").strip(),
                    "min_mcap": (self.min_mcap_var.get() or "").strip(),
                    "max_abs_chg24": (self.max_abs_chg24_var.get() or "").strip(),
                },
            },
            "items": items,
            "saved_db_id": None,
        }

        self._refresh_top_sets_dropdown(select_mem_id=mem_id)
        self._show_top_set(mem_id)
        self.set_status("TOP built in memory (not saved)")

    def _refresh_top_sets_dropdown(self, select_mem_id=None):
        vals = list(self.top_library.keys())
        self.cmb_top_sets["values"] = vals

        if select_mem_id and select_mem_id in self.top_library:
            self.top_sets_var.set(select_mem_id)
            self.selected_mem_top_id = select_mem_id
        elif self.selected_mem_top_id in self.top_library:
            self.top_sets_var.set(self.selected_mem_top_id)
        elif vals:
            self.top_sets_var.set(vals[-1])
            self.selected_mem_top_id = vals[-1]
        else:
            self.top_sets_var.set("")
            self.selected_mem_top_id = None

        self._autofit_topset_width()
        self._update_counts()

    def on_select_top_set(self):
        mem_id = (self.top_sets_var.get() or "").strip()
        if not mem_id:
            return
        if mem_id not in self.top_library:
            return
        self._show_top_set(mem_id)

    def _show_top_set(self, mem_id):
        self.selected_mem_top_id = mem_id
        items = self.top_library[mem_id]["items"]
        self.top_view = list(items)
        self.top_view.sort(key=lambda r: safe_int(r.get("top_rank"), 999999))
        self._top_sort = {"col": "top_rank", "desc": False}
        self._render_top(self.top_view)

        saved = self.top_library[mem_id].get("saved_db_id")
        if saved:
            self.set_status(f"TOP selected: saved as {saved}")
        else:
            self.set_status("TOP selected: not saved")

    def commit_top_to_db(self):
        mem_id = (self.top_sets_var.get() or "").strip()
        if not mem_id or mem_id not in self.top_library:
            messagebox.showerror("Error", "No TOP set selected.")
            return
        if not self.current_run:
            messagebox.showerror("Error", "No run loaded.")
            return

        top_obj = self.top_library[mem_id]
        if not top_obj["items"]:
            messagebox.showerror("Error", "Selected TOP set is empty.")
            return

        if top_obj.get("saved_db_id"):
            messagebox.showinfo("Info", "This TOP set is already saved as:\n" + str(top_obj["saved_db_id"]))
            return

        meta = top_obj["meta"]
        run_id = str(meta.get("run_id") or "")
        mode = str(meta.get("mode") or "")
        tf = str(meta.get("timeframe") or "")
        top_n = safe_int(meta.get("top_n"), 0)
        load_n = safe_int(meta.get("load_n"), 0)

        f = meta.get("filters") or {}
        filters_str = filters_to_jsonlike(
            exclude_stable=bool(safe_int(f.get("exclude_stable", 1), 1)),
            min_vol24=(str(f.get("min_vol24", "")).strip() or "null"),
            min_mcap=(str(f.get("min_mcap", "")).strip() or "null"),
            max_abs_chg24=(str(f.get("max_abs_chg24", "")).strip() or "null"),
        )

        saved_id = make_saved_top_set_id()

        try:
            con = db_connect()
            try:
                ensure_top_tables(con)
                con.execute("BEGIN;")
                con.execute(
                    """
                    INSERT INTO top_sets (top_set_id, created_utc, source_run_id, vs_currency, load_n, filters_json, timeframe, mode, top_n, notes)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        saved_id,
                        utc_now_iso(),
                        run_id,
                        (self.current_run.get("vs_currency") or ""),
                        int(load_n),
                        filters_str,
                        tf,
                        mode,
                        int(top_n),
                        "",
                    ),
                )

                for it in top_obj["items"]:
                    con.execute(
                        """
                        INSERT INTO top_set_items
                        (top_set_id, rank_in_top, unified_symbol, pair, price, change_24h_pct, volume_24h, market_cap, cg_rank, spot_score, top_score)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            saved_id,
                            int(safe_int(it.get("top_rank"), 0)),
                            str((it.get("symbol") or "")).upper().strip(),
                            it.get("pair"),
                            safe_float(it.get("price"), None),
                            safe_float(it.get("chg24"), None),
                            safe_float(it.get("vol24"), None),
                            safe_float(it.get("mcap"), None),
                            safe_int(it.get("rank"), None) if it.get("rank") is not None else None,
                            safe_int(it.get("score"), None) if it.get("score") is not None else None,
                            safe_float(it.get("top_score"), None),
                        ),
                    )

                con.commit()
            except Exception:
                con.rollback()
                raise
            finally:
                con.close()

            top_obj["saved_db_id"] = saved_id
            self._update_counts()
            self.set_status("Saved to DB: " + saved_id)
            messagebox.showinfo("OK", "Saved TOP set to DB:\n" + saved_id)

        except Exception as e:
            messagebox.showerror("Error", str(e)[:800])
            self.set_status("Error saving to DB")

    def analyse_top(self):
        mem_id = (self.top_sets_var.get() or "").strip()
        if not mem_id or mem_id not in self.top_library:
            messagebox.showerror("Error", "No TOP set selected.")
            return
        saved_id = self.top_library[mem_id].get("saved_db_id")
        if not saved_id:
            messagebox.showerror("Error", "Please save TOP to DB first (To DB).")
            return

        self.open_analysis_window(saved_id, mem_id)

    def open_analysis_window(self, top_set_id: str, mem_id: str):
        if getattr(self, "_analysis_win", None) is not None:
            try:
                self._analysis_win.destroy()
            except Exception:
                pass
            self._analysis_win = None

        win = tk.Toplevel(self)
        self._analysis_win = win
        win.title(f"Analyse TOP {mem_id}")
        try:
            win.transient(self)
        except Exception:
            pass

        # Default size should be readable on mobile / small screens.
        # Keep it resizable so the user can expand it if needed.
        try:
            win.geometry("860x520")
            win.minsize(720, 460)
            win.resizable(True, True)
        except Exception:
            pass

        container = ttk.Frame(win, padding=10)
        container.grid(row=0, column=0, sticky="nsew")
        win.grid_rowconfigure(0, weight=1)
        win.grid_columnconfigure(0, weight=1)

        header = ttk.Label(container, text=f"TOP set id: {top_set_id}")
        header.grid(row=0, column=0, columnspan=4, sticky="w", pady=(0, 8))

        mode_frame = ttk.LabelFrame(container, text="Mode", padding=(8, 6))
        mode_frame.grid(row=1, column=0, columnspan=4, sticky="ew", pady=(0, 10))
        mode_frame.grid_columnconfigure(3, weight=1)

        self.analysis_mode_var = tk.StringVar(value="RUN_ALL")
        rb1 = ttk.Radiobutton(
            mode_frame,
            text="Run all",
            value="RUN_ALL",
            variable=self.analysis_mode_var,
            command=self._analysis_update_layer_controls
        )
        rb2 = ttk.Radiobutton(
            mode_frame,
            text="STEP",
            value="STEP",
            variable=self.analysis_mode_var,
            command=self._analysis_update_layer_controls
        )
        rb1.grid(row=0, column=0, sticky="w")
        rb2.grid(row=0, column=1, sticky="w", padx=(12, 0))

        hint = ttk.Label(mode_frame, text="Run all uses all layers. STEP lets you disable layers.")
        hint.grid(row=0, column=2, sticky="w", padx=(14, 0))

        layers_frame = ttk.LabelFrame(container, text="Layers (execution order)", padding=(8, 6))
        layers_frame.grid(row=2, column=0, columnspan=4, sticky="nsew")
        container.grid_rowconfigure(2, weight=1)
        layers_frame.grid_columnconfigure(1, weight=1)

        self.analysis_layers = [
            ("Spot", "Spot market snapshot and basic scoring (already used for TOP selection)."),
            ("On-chain", "Network activity, holders, flows, exchange balances and similar signals."),
            ("Derivatives", "Futures and options metrics: open interest, funding, liquidations, basis."),
            ("Institutional", "ETFs, fund flows, public filings and other institutional signals."),
            ("Macro", "Rates, DXY, equity indices, liquidity proxies, macro regime filters."),
            ("Sentiment", "Social and search sentiment as an additional context layer."),
            ("Narrative", "Fundamentals, GitHub, roadmap, whitepaper, narrative classification."),
        ]

        self.analysis_layer_vars = []
        self.analysis_layer_checks = []

        for i, (name, info) in enumerate(self.analysis_layers):
            var = tk.BooleanVar(value=True)
            self.analysis_layer_vars.append(var)

            lbl = ttk.Label(layers_frame, text=f"{i+1}. {name}")
            lbl.grid(row=i, column=0, sticky="w", pady=2)

            cb = ttk.Checkbutton(layers_frame, variable=var)
            cb.grid(row=i, column=1, sticky="w", pady=2)
            self.analysis_layer_checks.append(cb)

            b_info = ttk.Button(layers_frame, text="Info", command=lambda n=name, t=info: self._analysis_show_info(n, t))
            b_info.grid(row=i, column=2, sticky="e", padx=(10, 0), pady=2)

            b_setup = ttk.Button(layers_frame, text="Setup", state="disabled")
            b_setup.grid(row=i, column=3, sticky="e", padx=(6, 0), pady=2)

        footer = ttk.Frame(container)
        footer.grid(row=3, column=0, columnspan=4, sticky="ew", pady=(10, 0))
        footer.grid_columnconfigure(0, weight=1)

        self.analysis_progress_var = tk.StringVar(value="Ready")
        prog_lbl = ttk.Label(footer, textvariable=self.analysis_progress_var)
        prog_lbl.grid(row=0, column=0, sticky="w")

        btn_close = ttk.Button(footer, text="Close", command=win.destroy)
        btn_close.grid(row=0, column=3, sticky="e")

        btn_start = ttk.Button(footer, text="Start", command=lambda: self._analysis_start(top_set_id, mem_id))
        btn_start.grid(row=0, column=2, sticky="e", padx=(0, 6))

        self._analysis_update_layer_controls()

        try:
            win.geometry("640x420")
        except Exception:
            pass

    def _analysis_update_layer_controls(self):
        mode = self.analysis_mode_var.get() if hasattr(self, "analysis_mode_var") else "RUN_ALL"
        step = mode == "STEP"

        for cb in getattr(self, "analysis_layer_checks", []):
            cb.configure(state=("normal" if step else "disabled"))

        if not step:
            for v in getattr(self, "analysis_layer_vars", []):
                v.set(True)

    def _analysis_show_info(self, name: str, text: str):
        messagebox.showinfo(f"Layer info: {name}", text)

    def _analysis_start(self, top_set_id: str, mem_id: str):
        mode = self.analysis_mode_var.get()
        enabled = []
        for (name, _), var in zip(self.analysis_layers, self.analysis_layer_vars):
            if var.get():
                enabled.append(name)

        self.analysis_progress_var.set(
            f"Mode: {'Run all' if mode=='RUN_ALL' else 'STEP'}   Layers: {', '.join(enabled)}"
        )
        self.set_status(f"Analyse planned for {mem_id} ({top_set_id}) using: {', '.join(enabled)}")

        messagebox.showinfo(
            "Analyse",
            (
                "Analysis pipeline is not implemented yet.\n\n"
                "This window is ready for next development steps.\n\n"
                f"Mode: {'Run all' if mode=='RUN_ALL' else 'STEP'}\n"
                f"Enabled layers: {', '.join(enabled)}\n"
                f"TOP set id: {top_set_id}"
            )
        )


if __name__ == "__main__":
    ascii_guard()

    if not os.path.isdir(PROJECT_ROOT):
        messagebox.showerror("Error", "Project root not found:\n" + PROJECT_ROOT)
        raise SystemExit(1)

    app = App()
    app.mainloop()
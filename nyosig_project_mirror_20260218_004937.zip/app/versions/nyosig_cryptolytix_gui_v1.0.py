#!/usr/bin/env python3
# NyoSig Cryptolytix v1.0
# GUI pro cteni DB a zobrazeni SPOT 300 a TOP 15
# Root je pevne /storage/emulated/0/NyoSig/NyoSig_Cryptolytix/

import os
import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime

PROJECT_ROOT = "/storage/emulated/0/NyoSig/NyoSig_Cryptolytix"
DB_PATH = os.path.join(PROJECT_ROOT, "db", "nyosig_cryptolytix.db")

EXCLUDE_STABLE_BASE = {
    "USDT", "USDC", "DAI", "TUSD", "FDUSD", "USDP", "BUSD", "EURC", "USDE", "USD1"
}

DEFAULT_TIMEFRAME = "4h"

FONT_SIZE_DEFAULT = 4
FONT_SIZE_MIN = 4
FONT_SIZE_MAX = 30


def fmt_num(x, digits=2):
    if x is None:
        return ""
    try:
        v = float(x)
    except Exception:
        return ""
    if abs(v) >= 1000:
        return f"{v:,.0f}"
    return f"{v:.{digits}f}"


def fmt_price(x):
    if x is None:
        return ""
    try:
        v = float(x)
    except Exception:
        return ""
    if abs(v) >= 1:
        return f"{v:,.4f}"
    return f"{v:.8f}"


def fmt_pct(x):
    if x is None:
        return ""
    try:
        v = float(x)
    except Exception:
        return ""
    return f"{v:.2f}"


def db_connect():
    if not os.path.exists(DB_PATH):
        raise RuntimeError("DB nenalezena na ceste: " + DB_PATH)
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def get_last_run(con):
    row = con.execute(
        """
        SELECT run_id, created_utc, status, vs_currency, coins_limit, sort_mode, source
        FROM runs
        ORDER BY run_id DESC
        LIMIT 1
        """
    ).fetchone()
    return row


def get_spot_rows(con, run_id):
    rows = con.execute(
        """
        SELECT
            unified_symbol,
            pair,
            price,
            change_24h_pct,
            volume_24h,
            market_cap,
            rank,
            score
        FROM spot_markets
        WHERE run_id = ?
        """,
        (int(run_id),),
    ).fetchall()
    return rows


def get_top15(con, run_id):
    rows = con.execute(
        """
        SELECT
            unified_symbol,
            pair,
            price,
            change_24h_pct,
            volume_24h,
            market_cap,
            rank,
            score
        FROM spot_markets
        WHERE run_id = ?
        ORDER BY score DESC, market_cap DESC
        """,
        (int(run_id),),
    ).fetchall()

    out = []
    for r in rows:
        base = (r["unified_symbol"] or "").upper().strip()
        if not base:
            continue
        if base in EXCLUDE_STABLE_BASE:
            continue
        if base == "USDT":
            continue
        out.append(r)
        if len(out) >= 15:
            break
    return out


def get_ohlcv_last(con, symbol, timeframe=DEFAULT_TIMEFRAME, limit=80):
    rows = con.execute(
        """
        SELECT open_time_utc, open, high, low, close, volume
        FROM ohlcv
        WHERE unified_symbol = ? AND timeframe = ?
        ORDER BY open_time_utc DESC
        LIMIT ?
        """,
        (symbol, timeframe, int(limit)),
    ).fetchall()
    return rows


class SortableTree:
    def __init__(self, tree: ttk.Treeview):
        self.tree = tree
        self._sort_state = {}

    def make_sortable(self, columns, numeric_cols):
        for col in columns:
            self.tree.heading(col, command=lambda c=col: self.sort_by(c, c in numeric_cols))

    def sort_by(self, col, numeric):
        items = list(self.tree.get_children(""))
        if not items:
            return

        current = self._sort_state.get(col, "asc")
        new_state = "desc" if current == "asc" else "asc"
        self._sort_state[col] = new_state

        def get_val(iid):
            vals = self.tree.item(iid, "values")
            try:
                idx = self.tree["columns"].index(col)
            except Exception:
                return ""
            v = vals[idx] if idx < len(vals) else ""
            if numeric:
                try:
                    if v is None or v == "":
                        return float("-inf")
                    s = str(v).replace(",", "")
                    return float(s)
                except Exception:
                    return float("-inf")
            return str(v or "").upper()

        items.sort(key=get_val, reverse=(new_state == "desc"))

        for i, iid in enumerate(items):
            self.tree.move(iid, "", i)


class App(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("NyoSig Cryptolytix")
        self.geometry("1100x700")

        self.run_row = None
        self.run_id = None

        self.spot_data = []
        self.top_data = []

        self.font_size_var = tk.IntVar(value=FONT_SIZE_DEFAULT)

        self._apply_style(FONT_SIZE_DEFAULT)
        self._build_ui()

        self.refresh_all()

    def _apply_style(self, font_size):
        style = ttk.Style(self)
        try:
            style.theme_use("default")
        except Exception:
            pass
        style.configure("Treeview", font=("TkDefaultFont", int(font_size)))
        style.configure("Treeview.Heading", font=("TkDefaultFont", int(font_size)))
        style.configure("TButton", font=("TkDefaultFont", int(font_size)))
        style.configure("TLabel", font=("TkDefaultFont", int(font_size)))

    def apply_font_size(self):
        try:
            size = int(self.font_size_var.get())
        except Exception:
            return
        if size < FONT_SIZE_MIN:
            size = FONT_SIZE_MIN
            self.font_size_var.set(size)
        if size > FONT_SIZE_MAX:
            size = FONT_SIZE_MAX
            self.font_size_var.set(size)

        self._apply_style(size)

        try:
            self.detail_spot.configure(font=("TkDefaultFont", size))
            self.detail_top.configure(font=("TkDefaultFont", size))
        except Exception:
            pass

    def _build_ui(self):
        self.container = ttk.Frame(self, padding=10)
        self.container.pack(fill=tk.BOTH, expand=True)

        topbar = ttk.Frame(self.container)
        topbar.pack(fill=tk.X)

        self.btn_screen_spot = ttk.Button(topbar, text="SPOT 300", command=self.show_spot)
        self.btn_screen_spot.pack(side=tk.LEFT)

        self.btn_screen_top = ttk.Button(topbar, text="TOP 15", command=self.show_top)
        self.btn_screen_top.pack(side=tk.LEFT, padx=(8, 0))

        self.btn_refresh = ttk.Button(topbar, text="Refresh", command=self.refresh_all)
        self.btn_refresh.pack(side=tk.LEFT, padx=(8, 0))

        ttk.Label(topbar, text="Font").pack(side=tk.LEFT, padx=(12, 0))
        self.font_spin = ttk.Spinbox(
            topbar,
            from_=FONT_SIZE_MIN,
            to=FONT_SIZE_MAX,
            increment=1,
            textvariable=self.font_size_var,
            width=4,
            command=self.apply_font_size,
        )
        self.font_spin.pack(side=tk.LEFT, padx=(6, 0))

        self.btn_font_apply = ttk.Button(topbar, text="Apply", command=self.apply_font_size)
        self.btn_font_apply.pack(side=tk.LEFT, padx=(6, 0))

        self.info_var = tk.StringVar(value="DB: " + DB_PATH)
        ttk.Label(self.container, textvariable=self.info_var).pack(anchor="w", pady=(10, 6))

        self.status_var = tk.StringVar(value="Ready")
        ttk.Label(self.container, textvariable=self.status_var).pack(anchor="w", pady=(0, 8))

        self.screen_frame = ttk.Frame(self.container)
        self.screen_frame.pack(fill=tk.BOTH, expand=True)

        self.frame_spot = ttk.Frame(self.screen_frame)
        self.frame_top = ttk.Frame(self.screen_frame)

        self._build_spot_screen()
        self._build_top_screen()

        self.apply_font_size()
        self.show_spot()

    def _build_spot_screen(self):
        holder = ttk.Frame(self.frame_spot)
        holder.pack(fill=tk.BOTH, expand=True)

        cols = ("symbol", "pair", "score", "price", "chg24", "vol24", "mcap", "rank")
        self.tree_spot = ttk.Treeview(holder, columns=cols, show="headings")

        vsb = ttk.Scrollbar(holder, orient="vertical", command=self.tree_spot.yview)
        hsb = ttk.Scrollbar(holder, orient="horizontal", command=self.tree_spot.xview)

        self.tree_spot.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        self.tree_spot.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")

        holder.grid_rowconfigure(0, weight=1)
        holder.grid_columnconfigure(0, weight=1)

        headings = {
            "symbol": "Symbol",
            "pair": "Pair",
            "score": "Score",
            "price": "Price",
            "chg24": "24h pct",
            "vol24": "Volume",
            "mcap": "Market cap",
            "rank": "Rank",
        }
        for c in cols:
            self.tree_spot.heading(c, text=headings.get(c, c))

        self.tree_spot.column("symbol", width=110, anchor=tk.W, stretch=False)
        self.tree_spot.column("pair", width=150, anchor=tk.W, stretch=True)
        self.tree_spot.column("score", width=80, anchor=tk.CENTER, stretch=False)
        self.tree_spot.column("price", width=140, anchor=tk.E, stretch=True)
        self.tree_spot.column("chg24", width=90, anchor=tk.E, stretch=False)
        self.tree_spot.column("vol24", width=170, anchor=tk.E, stretch=True)
        self.tree_spot.column("mcap", width=180, anchor=tk.E, stretch=True)
        self.tree_spot.column("rank", width=70, anchor=tk.CENTER, stretch=False)

        self.sort_spot = SortableTree(self.tree_spot)
        self.sort_spot.make_sortable(
            columns=list(cols),
            numeric_cols={"score", "price", "chg24", "vol24", "mcap", "rank"},
        )

        self.tree_spot.bind("<<TreeviewSelect>>", self.on_select_spot)

        self.detail_spot = tk.Text(self.frame_spot, height=10, wrap="word", font=("TkDefaultFont", FONT_SIZE_DEFAULT))
        self.detail_spot.pack(fill=tk.X, pady=(10, 0))

    def _build_top_screen(self):
        holder = ttk.Frame(self.frame_top)
        holder.pack(fill=tk.BOTH, expand=True)

        cols = ("symbol", "pair", "score", "price", "chg24", "vol24", "mcap", "rank", "ohlcv")
        self.tree_top = ttk.Treeview(holder, columns=cols, show="headings")

        vsb = ttk.Scrollbar(holder, orient="vertical", command=self.tree_top.yview)
        hsb = ttk.Scrollbar(holder, orient="horizontal", command=self.tree_top.xview)

        self.tree_top.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        self.tree_top.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")

        holder.grid_rowconfigure(0, weight=1)
        holder.grid_columnconfigure(0, weight=1)

        headings = {
            "symbol": "Symbol",
            "pair": "Pair",
            "score": "Score",
            "price": "Price",
            "chg24": "24h pct",
            "vol24": "Volume",
            "mcap": "Market cap",
            "rank": "Rank",
            "ohlcv": "OHLCV rows",
        }
        for c in cols:
            self.tree_top.heading(c, text=headings.get(c, c))

        self.tree_top.column("symbol", width=110, anchor=tk.W, stretch=False)
        self.tree_top.column("pair", width=150, anchor=tk.W, stretch=True)
        self.tree_top.column("score", width=80, anchor=tk.CENTER, stretch=False)
        self.tree_top.column("price", width=140, anchor=tk.E, stretch=True)
        self.tree_top.column("chg24", width=90, anchor=tk.E, stretch=False)
        self.tree_top.column("vol24", width=170, anchor=tk.E, stretch=True)
        self.tree_top.column("mcap", width=180, anchor=tk.E, stretch=True)
        self.tree_top.column("rank", width=70, anchor=tk.CENTER, stretch=False)
        self.tree_top.column("ohlcv", width=110, anchor=tk.E, stretch=False)

        self.sort_top = SortableTree(self.tree_top)
        self.sort_top.make_sortable(
            columns=list(cols),
            numeric_cols={"score", "price", "chg24", "vol24", "mcap", "rank", "ohlcv"},
        )

        self.tree_top.bind("<<TreeviewSelect>>", self.on_select_top)

        tf_bar = ttk.Frame(self.frame_top)
        tf_bar.pack(fill=tk.X, pady=(10, 6))
        ttk.Label(tf_bar, text="Timeframe").pack(side=tk.LEFT)
        self.tf_var = tk.StringVar(value=DEFAULT_TIMEFRAME)
        self.tf_entry = ttk.Entry(tf_bar, textvariable=self.tf_var, width=8)
        self.tf_entry.pack(side=tk.LEFT, padx=(8, 0))
        ttk.Button(tf_bar, text="Load OHLCV", command=self.load_selected_ohlcv).pack(side=tk.LEFT, padx=(8, 0))

        self.detail_top = tk.Text(self.frame_top, height=14, wrap="word", font=("TkDefaultFont", FONT_SIZE_DEFAULT))
        self.detail_top.pack(fill=tk.BOTH, expand=False)

    def show_spot(self):
        self.frame_top.pack_forget()
        self.frame_spot.pack(fill=tk.BOTH, expand=True)
        self.status_var.set("SPOT 300")

    def show_top(self):
        self.frame_spot.pack_forget()
        self.frame_top.pack(fill=tk.BOTH, expand=True)
        self.status_var.set("TOP 15")

    def refresh_all(self):
        try:
            con = db_connect()
            with con:
                self.run_row = get_last_run(con)
                if not self.run_row:
                    self.status_var.set("V DB neni zadny run")
                    return

                self.run_id = int(self.run_row["run_id"])
                self.spot_data = list(get_spot_rows(con, self.run_id))
                self.top_data = list(get_top15(con, self.run_id))

                self._fill_spot_tree()
                self._fill_top_tree(con)

            self._update_header()
            self.status_var.set("Nacteno. run_id " + str(self.run_id))
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _update_header(self):
        if not self.run_row:
            self.info_var.set("DB: " + DB_PATH)
            return
        created = self.run_row["created_utc"]
        status = self.run_row["status"]
        vs = self.run_row["vs_currency"]
        coins = self.run_row["coins_limit"]
        sort_mode = self.run_row["sort_mode"]
        source = self.run_row["source"]
        self.info_var.set(
            "DB: "
            + DB_PATH
            + "\nRun: "
            + str(self.run_id)
            + "   created: "
            + str(created)
            + "   status: "
            + str(status)
            + "\nvs: "
            + str(vs)
            + "   coins: "
            + str(coins)
            + "   sort: "
            + str(sort_mode)
            + "   source: "
            + str(source)
        )

    def _fill_spot_tree(self):
        for iid in self.tree_spot.get_children(""):
            self.tree_spot.delete(iid)

        for r in self.spot_data:
            self.tree_spot.insert(
                "",
                tk.END,
                values=(
                    r["unified_symbol"],
                    r["pair"],
                    r["score"],
                    fmt_price(r["price"]),
                    fmt_pct(r["change_24h_pct"]),
                    fmt_num(r["volume_24h"], 0),
                    fmt_num(r["market_cap"], 0),
                    r["rank"] if r["rank"] is not None else "",
                ),
            )

        self.detail_spot.delete("1.0", tk.END)
        self.detail_spot.insert(tk.END, "Klikni na radek pro detail\n")

    def _fill_top_tree(self, con):
        for iid in self.tree_top.get_children(""):
            self.tree_top.delete(iid)

        tf = self.tf_var.get().strip() or DEFAULT_TIMEFRAME

        for r in self.top_data:
            sym = r["unified_symbol"]
            cnt_row = con.execute(
                "SELECT COUNT(*) AS c FROM ohlcv WHERE unified_symbol=? AND timeframe=?",
                (sym, tf),
            ).fetchone()
            cnt = int(cnt_row["c"]) if cnt_row and cnt_row["c"] is not None else 0

            self.tree_top.insert(
                "",
                tk.END,
                values=(
                    sym,
                    r["pair"],
                    r["score"],
                    fmt_price(r["price"]),
                    fmt_pct(r["change_24h_pct"]),
                    fmt_num(r["volume_24h"], 0),
                    fmt_num(r["market_cap"], 0),
                    r["rank"] if r["rank"] is not None else "",
                    cnt,
                ),
            )

        self.detail_top.delete("1.0", tk.END)
        self.detail_top.insert(tk.END, "Klikni na radek a pak Load OHLCV\n")

    def on_select_spot(self, _evt):
        sel = self.tree_spot.selection()
        if not sel:
            return
        vals = self.tree_spot.item(sel[0], "values")
        if not vals:
            return
        sym = str(vals[0])

        for r in self.spot_data:
            if str(r["unified_symbol"]) == sym:
                self.detail_spot.delete("1.0", tk.END)
                self.detail_spot.insert(
                    tk.END,
                    "Symbol: "
                    + sym
                    + "\nPrice: "
                    + fmt_price(r["price"])
                    + "\n24h pct: "
                    + fmt_pct(r["change_24h_pct"])
                    + "\nScore: "
                    + str(r["score"])
                    + "\nVolume 24h: "
                    + fmt_num(r["volume_24h"], 0)
                    + "\nMarket cap: "
                    + fmt_num(r["market_cap"], 0)
                    + "\nRank: "
                    + (str(r["rank"]) if r["rank"] is not None else "")
                )
                break

    def on_select_top(self, _evt):
        sel = self.tree_top.selection()
        if not sel:
            return
        vals = self.tree_top.item(sel[0], "values")
        if not vals:
            return
        sym = str(vals[0])
        self.detail_top.delete("1.0", tk.END)
        self.detail_top.insert(tk.END, "Vybrano: " + sym + "\nStiskni Load OHLCV\n")

    def load_selected_ohlcv(self):
        sel = self.tree_top.selection()
        if not sel:
            messagebox.showinfo("Info", "Nejdriv vyber coin v TOP 15")
            return

        vals = self.tree_top.item(sel[0], "values")
        if not vals:
            return
        sym = str(vals[0])
        tf = self.tf_var.get().strip() or DEFAULT_TIMEFRAME

        try:
            con = db_connect()
            with con:
                rows = list(get_ohlcv_last(con, sym, tf, limit=80))
        except Exception as e:
            messagebox.showerror("Error", str(e))
            return

        self.detail_top.delete("1.0", tk.END)
        self.detail_top.insert(tk.END, "Symbol: " + sym + "   TF: " + tf + "\n")
        self.detail_top.insert(tk.END, "Radku v DB: " + str(len(rows)) + "\n\n")

        if not rows:
            self.detail_top.insert(tk.END, "Pro tento coin neni OHLCV v DB\n")
            self.detail_top.insert(tk.END, "Mozne duvody: Binance symbol neexistuje, nebo se preskocil\n")
            return

        last = rows[0]
        self.detail_top.insert(
            tk.END,
            "Posledni close: "
            + fmt_price(last["close"])
            + "   high: "
            + fmt_price(last["high"])
            + "   low: "
            + fmt_price(last["low"])
            + "\n\n",
        )

        self.detail_top.insert(tk.END, "Poslednich 20 svicky od nejnovnejsi\n\n")
        for i, r in enumerate(rows[:20], start=1):
            self.detail_top.insert(
                tk.END,
                str(i)
                + ". "
                + str(r["open_time_utc"])
                + "   O "
                + fmt_price(r["open"])
                + "   H "
                + fmt_price(r["high"])
                + "   L "
                + fmt_price(r["low"])
                + "   C "
                + fmt_price(r["close"])
                + "   V "
                + fmt_num(r["volume"], 0)
                + "\n",
            )


def main():
    try:
        app = App()
        app.mainloop()
    except Exception as e:
        try:
            messagebox.showerror("Error", str(e))
        except Exception:
            print(str(e))


if __name__ == "__main__":
    main()
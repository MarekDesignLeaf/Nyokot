#!/usr/bin/env python3
# Analyza_trhu_v1.1c
# GUI for DB view + TOP scoring + export TOP into DB only
# ASCII only, hard stop if this file contains non ASCII chars

import json
import math
import os
import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime

PROJECT_ROOT = "/storage/emulated/0/NyoSig/NyoSig_Cryptolytix"
DB_PATH = os.path.join(PROJECT_ROOT, "db", "nyosig_cryptolytix.db")

FONT_DEFAULT = 4
FONT_MIN = 4
FONT_MAX = 30

TIMEFRAMES = ["1m", "5m", "15m", "30m", "1h", "4h", "1d", "1w"]
TOP_MODES = ["Conservative", "Balanced", "Aggressive"]

STABLE_BASE = {
    "USDT", "USDC", "DAI", "TUSD", "FDUSD", "USDP", "BUSD", "EURC", "USDE", "USD1",
    "PYUSD", "USDS", "FRAX", "LUSD", "GUSD"
}


def assert_ascii_source():
    try:
        p = os.path.abspath(__file__)
        with open(p, "rb") as f:
            b = f.read()
        try:
            s = b.decode("utf-8", errors="strict")
        except Exception:
            raise RuntimeError("File is not valid UTF-8")
        bad = []
        for i, ch in enumerate(s):
            if ord(ch) > 127:
                bad.append((i, ch, ord(ch)))
                if len(bad) >= 5:
                    break
        if bad:
            msg = "Non ASCII chars found in source file. Remove them.\n"
            for i, ch, code in bad:
                msg += f"pos {i} char {repr(ch)} code {code}\n"
            raise RuntimeError(msg)
    except Exception as e:
        try:
            messagebox.showerror("Error", str(e))
        except Exception:
            pass
        raise


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def safe_float(x, default=None):
    try:
        if x is None:
            return default
        return float(x)
    except Exception:
        return default


def fmt_price(x):
    if x is None:
        return ""
    try:
        v = float(x)
    except Exception:
        return ""
    if abs(v) >= 1:
        return f"{v:,.4f}"
    return f"{v:.8f}"


def fmt_num(x):
    if x is None:
        return ""
    try:
        v = float(x)
    except Exception:
        return ""
    return f"{v:,.0f}"


def fmt_pct(x):
    if x is None:
        return ""
    try:
        v = float(x)
    except Exception:
        return ""
    return f"{v:.2f}"


def now_tag():
    return datetime.utcnow().strftime("%Y%m%d_%H%M%S")


def db_connect():
    if not os.path.exists(DB_PATH):
        raise RuntimeError("DB not found: " + DB_PATH)
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def table_cols(con, table):
    rows = con.execute(f"PRAGMA table_info({table})").fetchall()
    return {r["name"] for r in rows}


def first_existing(cols, candidates):
    for c in candidates:
        if c in cols:
            return c
    return None


def get_latest_run(con):
    cols = table_cols(con, "runs")
    created_col = first_existing(cols, ["created_utc", "created_at", "created", "fetched_utc", "timestamp", "ts_utc"])
    status_col = first_existing(cols, ["status"])
    run_id_col = first_existing(cols, ["run_id", "id"])
    run_tag_col = first_existing(cols, ["run_tag"])

    select_parts = []
    if run_id_col:
        select_parts.append(f"{run_id_col} AS run_id")
    else:
        select_parts.append("rowid AS run_id")

    if run_tag_col:
        select_parts.append(f"{run_tag_col} AS run_tag")
    else:
        select_parts.append("'' AS run_tag")

    if created_col:
        select_parts.append(f"{created_col} AS created_any")
        order_by = f"{created_col} DESC"
    else:
        select_parts.append("'' AS created_any")
        order_by = "rowid DESC"

    if status_col:
        select_parts.append(f"{status_col} AS status_any")
    else:
        select_parts.append("'' AS status_any")

    sql = f"SELECT {', '.join(select_parts)} FROM runs ORDER BY {order_by} LIMIT 1"
    row = con.execute(sql).fetchone()
    return dict(row) if row else None


def fetch_spot_rows(con, run_id, limit_n):
    cols = table_cols(con, "spot_markets")

    sym_col = first_existing(cols, ["symbol", "unified_symbol"])
    pair_col = first_existing(cols, ["pair"])
    price_col = first_existing(cols, ["price", "current_price"])
    vol_col = first_existing(cols, ["volume_24h", "total_volume"])
    mcap_col = first_existing(cols, ["market_cap"])
    rank_col = first_existing(cols, ["market_cap_rank", "rank"])
    chg_col = first_existing(cols, ["change_24h_pct", "price_change_percentage_24h", "chg_24h_pct"])
    score_col = first_existing(cols, ["score"])

    if not sym_col or not pair_col:
        raise RuntimeError("spot_markets schema mismatch: missing symbol or pair")

    select_parts = [
        f"{sym_col} AS symbol",
        f"{pair_col} AS pair",
        (f"{price_col} AS price" if price_col else "NULL AS price"),
        (f"{vol_col} AS volume_24h" if vol_col else "NULL AS volume_24h"),
        (f"{mcap_col} AS market_cap" if mcap_col else "NULL AS market_cap"),
        (f"{rank_col} AS rank" if rank_col else "NULL AS rank"),
        (f"{chg_col} AS chg_24h_pct" if chg_col else "NULL AS chg_24h_pct"),
        (f"{score_col} AS spot_score" if score_col else "NULL AS spot_score"),
    ]

    order_by = f"{rank_col} ASC" if rank_col else "rowid ASC"

    sql = f"""
    SELECT {', '.join(select_parts)}
    FROM spot_markets
    WHERE run_id = ?
    ORDER BY {order_by}
    LIMIT ?
    """
    rows = con.execute(sql, (run_id, int(limit_n))).fetchall()
    return [dict(r) for r in rows]


def fetch_ohlcv_closes(con, run_id, symbol, timeframe, limit_n=160):
    cols = table_cols(con, "ohlcv")

    ts_col = first_existing(cols, ["ts_ms", "timestamp", "t"])
    c_col = first_existing(cols, ["c", "close"])
    sym_col = first_existing(cols, ["symbol"])
    tf_col = first_existing(cols, ["timeframe"])

    if not ts_col or not c_col or not sym_col or not tf_col:
        return []

    sql = f"""
    SELECT {c_col} AS close
    FROM ohlcv
    WHERE run_id = ? AND {sym_col} = ? AND {tf_col} = ?
    ORDER BY {ts_col} DESC
    LIMIT ?
    """
    rows = con.execute(sql, (run_id, symbol, timeframe, int(limit_n))).fetchall()

    closes = []
    for r in rows:
        v = safe_float(r["close"], None)
        if v is not None:
            closes.append(v)
    closes.reverse()
    return closes


def calc_trend_score_from_closes(closes):
    if not closes or len(closes) < 20:
        return None

    n = len(closes)
    sx = (n - 1) * n / 2.0
    sxx = (n - 1) * n * (2 * n - 1) / 6.0
    sy = sum(closes)
    sxy = sum(i * closes[i] for i in range(n))
    denom = (n * sxx - sx * sx)
    if denom == 0:
        return None

    slope = (n * sxy - sx * sy) / denom
    price = closes[-1] if closes[-1] != 0 else 1.0
    rel = slope / price

    raw = rel * 5000.0
    score = 50.0 + raw
    return int(round(clamp(score, 0.0, 100.0)))


def calc_vol_score_from_closes(closes):
    if not closes or len(closes) < 20:
        return None

    rets = []
    for i in range(1, len(closes)):
        p0 = closes[i - 1]
        p1 = closes[i]
        if p0 and p0 > 0:
            rets.append((p1 - p0) / p0)

    if len(rets) < 10:
        return None

    mean = sum(rets) / len(rets)
    var = sum((r - mean) ** 2 for r in rets) / max(1, (len(rets) - 1))
    vol = math.sqrt(var)

    target_lo = 0.002
    target_hi = 0.02

    if vol <= target_lo:
        score = (vol / target_lo) * 40.0
    elif vol <= target_hi:
        score = 40.0 + ((vol - target_lo) / (target_hi - target_lo)) * 60.0
    else:
        score = 100.0 - min(70.0, ((vol - target_hi) / target_hi) * 70.0)

    return int(round(clamp(score, 0.0, 100.0)))


def normalize_0_100(values, fallback_mid=50):
    vals = [v for v in values if v is not None]
    if not vals:
        return [fallback_mid if v is not None else None for v in values]
    mn = min(vals)
    mx = max(vals)
    if mx == mn:
        return [fallback_mid if v is not None else None for v in values]
    out = []
    for v in values:
        if v is None:
            out.append(None)
        else:
            out.append(int(round(((v - mn) / (mx - mn)) * 100.0)))
    return out


def calc_liquidity_components(rows):
    vol_logs = []
    ratios = []
    for r in rows:
        vol = safe_float(r.get("volume_24h"), None)
        mcap = safe_float(r.get("market_cap"), None)
        if vol is None or vol <= 0:
            vol_logs.append(None)
        else:
            vol_logs.append(math.log10(vol))
        if vol is None or mcap is None or mcap <= 0:
            ratios.append(None)
        else:
            ratios.append(vol / mcap)

    vol_scores = normalize_0_100(vol_logs, fallback_mid=50)
    ratio_scores = normalize_0_100(ratios, fallback_mid=50)

    liq = []
    for i in range(len(rows)):
        if vol_scores[i] is None and ratio_scores[i] is None:
            liq.append(None)
        else:
            a = vol_scores[i] if vol_scores[i] is not None else 50
            b = ratio_scores[i] if ratio_scores[i] is not None else 50
            liq.append(int(round(0.6 * a + 0.4 * b)))
    return liq


def weights_for_mode(mode):
    if mode == "Conservative":
        return (0.55, 0.35, 0.10)
    if mode == "Aggressive":
        return (0.35, 0.25, 0.40)
    return (0.45, 0.30, 0.25)


def ensure_export_tables(con):
    con.execute("""
    CREATE TABLE IF NOT EXISTS top_exports (
      export_id INTEGER PRIMARY KEY AUTOINCREMENT,
      created_utc TEXT NOT NULL,
      run_id INTEGER NOT NULL,
      timeframe TEXT NOT NULL,
      mode TEXT NOT NULL,
      load_n INTEGER NOT NULL,
      top_n INTEGER NOT NULL,
      filters_json TEXT NOT NULL
    )
    """)
    con.execute("""
    CREATE TABLE IF NOT EXISTS top_export_items (
      export_id INTEGER NOT NULL,
      idx INTEGER NOT NULL,
      symbol TEXT NOT NULL,
      pair TEXT,
      rank INTEGER,
      price REAL,
      chg_24h_pct REAL,
      volume_24h REAL,
      market_cap REAL,
      spot_score INTEGER,
      liq_score INTEGER,
      trend_score INTEGER,
      vol_score INTEGER,
      top_score INTEGER,
      PRIMARY KEY (export_id, idx),
      FOREIGN KEY (export_id) REFERENCES top_exports(export_id) ON DELETE CASCADE
    )
    """)


class App(tk.Tk):
    def __init__(self):
        assert_ascii_source()

        super().__init__()
        self.title("Analyza_trhu_v1.1c")
        self.geometry("1100x760")

        self.font_var = tk.IntVar(value=FONT_DEFAULT)
        self.load_n_var = tk.IntVar(value=300)
        self.top_x_var = tk.IntVar(value=50)
        self.tf_var = tk.StringVar(value="4h")
        self.mode_var = tk.StringVar(value="Balanced")

        self.filter_ex_stable = tk.BooleanVar(value=True)
        self.filter_require_ohlcv = tk.BooleanVar(value=False)

        self.min_mcap_var = tk.StringVar(value="0")
        self.min_vol_var = tk.StringVar(value="0")
        self.max_move_var = tk.StringVar(value="0")

        self.run_id = None
        self.run_meta = None

        self.rows_raw = []
        self.rows_calc = []
        self.rows_view = []

        self.sort_col = "rank"
        self.sort_desc = False

        self._apply_style(FONT_DEFAULT)
        self._build_ui()
        self.refresh()

    def _apply_style(self, fs):
        style = ttk.Style(self)
        try:
            style.theme_use("default")
        except Exception:
            pass
        style.configure("Treeview", font=("TkDefaultFont", int(fs)))
        style.configure("Treeview.Heading", font=("TkDefaultFont", int(fs)))
        style.configure("TLabel", font=("TkDefaultFont", int(fs)))
        style.configure("TButton", font=("TkDefaultFont", int(fs)))

    def apply_font(self):
        try:
            fs = int(self.font_var.get())
        except Exception:
            fs = FONT_DEFAULT
        fs = clamp(fs, FONT_MIN, FONT_MAX)
        self.font_var.set(fs)
        self._apply_style(fs)
        self.detail.configure(font=("TkDefaultFont", fs))

    def _build_ui(self):
        top = ttk.Frame(self, padding=8)
        top.pack(fill=tk.X)

        top.grid_columnconfigure(0, weight=0)
        top.grid_columnconfigure(1, weight=0)
        top.grid_columnconfigure(2, weight=0)
        top.grid_columnconfigure(3, weight=0)
        top.grid_columnconfigure(4, weight=0)
        top.grid_columnconfigure(5, weight=0)
        top.grid_columnconfigure(6, weight=0)
        top.grid_columnconfigure(7, weight=0)
        top.grid_columnconfigure(8, weight=0)
        top.grid_columnconfigure(9, weight=1)
        top.grid_columnconfigure(10, weight=0)

        ttk.Button(top, text="Refresh", command=self.refresh).grid(row=0, column=0, padx=(0, 10), sticky="w")

        ttk.Label(top, text="Load").grid(row=0, column=1, sticky="w")
        self.load_entry = ttk.Entry(top, textvariable=self.load_n_var, width=6)
        self.load_entry.grid(row=0, column=2, padx=(6, 6), sticky="w")
        ttk.Button(top, text="Apply", command=self.apply_load).grid(row=0, column=3, padx=(0, 12), sticky="w")

        ttk.Label(top, text="Top").grid(row=0, column=4, sticky="w")
        self.top_entry = ttk.Entry(top, textvariable=self.top_x_var, width=6)
        self.top_entry.grid(row=0, column=5, padx=(6, 6), sticky="w")
        ttk.Button(top, text="Recalc", command=self.recalc_top).grid(row=0, column=6, padx=(0, 12), sticky="w")

        ttk.Label(top, text="Mode").grid(row=0, column=7, sticky="w")
        self.mode_combo = ttk.Combobox(top, textvariable=self.mode_var, values=TOP_MODES, state="readonly", width=12)
        self.mode_combo.grid(row=0, column=8, padx=(6, 12), sticky="w")

        ttk.Label(top, text="TF").grid(row=0, column=9, sticky="e")
        self.tf_combo = ttk.Combobox(top, textvariable=self.tf_var, values=TIMEFRAMES, state="readonly", width=6)
        self.tf_combo.grid(row=0, column=10, padx=(6, 12), sticky="w")

        fontf = ttk.Frame(top)
        fontf.grid(row=0, column=11, sticky="e")
        ttk.Label(fontf, text="Font").pack(side=tk.LEFT)
        ttk.Spinbox(fontf, from_=FONT_MIN, to=FONT_MAX, textvariable=self.font_var, width=4).pack(side=tk.LEFT, padx=(6, 6))
        ttk.Button(fontf, text="Apply", command=self.apply_font).pack(side=tk.LEFT)

        ttk.Button(top, text="Export TOP to DB", command=self.export_top_to_db).grid(row=0, column=12, padx=(12, 0), sticky="e")

        info = ttk.Frame(self, padding=(10, 0, 10, 10))
        info.pack(fill=tk.X)
        self.info_var = tk.StringVar(value="DB: " + DB_PATH)
        ttk.Label(info, textvariable=self.info_var).pack(anchor="w")

        filt = ttk.Frame(self, padding=(10, 0, 10, 10))
        filt.pack(fill=tk.X)

        ttk.Checkbutton(filt, text="Exclude stable", variable=self.filter_ex_stable).pack(side=tk.LEFT)
        ttk.Checkbutton(filt, text="Require OHLCV", variable=self.filter_require_ohlcv).pack(side=tk.LEFT, padx=(10, 0))

        ttk.Label(filt, text="Min mcap").pack(side=tk.LEFT, padx=(12, 0))
        ttk.Entry(filt, textvariable=self.min_mcap_var, width=10).pack(side=tk.LEFT, padx=(6, 0))

        ttk.Label(filt, text="Min vol24").pack(side=tk.LEFT, padx=(12, 0))
        ttk.Entry(filt, textvariable=self.min_vol_var, width=10).pack(side=tk.LEFT, padx=(6, 0))

        ttk.Label(filt, text="Max 24h move pct").pack(side=tk.LEFT, padx=(12, 0))
        ttk.Entry(filt, textvariable=self.max_move_var, width=8).pack(side=tk.LEFT, padx=(6, 0))

        ttk.Button(filt, text="Recalc", command=self.recalc_top).pack(side=tk.RIGHT)

        main = ttk.Frame(self, padding=(10, 0, 10, 10))
        main.pack(fill=tk.BOTH, expand=True)

        table_frame = ttk.Frame(main)
        table_frame.pack(fill=tk.BOTH, expand=True)

        cols = ("symbol", "pair", "rank", "spot_score", "price", "chg24", "vol24", "mcap", "liq", "trend", "vol", "top")
        self.tree = ttk.Treeview(table_frame, columns=cols, show="headings")

        vsb = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(table_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")

        table_frame.grid_rowconfigure(0, weight=1)
        table_frame.grid_columnconfigure(0, weight=1)

        headings = {
            "symbol": "Symbol",
            "pair": "Pair",
            "rank": "Rank",
            "spot_score": "SpotSc",
            "price": "Price",
            "chg24": "24h%",
            "vol24": "Vol24",
            "mcap": "MCap",
            "liq": "Liq",
            "trend": "Tren",
            "vol": "Vol",
            "top": "TopSc",
        }
        for c in cols:
            self.tree.heading(c, text=headings.get(c, c), command=lambda cc=c: self.on_sort(cc))

        self.tree.column("symbol", width=90, anchor=tk.W, stretch=False)
        self.tree.column("pair", width=140, anchor=tk.W, stretch=True)
        self.tree.column("rank", width=60, anchor=tk.CENTER, stretch=False)
        self.tree.column("spot_score", width=70, anchor=tk.CENTER, stretch=False)
        self.tree.column("price", width=120, anchor=tk.E, stretch=True)
        self.tree.column("chg24", width=70, anchor=tk.E, stretch=False)
        self.tree.column("vol24", width=140, anchor=tk.E, stretch=True)
        self.tree.column("mcap", width=140, anchor=tk.E, stretch=True)
        self.tree.column("liq", width=50, anchor=tk.CENTER, stretch=False)
        self.tree.column("trend", width=50, anchor=tk.CENTER, stretch=False)
        self.tree.column("vol", width=50, anchor=tk.CENTER, stretch=False)
        self.tree.column("top", width=60, anchor=tk.CENTER, stretch=False)

        self.tree.bind("<<TreeviewSelect>>", self.on_select)

        self.status_var = tk.StringVar(value="Ready")
        ttk.Label(main, textvariable=self.status_var).pack(anchor="w", pady=(10, 0))

        self.detail = tk.Text(main, height=7, wrap="word", font=("TkDefaultFont", FONT_DEFAULT))
        self.detail.pack(fill=tk.BOTH, expand=False, pady=(6, 0))
        self.detail.configure(state="disabled")

        self.load_entry.bind("<Return>", lambda _e: self.apply_load())
        self.top_entry.bind("<Return>", lambda _e: self.recalc_top())
        self.mode_combo.bind("<<ComboboxSelected>>", lambda _e: self.recalc_top())
        self.tf_combo.bind("<<ComboboxSelected>>", lambda _e: self.recalc_top())

    def set_detail(self, text):
        self.detail.configure(state="normal")
        self.detail.delete("1.0", tk.END)
        self.detail.insert(tk.END, text)
        self.detail.configure(state="disabled")

    def apply_load(self):
        self.refresh()

    def refresh(self):
        try:
            con = db_connect()
            with con:
                run = get_latest_run(con)
                if not run:
                    raise RuntimeError("No runs in DB")
                self.run_meta = run
                self.run_id = run["run_id"]

                load_n = int(self.load_n_var.get())
                load_n = clamp(load_n, 1, 5000)
                self.load_n_var.set(load_n)

                self.rows_raw = fetch_spot_rows(con, self.run_id, load_n)

            self.info_var.set(
                "DB: " + DB_PATH
                + "\nrun_id: " + str(self.run_meta.get("run_id"))
                + " run_tag: " + str(self.run_meta.get("run_tag"))
                + " created: " + str(self.run_meta.get("created_any"))
                + " status: " + str(self.run_meta.get("status_any"))
            )
            self.recalc_top()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def parse_filters(self):
        min_mcap = safe_float(self.min_mcap_var.get(), 0.0) or 0.0
        min_vol = safe_float(self.min_vol_var.get(), 0.0) or 0.0
        max_move = safe_float(self.max_move_var.get(), 0.0) or 0.0
        return min_mcap, min_vol, max_move

    def recalc_top(self):
        if not self.run_id:
            return

        tf = (self.tf_var.get() or "4h").strip()
        mode = (self.mode_var.get() or "Balanced").strip()
        w_liq, w_trend, w_vol = weights_for_mode(mode)

        try:
            top_x = int(self.top_x_var.get())
        except Exception:
            top_x = 50
        top_x = clamp(top_x, 1, 5000)
        self.top_x_var.set(top_x)

        min_mcap, min_vol, max_move = self.parse_filters()
        ex_stable = bool(self.filter_ex_stable.get())
        req_ohlcv = bool(self.filter_require_ohlcv.get())

        base_rows = []
        for r in self.rows_raw:
            sym = (r.get("symbol") or "").upper().strip()
            if not sym:
                continue
            if ex_stable and sym in STABLE_BASE:
                continue

            vol24 = safe_float(r.get("volume_24h"), None)
            mcap = safe_float(r.get("market_cap"), None)
            chg24 = safe_float(r.get("chg_24h_pct"), None)

            if mcap is None or vol24 is None:
                continue
            if mcap < min_mcap:
                continue
            if vol24 < min_vol:
                continue
            if max_move > 0 and chg24 is not None and abs(chg24) > max_move:
                continue

            base_rows.append(r)

        liq_scores = calc_liquidity_components(base_rows)

        trend_scores = []
        vol_scores = []

        con = None
        try:
            con = db_connect()
            for i, r in enumerate(base_rows):
                sym = (r.get("symbol") or "").upper().strip()
                closes = fetch_ohlcv_closes(con, self.run_id, sym, tf, limit_n=160)

                tr = calc_trend_score_from_closes(closes)
                vv = calc_vol_score_from_closes(closes)

                if req_ohlcv and (tr is None or vv is None):
                    trend_scores.append(None)
                    vol_scores.append(None)
                else:
                    trend_scores.append(tr)
                    vol_scores.append(vv)
        finally:
            if con is not None:
                con.close()

        rows_calc = []
        for i, r in enumerate(base_rows):
            liq = liq_scores[i]
            tr = trend_scores[i]
            vv = vol_scores[i]

            if req_ohlcv and (tr is None or vv is None):
                continue

            a = liq if liq is not None else 50
            b = tr if tr is not None else 50
            c = vv if vv is not None else 50

            top_score = (w_liq * a) + (w_trend * b) + (w_vol * c)

            rr = dict(r)
            rr["liq_score"] = liq
            rr["trend_score"] = tr
            rr["vol_score"] = vv
            rr["top_score"] = int(round(clamp(top_score, 0.0, 100.0)))
            rows_calc.append(rr)

        self.rows_calc = rows_calc
        self.sort_col = "top"
        self.sort_desc = True
        self.refresh_view()

        self.status_var.set(
            "Loaded " + str(len(self.rows_raw))
            + " filtered " + str(len(self.rows_calc))
            + " mode " + mode + " tf " + tf
            + " top " + str(top_x)
        )
        self.set_detail("Select a row\n")

    def on_sort(self, col):
        if self.sort_col == col:
            self.sort_desc = not self.sort_desc
        else:
            self.sort_col = col
            self.sort_desc = True if col in ("top", "spot_score", "liq", "trend", "vol", "vol24", "mcap", "chg24", "price") else False
        self.refresh_view()

    def refresh_view(self):
        for iid in self.tree.get_children(""):
            self.tree.delete(iid)

        rows = list(self.rows_calc)

        def num(v, default):
            vv = safe_float(v, None)
            return vv if vv is not None else default

        def txt(v):
            return str(v or "").upper()

        col = self.sort_col
        desc = self.sort_desc

        if col == "symbol":
            rows.sort(key=lambda r: txt(r.get("symbol")), reverse=desc)
        elif col == "pair":
            rows.sort(key=lambda r: txt(r.get("pair")), reverse=desc)
        elif col == "rank":
            rows.sort(key=lambda r: num(r.get("rank"), 999999), reverse=desc)
        elif col == "spot_score":
            rows.sort(key=lambda r: num(r.get("spot_score"), -1), reverse=desc)
        elif col == "price":
            rows.sort(key=lambda r: num(r.get("price"), -1), reverse=desc)
        elif col == "chg24":
            rows.sort(key=lambda r: num(r.get("chg_24h_pct"), -999999), reverse=desc)
        elif col == "vol24":
            rows.sort(key=lambda r: num(r.get("volume_24h"), -1), reverse=desc)
        elif col == "mcap":
            rows.sort(key=lambda r: num(r.get("market_cap"), -1), reverse=desc)
        elif col == "liq":
            rows.sort(key=lambda r: num(r.get("liq_score"), -1), reverse=desc)
        elif col == "trend":
            rows.sort(key=lambda r: num(r.get("trend_score"), -1), reverse=desc)
        elif col == "vol":
            rows.sort(key=lambda r: num(r.get("vol_score"), -1), reverse=desc)
        elif col == "top":
            rows.sort(key=lambda r: num(r.get("top_score"), -1), reverse=desc)
        else:
            rows.sort(key=lambda r: num(r.get("rank"), 999999))

        self.rows_view = rows

        for r in rows:
            self.tree.insert(
                "",
                tk.END,
                values=(
                    r.get("symbol") or "",
                    r.get("pair") or "",
                    r.get("rank") if r.get("rank") is not None else "",
                    r.get("spot_score") if r.get("spot_score") is not None else "",
                    fmt_price(r.get("price")),
                    fmt_pct(r.get("chg_24h_pct")),
                    fmt_num(r.get("volume_24h")),
                    fmt_num(r.get("market_cap")),
                    r.get("liq_score") if r.get("liq_score") is not None else "",
                    r.get("trend_score") if r.get("trend_score") is not None else "",
                    r.get("vol_score") if r.get("vol_score") is not None else "",
                    r.get("top_score") if r.get("top_score") is not None else "",
                ),
            )

    def on_select(self, _evt):
        sel = self.tree.selection()
        if not sel:
            return
        vals = self.tree.item(sel[0], "values")
        if not vals:
            return
        sym = str(vals[0])

        r0 = None
        for r in self.rows_view:
            if str(r.get("symbol") or "").upper() == sym.upper():
                r0 = r
                break
        if not r0:
            return

        tf = (self.tf_var.get() or "4h").strip()
        mode = (self.mode_var.get() or "Balanced").strip()

        text = ""
        text += "Symbol: " + sym + "\n"
        text += "Pair: " + str(r0.get("pair") or "") + "\n"
        text += "Rank: " + str(r0.get("rank") or "") + "\n"
        text += "Price: " + fmt_price(r0.get("price")) + "\n"
        text += "24h pct: " + fmt_pct(r0.get("chg_24h_pct")) + "\n"
        text += "Vol24: " + fmt_num(r0.get("volume_24h")) + "\n"
        text += "MCap: " + fmt_num(r0.get("market_cap")) + "\n"
        text += "SpotSc: " + (str(r0.get("spot_score")) if r0.get("spot_score") is not None else "") + "\n"
        text += "TF: " + tf + " Mode: " + mode + "\n"
        text += "Liq: " + (str(r0.get("liq_score")) if r0.get("liq_score") is not None else "n/a") + "\n"
        text += "Trend: " + (str(r0.get("trend_score")) if r0.get("trend_score") is not None else "n/a") + "\n"
        text += "Vol: " + (str(r0.get("vol_score")) if r0.get("vol_score") is not None else "n/a") + "\n"
        text += "TopSc: " + (str(r0.get("top_score")) if r0.get("top_score") is not None else "n/a") + "\n"
        self.set_detail(text)

    def get_top_list(self):
        try:
            top_x = int(self.top_x_var.get())
        except Exception:
            top_x = 50
        top_x = clamp(top_x, 1, 5000)
        self.top_x_var.set(top_x)

        rows = list(self.rows_calc)
        rows.sort(key=lambda r: safe_float(r.get("top_score"), -1), reverse=True)
        return rows[:top_x]

    def export_top_to_db(self):
        if not self.run_id:
            return
        try:
            tf = (self.tf_var.get() or "4h").strip()
            mode = (self.mode_var.get() or "Balanced").strip()
            load_n = int(self.load_n_var.get())
            top_n = int(self.top_x_var.get())

            min_mcap, min_vol, max_move = self.parse_filters()
            filters = {
                "exclude_stable": bool(self.filter_ex_stable.get()),
                "require_ohlcv": bool(self.filter_require_ohlcv.get()),
                "min_market_cap": min_mcap,
                "min_volume_24h": min_vol,
                "max_24h_move_pct": max_move,
            }

            top_rows = self.get_top_list()

            con = db_connect()
            try:
                con.execute("PRAGMA foreign_keys = ON;")
                con.execute("BEGIN;")
                ensure_export_tables(con)

                created_utc = datetime.utcnow().isoformat(timespec="seconds") + "Z"
                cur = con.execute(
                    """
                    INSERT INTO top_exports (created_utc, run_id, timeframe, mode, load_n, top_n, filters_json)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (created_utc, int(self.run_id), tf, mode, int(load_n), int(top_n), json.dumps(filters, ensure_ascii=True)),
                )
                export_id = cur.lastrowid

                for idx, r in enumerate(top_rows, start=1):
                    con.execute(
                        """
                        INSERT INTO top_export_items
                        (export_id, idx, symbol, pair, rank, price, chg_24h_pct, volume_24h, market_cap,
                         spot_score, liq_score, trend_score, vol_score, top_score)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            int(export_id),
                            int(idx),
                            str(r.get("symbol") or ""),
                            str(r.get("pair") or ""),
                            int(r.get("rank")) if r.get("rank") is not None else None,
                            safe_float(r.get("price"), None),
                            safe_float(r.get("chg_24h_pct"), None),
                            safe_float(r.get("volume_24h"), None),
                            safe_float(r.get("market_cap"), None),
                            int(r.get("spot_score")) if r.get("spot_score") is not None else None,
                            int(r.get("liq_score")) if r.get("liq_score") is not None else None,
                            int(r.get("trend_score")) if r.get("trend_score") is not None else None,
                            int(r.get("vol_score")) if r.get("vol_score") is not None else None,
                            int(r.get("top_score")) if r.get("top_score") is not None else None,
                        ),
                    )

                con.commit()
            except Exception:
                con.rollback()
                raise
            finally:
                con.close()

            messagebox.showinfo("OK", "Exported TOP into DB\nexport_id: " + str(export_id))
        except Exception as e:
            messagebox.showerror("Error", str(e))


def main():
    app = App()
    app.mainloop()


if __name__ == "__main__":
    main()
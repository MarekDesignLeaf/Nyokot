#!/usr/bin/env python3
# nyosig_cryptolytix_gui_v2.0a
# ASCII only, Tkinter
# Fixed project root: /storage/emulated/0/NyoSig/NyoSig_Cryptolytix

import os
import sqlite3
import time
import tkinter as tk
from tkinter import ttk, messagebox

APP_VERSION = "2.0b"
APP_FILE_TAG = "nyosig_cryptolytix_gui_v" + APP_VERSION

PROJECT_ROOT = "/storage/emulated/0/NyoSig/NyoSig_Cryptolytix"
DB_PATH = os.path.join(PROJECT_ROOT, "db", "nyosig_cryptolytix.db")

TIMEFRAMES = ["1m", "5m", "15m", "30m", "1h", "4h", "1d", "1w"]
MODES = ["conservative", "balanced", "aggressive"]

EXCLUDE_STABLE_BASE = {
    "USDT", "USDC", "DAI", "TUSD", "FDUSD", "USDP", "BUSD", "EURC", "USDE", "USD1"
}

FONT_SIZE_DEFAULT = 4

# Pipeline layers (UI only in v2.0a)
LAYERS = [
    {
        "key": "spot",
        "name": "SPOT",
        "info": "SPOT market snapshot used to build the initial candidate universe (liquidity, mcap, rank, base score).",
    },
    {
        "key": "derivatives",
        "name": "Derivatives",
        "info": "Futures / perpetuals signals (open interest, funding, basis, liquidations).",
    },
    {
        "key": "onchain",
        "name": "On-chain",
        "info": "On-chain flows and network activity signals (exchange flows, active addresses, holder behaviour).",
    },
    {
        "key": "institutional",
        "name": "Institutional",
        "info": "Institutional flow proxies (ETFs, funds, reports, large allocations).",
    },
    {
        "key": "macro",
        "name": "Macro",
        "info": "Macro context (rates, USD, equities, liquidity, risk-on/off regime drivers).",
    },
    {
        "key": "sentiment",
        "name": "Sentiment",
        "info": "Sentiment layer as a supplement (search interest, social signals).",
    },
    {
        "key": "ohlcv",
        "name": "OHLCV",
        "info": "Price action and OHLCV history for technical features and regime detection.",
    },
]


def ascii_guard():
    with open(__file__, "rb") as f:
        b = f.read()
    start = 3 if b.startswith(b"\xef\xbb\xbf") else 0
    for i in range(start, len(b)):
        if b[i] > 127:
            raise RuntimeError("Non ASCII byte found at offset %d" % i)


def utc_now_iso():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def safe_int(x, default=0):
    try:
        return int(x)
    except Exception:
        return default


def safe_float(x, default=None):
    try:
        if x is None:
            return default
        return float(x)
    except Exception:
        return default


def fmt_price(v):
    v = safe_float(v, None)
    if v is None:
        return ""
    if abs(v) >= 1:
        return f"{v:,.4f}"
    return f"{v:.8f}"


def fmt_pct(v):
    v = safe_float(v, None)
    if v is None:
        return ""
    return f"{v:.2f}"


def fmt_int(v):
    v = safe_float(v, None)
    if v is None:
        return ""
    try:
        return f"{int(round(v)):,d}"
    except Exception:
        return ""


def db_connect():
    if not os.path.exists(DB_PATH):
        raise RuntimeError("DB not found at: " + DB_PATH)
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON;")
    return con


def ensure_top_tables(con):
    con.execute(
        """
        CREATE TABLE IF NOT EXISTS top_sets (
          top_set_id TEXT PRIMARY KEY,
          created_utc TEXT NOT NULL,
          source_run_id TEXT NOT NULL,
          vs_currency TEXT,
          load_n INTEGER,
          filters_json TEXT,
          timeframe TEXT,
          mode TEXT,
          top_n INTEGER,
          notes TEXT
        );
        """
    )
    con.execute(
        """
        CREATE TABLE IF NOT EXISTS top_set_items (
          top_set_id TEXT NOT NULL,
          rank_in_top INTEGER NOT NULL,
          unified_symbol TEXT NOT NULL,
          pair TEXT,
          price REAL,
          change_24h_pct REAL,
          volume_24h REAL,
          market_cap REAL,
          cg_rank INTEGER,
          spot_score INTEGER,
          top_score REAL,
          PRIMARY KEY (top_set_id, unified_symbol),
          FOREIGN KEY (top_set_id) REFERENCES top_sets(top_set_id) ON DELETE CASCADE
        );
        """
    )
    con.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_top_set_items_rank
        ON top_set_items (top_set_id, rank_in_top);
        """
    )


def make_saved_top_set_id():
    return "TS_" + time.strftime("%Y%m%d_%H%M%S", time.gmtime()) + "_" + str(int(time.time() * 1000) % 1000).zfill(3)


def filters_to_jsonlike(exclude_stable, min_vol24, min_mcap, max_abs_chg24):
    return (
        "{"
        + f"exclude_stable:{int(bool(exclude_stable))},"
        + f"min_vol24:{min_vol24},"
        + f"min_mcap:{min_mcap},"
        + f"max_abs_chg24:{max_abs_chg24}"
        + "}"
    )


def top_score(mode, row):
    vol = safe_float(row.get("vol24"), 0.0) or 0.0
    mcap = safe_float(row.get("mcap"), 0.0) or 0.0
    chg = abs(safe_float(row.get("chg24"), 0.0) or 0.0)
    rank = safe_float(row.get("rank"), 999999.0) or 999999.0
    base = safe_float(row.get("score"), 0.0) or 0.0

    try:
        import math
        lv = math.log1p(max(0.0, float(vol)))
        lm = math.log1p(max(0.0, float(mcap)))
    except Exception:
        lv = 0.0
        lm = 0.0

    if mode == "aggressive":
        return (base * 1.0) + (lv * 9.0) + (chg * 2.2) - (rank * 0.01)
    if mode == "conservative":
        return (base * 1.3) + (lv * 5.5) + (lm * 2.5) - (chg * 1.6) - (rank * 0.02)
    return (base * 1.15) + (lv * 7.0) + (lm * 1.2) + (chg * 0.6) - (rank * 0.015)


class AnalyseWindow(tk.Toplevel):
    def __init__(self, master, top_set_id, selected_symbols, layer_keys_ordered):
        super().__init__(master)
        self.title("Analyse - " + str(top_set_id))
        self.geometry("860x520")
        self.resizable(True, True)

        self.top_set_id = str(top_set_id)
        self.selected_symbols = list(selected_symbols or [])
        self.layer_keys = list(layer_keys_ordered or [])

        self.mode_var = tk.StringVar(value="run_all")  # run_all or step_mode

        header = ttk.Frame(self, padding=10)
        header.grid(row=0, column=0, sticky="ew")
        header.grid_columnconfigure(1, weight=1)

        ttk.Label(header, text="TOP set:").grid(row=0, column=0, sticky="w")
        ttk.Label(header, text=self.top_set_id).grid(row=0, column=1, sticky="w")

        ttk.Label(header, text="Selected:").grid(row=1, column=0, sticky="w", pady=(6, 0))
        ttk.Label(header, text=str(len(self.selected_symbols))).grid(row=1, column=1, sticky="w", pady=(6, 0))

        controls = ttk.Frame(self, padding=(10, 0, 10, 10))
        controls.grid(row=1, column=0, sticky="ew")
        controls.grid_columnconfigure(2, weight=1)

        rb1 = ttk.Radiobutton(controls, text="Run all", variable=self.mode_var, value="run_all", command=self._apply_mode)
        rb2 = ttk.Radiobutton(controls, text="STEP mode", variable=self.mode_var, value="step_mode", command=self._apply_mode)
        rb1.grid(row=0, column=0, sticky="w")
        rb2.grid(row=0, column=1, sticky="w", padx=(10, 0))

        self.progress = ttk.Progressbar(controls, orient="horizontal", mode="determinate", maximum=100)
        self.progress.grid(row=0, column=2, sticky="ew", padx=(12, 0))

        self.status_var = tk.StringVar(value="Ready")
        ttk.Label(controls, textvariable=self.status_var).grid(row=1, column=0, columnspan=3, sticky="w", pady=(6, 0))

        body = ttk.Frame(self, padding=(10, 0, 10, 10))
        body.grid(row=2, column=0, sticky="nsew")
        self.grid_rowconfigure(2, weight=1)
        self.grid_columnconfigure(0, weight=1)

        body.grid_columnconfigure(0, weight=1)
        body.grid_rowconfigure(0, weight=1)

        box = ttk.Labelframe(body, text="Layers (execution order)", padding=8)
        box.grid(row=0, column=0, sticky="nsew")
        box.grid_columnconfigure(0, weight=1)

        self.layer_vars = {}
        self.info_btns = {}
        self.setup_btns = {}

        for i, k in enumerate(self.layer_keys):
            layer = self._layer_by_key(k)
            name = layer.get("name", k)
            v = tk.BooleanVar(value=True)
            self.layer_vars[k] = v

            row = ttk.Frame(box)
            row.grid(row=i, column=0, sticky="ew", pady=2)
            row.grid_columnconfigure(1, weight=1)

            cb = ttk.Checkbutton(row, variable=v)
            cb.grid(row=0, column=0, sticky="w")

            ttk.Label(row, text=name).grid(row=0, column=1, sticky="w")

            b_info = ttk.Button(row, text="Info", command=lambda kk=k: self._show_layer_info(kk))
            b_info.grid(row=0, column=2, sticky="e", padx=(8, 0))

            b_setup = ttk.Button(row, text="Setup", command=lambda kk=k: self._setup_placeholder(kk), state="disabled")
            b_setup.grid(row=0, column=3, sticky="e", padx=(6, 0))

            self.info_btns[k] = b_info
            self.setup_btns[k] = b_setup

        footer = ttk.Frame(self, padding=(10, 0, 10, 10))
        footer.grid(row=3, column=0, sticky="ew")
        footer.grid_columnconfigure(1, weight=1)

        self.btn_start = ttk.Button(footer, text="Start", command=self._start_placeholder)
        self.btn_start.grid(row=0, column=0, sticky="w")

        self.btn_close = ttk.Button(footer, text="Close", command=self.destroy)
        self.btn_close.grid(row=0, column=2, sticky="e")

        self._apply_mode()

    def _layer_by_key(self, key):
        for x in LAYERS:
            if x.get("key") == key:
                return x
        return {"key": key, "name": key, "info": "No description."}

    def _apply_mode(self):
        mode = (self.mode_var.get() or "run_all").strip()
        allow_toggle = bool(mode == "step_mode")
        for k, v in self.layer_vars.items():
            # Tk Checkbutton state: normal/disabled
            st = "normal" if allow_toggle else "disabled"
            # find the checkbutton widget: it is the first child in row frame
            # safest: walk all children and set state on checkbuttons using this variable
            self._set_checkbutton_state_for_var(v, st)

        if allow_toggle:
            self.status_var.set("STEP mode: you can enable/disable layers.")
        else:
            self.status_var.set("Run all: layers are locked ON.")

    def _set_checkbutton_state_for_var(self, var, state):
        # brute force: scan widgets in window
        for w in self.winfo_children():
            self._walk_set_state(w, var, state)

    def _walk_set_state(self, w, var, state):
        try:
            if isinstance(w, ttk.Checkbutton):
                try:
                    if str(w.cget("variable")) == str(var):
                        w.state(["!disabled"] if state == "normal" else ["disabled"])
                except Exception:
                    pass
        except Exception:
            pass
        try:
            for ch in w.winfo_children():
                self._walk_set_state(ch, var, state)
        except Exception:
            pass

    def _show_layer_info(self, key):
        layer = self._layer_by_key(key)
        messagebox.showinfo(layer.get("name", "Layer"), layer.get("info", ""))

    def _setup_placeholder(self, key):
        messagebox.showinfo("Setup", "Setup is not implemented in v2.0a.")

    def _start_placeholder(self):
        # In v2.0a this is a placeholder to confirm the UI wiring.
        mode = (self.mode_var.get() or "run_all").strip()
        enabled_layers = []
        for k in self.layer_keys:
            if bool(self.layer_vars[k].get()):
                enabled_layers.append(k)

        txt = []
        txt.append("v2.0a placeholder")
        txt.append("Mode: " + ("Run all" if mode == "run_all" else "STEP mode"))
        txt.append("Enabled layers: " + (", ".join(enabled_layers) if enabled_layers else "(none)"))
        txt.append("Selected symbols: " + str(len(self.selected_symbols)))
        messagebox.showinfo("Analyse", "\n".join(txt))

        # fake progress
        self.progress["value"] = 0
        self.status_var.set("Running (placeholder)...")
        self.after(120, lambda: self.progress.configure(value=35))
        self.after(240, lambda: self.progress.configure(value=70))
        self.after(360, lambda: self.progress.configure(value=100))
        self.after(500, lambda: self.status_var.set("Done (placeholder)."))


class App(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("NyoSig Cryptolytix - " + APP_FILE_TAG)
        self._set_big_window()

        self.current_run = None
        self.rows_loaded = []
        self.rows_filtered = []
        self.cand_view = []
        self.top_view = []

        self.top_library = {}
        self.mem_top_counter = 0
        self.selected_mem_top_id = None

        self.load_n_var = tk.IntVar(value=300)

        self.exclude_stable_var = tk.BooleanVar(value=True)
        self.min_vol24_var = tk.StringVar(value="")
        self.min_mcap_var = tk.StringVar(value="")
        self.max_abs_chg24_var = tk.StringVar(value="")

        self.top_n_var = tk.IntVar(value=15)
        self.mode_var = tk.StringVar(value="balanced")
        self.tf_var = tk.StringVar(value="4h")

        self.top_sets_var = tk.StringVar(value="")

        self.status_var = tk.StringVar(value="Ready")

        self._cand_sort = {"col": None, "desc": True}
        self._top_sort = {"col": None, "desc": True}

        self._build_ui()
        self._apply_fonts_fixed()
        self._refresh_run_meta()
        self.apply_load()

    def _set_big_window(self):
        try:
            w = self.winfo_screenwidth()
            h = self.winfo_screenheight()
            self.geometry(f"{w}x{h}")
        except Exception:
            self.geometry("1040x790")

    def _apply_fonts_fixed(self):
        fs = FONT_SIZE_DEFAULT
        style = ttk.Style(self)
        try:
            style.theme_use("default")
        except Exception:
            pass
        style.configure("Treeview", font=("TkDefaultFont", fs))
        style.configure("Treeview.Heading", font=("TkDefaultFont", fs))

    def set_status(self, txt):
        self.status_var.set(txt)

    def _build_ui(self):
        self.grid_rowconfigure(1, weight=1)
        self.grid_columnconfigure(0, weight=1)

        style = ttk.Style()
        try:
            style.configure("TButton", padding=(4, 2))
            style.configure("TLabel", padding=(2, 0))
            style.configure("TCheckbutton", padding=(2, 0))
        except Exception:
            pass

        top = ttk.Frame(self, padding=6)
        top.grid(row=0, column=0, sticky="ew")
        top.grid_columnconfigure(0, weight=1)
        top.grid_columnconfigure(1, weight=1)

        # left column groups
        grp_run = ttk.Labelframe(top, text="Run", padding=6)
        grp_filters = ttk.Labelframe(top, text="Filters", padding=6)

        # right column groups
        grp_top = ttk.Labelframe(top, text="TOP", padding=6)
        grp_actions = ttk.Labelframe(top, text="Actions", padding=6)

        # Layout (v2.x): Run + Filters on the left; TOP + Actions aligned under them
        grp_run.grid(row=0, column=0, sticky="ew", padx=(0, 6), pady=(0, 6))
        grp_filters.grid(row=1, column=0, sticky="ew", padx=(0, 6), pady=(0, 6))

        grp_top.grid(row=2, column=0, sticky="ew", padx=(0, 6), pady=(0, 6))
        grp_actions.grid(row=2, column=1, sticky="ew", padx=(6, 0), pady=(0, 6))

        # Version label in top-right corner area
        ver_row = ttk.Frame(top, padding=(0, 0, 0, 0))
        ver_row.grid(row=2, column=0, columnspan=2, sticky="ew")
        ver_row.grid_columnconfigure(0, weight=1)
        ttk.Label(ver_row, text="").grid(row=0, column=0, sticky="w")
        self.version_lbl = ttk.Label(ver_row, text="Version: " + APP_VERSION)
        self.version_lbl.grid(row=0, column=1, sticky="e")

        # Run group
        ttk.Label(grp_run, text="Load N:").grid(row=0, column=0, pady=2, sticky="e")
        self.spin_load = ttk.Spinbox(grp_run, from_=50, to=5000, increment=50, textvariable=self.load_n_var, width=7)
        self.spin_load.grid(row=0, column=1, padx=(4, 10), pady=2, sticky="w")

        self.btn_apply_load = ttk.Button(grp_run, text="Apply", command=self.apply_load)
        self.btn_apply_load.grid(row=0, column=2, padx=(0, 10), pady=2, sticky="w")

        self.db_meta_lbl = ttk.Label(grp_run, text="DB: -  Run: -")
        self.db_meta_lbl.grid(row=0, column=3, pady=2, sticky="e")
        grp_run.grid_columnconfigure(3, weight=1)

        # Filters group (pushed to the left by being in left column)
        self.chk_stable = ttk.Checkbutton(grp_filters, text="Exclude stable", variable=self.exclude_stable_var)
        self.chk_stable.grid(row=0, column=0, padx=(0, 10), pady=2, sticky="w")

        ttk.Label(grp_filters, text="Min vol24:").grid(row=0, column=1, pady=2, sticky="e")
        self.ent_min_vol = ttk.Combobox(
            grp_filters, textvariable=self.min_vol24_var, width=12,
            values=["off", "1000000", "5000000", "10000000", "25000000", "50000000", "100000000"]
        )
        self.ent_min_vol.grid(row=0, column=2, padx=(4, 10), pady=2, sticky="w")

        ttk.Label(grp_filters, text="Min mcap:").grid(row=0, column=3, pady=2, sticky="e")
        self.ent_min_mcap = ttk.Combobox(
            grp_filters, textvariable=self.min_mcap_var, width=12,
            values=["off", "10000000", "25000000", "50000000", "100000000", "250000000", "500000000", "1000000000"]
        )
        self.ent_min_mcap.grid(row=0, column=4, padx=(4, 10), pady=2, sticky="w")

        ttk.Label(grp_filters, text="Max abs chg24%:").grid(row=0, column=5, pady=2, sticky="e")
        self.ent_max_chg = ttk.Combobox(
            grp_filters, textvariable=self.max_abs_chg24_var, width=8,
            values=["off", "5", "10", "15", "20", "25", "30", "40", "50", "75", "100", "150", "200"]
        )
        self.ent_max_chg.grid(row=0, column=6, padx=(4, 10), pady=2, sticky="w")

        self.btn_apply_filters = ttk.Button(grp_filters, text="Apply filters", command=self.apply_filters)
        self.btn_apply_filters.grid(row=0, column=7, padx=(0, 10), pady=2, sticky="w")

        grp_filters.grid_columnconfigure(8, weight=1)

        # TOP group
        ttk.Label(grp_top, text="Top N:").grid(row=0, column=0, pady=2, sticky="e")
        self.spin_top_n = ttk.Spinbox(grp_top, from_=5, to=500, increment=5, textvariable=self.top_n_var, width=6)
        self.spin_top_n.grid(row=0, column=1, padx=(4, 10), pady=2, sticky="w")

        ttk.Label(grp_top, text="Mode:").grid(row=0, column=2, pady=2, sticky="e")
        self.cmb_mode = ttk.Combobox(grp_top, textvariable=self.mode_var, values=MODES, state="readonly", width=12)
        self.cmb_mode.grid(row=0, column=3, padx=(4, 10), pady=2, sticky="w")

        ttk.Label(grp_top, text="TF:").grid(row=0, column=4, pady=2, sticky="e")
        self.cmb_tf = ttk.Combobox(grp_top, textvariable=self.tf_var, values=TIMEFRAMES, state="readonly", width=6)
        self.cmb_tf.grid(row=0, column=5, padx=(4, 10), pady=2, sticky="w")

        self.btn_build_top = ttk.Button(grp_top, text="Build TOP", command=self.build_top)
        self.btn_build_top.grid(row=0, column=6, padx=(0, 10), pady=2, sticky="w")

        self.btn_top_all = ttk.Button(grp_top, text="All", command=self.top_select_all_toggle)
        self.btn_top_all.grid(row=0, column=7, padx=(0, 14), pady=2, sticky="w")

        ttk.Label(grp_top, text="TOP sets:").grid(row=0, column=8, pady=2, sticky="e")
        self.cmb_top_sets = ttk.Combobox(grp_top, textvariable=self.top_sets_var, values=[], state="readonly", width=18)
        self.cmb_top_sets.grid(row=0, column=9, padx=(4, 10), pady=2, sticky="w")
        self.cmb_top_sets.bind("<<ComboboxSelected>>", lambda _e: self.on_select_top_set())

        grp_top.grid_columnconfigure(10, weight=1)

        # Actions group
        self.btn_to_db = tk.Button(
            grp_actions, text="To DB", command=self.commit_top_to_db,
            bg="#cc0000", fg="white", activebackground="#ff3333",
            relief="raised", padx=10, pady=2
        )
        self.btn_to_db.grid(row=0, column=0, padx=(0, 10), pady=2, sticky="w")

        self.btn_analyse = ttk.Button(grp_actions, text="Analyse", command=self.analyse_top)
        self.btn_analyse.grid(row=0, column=1, padx=(0, 10), pady=2, sticky="w")

        self.counts_lbl = ttk.Label(grp_actions, text="Candidates: 0  Filtered: 0  TOP sets: 0")
        self.counts_lbl.grid(row=0, column=2, pady=2, sticky="w")
        grp_actions.grid_columnconfigure(2, weight=1)

        # Main pane
        main = ttk.PanedWindow(self, orient=tk.VERTICAL)
        main.grid(row=1, column=0, sticky="nsew", padx=6, pady=(0, 6))

        cand_frame = ttk.Labelframe(main, text="Candidates (from DB)", padding=6)
        top_frame = ttk.Labelframe(main, text="TOP (in memory)", padding=6)

        main.add(cand_frame, weight=1)
        main.add(top_frame, weight=1)

        self.cand_tree = self._make_tree(
            parent=cand_frame,
            cols=("rank", "pair", "price", "chg24", "vol24", "mcap", "score"),
            headings=("Rank", "Pair", "Price", "Chg24%", "Vol24", "MCap", "Score"),
            sort_handler=self.sort_candidates_by,
        )

        # TOP tree includes a selectable checkbox-like column
        self.top_tree = self._make_tree(
            parent=top_frame,
            cols=("use", "top_rank", "pair", "price", "chg24", "vol24", "mcap", "rank", "score", "top_score"),
            headings=("Use", "Top", "Pair", "Price", "Chg24%", "Vol24", "MCap", "CgRank", "SpotScore", "TopScore"),
            sort_handler=self.sort_top_by,
        )
        self.top_tree.column("use", width=50, anchor=tk.CENTER, stretch=False)

        # toggle selection by clicking the first column
        self.top_tree.bind("<Button-1>", self._on_top_tree_click, add=True)

        status = ttk.Frame(self, padding=(6, 0, 6, 6))
        status.grid(row=2, column=0, sticky="ew")
        status.grid_columnconfigure(0, weight=1)
        ttk.Label(status, textvariable=self.status_var).grid(row=0, column=0, sticky="w")

    def _make_tree(self, parent, cols, headings, sort_handler):
        parent.grid_rowconfigure(0, weight=1)
        parent.grid_columnconfigure(0, weight=1)

        wrap = ttk.Frame(parent)
        wrap.grid(row=0, column=0, sticky="nsew")
        wrap.grid_rowconfigure(0, weight=1)
        wrap.grid_columnconfigure(0, weight=1)

        tree = ttk.Treeview(wrap, columns=cols, show="headings")
        tree.grid(row=0, column=0, sticky="nsew")

        ysb = ttk.Scrollbar(wrap, orient="vertical", command=tree.yview)
        xsb = ttk.Scrollbar(wrap, orient="horizontal", command=tree.xview)
        tree.configure(yscroll=ysb.set, xscroll=xsb.set)
        ysb.grid(row=0, column=1, sticky="ns")
        xsb.grid(row=1, column=0, sticky="ew")

        for c, h in zip(cols, headings):
            tree.heading(c, text=h, command=lambda cc=c: sort_handler(cc))

        for c in cols:
            if c == "pair":
                tree.column(c, width=140, anchor=tk.W, stretch=True)
            elif c == "use":
                tree.column(c, width=50, anchor=tk.CENTER, stretch=False)
            else:
                tree.column(c, width=100, anchor=tk.E, stretch=False)

        return tree

    def _refresh_run_meta(self):
        try:
            if not os.path.isdir(PROJECT_ROOT):
                self.db_meta_lbl.config(text="DB: project root missing")
                return
            con = db_connect()
            try:
                run = con.execute(
                    """
                    SELECT run_id, created_utc, status, vs_currency, coins_limit, sort_mode, source
                    FROM runs
                    ORDER BY run_id DESC
                    LIMIT 1
                    """
                ).fetchone()
                if not run:
                    self.current_run = None
                    self.db_meta_lbl.config(text="DB: OK  Run: none")
                    return
                self.current_run = dict(run)
                rid = str(run["run_id"])
                created = str(run["created_utc"] or "")
                src = str(run["source"] or "")
                self.db_meta_lbl.config(text=f"DB: OK  Run: {rid}  {created}  {src}")
            finally:
                con.close()
        except Exception as e:
            self.current_run = None
            self.db_meta_lbl.config(text="DB error: " + str(e)[:60])

    def apply_load(self):
        self._refresh_run_meta()

        try:
            if not self.current_run:
                self.set_status("No run in DB")
                self.rows_loaded = []
                self.rows_filtered = []
                self.cand_view = []
                self._render_candidates([])
                self._render_top([])
                self._update_counts()
                return

            load_n = safe_int(self.load_n_var.get(), 300)
            if load_n <= 0:
                load_n = 300

            run_id = str(self.current_run["run_id"])

            con = db_connect()
            try:
                rows = con.execute(
                    """
                    SELECT unified_symbol, pair, price, change_24h_pct, volume_24h, market_cap, rank, score
                    FROM spot_markets
                    WHERE run_id = ?
                    ORDER BY rank ASC
                    LIMIT ?
                    """,
                    (run_id, load_n),
                ).fetchall()

                out = []
                for r in rows:
                    sym = (r["unified_symbol"] or "").upper().strip()
                    if not sym:
                        continue
                    out.append(
                        {
                            "symbol": sym,
                            "pair": r["pair"] or (sym + "/USD"),
                            "price": safe_float(r["price"], None),
                            "chg24": safe_float(r["change_24h_pct"], None),
                            "vol24": safe_float(r["volume_24h"], None),
                            "mcap": safe_float(r["market_cap"], None),
                            "rank": safe_int(r["rank"], 999999),
                            "score": safe_int(r["score"], 0),
                        }
                    )

                self.rows_loaded = out
                self.apply_filters()
                self.set_status(f"Loaded {len(self.rows_loaded)} candidates from run {run_id}")
            finally:
                con.close()
        except Exception as e:
            messagebox.showerror("Error", str(e)[:800])
            self.set_status("Error")

    def apply_filters(self):
        ex_stable = bool(self.exclude_stable_var.get())

        min_vol24 = safe_float(self.min_vol24_var.get().strip() if self.min_vol24_var.get() is not None else "", None)
        min_mcap = safe_float(self.min_mcap_var.get().strip() if self.min_mcap_var.get() is not None else "", None)
        max_abs_chg = safe_float(self.max_abs_chg24_var.get().strip() if self.max_abs_chg24_var.get() is not None else "", None)

        filtered = []
        for r in self.rows_loaded:
            sym = (r.get("symbol") or "").upper().strip()
            if not sym:
                continue
            if ex_stable and sym in EXCLUDE_STABLE_BASE:
                continue

            vol24 = safe_float(r.get("vol24"), None)
            mcap = safe_float(r.get("mcap"), None)
            chg24 = safe_float(r.get("chg24"), None)

            if min_vol24 is not None and (vol24 is None or vol24 < min_vol24):
                continue
            if min_mcap is not None and (mcap is None or mcap < min_mcap):
                continue
            if max_abs_chg is not None and (chg24 is None or abs(chg24) > max_abs_chg):
                continue

            filtered.append(r)

        self.rows_filtered = filtered
        self.cand_view = list(filtered)

        self.cand_view.sort(key=lambda x: safe_int(x.get("rank"), 999999))
        self._cand_sort = {"col": "rank", "desc": False}

        self._render_candidates(self.cand_view)
        self._update_counts()
        self.set_status("Filters applied")

    def _render_candidates(self, rows):
        self.cand_tree.delete(*self.cand_tree.get_children())
        for r in rows:
            self.cand_tree.insert(
                "",
                "end",
                values=(
                    r.get("rank", ""),
                    r.get("pair", ""),
                    fmt_price(r.get("price")),
                    fmt_pct(r.get("chg24")),
                    fmt_int(r.get("vol24")),
                    fmt_int(r.get("mcap")),
                    r.get("score", ""),
                ),
            )

    def _render_top(self, items):
        self.top_tree.delete(*self.top_tree.get_children())
        for r in items:
            self.top_tree.insert(
                "",
                "end",
                values=(
                    "X" if bool(r.get("use", True)) else "",
                    r.get("top_rank", ""),
                    r.get("pair", ""),
                    fmt_price(r.get("price")),
                    fmt_pct(r.get("chg24")),
                    fmt_int(r.get("vol24")),
                    fmt_int(r.get("mcap")),
                    r.get("rank", ""),
                    r.get("score", ""),
                    f"{safe_float(r.get('top_score'), 0.0):.4f}" if r.get("top_score") is not None else "",
                ),
            )

    def _update_counts(self):
        cand_n = len(self.rows_loaded)
        filt_n = len(self.rows_filtered)
        top_sets_n = len(self.top_library)
        self.counts_lbl.config(text=f"Candidates: {cand_n}  Filtered: {filt_n}  TOP sets: {top_sets_n}")

    def sort_candidates_by(self, col):
        if not self.cand_view:
            return

        desc = True
        if self._cand_sort["col"] == col:
            desc = not bool(self._cand_sort["desc"])

        def keyf(r):
            if col == "pair":
                return (str(r.get("pair") or "")).upper()
            if col == "rank":
                return safe_int(r.get("rank"), 999999)
            if col == "score":
                return safe_int(r.get("score"), 0)
            if col == "price":
                return safe_float(r.get("price"), -1e99)
            if col == "chg24":
                return safe_float(r.get("chg24"), -1e99)
            if col == "vol24":
                return safe_float(r.get("vol24"), -1e99)
            if col == "mcap":
                return safe_float(r.get("mcap"), -1e99)
            return 0

        self.cand_view = sorted(self.cand_view, key=keyf, reverse=desc)
        self._cand_sort = {"col": col, "desc": desc}
        self._render_candidates(self.cand_view)

    def sort_top_by(self, col):
        if not self.top_view:
            return

        # Do not sort by checkbox column via header clicks (keep it simple)
        if col == "use":
            return

        desc = True
        if self._top_sort["col"] == col:
            desc = not bool(self._top_sort["desc"])

        def keyf(r):
            if col == "pair":
                return (str(r.get("pair") or "")).upper()
            if col == "top_rank":
                return safe_int(r.get("top_rank"), 999999)
            if col == "rank":
                return safe_int(r.get("rank"), 999999)
            if col == "score":
                return safe_int(r.get("score"), 0)
            if col == "top_score":
                return safe_float(r.get("top_score"), -1e99)
            if col == "price":
                return safe_float(r.get("price"), -1e99)
            if col == "chg24":
                return safe_float(r.get("chg24"), -1e99)
            if col == "vol24":
                return safe_float(r.get("vol24"), -1e99)
            if col == "mcap":
                return safe_float(r.get("mcap"), -1e99)
            return 0

        self.top_view = sorted(self.top_view, key=keyf, reverse=desc)
        self._top_sort = {"col": col, "desc": desc}
        self._render_top(self.top_view)

    def _on_top_tree_click(self, event):
        # Toggle selection when clicking the first column ("use")
        try:
            region = self.top_tree.identify("region", event.x, event.y)
            if region != "cell":
                return
            col = self.top_tree.identify_column(event.x)
            if col != "#1":  # first visible column is "use"
                return
            item_id = self.top_tree.identify_row(event.y)
            if not item_id:
                return
            idx = self.top_tree.index(item_id)
            if idx < 0 or idx >= len(self.top_view):
                return
            self.top_view[idx]["use"] = not bool(self.top_view[idx].get("use", True))
            self._render_top(self.top_view)
        except Exception:
            return

    def top_select_all_toggle(self):
        if not self.top_view:
            return
        all_on = True
        for r in self.top_view:
            if not bool(r.get("use", True)):
                all_on = False
                break
        new_val = False if all_on else True
        for r in self.top_view:
            r["use"] = new_val
        self._render_top(self.top_view)

    def build_top(self):
        if not self.rows_filtered:
            messagebox.showerror("Error", "No filtered candidates. Load and apply filters first.")
            return
        if not self.current_run:
            messagebox.showerror("Error", "No run loaded.")
            return

        top_n = safe_int(self.top_n_var.get(), 15)
        if top_n <= 0:
            top_n = 15

        mode = (self.mode_var.get() or "balanced").strip().lower()
        if mode not in MODES:
            mode = "balanced"

        tf = (self.tf_var.get() or "4h").strip()
        if tf not in TIMEFRAMES:
            tf = "4h"

        base_sorted = sorted(
            self.rows_filtered,
            key=lambda r: (
                safe_float(r.get("vol24"), 0.0) or 0.0,
                safe_float(r.get("mcap"), 0.0) or 0.0,
                -safe_float(r.get("rank"), 999999.0) if safe_float(r.get("rank"), None) is not None else 0.0,
            ),
            reverse=True,
        )

        scored = []
        for r in base_sorted:
            sym = (r.get("symbol") or "").upper().strip()
            if not sym:
                continue
            rr = dict(r)
            rr["top_score"] = float(top_score(mode, rr))
            scored.append(rr)

        scored.sort(
            key=lambda r: (
                safe_float(r.get("top_score"), 0.0) or 0.0,
                safe_float(r.get("vol24"), 0.0) or 0.0,
            ),
            reverse=True,
        )
        picked = scored[:top_n]

        items = []
        for i, r in enumerate(picked, start=1):
            items.append(
                {
                    "use": True,
                    "top_rank": i,
                    "symbol": r.get("symbol"),
                    "pair": r.get("pair"),
                    "price": r.get("price"),
                    "chg24": r.get("chg24"),
                    "vol24": r.get("vol24"),
                    "mcap": r.get("mcap"),
                    "rank": r.get("rank"),
                    "score": r.get("score"),
                    "top_score": r.get("top_score"),
                }
            )

        self.mem_top_counter += 1
        mem_id = f"TOP_{self.mem_top_counter:03d}  {mode}  {tf}  n={top_n}"
        self.top_library[mem_id] = {
            "meta": {
                "created_utc": utc_now_iso(),
                "run_id": str(self.current_run["run_id"]),
                "mode": mode,
                "timeframe": tf,
                "top_n": top_n,
                "load_n": safe_int(self.load_n_var.get(), 300),
                "filters": {
                    "exclude_stable": int(bool(self.exclude_stable_var.get())),
                    "min_vol24": (self.min_vol24_var.get() or "").strip(),
                    "min_mcap": (self.min_mcap_var.get() or "").strip(),
                    "max_abs_chg24": (self.max_abs_chg24_var.get() or "").strip(),
                },
            },
            "items": items,
            "saved_db_id": None,
        }

        self._refresh_top_sets_dropdown(select_mem_id=mem_id)
        self._show_top_set(mem_id)
        self.set_status("TOP built in memory (not saved)")

    def _fit_top_sets_width(self):
        vals = list(self.top_library.keys())
        if not vals:
            self.cmb_top_sets.configure(width=18)
            return
        mx = max(len(v) for v in vals)
        # A conservative clamp so the control does not eat the whole UI
        w = max(18, min(60, mx + 2))
        try:
            self.cmb_top_sets.configure(width=w)
        except Exception:
            pass

    def _refresh_top_sets_dropdown(self, select_mem_id=None):
        vals = list(self.top_library.keys())
        self.cmb_top_sets["values"] = vals

        if select_mem_id and select_mem_id in self.top_library:
            self.top_sets_var.set(select_mem_id)
            self.selected_mem_top_id = select_mem_id
        elif self.selected_mem_top_id in self.top_library:
            self.top_sets_var.set(self.selected_mem_top_id)
        elif vals:
            self.top_sets_var.set(vals[-1])
            self.selected_mem_top_id = vals[-1]
        else:
            self.top_sets_var.set("")
            self.selected_mem_top_id = None

        self._fit_top_sets_width()
        self._update_counts()

    def on_select_top_set(self):
        mem_id = (self.top_sets_var.get() or "").strip()
        if not mem_id:
            return
        if mem_id not in self.top_library:
            return
        self._show_top_set(mem_id)

    def _show_top_set(self, mem_id):
        self.selected_mem_top_id = mem_id
        items = self.top_library[mem_id]["items"]
        self.top_view = list(items)
        self.top_view.sort(key=lambda r: safe_int(r.get("top_rank"), 999999))
        self._top_sort = {"col": "top_rank", "desc": False}
        self._render_top(self.top_view)

        saved = self.top_library[mem_id].get("saved_db_id")
        if saved:
            self.set_status(f"TOP selected: saved as {saved}")
        else:
            self.set_status("TOP selected: not saved")

    def _selected_top_items(self, mem_id):
        if not mem_id or mem_id not in self.top_library:
            return []
        items = self.top_library[mem_id].get("items") or []
        out = []
        for it in items:
            if bool(it.get("use", True)):
                out.append(it)
        return out

    def commit_top_to_db(self):
        mem_id = (self.top_sets_var.get() or "").strip()
        if not mem_id or mem_id not in self.top_library:
            messagebox.showerror("Error", "No TOP set selected.")
            return
        if not self.current_run:
            messagebox.showerror("Error", "No run loaded.")
            return

        top_obj = self.top_library[mem_id]
        selected_items = self._selected_top_items(mem_id)
        if not selected_items:
            messagebox.showerror("Error", "No selected candidates in TOP. Use the checkbox column or press All.")
            return

        if top_obj.get("saved_db_id"):
            messagebox.showinfo("Info", "This TOP set is already saved as:\n" + str(top_obj["saved_db_id"]))
            return

        meta = top_obj["meta"]
        run_id = str(meta.get("run_id") or "")
        mode = str(meta.get("mode") or "")
        tf = str(meta.get("timeframe") or "")
        top_n = safe_int(meta.get("top_n"), 0)
        load_n = safe_int(meta.get("load_n"), 0)

        f = meta.get("filters") or {}
        filters_str = filters_to_jsonlike(
            exclude_stable=bool(safe_int(f.get("exclude_stable", 1), 1)),
            min_vol24=(str(f.get("min_vol24", "")).strip() or "null"),
            min_mcap=(str(f.get("min_mcap", "")).strip() or "null"),
            max_abs_chg24=(str(f.get("max_abs_chg24", "")).strip() or "null"),
        )

        saved_id = make_saved_top_set_id()

        try:
            con = db_connect()
            try:
                ensure_top_tables(con)
                con.execute("BEGIN;")
                con.execute(
                    """
                    INSERT INTO top_sets (top_set_id, created_utc, source_run_id, vs_currency, load_n, filters_json, timeframe, mode, top_n, notes)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        saved_id,
                        utc_now_iso(),
                        run_id,
                        (self.current_run.get("vs_currency") or ""),
                        int(load_n),
                        filters_str,
                        tf,
                        mode,
                        int(top_n),
                        "",
                    ),
                )

                # re-rank selected only
                rank_in_top = 0
                for it in selected_items:
                    rank_in_top += 1
                    con.execute(
                        """
                        INSERT INTO top_set_items
                        (top_set_id, rank_in_top, unified_symbol, pair, price, change_24h_pct, volume_24h, market_cap, cg_rank, spot_score, top_score)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            saved_id,
                            int(rank_in_top),
                            str((it.get("symbol") or "")).upper().strip(),
                            it.get("pair"),
                            safe_float(it.get("price"), None),
                            safe_float(it.get("chg24"), None),
                            safe_float(it.get("vol24"), None),
                            safe_float(it.get("mcap"), None),
                            safe_int(it.get("rank"), None) if it.get("rank") is not None else None,
                            safe_int(it.get("score"), None) if it.get("score") is not None else None,
                            safe_float(it.get("top_score"), None),
                        ),
                    )

                con.commit()
            except Exception:
                con.rollback()
                raise
            finally:
                con.close()

            top_obj["saved_db_id"] = saved_id
            self.set_status("Saved to DB: " + saved_id)
            messagebox.showinfo("OK", "Saved selected candidates to DB:\n" + saved_id)

        except Exception as e:
            messagebox.showerror("Error", str(e)[:800])
            self.set_status("Error saving to DB")

    def analyse_top(self):
        mem_id = (self.top_sets_var.get() or "").strip()
        if not mem_id or mem_id not in self.top_library:
            messagebox.showerror("Error", "No TOP set selected.")
            return

        saved_id = self.top_library[mem_id].get("saved_db_id")
        if not saved_id:
            messagebox.showerror("Error", "Please save TOP to DB first (To DB).")
            return

        selected_items = self._selected_top_items(mem_id)
        if not selected_items:
            messagebox.showerror("Error", "No selected candidates in TOP.")
            return

        selected_symbols = [str((x.get("symbol") or "")).upper().strip() for x in selected_items if (x.get("symbol") or "").strip()]
        selected_symbols = [s for s in selected_symbols if s]

        layer_keys = [x.get("key") for x in LAYERS]

        win = AnalyseWindow(self, top_set_id=saved_id, selected_symbols=selected_symbols, layer_keys_ordered=layer_keys)
        win.grab_set()


if __name__ == "__main__":
    ascii_guard()

    if not os.path.isdir(PROJECT_ROOT):
        messagebox.showerror("Error", "Project root not found:\n" + PROJECT_ROOT)
        raise SystemExit(1)

    app = App()
    app.mainloop()

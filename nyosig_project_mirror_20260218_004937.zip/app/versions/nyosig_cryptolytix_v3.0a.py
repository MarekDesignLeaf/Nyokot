#!/usr/bin/env python3
# nyosig_cryptolytix_v3.0a
# First functional pipeline up to candidate group selection (TopNow) and DB persistence.
# Project root is fixed to Android path as required.

import os
import sys
import json
import time
import sqlite3
import hashlib
import urllib.parse
import urllib.request
from pathlib import Path

PROJECT_ROOT = "/storage/emulated/0/NyoSig/NyoSig_Cryptolytix"
DEFAULTS_YAML = os.path.join(PROJECT_ROOT, "config", "defaults.yaml")
SECRETS_ENV = os.path.join(PROJECT_ROOT, "config", "secrets.env")
DB_PATH_DEFAULT = os.path.join(PROJECT_ROOT, "db", "nyosig_cryptolytix.db")
CACHE_DIR_DEFAULT = os.path.join(PROJECT_ROOT, "cache")
LOG_DIR_RUNS = os.path.join(PROJECT_ROOT, "logs", "runs")
SAMPLES_DIR = os.path.join(PROJECT_ROOT, "samples", "raw_snapshots")

APP_VERSION = "v3.0a"
SOURCE = "coingecko"
COINGECKO_BASE_URL = "https://api.coingecko.com/api/v3"

def utc_now_iso():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

def utc_stamp_compact():
    return time.strftime("%Y%m%d_%H%M%S", time.gmtime())

def ensure_dir(p):
    os.makedirs(p, exist_ok=True)

def read_text(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def parse_secrets_env(path):
    secrets = {}
    if not os.path.isfile(path):
        return secrets
    for line in read_text(path).splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        k, v = line.split("=", 1)
        secrets[k.strip()] = v.strip()
    return secrets

def parse_simple_yaml(path):
    # Minimal YAML reader for the known defaults.yaml structure.
    # Supports nested dicts and simple lists like [a, b].
    if not os.path.isfile(path):
        return {}
    data = {}
    stack = [(0, data)]
    for raw_line in read_text(path).splitlines():
        line = raw_line.rstrip("\n")
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        indent = len(line) - len(line.lstrip(" "))
        keyval = line.strip()
        if ":" not in keyval:
            continue
        key, val = keyval.split(":", 1)
        key = key.strip()
        val = val.strip()
        while stack and indent < stack[-1][0]:
            stack.pop()
        cur = stack[-1][1] if stack else data
        if val == "":
            cur[key] = {}
            stack.append((indent + 2, cur[key]))
            continue
        if val.startswith("[") and val.endswith("]"):
            inner = val[1:-1].strip()
            if not inner:
                cur[key] = []
            else:
                cur[key] = [x.strip() for x in inner.split(",")]
            continue
        if val.lower() in ("true", "false"):
            cur[key] = (val.lower() == "true")
            continue
        try:
            if "." in val:
                cur[key] = float(val)
            else:
                cur[key] = int(val)
            continue
        except Exception:
            pass
        cur[key] = val
    return data

def log_line(log_fp, msg):
    s = f"{utc_now_iso()} {msg}\n"
    log_fp.write(s)
    log_fp.flush()

def db_connect(db_path):
    con = sqlite3.connect(db_path)
    con.execute("PRAGMA foreign_keys = ON;")
    return con

def db_table_exists(con, name):
    cur = con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?;", (name,))
    return cur.fetchone() is not None

def state_log(con, run_id, from_status, to_status, severity, message):
    con.execute(
        "INSERT INTO state_log(run_id, from_status, to_status, severity, message, timestamp_utc) VALUES (?,?,?,?,?,?);",
        (run_id, from_status, to_status, severity, message, utc_now_iso()),
    )

def set_run_status(con, run_id, status):
    con.execute("UPDATE runs SET status=? WHERE run_id=?;", (status, run_id))

def create_run(con, vs_currency, coins_limit, timeframes, sort_mode, source, params):
    created = utc_now_iso()
    con.execute(
        "INSERT INTO runs(created_utc, app_version, status, vs_currency, coins_limit, timeframes_json, sort_mode, source, params_json) VALUES (?,?,?,?,?,?,?,?,?);",
        (created, APP_VERSION, "created", vs_currency, coins_limit, json.dumps(timeframes), sort_mode, source, json.dumps(params)),
    )
    run_id = con.execute("SELECT last_insert_rowid();").fetchone()[0]
    return run_id

def upsert_run_scope(con, run_id, scope_text):
    con.execute("INSERT OR REPLACE INTO run_scope(run_id, scope) VALUES (?,?);", (run_id, scope_text))

def cache_key(payload_dict):
    raw = json.dumps(payload_dict, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()

def cache_path(cache_dir, key):
    return os.path.join(cache_dir, f"{key}.json")

def load_cache_if_fresh(path, ttl_s):
    if not os.path.isfile(path):
        return None
    age = time.time() - os.path.getmtime(path)
    if age > ttl_s:
        return None
    try:
        return json.loads(read_text(path))
    except Exception:
        return None

def save_cache(path, obj):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f)

def http_get_json(url, headers, timeout_s):
    req = urllib.request.Request(url, headers=headers, method="GET")
    with urllib.request.urlopen(req, timeout=timeout_s) as resp:
        b = resp.read()
        return json.loads(b.decode("utf-8"))

def fetch_coingecko_markets(vs_currency, order, per_page, page, price_change_percentage):
    q = {
        "vs_currency": vs_currency,
        "order": order,
        "per_page": str(per_page),
        "page": str(page),
        "sparkline": "false",
        "price_change_percentage": price_change_percentage,
    }
    url = COINGECKO_BASE_URL + "/coins/markets?" + urllib.parse.urlencode(q)
    return url, q

def retry_fetch(url, headers, connect_timeout_s, read_timeout_s, max_attempts, backoff_s, on_429_sleep_s, log_fp):
    last_err = None
    for attempt in range(1, max_attempts + 1):
        try:
            log_line(log_fp, f"FETCH attempt={attempt} url={url}")
            return http_get_json(url, headers=headers, timeout_s=connect_timeout_s + read_timeout_s)
        except Exception as e:
            last_err = e
            msg = str(e)
            if "HTTP Error 429" in msg:
                log_line(log_fp, f"RATE_LIMIT 429 sleep_s={on_429_sleep_s}")
                time.sleep(on_429_sleep_s)
            else:
                sleep_s = backoff_s[min(attempt - 1, len(backoff_s) - 1)]
                log_line(log_fp, f"RETRY sleep_s={sleep_s} err={msg}")
                time.sleep(sleep_s)
    raise last_err

def load_offline_sample():
    sample_path = os.path.join(SAMPLES_DIR, "coingecko_markets_sample_v1.0a.json")
    if not os.path.isfile(sample_path):
        raise FileNotFoundError("Offline sample not found: " + sample_path)
    return json.loads(read_text(sample_path))

def normalise_markets_to_snapshot_rows(markets, run_id, snapshot_id, scope_text, timeframe, timestamp_utc):
    rows = []
    for it in markets:
        sym = (it.get("symbol") or "").strip()
        if not sym:
            continue
        unified_symbol = sym.upper()
        row = (
            snapshot_id,
            run_id,
            timestamp_utc,
            scope_text,
            timeframe,
            unified_symbol,
            None,
            it.get("current_price"),
            it.get("price_change_percentage_24h"),
            it.get("total_volume"),
            it.get("market_cap"),
            it.get("market_cap_rank"),
            None,
            SOURCE,
        )
        rows.append(row)
    return rows

def insert_market_snapshots(con, rows):
    con.executemany(
        "INSERT OR IGNORE INTO market_snapshots(snapshot_id, run_id, timestamp_utc, scope, timeframe, unified_symbol, pair, price, change_24h_pct, vol24, mcap, rank, base_score, source) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?);",
        rows,
    )

def select_candidates(con, snapshot_id, timeframe, limit_n, filters):
    # filters keys: min_vol24, min_mcap, max_rank, max_abs_chg24, include_symbols, exclude_symbols
    where = ["snapshot_id=? AND timeframe=?"]
    args = [snapshot_id, timeframe]

    if filters.get("min_vol24") is not None:
        where.append("vol24 IS NOT NULL AND vol24>=?")
        args.append(float(filters["min_vol24"]))
    if filters.get("min_mcap") is not None:
        where.append("mcap IS NOT NULL AND mcap>=?")
        args.append(float(filters["min_mcap"]))
    if filters.get("max_rank") is not None:
        where.append("rank IS NOT NULL AND rank<=?")
        args.append(int(filters["max_rank"]))
    if filters.get("max_abs_chg24") is not None:
        where.append("change_24h_pct IS NOT NULL AND ABS(change_24h_pct)<=?")
        args.append(float(filters["max_abs_chg24"]))

    include_symbols = filters.get("include_symbols")
    if include_symbols:
        placeholders = ",".join(["?"] * len(include_symbols))
        where.append(f"unified_symbol IN ({placeholders})")
        args.extend(include_symbols)

    exclude_symbols = filters.get("exclude_symbols")
    if exclude_symbols:
        placeholders = ",".join(["?"] * len(exclude_symbols))
        where.append(f"unified_symbol NOT IN ({placeholders})")
        args.extend(exclude_symbols)

    sql = (
        "SELECT unified_symbol, rank, mcap, vol24, change_24h_pct "
        "FROM market_snapshots WHERE " + " AND ".join(where) +
        " ORDER BY CASE WHEN rank IS NULL THEN 1 ELSE 0 END, rank ASC, CASE WHEN mcap IS NULL THEN 1 ELSE 0 END, mcap DESC "
        " LIMIT ?"
    )
    args.append(int(limit_n))
    cur = con.execute(sql, tuple(args))
    return cur.fetchall()

def create_topnow_selection(con, run_id, snapshot_id, params_json):
    con.execute(
        "INSERT INTO topnow_selection(run_id, snapshot_id, params_json) VALUES (?,?,?);",
        (run_id, snapshot_id, json.dumps(params_json, sort_keys=True)),
    )
    return con.execute("SELECT last_insert_rowid();").fetchone()[0]

def insert_topnow_items(con, selection_id, items):
    con.executemany(
        "INSERT OR REPLACE INTO topnow_selection_items(selection_id, unified_symbol, rank_in_selection, composite_preview) VALUES (?,?,?,?);",
        items,
    )

def require_schema(con):
    required = [
        "runs",
        "run_scope",
        "raw_snapshots",
        "market_snapshots",
        "topnow_selection",
        "topnow_selection_items",
        "state_log",
    ]
    missing = [t for t in required if not db_table_exists(con, t)]
    if missing:
        raise RuntimeError("Missing required tables: " + ", ".join(missing))

def main():
    ensure_dir(LOG_DIR_RUNS)
    ensure_dir(CACHE_DIR_DEFAULT)

    cfg = parse_simple_yaml(DEFAULTS_YAML)
    secrets = parse_secrets_env(SECRETS_ENV)

    db_path = cfg.get("paths", {}).get("db_path", DB_PATH_DEFAULT)
    cache_dir = cfg.get("paths", {}).get("cache_path", CACHE_DIR_DEFAULT)

    mvp = cfg.get("mvp", {})
    vs_currency = str(mvp.get("vs_currency", "usd")).lower()
    coins_limit = int(mvp.get("coins_limit", 250))
    order = str(mvp.get("order", "market_cap_desc"))
    offline_mode = bool(mvp.get("offline_mode", False))
    timeframes = mvp.get("timeframes", ["15m", "1h"])

    # Scope selection
    scope_text = os.environ.get("NYOSIG_SCOPE", "").strip()
    if len(sys.argv) > 1 and sys.argv[1].strip():
        scope_text = sys.argv[1].strip()
    if not scope_text:
        # MVP default
        scope_text = "crypto_spot"

    topnow_limit = int(os.environ.get("NYOSIG_TOPNOW_LIMIT", "100"))

    # Optional filters from env
    def env_float(name):
        v = os.environ.get(name, "").strip()
        return float(v) if v else None
    def env_int(name):
        v = os.environ.get(name, "").strip()
        return int(v) if v else None

    filters = {
        "min_vol24": env_float("NYOSIG_MIN_VOL24"),
        "min_mcap": env_float("NYOSIG_MIN_MCAP"),
        "max_rank": env_int("NYOSIG_MAX_RANK"),
        "max_abs_chg24": env_float("NYOSIG_MAX_ABS_CHG24"),
        "include_symbols": None,
        "exclude_symbols": None,
    }

    # Optional stablecoin exclusion list file
    stable_list_path = os.path.join(PROJECT_ROOT, "config", "exclude_symbols.txt")
    if os.path.isfile(stable_list_path):
        syms = []
        for line in read_text(stable_list_path).splitlines():
            s = line.strip().upper()
            if s and not s.startswith("#"):
                syms.append(s)
        if syms:
            filters["exclude_symbols"] = syms

    log_path = os.path.join(LOG_DIR_RUNS, f"run_{utc_stamp_compact()}_{APP_VERSION}.log")
    with open(log_path, "w", encoding="utf-8") as log_fp:
        log_line(log_fp, "START")
        log_line(log_fp, f"PROJECT_ROOT {PROJECT_ROOT}")
        log_line(log_fp, f"DB {db_path}")
        log_line(log_fp, f"SCOPE {scope_text}")
        log_line(log_fp, f"OFFLINE {int(offline_mode)}")
        log_line(log_fp, f"TOPNOW_LIMIT {topnow_limit}")

        con = db_connect(db_path)
        try:
            require_schema(con)
            con.execute("BEGIN;")

            params = {
                "scope": scope_text,
                "offline_mode": offline_mode,
                "order": order,
                "filters": filters,
                "topnow_limit": topnow_limit,
            }
            run_id = create_run(con, vs_currency, coins_limit, timeframes, "by_mcap_rank", SOURCE, params)
            state_log(con, run_id, "", "created", "info", "run created")
            set_run_status(con, run_id, "created")

            upsert_run_scope(con, run_id, scope_text)
            state_log(con, run_id, "created", "scope_selected", "info", "scope stored")
            set_run_status(con, run_id, "scope_selected")

            state_log(con, run_id, "scope_selected", "sources_ready", "info", "source ready coingecko")
            set_run_status(con, run_id, "sources_ready")

            # Fetch or load offline
            state_log(con, run_id, "sources_ready", "data_collecting", "info", "starting data collection")
            set_run_status(con, run_id, "data_collecting")

            fetched_utc = utc_now_iso()
            endpoint = "/coins/markets"
            query = {
                "vs_currency": vs_currency,
                "order": order,
                "coins_limit": coins_limit,
                "price_change_percentage": "24h",
            }

            if offline_mode:
                markets = load_offline_sample()
                response_json = json.dumps(markets)
                con.execute(
                    "INSERT INTO raw_snapshots(run_id, source, endpoint, query_json, response_json, fetched_utc) VALUES (?,?,?,?,?,?);",
                    (run_id, SOURCE, endpoint, json.dumps(query, sort_keys=True), response_json, fetched_utc),
                )
                state_log(con, run_id, "data_collecting", "data_collected", "warning", "offline mode used sample raw payload")
                set_run_status(con, run_id, "data_collected")
            else:
                ensure_dir(cache_dir)
                connect_timeout_s = int(cfg.get("network", {}).get("connect_timeout_s", 10))
                read_timeout_s = int(cfg.get("network", {}).get("read_timeout_s", 30))
                max_attempts = int(cfg.get("retry", {}).get("max_attempts", 4))
                backoff_s = cfg.get("retry", {}).get("backoff_s", [1, 2, 4, 8])
                on_429_sleep_s = int(cfg.get("rate_limit", {}).get("on_429_sleep_s", 20))
                ttl_s = int(cfg.get("cache", {}).get("ttl_s", 120))

                per_page = 250
                pages = (coins_limit + per_page - 1) // per_page
                all_markets = []
                headers = {"Accept": "application/json"}
                api_key = secrets.get("COINGECKO_API_KEY", "").strip()
                if api_key:
                    headers["x-cg-pro-api-key"] = api_key

                for page in range(1, pages + 1):
                    url, q = fetch_coingecko_markets(vs_currency, order, per_page, page, "24h")
                    ck = cache_key({"source": SOURCE, "endpoint": endpoint, **q})
                    cp = cache_path(cache_dir, ck)
                    cached = load_cache_if_fresh(cp, ttl_s)
                    if cached is not None:
                        log_line(log_fp, f"CACHE_HIT page={page}")
                        markets_page = cached
                    else:
                        markets_page = retry_fetch(url, headers, connect_timeout_s, read_timeout_s, max_attempts, backoff_s, on_429_sleep_s, log_fp)
                        save_cache(cp, markets_page)
                        log_line(log_fp, f"CACHE_SAVE page={page}")
                    if isinstance(markets_page, list):
                        all_markets.extend(markets_page)
                    else:
                        raise RuntimeError("Unexpected response type from CoinGecko")

                    # Stop if enough
                    if len(all_markets) >= coins_limit:
                        break

                markets = all_markets[:coins_limit]
                con.execute(
                    "INSERT INTO raw_snapshots(run_id, source, endpoint, query_json, response_json, fetched_utc) VALUES (?,?,?,?,?,?);",
                    (run_id, SOURCE, endpoint, json.dumps(query, sort_keys=True), json.dumps(markets), fetched_utc),
                )
                state_log(con, run_id, "data_collecting", "data_collected", "info", f"fetched markets count={len(markets)}")
                set_run_status(con, run_id, "data_collected")

            state_log(con, run_id, "data_collected", "raw_saved", "info", "raw snapshot stored")
            set_run_status(con, run_id, "raw_saved")

            # Normalise to snapshot rows
            snapshot_id = f"SN_{run_id}"
            timeframe = "spot"
            timestamp_utc = fetched_utc
            rows = normalise_markets_to_snapshot_rows(markets, run_id, snapshot_id, scope_text, timeframe, timestamp_utc)
            insert_market_snapshots(con, rows)
            state_log(con, run_id, "raw_saved", "normalized", "info", f"normalized snapshot rows={len(rows)}")
            set_run_status(con, run_id, "normalized")

            # Build TopNow candidates
            state_log(con, run_id, "normalized", "topnow_built", "info", "building topnow candidates")
            set_run_status(con, run_id, "topnow_built")

            candidates = select_candidates(con, snapshot_id, timeframe, topnow_limit, filters)
            sel_params = {
                "limit": topnow_limit,
                "filters": filters,
                "order": "rank_asc_mcap_desc",
            }
            selection_id = create_topnow_selection(con, run_id, snapshot_id, sel_params)

            items = []
            for i, row in enumerate(candidates, start=1):
                sym = row[0]
                items.append((selection_id, sym, i, None))
            insert_topnow_items(con, selection_id, items)

            state_log(con, run_id, "topnow_built", "analysis_ready", "info", f"topnow selection_id={selection_id} items={len(items)}")
            set_run_status(con, run_id, "analysis_ready")

            state_log(con, run_id, "analysis_ready", "completed", "info", "mvp phase completed up to candidates")
            set_run_status(con, run_id, "completed")

            con.commit()

            log_line(log_fp, f"RUN_ID {run_id}")
            log_line(log_fp, f"SNAPSHOT_ID {snapshot_id}")
            log_line(log_fp, f"SELECTION_ID {selection_id}")
            log_line(log_fp, f"CANDIDATES {len(items)}")
            log_line(log_fp, "DONE OK")
            print("OK")
            print("run_id", run_id)
            print("snapshot_id", snapshot_id)
            print("selection_id", selection_id)
            print("candidates", len(items))
            print("log", log_path)
            return 0
        except Exception as e:
            try:
                con.rollback()
            except Exception:
                pass
            log_line(log_fp, "FAILED " + str(e))
            print("FAILED")
            print(str(e))
            return 1
        finally:
            con.close()

if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
# Analyza_trhu_v1.1a
# GUI pro CoinGecko SPOT DB, TOP mode, filtry, export TOP
# Bez diakritiky v UI

import json
import math
import os
import shutil
import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime

PROJECT_ROOT = "/storage/emulated/0/NyoSig/NyoSig_Cryptolytix"
DB_PATH = os.path.join(PROJECT_ROOT, "db", "nyosig_cryptolytix.db")
EXPORT_DIR = os.path.join(PROJECT_ROOT, "exports")

FONT_DEFAULT = 4
FONT_MIN = 4
FONT_MAX = 30

TIMEFRAMES = ["1m", "5m", "15m", "30m", "1h", "4h", "1d", "1w"]

TOP_MODES = ["Conservative", "Balanced", "Aggressive"]

STABLE_BASE = {
    "USDT", "USDC", "DAI", "TUSD", "FDUSD", "USDP", "BUSD", "EURC", "USDE", "USD1",
    "PYUSD", "USDS", "FRAX", "LUSD", "GUSD", "SUSDS", "SDAI"
}


def ensure_dirs():
    os.makedirs(EXPORT_DIR, exist_ok=True)


def now_tag():
    return datetime.utcnow().strftime("%Y%m%d_%H%M%S")


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def safe_float(x, default=None):
    try:
        if x is None:
            return default
        return float(x)
    except Exception:
        return default


def fmt_price(x):
    if x is None:
        return ""
    try:
        v = float(x)
    except Exception:
        return ""
    if abs(v) >= 1:
        return f"{v:,.4f}"
    return f"{v:.8f}"


def fmt_num(x):
    if x is None:
        return ""
    try:
        v = float(x)
    except Exception:
        return ""
    return f"{v:,.0f}"


def fmt_pct(x):
    if x is None:
        return ""
    try:
        v = float(x)
    except Exception:
        return ""
    return f"{v:.2f}"


def db_connect():
    if not os.path.exists(DB_PATH):
        raise RuntimeError("DB not found: " + DB_PATH)
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def get_latest_run_id(con):
    row = con.execute(
        "SELECT run_id, created_at, status FROM runs ORDER BY created_at DESC LIMIT 1"
    ).fetchone()
    return row


def fetch_spot_rows(con, run_id, limit_n):
    rows = con.execute(
        """
        SELECT
            m.unified_symbol,
            m.pair,
            m.price,
            m.volume_24h,
            m.market_cap,
            m.rank,
            m.chg_24h_pct,
            f.score AS spot_score
        FROM spot_markets m
        LEFT JOIN spot_features f
          ON f.run_id = m.run_id AND f.unified_symbol = m.unified_symbol
        WHERE m.run_id = ?
        ORDER BY m.rank ASC
        LIMIT ?
        """,
        (run_id, int(limit_n)),
    ).fetchall()
    return list(rows)


def fetch_ohlcv_closes(con, run_id, symbol, timeframe, limit_n=120):
    rows = con.execute(
        """
        SELECT close
        FROM ohlcv
        WHERE run_id = ? AND symbol = ? AND timeframe = ?
        ORDER BY timestamp DESC
        LIMIT ?
        """,
        (run_id, symbol, timeframe, int(limit_n)),
    ).fetchall()
    closes = []
    for r in rows:
        c = safe_float(r["close"], None)
        if c is not None:
            closes.append(c)
    closes.reverse()
    return closes


def calc_trend_score_from_closes(closes):
    if not closes or len(closes) < 20:
        return None

    n = len(closes)
    x = list(range(n))
    y = closes

    sx = sum(x)
    sy = sum(y)
    sxx = sum(v * v for v in x)
    sxy = sum(x[i] * y[i] for i in range(n))
    denom = (n * sxx - sx * sx)
    if denom == 0:
        return None

    slope = (n * sxy - sx * sy) / denom
    price = y[-1] if y[-1] != 0 else 1.0
    rel = slope / price

    raw = rel * 5000.0
    score = 50.0 + raw
    return int(round(clamp(score, 0.0, 100.0)))


def calc_vol_score_from_closes(closes):
    if not closes or len(closes) < 20:
        return None

    rets = []
    for i in range(1, len(closes)):
        p0 = closes[i - 1]
        p1 = closes[i]
        if p0 and p0 > 0:
            rets.append((p1 - p0) / p0)

    if len(rets) < 10:
        return None

    mean = sum(rets) / len(rets)
    var = sum((r - mean) ** 2 for r in rets) / max(1, (len(rets) - 1))
    vol = math.sqrt(var)

    target_lo = 0.002
    target_hi = 0.02

    if vol <= target_lo:
        score = (vol / target_lo) * 40.0
    elif vol <= target_hi:
        score = 40.0 + ((vol - target_lo) / (target_hi - target_lo)) * 60.0
    else:
        score = 100.0 - min(70.0, ((vol - target_hi) / target_hi) * 70.0)

    return int(round(clamp(score, 0.0, 100.0)))


def normalize_0_100(values, fallback_mid=50):
    vals = [v for v in values if v is not None]
    if not vals:
        return [fallback_mid if v is not None else None for v in values]
    mn = min(vals)
    mx = max(vals)
    if mx == mn:
        return [fallback_mid if v is not None else None for v in values]
    out = []
    for v in values:
        if v is None:
            out.append(None)
        else:
            out.append(int(round(((v - mn) / (mx - mn)) * 100.0)))
    return out


def calc_liquidity_components(rows):
    vol_logs = []
    ratios = []
    for r in rows:
        vol = safe_float(r.get("volume_24h"), None)
        mcap = safe_float(r.get("market_cap"), None)
        if vol is None or vol <= 0:
            vol_logs.append(None)
        else:
            vol_logs.append(math.log10(vol))
        if vol is None or mcap is None or mcap <= 0:
            ratios.append(None)
        else:
            ratios.append(vol / mcap)
    vol_scores = normalize_0_100(vol_logs, fallback_mid=50)
    ratio_scores = normalize_0_100(ratios, fallback_mid=50)
    liq = []
    for i in range(len(rows)):
        if vol_scores[i] is None and ratio_scores[i] is None:
            liq.append(None)
        else:
            a = vol_scores[i] if vol_scores[i] is not None else 50
            b = ratio_scores[i] if ratio_scores[i] is not None else 50
            liq.append(int(round(0.6 * a + 0.4 * b)))
    return liq


def weights_for_mode(mode):
    if mode == "Conservative":
        return (0.55, 0.35, 0.10)
    if mode == "Aggressive":
        return (0.35, 0.25, 0.40)
    return (0.45, 0.30, 0.25)


class App(tk.Tk):
    def __init__(self):
        super().__init__()

        ensure_dirs()

        self.title("Analyza_trhu_v1.1a")
        self.geometry("1100x760")

        self.sort_col = "rank"
        self.sort_desc = False

        self.font_var = tk.IntVar(value=FONT_DEFAULT)
        self.load_n_var = tk.IntVar(value=300)
        self.top_x_var = tk.IntVar(value=50)
        self.tf_var = tk.StringVar(value="4h")
        self.mode_var = tk.StringVar(value="Balanced")

        self.filter_ex_stable = tk.BooleanVar(value=True)
        self.filter_require_ohlcv = tk.BooleanVar(value=False)

        self.min_mcap_var = tk.StringVar(value="0")
        self.min_vol_var = tk.StringVar(value="0")
        self.max_move_var = tk.StringVar(value="0")

        self.run_id = None
        self.run_meta = None

        self.rows_raw = []
        self.rows_calc = []
        self.rows_view = []

        self._apply_style(FONT_DEFAULT)
        self._build_ui()
        self.refresh()

    def _apply_style(self, fs):
        style = ttk.Style(self)
        try:
            style.theme_use("default")
        except Exception:
            pass
        style.configure("Treeview", font=("TkDefaultFont", int(fs)))
        style.configure("Treeview.Heading", font=("TkDefaultFont", int(fs)))
        style.configure("TLabel", font=("TkDefaultFont", int(fs)))
        style.configure("TButton", font=("TkDefaultFont", int(fs)))

    def apply_font(self):
        try:
            fs = int(self.font_var.get())
        except Exception:
            fs = FONT_DEFAULT
        fs = clamp(fs, FONT_MIN, FONT_MAX)
        self.font_var.set(fs)
        self._apply_style(fs)
        try:
            self.detail.configure(font=("TkDefaultFont", fs))
        except Exception:
            pass

    def _build_ui(self):
        top = ttk.Frame(self, padding=10)
        top.pack(fill=tk.X)

        ttk.Button(top, text="Refresh", command=self.refresh).pack(side=tk.LEFT)

        ttk.Label(top, text="Load").pack(side=tk.LEFT, padx=(12, 0))
        ttk.Entry(top, textvariable=self.load_n_var, width=6).pack(side=tk.LEFT, padx=(6, 0))

        ttk.Label(top, text="Top").pack(side=tk.LEFT, padx=(12, 0))
        ttk.Entry(top, textvariable=self.top_x_var, width=6).pack(side=tk.LEFT, padx=(6, 0))

        ttk.Label(top, text="Mode").pack(side=tk.LEFT, padx=(12, 0))
        ttk.Combobox(top, textvariable=self.mode_var, values=TOP_MODES, state="readonly", width=12).pack(
            side=tk.LEFT, padx=(6, 0)
        )

        ttk.Label(top, text="TF").pack(side=tk.LEFT, padx=(12, 0))
        ttk.Combobox(top, textvariable=self.tf_var, values=TIMEFRAMES, state="readonly", width=6).pack(
            side=tk.LEFT, padx=(6, 0)
        )

        ttk.Label(top, text="Font").pack(side=tk.LEFT, padx=(12, 0))
        ttk.Spinbox(top, from_=FONT_MIN, to=FONT_MAX, textvariable=self.font_var, width=4).pack(side=tk.LEFT, padx=(6, 0))
        ttk.Button(top, text="Apply", command=self.apply_font).pack(side=tk.LEFT, padx=(6, 0))

        ttk.Button(top, text="Recalc TOP", command=self.recalc_top).pack(side=tk.LEFT, padx=(12, 0))

        ttk.Button(top, text="Export TOP", command=self.export_top).pack(side=tk.RIGHT)
        ttk.Button(top, text="Export DB", command=self.export_db).pack(side=tk.RIGHT, padx=(0, 10))

        info = ttk.Frame(self, padding=(10, 0, 10, 10))
        info.pack(fill=tk.X)

        self.info_var = tk.StringVar(value="DB: " + DB_PATH)
        ttk.Label(info, textvariable=self.info_var).pack(anchor="w")

        filt = ttk.Frame(self, padding=(10, 0, 10, 10))
        filt.pack(fill=tk.X)

        ttk.Checkbutton(filt, text="Exclude stable", variable=self.filter_ex_stable, command=self.recalc_top).pack(
            side=tk.LEFT
        )
        ttk.Checkbutton(filt, text="Require OHLCV", variable=self.filter_require_ohlcv, command=self.recalc_top).pack(
            side=tk.LEFT, padx=(10, 0)
        )

        ttk.Label(filt, text="Min mcap").pack(side=tk.LEFT, padx=(12, 0))
        ttk.Entry(filt, textvariable=self.min_mcap_var, width=10).pack(side=tk.LEFT, padx=(6, 0))

        ttk.Label(filt, text="Min vol24").pack(side=tk.LEFT, padx=(12, 0))
        ttk.Entry(filt, textvariable=self.min_vol_var, width=10).pack(side=tk.LEFT, padx=(6, 0))

        ttk.Label(filt, text="Max 24h move pct").pack(side=tk.LEFT, padx=(12, 0))
        ttk.Entry(filt, textvariable=self.max_move_var, width=8).pack(side=tk.LEFT, padx=(6, 0))

        main = ttk.Frame(self, padding=(10, 0, 10, 10))
        main.pack(fill=tk.BOTH, expand=True)

        table_frame = ttk.Frame(main)
        table_frame.pack(fill=tk.BOTH, expand=True)

        cols = (
            "symbol", "pair", "rank", "spot_score", "price", "chg24",
            "vol24", "mcap", "liq", "trend", "vol", "top"
        )
        self.tree = ttk.Treeview(table_frame, columns=cols, show="headings")

        vsb = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(table_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")

        table_frame.grid_rowconfigure(0, weight=1)
        table_frame.grid_columnconfigure(0, weight=1)

        headings = {
            "symbol": "Symbol",
            "pair": "Pair",
            "rank": "Rank",
            "spot_score": "SpotScore",
            "price": "Price",
            "chg24": "24h%",
            "vol24": "Vol24",
            "mcap": "MCap",
            "liq": "Liq",
            "trend": "Trend",
            "vol": "Vol",
            "top": "TopScore",
        }
        for c in cols:
            self.tree.heading(c, text=headings.get(c, c), command=lambda cc=c: self.on_sort(cc))

        self.tree.column("symbol", width=90, anchor=tk.W, stretch=False)
        self.tree.column("pair", width=140, anchor=tk.W, stretch=True)
        self.tree.column("rank", width=60, anchor=tk.CENTER, stretch=False)
        self.tree.column("spot_score", width=80, anchor=tk.CENTER, stretch=False)
        self.tree.column("price", width=120, anchor=tk.E, stretch=True)
        self.tree.column("chg24", width=70, anchor=tk.E, stretch=False)
        self.tree.column("vol24", width=140, anchor=tk.E, stretch=True)
        self.tree.column("mcap", width=140, anchor=tk.E, stretch=True)
        self.tree.column("liq", width=60, anchor=tk.CENTER, stretch=False)
        self.tree.column("trend", width=60, anchor=tk.CENTER, stretch=False)
        self.tree.column("vol", width=60, anchor=tk.CENTER, stretch=False)
        self.tree.column("top", width=80, anchor=tk.CENTER, stretch=False)

        self.tree.bind("<<TreeviewSelect>>", self.on_select)

        self.status_var = tk.StringVar(value="Ready")
        ttk.Label(main, textvariable=self.status_var).pack(anchor="w", pady=(10, 0))

        self.detail = tk.Text(main, height=7, wrap="word", font=("TkDefaultFont", FONT_DEFAULT))
        self.detail.pack(fill=tk.BOTH, expand=False, pady=(6, 0))
        self.detail.configure(state="disabled")

    def set_detail(self, text):
        self.detail.configure(state="normal")
        self.detail.delete("1.0", tk.END)
        self.detail.insert(tk.END, text)
        self.detail.configure(state="disabled")

    def refresh(self):
        try:
            con = db_connect()
            with con:
                run = get_latest_run_id(con)
                if not run:
                    raise RuntimeError("No runs in DB")
                self.run_meta = dict(run)
                self.run_id = run["run_id"]

                load_n = int(self.load_n_var.get())
                load_n = clamp(load_n, 1, 5000)
                self.load_n_var.set(load_n)

                self.rows_raw = [dict(r) for r in fetch_spot_rows(con, self.run_id, load_n)]

            self.info_var.set(
                "DB: " + DB_PATH
                + "\nrun_id: " + str(self.run_id)
                + " created_at: " + str(self.run_meta.get("created_at"))
                + " status: " + str(self.run_meta.get("status"))
            )
            self.recalc_top()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def parse_filters(self):
        min_mcap = safe_float(self.min_mcap_var.get(), 0.0) or 0.0
        min_vol = safe_float(self.min_vol_var.get(), 0.0) or 0.0
        max_move = safe_float(self.max_move_var.get(), 0.0) or 0.0
        return min_mcap, min_vol, max_move

    def recalc_top(self):
        if not self.run_id:
            return

        tf = (self.tf_var.get() or "4h").strip()
        mode = (self.mode_var.get() or "Balanced").strip()
        w_liq, w_trend, w_vol = weights_for_mode(mode)

        min_mcap, min_vol, max_move = self.parse_filters()
        ex_stable = bool(self.filter_ex_stable.get())
        req_ohlcv = bool(self.filter_require_ohlcv.get())

        base_rows = []
        for r in self.rows_raw:
            sym = (r.get("unified_symbol") or "").upper().strip()
            if not sym:
                continue

            if ex_stable and sym in STABLE_BASE:
                continue

            price = safe_float(r.get("price"), None)
            vol24 = safe_float(r.get("volume_24h"), None)
            mcap = safe_float(r.get("market_cap"), None)
            chg24 = safe_float(r.get("chg_24h_pct"), None)

            if mcap is None or vol24 is None:
                continue
            if mcap < min_mcap:
                continue
            if vol24 < min_vol:
                continue
            if max_move > 0 and chg24 is not None and abs(chg24) > max_move:
                continue

            base_rows.append(dict(r))

        liq_scores = calc_liquidity_components(base_rows)

        trend_scores = []
        vol_scores = []

        con = None
        try:
            con = db_connect()
            for i, r in enumerate(base_rows):
                sym = (r.get("unified_symbol") or "").upper().strip()

                closes = fetch_ohlcv_closes(con, self.run_id, sym, tf, limit_n=160)
                if req_ohlcv and (not closes or len(closes) < 20):
                    trend_scores.append(None)
                    vol_scores.append(None)
                    continue

                tr = calc_trend_score_from_closes(closes)
                vv = calc_vol_score_from_closes(closes)
                trend_scores.append(tr)
                vol_scores.append(vv)
        finally:
            if con is not None:
                con.close()

        rows_calc = []
        for i, r in enumerate(base_rows):
            sym = (r.get("unified_symbol") or "").upper().strip()

            liq = liq_scores[i]
            tr = trend_scores[i]
            vv = vol_scores[i]

            if req_ohlcv and (tr is None or vv is None):
                continue

            a = liq if liq is not None else 50
            b = tr if tr is not None else 50
            c = vv if vv is not None else 50

            top_score = (w_liq * a) + (w_trend * b) + (w_vol * c)

            rr = dict(r)
            rr["liq_score"] = liq
            rr["trend_score"] = tr
            rr["vol_score"] = vv
            rr["top_score"] = int(round(clamp(top_score, 0.0, 100.0)))
            rows_calc.append(rr)

        self.rows_calc = rows_calc

        self.sort_col = "rank"
        self.sort_desc = False
        self.refresh_view()

        self.status_var.set(
            "Loaded " + str(len(self.rows_raw))
            + " filtered " + str(len(self.rows_calc))
            + " mode " + mode + " tf " + tf
        )

        self.set_detail("Select a row to see summary\n")

    def on_sort(self, col):
        if self.sort_col == col:
            self.sort_desc = not self.sort_desc
        else:
            self.sort_col = col
            self.sort_desc = True if col in ("top", "spot_score", "liq", "trend", "vol", "vol24", "mcap", "chg24", "price") else False
        self.refresh_view()

    def refresh_view(self):
        for iid in self.tree.get_children(""):
            self.tree.delete(iid)

        rows = list(self.rows_calc)

        def num(v, default):
            vv = safe_float(v, None)
            return vv if vv is not None else default

        def txt(v):
            return str(v or "").upper()

        col = self.sort_col
        desc = self.sort_desc

        if col == "symbol":
            rows.sort(key=lambda r: txt(r.get("unified_symbol")), reverse=desc)
        elif col == "pair":
            rows.sort(key=lambda r: txt(r.get("pair")), reverse=desc)
        elif col == "rank":
            rows.sort(key=lambda r: num(r.get("rank"), 999999), reverse=desc)
        elif col == "spot_score":
            rows.sort(key=lambda r: num(r.get("spot_score"), -1), reverse=desc)
        elif col == "price":
            rows.sort(key=lambda r: num(r.get("price"), -1), reverse=desc)
        elif col == "chg24":
            rows.sort(key=lambda r: num(r.get("chg_24h_pct"), -999999), reverse=desc)
        elif col == "vol24":
            rows.sort(key=lambda r: num(r.get("volume_24h"), -1), reverse=desc)
        elif col == "mcap":
            rows.sort(key=lambda r: num(r.get("market_cap"), -1), reverse=desc)
        elif col == "liq":
            rows.sort(key=lambda r: num(r.get("liq_score"), -1), reverse=desc)
        elif col == "trend":
            rows.sort(key=lambda r: num(r.get("trend_score"), -1), reverse=desc)
        elif col == "vol":
            rows.sort(key=lambda r: num(r.get("vol_score"), -1), reverse=desc)
        elif col == "top":
            rows.sort(key=lambda r: num(r.get("top_score"), -1), reverse=desc)
        else:
            rows.sort(key=lambda r: num(r.get("rank"), 999999))

        self.rows_view = rows

        for r in rows:
            self.tree.insert(
                "",
                tk.END,
                values=(
                    r.get("unified_symbol") or "",
                    r.get("pair") or "",
                    r.get("rank") if r.get("rank") is not None else "",
                    r.get("spot_score") if r.get("spot_score") is not None else "",
                    fmt_price(r.get("price")),
                    fmt_pct(r.get("chg_24h_pct")),
                    fmt_num(r.get("volume_24h")),
                    fmt_num(r.get("market_cap")),
                    r.get("liq_score") if r.get("liq_score") is not None else "",
                    r.get("trend_score") if r.get("trend_score") is not None else "",
                    r.get("vol_score") if r.get("vol_score") is not None else "",
                    r.get("top_score") if r.get("top_score") is not None else "",
                ),
            )

    def on_select(self, _evt):
        sel = self.tree.selection()
        if not sel:
            return
        vals = self.tree.item(sel[0], "values")
        if not vals:
            return
        sym = str(vals[0])

        r0 = None
        for r in self.rows_view:
            if str(r.get("unified_symbol") or "").upper() == sym.upper():
                r0 = r
                break
        if not r0:
            return

        tf = (self.tf_var.get() or "4h").strip()
        mode = (self.mode_var.get() or "Balanced").strip()

        text = ""
        text += "Symbol: " + sym + "\n"
        text += "Pair: " + str(r0.get("pair") or "") + "\n"
        text += "Rank: " + str(r0.get("rank") or "") + "\n"
        text += "Price: " + fmt_price(r0.get("price")) + "\n"
        text += "24h pct: " + fmt_pct(r0.get("chg_24h_pct")) + "\n"
        text += "Vol24: " + fmt_num(r0.get("volume_24h")) + "\n"
        text += "MCap: " + fmt_num(r0.get("market_cap")) + "\n"
        text += "SpotScore: " + (str(r0.get("spot_score")) if r0.get("spot_score") is not None else "") + "\n"
        text += "TF: " + tf + " Mode: " + mode + "\n"
        text += "Liq: " + (str(r0.get("liq_score")) if r0.get("liq_score") is not None else "n/a") + "\n"
        text += "Trend: " + (str(r0.get("trend_score")) if r0.get("trend_score") is not None else "n/a") + "\n"
        text += "Vol: " + (str(r0.get("vol_score")) if r0.get("vol_score") is not None else "n/a") + "\n"
        text += "TopScore: " + (str(r0.get("top_score")) if r0.get("top_score") is not None else "n/a") + "\n"

        self.set_detail(text)

    def get_top_list(self):
        try:
            top_x = int(self.top_x_var.get())
        except Exception:
            top_x = 50
        top_x = clamp(top_x, 1, 5000)
        self.top_x_var.set(top_x)

        rows = list(self.rows_calc)
        rows.sort(key=lambda r: safe_float(r.get("top_score"), -1), reverse=True)
        return rows[:top_x]

    def export_db(self):
        try:
            ensure_dirs()
            out = os.path.join(EXPORT_DIR, "analyza_trhu_db_export_" + now_tag() + ".db")
            shutil.copy2(DB_PATH, out)
            messagebox.showinfo("OK", "DB exported\n" + out)
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def export_top(self):
        if not self.run_id:
            return
        try:
            ensure_dirs()
            tf = (self.tf_var.get() or "4h").strip()
            mode = (self.mode_var.get() or "Balanced").strip()
            min_mcap, min_vol, max_move = self.parse_filters()

            top_rows = self.get_top_list()

            meta = {
                "app_version": "Analyza_trhu_v1.1a",
                "db_path": DB_PATH,
                "run_id": self.run_id,
                "timeframe": tf,
                "top_mode": mode,
                "filters": {
                    "exclude_stable": bool(self.filter_ex_stable.get()),
                    "require_ohlcv": bool(self.filter_require_ohlcv.get()),
                    "min_market_cap": min_mcap,
                    "min_volume_24h": min_vol,
                    "max_24h_move_pct": max_move,
                },
                "loaded_rows": int(self.load_n_var.get()),
                "filtered_rows": len(self.rows_calc),
                "exported_rows": len(top_rows),
                "exported_at_utc": datetime.utcnow().isoformat(timespec="seconds") + "Z",
            }

            out_csv = os.path.join(EXPORT_DIR, "top_export_" + now_tag() + ".csv")
            out_json = os.path.join(EXPORT_DIR, "top_export_" + now_tag() + ".json")

            header = [
                "symbol", "pair", "rank", "price", "chg_24h_pct", "volume_24h", "market_cap",
                "spot_score", "liq_score", "trend_score", "vol_score", "top_score"
            ]
            with open(out_csv, "w", encoding="utf-8") as f:
                f.write(",".join(header) + "\n")
                for r in top_rows:
                    line = [
                        str(r.get("unified_symbol") or ""),
                        str(r.get("pair") or ""),
                        str(r.get("rank") or ""),
                        str(r.get("price") if r.get("price") is not None else ""),
                        str(r.get("chg_24h_pct") if r.get("chg_24h_pct") is not None else ""),
                        str(r.get("volume_24h") if r.get("volume_24h") is not None else ""),
                        str(r.get("market_cap") if r.get("market_cap") is not None else ""),
                        str(r.get("spot_score") if r.get("spot_score") is not None else ""),
                        str(r.get("liq_score") if r.get("liq_score") is not None else ""),
                        str(r.get("trend_score") if r.get("trend_score") is not None else ""),
                        str(r.get("vol_score") if r.get("vol_score") is not None else ""),
                        str(r.get("top_score") if r.get("top_score") is not None else ""),
                    ]
                    f.write(",".join(line) + "\n")

            payload = {
                "meta": meta,
                "rows": top_rows,
            }
            with open(out_json, "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=True, indent=2)

            messagebox.showinfo("OK", "Exported\n" + out_csv + "\n" + out_json)
        except Exception as e:
            messagebox.showerror("Error", str(e))


def main():
    ensure_dirs()
    app = App()
    app.mainloop()


if __name__ == "__main__":
    main()
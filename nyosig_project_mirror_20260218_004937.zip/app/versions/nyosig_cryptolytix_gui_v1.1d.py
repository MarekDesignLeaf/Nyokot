#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NyoSig Cryptolytix GUI   Final version
This version consolidates and cleans up previous scripts. It loads candidate
coins from a text file, allows adding/removing coins, computes a simple
ranking (based on return over selected timeframes and a risk profile),
shows top results, and exports the top candidates to a CSV file.
"""

import os
import pandas as pd
import PySimpleGUI as sg

# Paths to data files
CANDIDATES_FILE = os.path.join(os.path.dirname(__file__), "kandidati_coins.txt")
DATA_FILE = os.path.join(os.path.dirname(__file__), "ohlcv_features_test_data.csv")

# Ensure candidate file exists
if not os.path.exists(CANDIDATES_FILE):
    with open(CANDIDATES_FILE, "w") as f:
        f.write("")

def load_candidates():
    """Load candidate symbols from the text file."""
    with open(CANDIDATES_FILE, "r") as f:
        coins = [line.strip().upper() for line in f if line.strip()]
    return sorted(set(coins))

def save_candidates(coins):
    """Save candidate symbols back to the text file."""
    with open(CANDIDATES_FILE, "w") as f:
        f.write("\n".join(sorted(set(coins))))

def calculate_ranking(df, risk_profile):
    """Calculate a ranking score based on timeframe and risk profile.
    
    df must contain columns: 'symbol', '1m_change', '5m_change', '15m_change',
    '30m_change', '1h_change', '4h_change', '1d_change', '1w_change'.
    
    risk_profile determines weighting of returns:
    - 'Aggressive' emphasises short term changes.
    - 'Moderate' balances all timeframes.
    - 'Conservative' emphasises long term changes.
    """
    weights = {
        'Aggressive': {'1m_change': 0.4, '5m_change': 0.3, '15m_change': 0.2,
                       '30m_change': 0.1, '1h_change': 0, '4h_change': 0,
                       '1d_change': 0, '1w_change': 0},
        'Moderate':   {'1m_change': 0.15, '5m_change': 0.15, '15m_change': 0.15,
                       '30m_change': 0.15, '1h_change': 0.15, '4h_change': 0.15,
                       '1d_change': 0.1, '1w_change': 0},
        'Conservative':{'1m_change':0, '5m_change':0, '15m_change':0,
                       '30m_change':0, '1h_change':0.2, '4h_change':0.3,
                       '1d_change':0.3, '1w_change':0.2}
    }
    w = weights.get(risk_profile, weights['Moderate'])
    # Compute weighted score
    score = sum(df[tf] * w[tf] for tf in w)
    return score

def load_ohlcv_data(symbols):
    """Load OHLCV feature data for the given symbols from local CSV.
    
    Expects CSV with columns: symbol, 1m_change, 5m_change, 15m_change,
    30m_change, 1h_change, 4h_change, 1d_change, 1w_change.
    """
    if not os.path.exists(DATA_FILE):
        sg.popup_error(f"Data file {DATA_FILE} not found.")
        return pd.DataFrame()
    df = pd.read_csv(DATA_FILE)
    df['symbol'] = df['symbol'].str.upper()
    return df[df['symbol'].isin(symbols)].copy()

def refresh_results(values):
    """Recalculate and return a DataFrame of ranked candidates."""
    symbols = values['-CANDLIST-']
    risk = values['-RISK-']
    amount = values['-AMOUNT-']
    df = load_ohlcv_data(symbols)
    if df.empty:
        return pd.DataFrame()
    df['score'] = calculate_ranking(df, risk)
    df.sort_values(by='score', ascending=False, inplace=True)
    return df.head(amount)

def main():
    candidates = load_candidates()
    risk_options = ['Aggressive', 'Moderate', 'Conservative']

    # GUI layout
    layout = [
        [sg.Text("NyoSig Cryptolytix - Market Analysis Tool", font=("Arial", 14, "bold"))],
        [sg.Text("Add coin:"), sg.Input(key='-NEWCOIN-', size=(10,1)), sg.Button("Add", key='-ADD-')],
        [sg.Listbox(candidates, size=(30,10), key='-CANDLIST-', select_mode=sg.LISTBOX_SELECT_MODE_EXTENDED),
         sg.Column([
             [sg.Button("Remove Selected", key='-REMOVE-')],
             [sg.Button("Save List", key='-SAVE-')]
         ])],
        [sg.Frame("Ranking Options", [
            [sg.Text("Risk profile:"), sg.Combo(risk_options, default_value=risk_options[1], key='-RISK-', readonly=True)],
            [sg.Text("Top N to display:"), sg.Input(default_text="5", size=(5,1), key='-AMOUNT-')],
            [sg.Button("Recalculate Top", key='-RECALC-')]
        ])],
        [sg.Table(values=[], headings=["Symbol","1m","5m","15m","30m","1h","4h","1d","1w","Score"],
                  key='-TABLE-', auto_size_columns=True, num_rows=10, enable_events=True)],
        [sg.Button("Export Top to CSV", key='-EXPORT-'), sg.Button("Exit")]
    ]

    window = sg.Window("NyoSig Cryptolytix GUI", layout, finalize=True)

    # Event loop
    ranked_df = pd.DataFrame()
    while True:
        event, values = window.read()
        if event == sg.WIN_CLOSED or event == 'Exit':
            break

        if event == '-ADD-':
            coin = values['-NEWCOIN-'].strip().upper()
            if coin and coin not in candidates:
                candidates.append(coin)
                window['-CANDLIST-'].update(sorted(candidates))
                window['-NEWCOIN-'].update("")
        elif event == '-REMOVE-':
            selected = values['-CANDLIST-']
            candidates = [c for c in candidates if c not in selected]
            window['-CANDLIST-'].update(candidates)
        elif event == '-SAVE-':
            save_candidates(candidates)
            sg.popup("Candidate list saved.")
        elif event == '-RECALC-':
            try:
                amount = int(values['-AMOUNT-'])
                window['-AMOUNT-'].update(str(amount))
            except ValueError:
                sg.popup_error("Top N must be an integer.")
                continue
            ranked_df = refresh_results(values)
            if not ranked_df.empty:
                table_data = ranked_df[['symbol','1m_change','5m_change','15m_change',
                                        '30m_change','1h_change','4h_change','1d_change',
                                        '1w_change','score']].values.tolist()
                window['-TABLE-'].update(values=table_data)
        elif event == '-EXPORT-':
            if ranked_df.empty:
                sg.popup_error("No results to export. Please recalculate first.")
            else:
                out_path = sg.popup_get_file("Save CSV", save_as=True, default_extension=".csv",
                                             file_types=(("CSV Files","*.csv"),))
                if out_path:
                    ranked_df.to_csv(out_path, index=False)
                    sg.popup(f"Top candidates exported to {out_path}")

    window.close()

if __name__ == "__main__":
    main()
#!/usr/bin/env python3
# nyosig_cryptolytix_gui_v1.2b
# ASCII only, Tkinter, MANUAL workflow
# Fixed project root: /storage/emulated/0/NyoSig/NyoSig_Cryptolytix

import os
import sqlite3
import time
import tkinter as tk
from tkinter import ttk, messagebox

PROJECT_ROOT = "/storage/emulated/0/NyoSig/NyoSig_Cryptolytix"
DB_PATH = os.path.join(PROJECT_ROOT, "db", "nyosig_cryptolytix.db")

TIMEFRAMES = ["1m", "5m", "15m", "30m", "1h", "4h", "1d", "1w"]
MODES = ["conservative", "balanced", "aggressive"]

EXCLUDE_STABLE_BASE = {
    "USDT", "USDC", "DAI", "TUSD", "FDUSD", "USDP", "BUSD", "EURC", "USDE", "USD1"
}

FONT_SIZE_MIN = 4
FONT_SIZE_MAX = 30
FONT_SIZE_DEFAULT = 4


def utc_now_iso():
    # simple UTC-ish string, no timezone dependency
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def safe_int(x, default=0):
    try:
        return int(x)
    except Exception:
        return default


def safe_float(x, default=None):
    try:
        if x is None:
            return default
        return float(x)
    except Exception:
        return default


def fmt_price(v):
    v = safe_float(v, None)
    if v is None:
        return ""
    if abs(v) >= 1:
        return f"{v:,.4f}"
    return f"{v:.8f}"


def fmt_pct(v):
    v = safe_float(v, None)
    if v is None:
        return ""
    return f"{v:.2f}"


def fmt_int(v):
    v = safe_float(v, None)
    if v is None:
        return ""
    try:
        return f"{int(round(v)):,d}"
    except Exception:
        return ""


def db_connect():
    if not os.path.exists(DB_PATH):
        raise RuntimeError("DB not found at: " + DB_PATH)
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON;")
    return con


def ensure_top_tables(con):
    con.execute(
        """
        CREATE TABLE IF NOT EXISTS top_sets (
          top_set_id TEXT PRIMARY KEY,
          created_utc TEXT NOT NULL,
          source_run_id TEXT NOT NULL,
          vs_currency TEXT,
          load_n INTEGER,
          filters_json TEXT,
          timeframe TEXT,
          mode TEXT,
          top_n INTEGER,
          notes TEXT
        );
        """
    )
    con.execute(
        """
        CREATE TABLE IF NOT EXISTS top_set_items (
          top_set_id TEXT NOT NULL,
          rank_in_top INTEGER NOT NULL,
          unified_symbol TEXT NOT NULL,
          pair TEXT,
          price REAL,
          change_24h_pct REAL,
          volume_24h REAL,
          market_cap REAL,
          cg_rank INTEGER,
          spot_score INTEGER,
          top_score REAL,
          PRIMARY KEY (top_set_id, unified_symbol),
          FOREIGN KEY (top_set_id) REFERENCES top_sets(top_set_id) ON DELETE CASCADE
        );
        """
    )
    con.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_top_set_items_rank
        ON top_set_items (top_set_id, rank_in_top);
        """
    )


def make_saved_top_set_id():
    # unique id created only on To DB
    return "TS_" + time.strftime("%Y%m%d_%H%M%S", time.gmtime()) + "_" + str(int(time.time() * 1000) % 1000).zfill(3)


def filters_to_jsonlike(exclude_stable, min_vol24, min_mcap, max_abs_chg24):
    # keep it ASCII and simple; store a JSON-like string
    return (
        "{"
        + f"exclude_stable:{int(bool(exclude_stable))},"
        + f"min_vol24:{min_vol24},"
        + f"min_mcap:{min_mcap},"
        + f"max_abs_chg24:{max_abs_chg24}"
        + "}"
    )


def top_score(mode, row):
    # MANUAL: selection starts by vol24, then mode score ranks inside candidates
    vol = safe_float(row.get("vol24"), 0.0) or 0.0
    mcap = safe_float(row.get("mcap"), 0.0) or 0.0
    chg = abs(safe_float(row.get("chg24"), 0.0) or 0.0)
    rank = safe_float(row.get("rank"), 999999.0) or 999999.0
    base = safe_float(row.get("score"), 0.0) or 0.0

    # lightweight log1p without importing math globally
    try:
        import math
        lv = math.log1p(max(0.0, float(vol)))
        lm = math.log1p(max(0.0, float(mcap)))
    except Exception:
        lv = 0.0
        lm = 0.0

    if mode == "aggressive":
        # reward vol and movement
        return (base * 1.0) + (lv * 9.0) + (chg * 2.2) - (rank * 0.01)
    if mode == "conservative":
        # reward mcap and stability, punish big move
        return (base * 1.3) + (lv * 5.5) + (lm * 2.5) - (chg * 1.6) - (rank * 0.02)
    # balanced
    return (base * 1.15) + (lv * 7.0) + (lm * 1.2) + (chg * 0.6) - (rank * 0.015)


class App(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("NyoSig Cryptolytix")
        self._set_big_window()

        # state
        self.current_run = None  # dict
        self.rows_loaded = []    # raw candidates loaded from DB (after stable exclusion + load limit)
        self.rows_filtered = []  # after filters
        self.cand_view = []      # current view (sorted) for candidates
        self.top_view = []       # current view (sorted) for top

        # TOP library in memory (multiple TOP sets)
        # mem_top_id -> {meta, items, saved_db_id or None}
        self.top_library = {}
        self.mem_top_counter = 0
        self.selected_mem_top_id = None

        # vars
        self.load_n_var = tk.IntVar(value=300)
        self.font_size_var = tk.IntVar(value=FONT_SIZE_DEFAULT)

        self.exclude_stable_var = tk.BooleanVar(value=True)
        self.min_vol24_var = tk.StringVar(value="")
        self.min_mcap_var = tk.StringVar(value="")
        self.max_abs_chg24_var = tk.StringVar(value="")

        self.top_n_var = tk.IntVar(value=15)
        self.mode_var = tk.StringVar(value="balanced")
        self.tf_var = tk.StringVar(value="4h")

        self.top_sets_var = tk.StringVar(value="")

        self.status_var = tk.StringVar(value="Ready")

        # sorting states
        self._cand_sort = {"col": None, "desc": True}
        self._top_sort = {"col": None, "desc": True}

        self._build_ui()
        self._apply_fonts()
        self._refresh_run_meta()
        self.apply_load()

    def _set_big_window(self):
        try:
            w = self.winfo_screenwidth()
            h = self.winfo_screenheight()
            self.geometry(f"{w}x{h}")
        except Exception:
            self.geometry("1040x790")

    def _apply_fonts(self):
        fs = safe_int(self.font_size_var.get(), FONT_SIZE_DEFAULT)
        if fs < FONT_SIZE_MIN:
            fs = FONT_SIZE_MIN
        if fs > FONT_SIZE_MAX:
            fs = FONT_SIZE_MAX
        style = ttk.Style(self)
        try:
            style.theme_use("default")
        except Exception:
            pass
        style.configure("Treeview", font=("TkDefaultFont", fs))
        style.configure("Treeview.Heading", font=("TkDefaultFont", fs))

    def set_status(self, txt):
        self.status_var.set(txt)

    def _build_ui(self):
        # Root layout: top controls + main split + status
        self.grid_rowconfigure(1, weight=1)
        self.grid_columnconfigure(0, weight=1)

        top = ttk.Frame(self, padding=6)
        top.grid(row=0, column=0, sticky="nsew")
        top.grid_columnconfigure(0, weight=1)

        # ROW 1: DATA
        r1 = ttk.Frame(top)
        r1.grid(row=0, column=0, sticky="ew")
        for i in range(20):
            r1.grid_columnconfigure(i, weight=0)
        r1.grid_columnconfigure(19, weight=1)

        self.btn_refresh = ttk.Button(r1, text="Refresh", command=self.refresh_all)
        self.btn_refresh.grid(row=0, column=0, padx=(0, 6))

        ttk.Label(r1, text="Load N:").grid(row=0, column=1, sticky="w")
        self.spin_load = ttk.Spinbox(r1, from_=50, to=5000, increment=50, textvariable=self.load_n_var, width=7)
        self.spin_load.grid(row=0, column=2, padx=(4, 8))

        self.btn_apply_load = ttk.Button(r1, text="Apply", command=self.apply_load)
        self.btn_apply_load.grid(row=0, column=3, padx=(0, 10))

        ttk.Label(r1, text="Font:").grid(row=0, column=4, sticky="w")
        self.spin_font = ttk.Spinbox(r1, from_=FONT_SIZE_MIN, to=FONT_SIZE_MAX, increment=1, textvariable=self.font_size_var, width=4)
        self.spin_font.grid(row=0, column=5, padx=(4, 6))
        self.btn_apply_font = ttk.Button(r1, text="Apply Font", command=self.on_apply_font)
        self.btn_apply_font.grid(row=0, column=6, padx=(0, 10))

        self.db_meta_lbl = ttk.Label(r1, text="DB: -  Run: -")
        self.db_meta_lbl.grid(row=0, column=19, sticky="e")

        # ROW 2: FILTERS
        r2 = ttk.Frame(top)
        r2.grid(row=1, column=0, sticky="ew", pady=(6, 0))
        for i in range(30):
            r2.grid_columnconfigure(i, weight=0)
        r2.grid_columnconfigure(29, weight=1)

        self.chk_stable = ttk.Checkbutton(r2, text="Exclude stable", variable=self.exclude_stable_var)
        self.chk_stable.grid(row=0, column=0, padx=(0, 10))

        ttk.Label(r2, text="Min vol24:").grid(row=0, column=1, sticky="w")
        self.ent_min_vol = ttk.Entry(r2, textvariable=self.min_vol24_var, width=10)
        self.ent_min_vol.grid(row=0, column=2, padx=(4, 10))

        ttk.Label(r2, text="Min mcap:").grid(row=0, column=3, sticky="w")
        self.ent_min_mcap = ttk.Entry(r2, textvariable=self.min_mcap_var, width=10)
        self.ent_min_mcap.grid(row=0, column=4, padx=(4, 10))

        ttk.Label(r2, text="Max abs chg24%:").grid(row=0, column=5, sticky="w")
        self.ent_max_chg = ttk.Entry(r2, textvariable=self.max_abs_chg24_var, width=8)
        self.ent_max_chg.grid(row=0, column=6, padx=(4, 10))

        self.btn_apply_filters = ttk.Button(r2, text="Apply filters", command=self.apply_filters)
        self.btn_apply_filters.grid(row=0, column=7, padx=(0, 10))

        self.counts_lbl = ttk.Label(r2, text="Candidates: 0  Filtered: 0  TOP sets: 0")
        self.counts_lbl.grid(row=0, column=29, sticky="e")

        # ROW 3: TOP BUILDER
        r3 = ttk.Frame(top)
        r3.grid(row=2, column=0, sticky="ew", pady=(6, 0))
        for i in range(30):
            r3.grid_columnconfigure(i, weight=0)
        r3.grid_columnconfigure(29, weight=1)

        ttk.Label(r3, text="Top N:").grid(row=0, column=0, sticky="w")
        self.spin_top_n = ttk.Spinbox(r3, from_=5, to=500, increment=5, textvariable=self.top_n_var, width=6)
        self.spin_top_n.grid(row=0, column=1, padx=(4, 10))

        ttk.Label(r3, text="Mode:").grid(row=0, column=2, sticky="w")
        self.cmb_mode = ttk.Combobox(r3, textvariable=self.mode_var, values=MODES, state="readonly", width=12)
        self.cmb_mode.grid(row=0, column=3, padx=(4, 10))

        ttk.Label(r3, text="TF:").grid(row=0, column=4, sticky="w")
        self.cmb_tf = ttk.Combobox(r3, textvariable=self.tf_var, values=TIMEFRAMES, state="readonly", width=6)
        self.cmb_tf.grid(row=0, column=5, padx=(4, 10))

        self.btn_build_top = ttk.Button(r3, text="Build TOP", command=self.build_top)
        self.btn_build_top.grid(row=0, column=6, padx=(0, 14))

        ttk.Label(r3, text="TOP sets:").grid(row=0, column=7, sticky="w")
        self.cmb_top_sets = ttk.Combobox(r3, textvariable=self.top_sets_var, values=[], state="readonly", width=28)
        self.cmb_top_sets.grid(row=0, column=8, padx=(4, 10))
        self.cmb_top_sets.bind("<<ComboboxSelected>>", lambda _e: self.on_select_top_set())

        self.btn_to_db = ttk.Button(r3, text="To DB", command=self.commit_top_to_db)
        self.btn_to_db.grid(row=0, column=9, padx=(0, 10))

        self.btn_analyse = ttk.Button(r3, text="Analyse", command=self.analyse_top)
        self.btn_analyse.grid(row=0, column=10, padx=(0, 10))

        # MAIN: two tables (candidates + top)
        main = ttk.PanedWindow(self, orient=tk.VERTICAL)
        main.grid(row=1, column=0, sticky="nsew", padx=6, pady=(0, 6))

        cand_frame = ttk.Labelframe(main, text="Candidates (from DB)", padding=6)
        top_frame = ttk.Labelframe(main, text="TOP (in memory)", padding=6)

        main.add(cand_frame, weight=1)
        main.add(top_frame, weight=1)

        # Candidates Treeview
        self.cand_tree = self._make_tree(
            parent=cand_frame,
            cols=("rank", "pair", "price", "chg24", "vol24", "mcap", "score"),
            headings=("Rank", "Pair", "Price", "Chg24%", "Vol24", "MCap", "Score"),
            sort_handler=self.sort_candidates_by,
        )

        # TOP Treeview
        self.top_tree = self._make_tree(
            parent=top_frame,
            cols=("top_rank", "pair", "price", "chg24", "vol24", "mcap", "rank", "score", "top_score"),
            headings=("Top", "Pair", "Price", "Chg24%", "Vol24", "MCap", "CgRank", "SpotScore", "TopScore"),
            sort_handler=self.sort_top_by,
        )

        # STATUS
        status = ttk.Frame(self, padding=(6, 0, 6, 6))
        status.grid(row=2, column=0, sticky="ew")
        status.grid_columnconfigure(0, weight=1)
        ttk.Label(status, textvariable=self.status_var).grid(row=0, column=0, sticky="w")

    def _make_tree(self, parent, cols, headings, sort_handler):
        parent.grid_rowconfigure(0, weight=1)
        parent.grid_columnconfigure(0, weight=1)

        wrap = ttk.Frame(parent)
        wrap.grid(row=0, column=0, sticky="nsew")
        wrap.grid_rowconfigure(0, weight=1)
        wrap.grid_columnconfigure(0, weight=1)

        tree = ttk.Treeview(wrap, columns=cols, show="headings")
        tree.grid(row=0, column=0, sticky="nsew")

        ysb = ttk.Scrollbar(wrap, orient="vertical", command=tree.yview)
        xsb = ttk.Scrollbar(wrap, orient="horizontal", command=tree.xview)
        tree.configure(yscroll=ysb.set, xscroll=xsb.set)
        ysb.grid(row=0, column=1, sticky="ns")
        xsb.grid(row=1, column=0, sticky="ew")

        for c, h in zip(cols, headings):
            tree.heading(c, text=h, command=lambda cc=c: sort_handler(cc))

        # reasonable widths
        for c in cols:
            if c in ("pair",):
                tree.column(c, width=140, anchor=tk.W, stretch=True)
            else:
                tree.column(c, width=100, anchor=tk.E, stretch=False)

        return tree

    def on_apply_font(self):
        self._apply_fonts()
        self.set_status("Font applied")

    def refresh_all(self):
        self._refresh_run_meta()
        self.apply_load()

    def _refresh_run_meta(self):
        try:
            if not os.path.isdir(PROJECT_ROOT):
                self.db_meta_lbl.config(text="DB: project root missing")
                return
            con = db_connect()
            try:
                run = con.execute(
                    """
                    SELECT run_id, created_utc, status, vs_currency, coins_limit, sort_mode, source
                    FROM runs
                    ORDER BY run_id DESC
                    LIMIT 1
                    """
                ).fetchone()
                if not run:
                    self.current_run = None
                    self.db_meta_lbl.config(text="DB: OK  Run: none")
                    return
                self.current_run = dict(run)
                rid = str(run["run_id"])
                created = str(run["created_utc"] or "")
                src = str(run["source"] or "")
                self.db_meta_lbl.config(text=f"DB: OK  Run: {rid}  {created}  {src}")
            finally:
                con.close()
        except Exception as e:
            self.current_run = None
            self.db_meta_lbl.config(text="DB error: " + str(e)[:60])

    def apply_load(self):
        # Load N candidates from spot_markets for latest run
        try:
            if not self.current_run:
                self.set_status("No run in DB")
                self.rows_loaded = []
                self.rows_filtered = []
                self.cand_view = []
                self._render_candidates([])
                self._render_top([])
                self._update_counts()
                return

            load_n = safe_int(self.load_n_var.get(), 300)
            if load_n <= 0:
                load_n = 300

            run_id = str(self.current_run["run_id"])

            con = db_connect()
            try:
                rows = con.execute(
                    """
                    SELECT unified_symbol, pair, price, change_24h_pct, volume_24h, market_cap, rank, score
                    FROM spot_markets
                    WHERE run_id = ?
                    ORDER BY rank ASC
                    LIMIT ?
                    """,
                    (run_id, load_n),
                ).fetchall()

                out = []
                for r in rows:
                    sym = (r["unified_symbol"] or "").upper().strip()
                    if not sym:
                        continue

                    # stable exclusion at load stage is optional; we still keep it controllable in filters
                    out.append(
                        {
                            "symbol": sym,
                            "pair": r["pair"] or (sym + "/USD"),
                            "price": safe_float(r["price"], None),
                            "chg24": safe_float(r["change_24h_pct"], None),
                            "vol24": safe_float(r["volume_24h"], None),
                            "mcap": safe_float(r["market_cap"], None),
                            "rank": safe_int(r["rank"], 999999),
                            "score": safe_int(r["score"], 0),
                        }
                    )

                self.rows_loaded = out
                self.apply_filters()
                self.set_status(f"Loaded {len(self.rows_loaded)} candidates from run {run_id}")
            finally:
                con.close()
        except Exception as e:
            messagebox.showerror("Error", str(e)[:800])
            self.set_status("Error")

    def apply_filters(self):
        # Apply filters only to candidates in memory
        ex_stable = bool(self.exclude_stable_var.get())

        min_vol24 = safe_float(self.min_vol24_var.get().strip() if self.min_vol24_var.get() is not None else "", None)
        min_mcap = safe_float(self.min_mcap_var.get().strip() if self.min_mcap_var.get() is not None else "", None)
        max_abs_chg = safe_float(self.max_abs_chg24_var.get().strip() if self.max_abs_chg24_var.get() is not None else "", None)

        filtered = []
        for r in self.rows_loaded:
            sym = (r.get("symbol") or "").upper().strip()
            if not sym:
                continue
            if ex_stable and sym in EXCLUDE_STABLE_BASE:
                continue

            vol24 = safe_float(r.get("vol24"), None)
            mcap = safe_float(r.get("mcap"), None)
            chg24 = safe_float(r.get("chg24"), None)

            if min_vol24 is not None and (vol24 is None or vol24 < min_vol24):
                continue
            if min_mcap is not None and (mcap is None or mcap < min_mcap):
                continue
            if max_abs_chg is not None and (chg24 is None or abs(chg24) > max_abs_chg):
                continue

            filtered.append(r)

        self.rows_filtered = filtered
        self.cand_view = list(filtered)

        # default sort in candidates: rank asc
        self.cand_view.sort(key=lambda x: safe_int(x.get("rank"), 999999))
        self._cand_sort = {"col": "rank", "desc": False}

        self._render_candidates(self.cand_view)
        self._update_counts()
        self.set_status("Filters applied")

    def _render_candidates(self, rows):
        self.cand_tree.delete(*self.cand_tree.get_children())
        for r in rows:
            self.cand_tree.insert(
                "",
                "end",
                values=(
                    r.get("rank", ""),
                    r.get("pair", ""),
                    fmt_price(r.get("price")),
                    fmt_pct(r.get("chg24")),
                    fmt_int(r.get("vol24")),
                    fmt_int(r.get("mcap")),
                    r.get("score", ""),
                ),
            )

    def _render_top(self, items):
        self.top_tree.delete(*self.top_tree.get_children())
        for r in items:
            self.top_tree.insert(
                "",
                "end",
                values=(
                    r.get("top_rank", ""),
                    r.get("pair", ""),
                    fmt_price(r.get("price")),
                    fmt_pct(r.get("chg24")),
                    fmt_int(r.get("vol24")),
                    fmt_int(r.get("mcap")),
                    r.get("rank", ""),
                    r.get("score", ""),
                    f"{safe_float(r.get('top_score'), 0.0):.4f}" if r.get("top_score") is not None else "",
                ),
            )

    def _update_counts(self):
        cand_n = len(self.rows_loaded)
        filt_n = len(self.rows_filtered)
        top_sets_n = len(self.top_library)
        self.counts_lbl.config(text=f"Candidates: {cand_n}  Filtered: {filt_n}  TOP sets: {top_sets_n}")

    def sort_candidates_by(self, col):
        if not self.cand_view:
            return

        desc = True
        if self._cand_sort["col"] == col:
            desc = not bool(self._cand_sort["desc"])

        def keyf(r):
            if col == "pair":
                return (str(r.get("pair") or "")).upper()
            if col == "rank":
                return safe_int(r.get("rank"), 999999)
            if col == "score":
                return safe_int(r.get("score"), 0)
            if col == "price":
                return safe_float(r.get("price"), -1e99)
            if col == "chg24":
                return safe_float(r.get("chg24"), -1e99)
            if col == "vol24":
                return safe_float(r.get("vol24"), -1e99)
            if col == "mcap":
                return safe_float(r.get("mcap"), -1e99)
            return 0

        self.cand_view = sorted(self.cand_view, key=keyf, reverse=desc)
        self._cand_sort = {"col": col, "desc": desc}
        self._render_candidates(self.cand_view)

    def sort_top_by(self, col):
        if not self.top_view:
            return

        desc = True
        if self._top_sort["col"] == col:
            desc = not bool(self._top_sort["desc"])

        def keyf(r):
            if col == "pair":
                return (str(r.get("pair") or "")).upper()
            if col == "top_rank":
                return safe_int(r.get("top_rank"), 999999)
            if col == "rank":
                return safe_int(r.get("rank"), 999999)
            if col == "score":
                return safe_int(r.get("score"), 0)
            if col == "top_score":
                return safe_float(r.get("top_score"), -1e99)
            if col == "price":
                return safe_float(r.get("price"), -1e99)
            if col == "chg24":
                return safe_float(r.get("chg24"), -1e99)
            if col == "vol24":
                return safe_float(r.get("vol24"), -1e99)
            if col == "mcap":
                return safe_float(r.get("mcap"), -1e99)
            return 0

        self.top_view = sorted(self.top_view, key=keyf, reverse=desc)
        self._top_sort = {"col": col, "desc": desc}
        self._render_top(self.top_view)

    def build_top(self):
        # MANUAL: build TOP in memory only, store as new TOP set snapshot
        if not self.rows_filtered:
            messagebox.showerror("Error", "No filtered candidates. Load and apply filters first.")
            return
        if not self.current_run:
            messagebox.showerror("Error", "No run loaded.")
            return

        top_n = safe_int(self.top_n_var.get(), 15)
        if top_n <= 0:
            top_n = 15

        mode = (self.mode_var.get() or "balanced").strip().lower()
        if mode not in MODES:
            mode = "balanced"

        tf = (self.tf_var.get() or "4h").strip()
        if tf not in TIMEFRAMES:
            tf = "4h"

        # requirement: first selection by vol24
        base_sorted = sorted(
            self.rows_filtered,
            key=lambda r: (
                safe_float(r.get("vol24"), 0.0) or 0.0,
                safe_float(r.get("mcap"), 0.0) or 0.0,
                -safe_float(r.get("rank"), 999999.0) if safe_float(r.get("rank"), None) is not None else 0.0,
            ),
            reverse=True,
        )

        scored = []
        for r in base_sorted:
            sym = (r.get("symbol") or "").upper().strip()
            if not sym:
                continue
            rr = dict(r)
            rr["top_score"] = float(top_score(mode, rr))
            scored.append(rr)

        scored.sort(key=lambda r: (safe_float(r.get("top_score"), 0.0) or 0.0, safe_float(r.get("vol24"), 0.0) or 0.0), reverse=True)
        picked = scored[:top_n]

        items = []
        for i, r in enumerate(picked, start=1):
            items.append(
                {
                    "top_rank": i,
                    "symbol": r.get("symbol"),
                    "pair": r.get("pair"),
                    "price": r.get("price"),
                    "chg24": r.get("chg24"),
                    "vol24": r.get("vol24"),
                    "mcap": r.get("mcap"),
                    "rank": r.get("rank"),
                    "score": r.get("score"),
                    "top_score": r.get("top_score"),
                }
            )

        # store snapshot
        self.mem_top_counter += 1
        mem_id = f"TOP_{self.mem_top_counter:03d}  {mode}  {tf}  n={top_n}"
        self.top_library[mem_id] = {
            "meta": {
                "created_utc": utc_now_iso(),
                "run_id": str(self.current_run["run_id"]),
                "mode": mode,
                "timeframe": tf,
                "top_n": top_n,
                "load_n": safe_int(self.load_n_var.get(), 300),
                "filters": {
                    "exclude_stable": int(bool(self.exclude_stable_var.get())),
                    "min_vol24": (self.min_vol24_var.get() or "").strip(),
                    "min_mcap": (self.min_mcap_var.get() or "").strip(),
                    "max_abs_chg24": (self.max_abs_chg24_var.get() or "").strip(),
                },
            },
            "items": items,
            "saved_db_id": None,
        }

        # update dropdown + select
        self._refresh_top_sets_dropdown(select_mem_id=mem_id)
        self._show_top_set(mem_id)
        self.set_status("TOP built in memory (not saved)")

    def _refresh_top_sets_dropdown(self, select_mem_id=None):
        vals = list(self.top_library.keys())
        self.cmb_top_sets["values"] = vals
        if select_mem_id and select_mem_id in self.top_library:
            self.top_sets_var.set(select_mem_id)
            self.selected_mem_top_id = select_mem_id
        elif self.selected_mem_top_id in self.top_library:
            self.top_sets_var.set(self.selected_mem_top_id)
        elif vals:
            self.top_sets_var.set(vals[-1])
            self.selected_mem_top_id = vals[-1]
        else:
            self.top_sets_var.set("")
            self.selected_mem_top_id = None
        self._update_counts()

    def on_select_top_set(self):
        mem_id = (self.top_sets_var.get() or "").strip()
        if not mem_id:
            return
        if mem_id not in self.top_library:
            return
        self._show_top_set(mem_id)

    def _show_top_set(self, mem_id):
        self.selected_mem_top_id = mem_id
        items = self.top_library[mem_id]["items"]
        self.top_view = list(items)
        # default sort: top_rank asc
        self.top_view.sort(key=lambda r: safe_int(r.get("top_rank"), 999999))
        self._top_sort = {"col": "top_rank", "desc": False}
        self._render_top(self.top_view)

        saved = self.top_library[mem_id].get("saved_db_id")
        if saved:
            self.set_status(f"TOP selected: saved as {saved}")
        else:
            self.set_status("TOP selected: not saved")

    def commit_top_to_db(self):
        # Save selected TOP set to DB, creating a unique top_set_id
        mem_id = (self.top_sets_var.get() or "").strip()
        if not mem_id or mem_id not in self.top_library:
            messagebox.showerror("Error", "No TOP set selected.")
            return
        if not self.current_run:
            messagebox.showerror("Error", "No run loaded.")
            return

        top_obj = self.top_library[mem_id]
        if not top_obj["items"]:
            messagebox.showerror("Error", "Selected TOP set is empty.")
            return

        if top_obj.get("saved_db_id"):
            messagebox.showinfo("Info", "This TOP set is already saved as:\n" + str(top_obj["saved_db_id"]))
            return

        meta = top_obj["meta"]
        run_id = str(meta.get("run_id") or "")
        mode = str(meta.get("mode") or "")
        tf = str(meta.get("timeframe") or "")
        top_n = safe_int(meta.get("top_n"), 0)
        load_n = safe_int(meta.get("load_n"), 0)

        f = meta.get("filters") or {}
        filters_str = filters_to_jsonlike(
            exclude_stable=bool(safe_int(f.get("exclude_stable", 1), 1)),
            min_vol24=(str(f.get("min_vol24", "")).strip() or "null"),
            min_mcap=(str(f.get("min_mcap", "")).strip() or "null"),
            max_abs_chg24=(str(f.get("max_abs_chg24", "")).strip() or "null"),
        )

        saved_id = make_saved_top_set_id()

        try:
            con = db_connect()
            try:
                ensure_top_tables(con)
                con.execute("BEGIN;")
                con.execute(
                    """
                    INSERT INTO top_sets (top_set_id, created_utc, source_run_id, vs_currency, load_n, filters_json, timeframe, mode, top_n, notes)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        saved_id,
                        utc_now_iso(),
                        run_id,
                        (self.current_run.get("vs_currency") or ""),
                        int(load_n),
                        filters_str,
                        tf,
                        mode,
                        int(top_n),
                        "",
                    ),
                )

                for it in top_obj["items"]:
                    con.execute(
                        """
                        INSERT INTO top_set_items
                        (top_set_id, rank_in_top, unified_symbol, pair, price, change_24h_pct, volume_24h, market_cap, cg_rank, spot_score, top_score)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            saved_id,
                            int(safe_int(it.get("top_rank"), 0)),
                            str((it.get("symbol") or "")).upper().strip(),
                            it.get("pair"),
                            safe_float(it.get("price"), None),
                            safe_float(it.get("chg24"), None),
                            safe_float(it.get("vol24"), None),
                            safe_float(it.get("mcap"), None),
                            safe_int(it.get("rank"), None) if it.get("rank") is not None else None,
                            safe_int(it.get("score"), None) if it.get("score") is not None else None,
                            safe_float(it.get("top_score"), None),
                        ),
                    )

                con.commit()
            except Exception:
                con.rollback()
                raise
            finally:
                con.close()

            top_obj["saved_db_id"] = saved_id
            self.set_status("Saved to DB: " + saved_id)
            messagebox.showinfo("OK", "Saved TOP set to DB:\n" + saved_id)

        except Exception as e:
            messagebox.showerror("Error", str(e)[:800])
            self.set_status("Error saving to DB")

    def analyse_top(self):
        # Placeholder: must require saved top_set_id
        mem_id = (self.top_sets_var.get() or "").strip()
        if not mem_id or mem_id not in self.top_library:
            messagebox.showerror("Error", "No TOP set selected.")
            return
        saved_id = self.top_library[mem_id].get("saved_db_id")
        if not saved_id:
            messagebox.showerror("Error", "Please save TOP to DB first (To DB).")
            return

        # In this version we only reserve the hook.
        messagebox.showinfo("Analyse", "Analyse pipeline is not implemented in v1.2b.\nSaved top_set_id:\n" + str(saved_id))
        self.set_status("Analyse requested for " + str(saved_id))


if __name__ == "__main__":
    app = App()

    if not os.path.isdir(PROJECT_ROOT):
        messagebox.showerror("Error", "Project root not found:\n" + PROJECT_ROOT)
        raise SystemExit(1)

    app.mainloop()
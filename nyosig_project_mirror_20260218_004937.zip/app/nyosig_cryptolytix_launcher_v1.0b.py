#!/usr/bin/env python3
# nyosig_cryptolytix_launcher_v1.0c
# ASCII only, Tkinter launcher for versioned GUIs
# Root: /storage/emulated/0/NyoSig/NyoSig_Cryptolytix

import os
import re
import tkinter as tk
from tkinter import ttk, messagebox
import sys

def get_project_root() -> str:
    """Resolve project root robustly (Android/Pydroid friendly).
    Tries core.config.get_project_root if available; otherwise falls back to app/.."""
    app_dir = os.path.dirname(os.path.abspath(__file__))
    root = os.path.abspath(os.path.join(app_dir, '..'))
    # Make sure imports like `core.*` work when running from app/ on Android
    if root not in sys.path:
        sys.path.insert(0, root)
    try:
        from core.config import get_project_root as _gpr  # type: ignore
        return _gpr()
    except Exception:
        return root

PROJECT_ROOT = get_project_root()
VERSIONS_DIR = os.path.join(PROJECT_ROOT, 'app', 'versions')



RE_VER = re.compile(r"(?:^|[_\-])v(\d+)\.(\d+)([a-z])?(?=\.py$|[_\-\.])", re.IGNORECASE)

_SELECTED_TO_RUN = {"path": None}


def ascii_guard():
    with open(__file__, "rb") as f:
        b = f.read()
    start = 3 if b.startswith(b"\xef\xbb\xbf") else 0
    for i in range(start, len(b)):
        if b[i] > 127:
            raise RuntimeError("Non ASCII byte found at offset %d" % i)


def parse_version_from_filename(name):
    m = RE_VER.search(name)
    if not m:
        return None
    major = int(m.group(1))
    minor = int(m.group(2))
    patch = (m.group(3) or "").lower()
    return (major, minor, patch)


def version_to_label(v):
    major, minor, patch = v
    return f"{major}.{minor}{patch}"



def compute_sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(1024 * 1024)
            if not b:
                break
            h.update(b)
    return h.hexdigest()

def verify_or_register_version(file_path: str, version_label: str) -> None:
    # version_label should be like 'v3.6b'
    paths = make_paths(PROJECT_ROOT)
    con = db_connect(paths.db_path)
    try:
        require_schema(con)
        ensure_indexes(con)
        ensure_snapshot_schema(con)  # also ensures version_registry
        sha = compute_sha256(file_path)
        expected = get_version_sha(con, version_label)
        if expected is None:
            # first-seen: register
            upsert_version_registry(con, version_label, sha, utc_now_iso(), notes="auto-registered by launcher")
            con.commit()
            return
        if expected != sha:
            raise RuntimeError(f"Version checksum mismatch for {version_label}: expected {expected[:12]}..., got {sha[:12]}...")
    finally:
        con.close()


def version_sort_key(v):
    major, minor, patch = v
    patch_val = ord(patch) if patch else 0
    return (major, minor, patch_val)


def find_versions(versions_dir):
    items = []
    try:
        names = os.listdir(versions_dir)
    except Exception:
        return []

    for name in names:
        if not name.lower().endswith(".py"):
            continue
        v = parse_version_from_filename(name)
        if not v:
            continue
        full = os.path.join(versions_dir, name)
        items.append((v, full, name))

    items.sort(key=lambda x: version_sort_key(x[0]), reverse=True)
    return items


class Launcher(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("NyoSig Cryptolytix Launcher v1.0b")
        self.geometry("620x760")
        self.minsize(420, 520)

        self.header_var = tk.StringVar(value="Ready")
        self.items = []

        self._build_ui()
        self.reload_versions()

    def _build_ui(self):
        root = ttk.Frame(self, padding=10)
        root.pack(fill="both", expand=True)

        top = ttk.Frame(root)
        top.pack(fill="x", pady=(0, 8))

        ttk.Label(top, text="Versions").pack(side="left")
        ttk.Button(top, text="Reload", command=self.reload_versions).pack(side="right")

        ttk.Label(root, textvariable=self.header_var).pack(fill="x", pady=(0, 8))

        self.canvas = tk.Canvas(root, highlightthickness=0)
        self.scroll = ttk.Scrollbar(root, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.scroll.set)

        self.scroll.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)

        self.inner = ttk.Frame(self.canvas)
        self.inner_id = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")

        self.inner.bind("<Configure>", self._on_inner_configure)
        self.canvas.bind("<Configure>", self._on_canvas_configure)

    def _on_inner_configure(self, _e=None):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _on_canvas_configure(self, e=None):
        if e:
            self.canvas.itemconfig(self.inner_id, width=e.width)

    def clear_buttons(self):
        for w in self.inner.winfo_children():
            w.destroy()

    def reload_versions(self):
        self.items = find_versions(VERSIONS_DIR)
        self.clear_buttons()

        if not os.path.isdir(VERSIONS_DIR):
            self.header_var.set("Versions folder missing: " + VERSIONS_DIR)
            messagebox.showerror("Error", "Versions folder missing:\n" + VERSIONS_DIR)
            return

        if not self.items:
            self.header_var.set("No versions found")
            messagebox.showerror(
                "No versions found",
                "No versioned .py files found in:\n"
                + VERSIONS_DIR
                + "\n\nExpected filenames containing vX.Y or vX.Ya"
            )
            return

        latest = self.items[0][0]
        self.header_var.set("Found %d versions. Latest: %s" % (len(self.items), version_to_label(latest)))

        for idx, (v, full, name) in enumerate(self.items):
            label = version_to_label(v)

            btn = tk.Button(
                self.inner,
                text=label,
                command=lambda p=full: self.select_and_close(p),
                relief="raised",
                padx=12,
                pady=10
            )

            if idx == 0:
                btn.configure(bg="#1a8f3a", fg="white", activebackground="#22aa45")
            else:
                btn.configure(bg="#e6e6e6", fg="black", activebackground="#d0d0d0")

            btn.pack(fill="x", pady=6)

        ttk.Separator(self.inner).pack(fill="x", pady=10)
        ttk.Label(self.inner, text="Folder: " + VERSIONS_DIR).pack(fill="x")

    def select_and_close(self, path):
        if not os.path.isfile(path):
            messagebox.showerror("Error", "File not found:\n" + path)
            return

        _SELECTED_TO_RUN["path"] = path
        self.header_var.set("Selected: " + os.path.basename(path))
        self.update_idletasks()
        self.destroy()


def run_selected(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            code = f.read()
    except Exception as e:
        messagebox.showerror("Error", "Failed to read:\n" + path + "\n\n" + str(e)[:800])
        return

    g = {
        "__name__": "__main__",
        "__file__": path,
        "__package__": None,
        "__cached__": None,
    }

    try:
        os.chdir(PROJECT_ROOT)
    except Exception:
        pass

    try:
        exec(compile(code, path, "exec"), g, g)
    except SystemExit:
        return
    except Exception as e:
        try:
            messagebox.showerror("Error", "App crashed:\n" + os.path.basename(path) + "\n\n" + str(e)[:1200])
        except Exception:
            pass


if __name__ == "__main__":
    ascii_guard()

    app = Launcher()
    app.mainloop()

    sel = _SELECTED_TO_RUN.get("path")
    if sel:
        run_selected(sel)

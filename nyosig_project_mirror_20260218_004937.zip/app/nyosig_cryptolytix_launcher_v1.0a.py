#!/usr/bin/env python3
# nyosig_cryptolytix_launcher_v1.0a
# ASCII only, Tkinter launcher for versioned GUIs
# Root: /storage/emulated/0/NyoSig/NyoSig_Cryptolytix

import os
import re
import sys
import subprocess
import tkinter as tk
from tkinter import ttk, messagebox

PROJECT_ROOT = "/storage/emulated/0/NyoSig/NyoSig_Cryptolytix"
VERSIONS_DIR = os.path.join(PROJECT_ROOT, "app", "versions")

# Accept: ..._v1.2.py, ..._v1.2a.py, ..._v12.34z.py
RE_VER = re.compile(r"(?:^|[_\-])v(\d+)\.(\d+)([a-z])?(?=\.py$|[_\-\.])", re.IGNORECASE)


def ascii_guard():
    with open(__file__, "rb") as f:
        b = f.read()
    start = 3 if b.startswith(b"\xef\xbb\xbf") else 0
    for i in range(start, len(b)):
        if b[i] > 127:
            raise RuntimeError("Non ASCII byte found at offset %d" % i)


def parse_version_from_filename(name):
    m = RE_VER.search(name)
    if not m:
        return None
    major = int(m.group(1))
    minor = int(m.group(2))
    patch = (m.group(3) or "").lower()
    return (major, minor, patch)


def version_to_label(v):
    major, minor, patch = v
    return f"{major}.{minor}{patch}"


def version_sort_key(v):
    major, minor, patch = v
    patch_val = ord(patch) if patch else 0
    return (major, minor, patch_val)


def find_versions(versions_dir):
    items = []
    try:
        names = os.listdir(versions_dir)
    except Exception:
        return []

    for name in names:
        if not name.lower().endswith(".py"):
            continue
        v = parse_version_from_filename(name)
        if not v:
            continue
        full = os.path.join(versions_dir, name)
        items.append((v, full, name))

    items.sort(key=lambda x: version_sort_key(x[0]), reverse=True)
    return items


class Launcher(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("NyoSig Cryptolytix Launcher v1.0a")
        self.geometry("620x760")
        self.minsize(420, 520)

        self.style = ttk.Style(self)
        try:
            self.style.theme_use("default")
        except Exception:
            pass

        self.header_var = tk.StringVar(value="Ready")
        self.items = []

        self._build_ui()
        self.reload_versions()

    def _build_ui(self):
        root = ttk.Frame(self, padding=10)
        root.pack(fill="both", expand=True)

        top = ttk.Frame(root)
        top.pack(fill="x", pady=(0, 8))

        ttk.Label(top, text="Versions").pack(side="left")
        ttk.Button(top, text="Reload", command=self.reload_versions).pack(side="right")

        ttk.Label(root, textvariable=self.header_var).pack(fill="x", pady=(0, 8))

        self.canvas = tk.Canvas(root, highlightthickness=0)
        self.scroll = ttk.Scrollbar(root, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.scroll.set)

        self.scroll.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)

        self.inner = ttk.Frame(self.canvas)
        self.inner_id = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")

        self.inner.bind("<Configure>", self._on_inner_configure)
        self.canvas.bind("<Configure>", self._on_canvas_configure)

    def _on_inner_configure(self, _e=None):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _on_canvas_configure(self, e=None):
        if e:
            self.canvas.itemconfig(self.inner_id, width=e.width)

    def clear_buttons(self):
        for w in self.inner.winfo_children():
            w.destroy()

    def reload_versions(self):
        self.items = find_versions(VERSIONS_DIR)
        self.clear_buttons()

        if not os.path.isdir(VERSIONS_DIR):
            self.header_var.set("Versions folder missing: " + VERSIONS_DIR)
            messagebox.showerror("Error", "Versions folder missing:\n" + VERSIONS_DIR)
            return

        if not self.items:
            self.header_var.set("No versions found")
            messagebox.showerror(
                "No versions found",
                "No versioned .py files found in:\n"
                + VERSIONS_DIR
                + "\n\nExpected filenames containing vX.Y or vX.Ya"
            )
            return

        latest = self.items[0][0]
        self.header_var.set("Found %d versions. Latest: %s" % (len(self.items), version_to_label(latest)))

        for idx, (v, full, name) in enumerate(self.items):
            label = version_to_label(v)

            btn = tk.Button(
                self.inner,
                text=label,
                command=lambda p=full: self.launch_file(p),
                relief="raised",
                padx=12,
                pady=10
            )

            if idx == 0:
                btn.configure(bg="#1a8f3a", fg="white", activebackground="#22aa45")
            else:
                btn.configure(bg="#e6e6e6", fg="black", activebackground="#d0d0d0")

            btn.pack(fill="x", pady=6)

        ttk.Separator(self.inner).pack(fill="x", pady=10)
        ttk.Label(self.inner, text="Folder: " + VERSIONS_DIR).pack(fill="x")

    def launch_file(self, path):
        if not os.path.isfile(path):
            messagebox.showerror("Error", "File not found:\n" + path)
            return

        py = sys.executable or "python3"
        try:
            subprocess.Popen([py, path], cwd=PROJECT_ROOT)
        except Exception as e:
            messagebox.showerror("Error", "Failed to start:\n" + path + "\n\n" + str(e)[:800])
            return

        self.header_var.set("Started: " + os.path.basename(path))


if __name__ == "__main__":
    ascii_guard()
    app = Launcher()
    app.mainloop()
#!/usr/bin/env python3
from __future__ import annotations
import argparse
import json
import os
import sqlite3
from typing import Optional

from core.config import get_project_root, make_paths
from core.db import db_connect, require_schema, ensure_indexes, ensure_snapshot_schema
from core.pipeline import run_snapshot_and_topnow, refresh_snapshot
from core.analysis import prepare_analysis
from core.export import export_selection_csv
from core.watchlist import ensure_watchlist_schema, add_watch, remove_watch, list_watch, refresh_watch, list_alerts
from core.diff import snapshot_diff_summary
from core.engine import run_layers, run_composite_and_expanders
from core.layers_spot_basic import SpotBasicLayer
from core.layers_accel_15m import Accel15mLayer
from core.layers_accel_1h import Accel1hLayer
from core.layers_accel_4h import Accel4hLayer
from core.retention import prune_snapshots_keep_last
from core.rules import load_rules, set_rule, reset_rules
from core.multi_timeframe import run_multi_timeframe
from core.scheduler import run_due_once, run_loop
from core.registry import decay_registry_once
from core.export_stage3 import export_stage3_json, export_stage3_csv
from core.health import health_report
from core.db import resolve_snapshot

APP_VERSION = "v3.9d"

def open_con(project_root: str) -> sqlite3.Connection:
    paths = make_paths(project_root)
    con = db_connect(paths.db_path)
    require_schema(con)
    ensure_indexes(con)
    ensure_snapshot_schema(con)
    return con

def cmd_snapshot(args) -> int:
    project_root = args.project_root
    def log_cb(msg: str):
        print(msg)
    res = run_snapshot_and_topnow(
        project_root=project_root,
        app_version=APP_VERSION,
        scope_text=args.scope,
        vs_currency=args.vs_currency,
        coins_limit=args.coins_limit,
        order=args.order,
        topnow_limit=args.topnow_limit,
        offline_mode=args.offline,
        log_cb=log_cb,
    )
    print(json.dumps(res.__dict__, indent=2))
    return 0

def cmd_analysis(args) -> int:
    con = open_con(args.project_root)
    try:
        n = prepare_analysis(con, selection_id=args.selection_id, snapshot_id=args.snapshot_id, timeframe=args.timeframe)
        con.commit()
        print(f"analysis_updated_rows={n}")
        return 0
    finally:
        con.close()

def cmd_export(args) -> int:
    project_root = args.project_root
    paths = make_paths(project_root)
    con = open_con(project_root)
    try:
        os.makedirs(os.path.dirname(args.out), exist_ok=True)
        p = export_selection_csv(con, args.selection_id, args.snapshot_id, args.timeframe, args.out)
        print(p)
        return 0
    finally:
        con.close()

def cmd_watchlist(args) -> int:
    con = open_con(args.project_root)
    try:
        ensure_watchlist_schema(con)
        if args.action == "add":
            add_watch(con, args.symbol, tag=args.tag or "")
            con.commit()
            print("added")
        elif args.action == "remove":
            remove_watch(con, args.symbol)
            con.commit()
            print("removed")
        elif args.action == "list":
            rows = list_watch(con)
            for r in rows:
                print(r)
        elif args.action == "refresh":
            n = refresh_watch(con, snapshot_id=args.snapshot_id, timeframe=args.timeframe)
            con.commit()
            print(f"refreshed={n}")
        elif args.action == "alerts":
            rows = list_alerts(con, limit=args.limit)
            for r in rows:
                print(r)
        return 0
    finally:
        con.close()


def cmd_refresh(args) -> int:
    project_root = args.project_root
    def log_cb(msg: str):
        print(msg)
    run_id, new_snap = refresh_snapshot(
        project_root=project_root,
        app_version=APP_VERSION,
        parent_snapshot_key=args.parent_snapshot_id,
        scope_text=args.scope,
        vs_currency=args.vs_currency,
        coins_limit=args.coins_limit,
        order=args.order,
        offline_mode=args.offline,
        log_cb=log_cb,
        reason=args.reason,
    )
    print(json.dumps({"run_id": run_id, "snapshot_id": new_snap, "parent_snapshot_id": args.parent_snapshot_id}, indent=2))
    return 0

def cmd_diff(args) -> int:
    con = open_con(args.project_root)
    try:
        rep = snapshot_diff_summary(con, args.snapshot_a, args.snapshot_b, timeframe=args.timeframe, limit=args.limit)
        print(json.dumps(rep, indent=2))
        return 0
    finally:
        con.close()


def cmd_runall(args) -> int:
    con = open_con(args.project_root)
    try:
        snap_ref, snap_key = resolve_snapshot(con, args.snapshot_id)
        if snap_ref is None:
            raise SystemExit(f"Snapshot not found: {args.snapshot_id}")
        ctx = LayerContext(
            run_id=args.run_id,
            snapshot_ref=snap_ref,
            snapshot_key=snap_key or str(args.snapshot_id),
            timeframe=args.timeframe,
            vs_currency=args.vs_currency,
            scope=args.scope,
        )
        layers = [SpotBasicLayer()]
        if ctx.timeframe == '15m':
            layers.append(Accel15mLayer())
        if ctx.timeframe == '1h':
            layers.append(Accel1hLayer())
        if ctx.timeframe == '4h':
            layers.append(Accel4hLayer())
        layers_out = run_layers(con, ctx, layers)
        post = run_composite_and_expanders(con, ctx, selection_id=args.selection_id)
        con.commit()
        print(json.dumps({"layers": layers_out, "post": post}, indent=2))
        return 0
    finally:
        con.close()

def cmd_step(args) -> int:
    con = open_con(args.project_root)
    try:
        snap_ref, snap_key = resolve_snapshot(con, args.snapshot_id)
        if snap_ref is None:
            raise SystemExit(f"Snapshot not found: {args.snapshot_id}")
        ctx = LayerContext(
            run_id=args.run_id,
            snapshot_ref=snap_ref,
            snapshot_key=snap_key or str(args.snapshot_id),
            timeframe=args.timeframe,
            vs_currency=args.vs_currency,
            scope=args.scope,
        )
        name = args.layer
        layers = {"spot_basic": SpotBasicLayer(), "accel_15m": Accel15mLayer(), "accel_1h": Accel1hLayer(), "accel_4h": Accel4hLayer()}
        if name not in layers:
            raise SystemExit(f"Unknown layer: {name}")
        out = run_layers(con, ctx, [layers[name]])
        if args.post:
            post = run_composite_and_expanders(con, ctx, selection_id=args.selection_id)
        else:
            post = None
        con.commit()
        print(json.dumps({"layers": out, "post": post}, indent=2))
        return 0
    finally:
        con.close()


def cmd_top(args) -> int:
    con = open_con(args.project_root)
    try:
        from core.db import resolve_snapshot
        snap_ref, snap_key = resolve_snapshot(con, args.snapshot_id)
        if snap_ref is None:
            raise SystemExit(f"Snapshot not found: {args.snapshot_id}")
        rows = con.execute(
            "SELECT unified_symbol, composite_score FROM composite_symbol_scores WHERE snapshot_ref=? AND timeframe=? ORDER BY composite_score DESC LIMIT ?;",
            (snap_ref, args.timeframe, int(args.limit)),
        ).fetchall()
        print(json.dumps({
            "snapshot_id": snap_key or str(args.snapshot_id),
            "snapshot_ref": snap_ref,
            "timeframe": args.timeframe,
            "top": [{"symbol": r[0], "score": r[1]} for r in rows]
        }, indent=2))
        return 0
    finally:
        con.close()


def cmd_retention(args) -> int:
    con = open_con(args.project_root)
    try:
        rep = prune_snapshots_keep_last(con, keep_last=args.keep, per_timeframe=(not args.global_keep))
        con.commit()
        print(json.dumps(rep, indent=2))
        return 0
    finally:
        con.close()


def cmd_expander_events(args) -> int:
    con = open_con(args.project_root)
    try:
        q = "SELECT unified_symbol, from_stage, to_stage, score, created_utc FROM expander_events ORDER BY expander_event_id DESC LIMIT ?;"
        rows = con.execute(q, (int(args.limit),)).fetchall()
        print(json.dumps([{"symbol":r[0], "from":r[1], "to":r[2], "score":r[3], "utc":r[4]} for r in rows], indent=2))
        return 0
    finally:
        con.close()


def cmd_rules(args) -> int:
    con = open_con(args.project_root)
    try:
        if args.action == "show":
            print(json.dumps(load_rules(con), indent=2))
        elif args.action == "set":
            # auto type by --type if provided
            typ = args.type
            val = args.value
            if typ == "float":
                val = float(val)
            elif typ == "int":
                val = int(float(val))
            elif typ == "json":
                val = json.loads(val)
            set_rule(con, args.key, val, typ=typ)
            con.commit()
            print("ok")
        elif args.action == "reset":
            reset_rules(con)
            con.commit()
            print("ok")
        return 0
    finally:
        con.close()

def cmd_snapshot_mtf(args) -> int:
    project_root = args.project_root
    def log_cb(msg: str):
        print(msg)
    tfs = [t.strip() for t in args.timeframes.split(",") if t.strip()]
    if not tfs:
        tfs = ["spot"]
    res = run_multi_timeframe(
        project_root=project_root,
        app_version=APP_VERSION,
        scope_text=args.scope,
        vs_currency=args.vs_currency,
        coins_limit=args.coins_limit,
        order=args.order,
        topnow_limit=args.topnow_limit,
        offline_mode=args.offline,
        log_cb=log_cb,
        timeframes=tfs,
        do_selection=(not args.no_selection),
    )
    print(json.dumps(res, indent=2))
    return 0


def cmd_scheduler(args) -> int:
    project_root = args.project_root
    def log_cb(msg: str):
        print(msg)
    tfs = [t.strip() for t in args.timeframes.split(",") if t.strip()]
    if not tfs:
        tfs = ["15m","1h","4h"]
    res = run_due_once(
        project_root=project_root,
        app_version=APP_VERSION,
        scope_text=args.scope,
        vs_currency=args.vs_currency,
        coins_limit=args.coins_limit,
        order=args.order,
        topnow_limit=args.topnow_limit,
        offline_mode=args.offline,
        log_cb=log_cb,
        timeframes=tfs,
        run_layers_after=(not args.no_layers),
    )
    print(json.dumps(res, indent=2))
    return 0


def cmd_scheduler_loop(args) -> int:
    project_root = args.project_root
    def log_cb(msg: str):
        print(msg)
    tfs = [t.strip() for t in args.timeframes.split(",") if t.strip()]
    if not tfs:
        tfs = ["15m","1h","4h"]
    run_loop(
        project_root=project_root,
        app_version=APP_VERSION,
        scope_text=args.scope,
        vs_currency=args.vs_currency,
        coins_limit=args.coins_limit,
        order=args.order,
        topnow_limit=args.topnow_limit,
        offline_mode=args.offline,
        log_cb=log_cb,
        timeframes=tfs,
        tick_s=args.tick,
        run_layers_after=(not args.no_layers),
    )
    return 0


def cmd_registry(args) -> int:
    con = open_con(args.project_root)
    try:
        if args.symbol:
            row = con.execute(
                "SELECT unified_symbol, stage, first_seen_utc, last_seen_utc, last_snapshot_ref, composite_score, reasons_json "
                "FROM expander_registry WHERE unified_symbol=?;",
                (args.symbol,),
            ).fetchone()
            print(json.dumps(None if not row else {
                "symbol": row[0], "stage": row[1], "first_seen_utc": row[2], "last_seen_utc": row[3],
                "last_snapshot_ref": row[4], "score": row[5], "reasons_json": row[6]
            }, indent=2))
            return 0
        rows = con.execute(
            "SELECT unified_symbol, stage, last_seen_utc, composite_score FROM expander_registry ORDER BY stage DESC, last_seen_utc DESC LIMIT ?;",
            (int(args.limit),),
        ).fetchall()
        print(json.dumps([{"symbol":r[0], "stage":r[1], "last_seen_utc":r[2], "score":r[3]} for r in rows], indent=2))
        return 0
    finally:
        con.close()

def cmd_obs(args) -> int:
    con = open_con(args.project_root)
    try:
        q = (
            "SELECT o.snapshot_ref, s.created_utc, o.timeframe, o.unified_symbol, o.stage, o.score "
            "FROM expander_observations o JOIN snapshots s ON s.snapshot_ref=o.snapshot_ref "
            "WHERE o.unified_symbol=? ORDER BY s.created_utc DESC LIMIT ?;"
        )
        rows = con.execute(q, (args.symbol, int(args.limit))).fetchall()
        print(json.dumps([{"snapshot_ref":r[0], "utc":r[1], "timeframe":r[2], "symbol":r[3], "stage":r[4], "score":r[5]} for r in rows], indent=2))
        return 0
    finally:
        con.close()


def cmd_decay(args) -> int:
    con = open_con(args.project_root)
    try:
        r = load_rules(con)
        rep = decay_registry_once(
            con,
            rules={
                "decay_step_hours": r.get("decay_step_hours", 6.0),
                "decay_max_drop": r.get("decay_max_drop", 2),
            },
        )
        con.commit()
        print(json.dumps(rep, indent=2))
        return 0
    finally:
        con.close()

def cmd_export_stage3(args) -> int:
    con = open_con(args.project_root)
    try:
        out = args.out
        if out.lower().endswith(".csv"):
            export_stage3_csv(con, out, min_stage=args.min_stage, limit=args.limit)
        else:
            export_stage3_json(con, out, min_stage=args.min_stage, limit=args.limit)
        print(out)
        return 0
    finally:
        con.close()


def cmd_alerts_reset(args) -> int:
    # Reset file-based alert dedup state
    import os
    state_path = os.path.join(args.project_root, "logs", ".alerts_state.json")
    try:
        if os.path.exists(state_path):
            os.remove(state_path)
        print("ok")
        return 0
    except Exception as e:
        raise SystemExit(str(e))


def cmd_health(args) -> int:
    con = open_con(args.project_root)
    try:
        rep = health_report(con, args.project_root)
        print(json.dumps(rep, indent=2))
        return 0
    finally:
        con.close()


def cmd_retention_auto(args) -> int:
    con = open_con(args.project_root)
    try:
        if args.action == "show":
            r = load_rules(con)
            print(json.dumps({
                "auto_retention": r.get("auto_retention", 1),
                "retention_keep": r.get("retention_keep", 300),
                "retention_global_keep": r.get("retention_global_keep", 0),
            }, indent=2))
            return 0
        if args.action == "set":
            set_rule(con, "auto_retention", int(args.enable), typ="int")
            set_rule(con, "retention_keep", int(args.keep), typ="int")
            set_rule(con, "retention_global_keep", int(args.global_keep), typ="int")
            con.commit()
            print("ok")
            return 0
        return 0
    finally:
        con.close()


def cmd_cleanup_auto(args) -> int:
    con = open_con(args.project_root)
    try:
        if args.action == "show":
            r = load_rules(con)
            print(json.dumps({
                "auto_cleanup": r.get("auto_cleanup", 1),
                "cleanup_keep_days": r.get("cleanup_keep_days", 14),
                "cleanup_keep_last": r.get("cleanup_keep_last", 50),
            }, indent=2))
            return 0
        if args.action == "set":
            set_rule(con, "auto_cleanup", int(args.enable), typ="int")
            set_rule(con, "cleanup_keep_days", int(args.keep_days), typ="int")
            set_rule(con, "cleanup_keep_last", int(args.keep_last), typ="int")
            con.commit()
            print("ok")
            return 0
        return 0
    finally:
        con.close()

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="nyosig-cli", description="NyoSig Cryptolytix CLI")
    p.add_argument("--project-root", default=get_project_root(), help="Override project root (or set NYOSIG_PROJECT_ROOT)")
    sub = p.add_subparsers(dest="cmd", required=True)

    schl = sub.add_parser("scheduler-loop", help="Looping scheduler (tick) that runs due timeframes repeatedly")
    schl.add_argument("--timeframes", default="15m,1h,4h")
    schl.add_argument("--scope", default="crypto_spot")
    schl.add_argument("--vs-currency", default="usd")
    schl.add_argument("--coins-limit", type=int, default=250)
    schl.add_argument("--order", default="market_cap_desc")
    schl.add_argument("--topnow-limit", type=int, default=100)
    schl.add_argument("--offline", action="store_true")
    schl.add_argument("--no-layers", action="store_true")
    schl.add_argument("--tick", type=int, default=30)
    schl.set_defaults(func=cmd_scheduler_loop)

    sch = sub.add_parser("scheduler", help="Run due timeframes once based on last snapshot timestamps (MVP scheduler)")
    sch.add_argument("--timeframes", default="15m,1h,4h")
    sch.add_argument("--scope", default="crypto_spot")
    sch.add_argument("--vs-currency", default="usd")
    sch.add_argument("--coins-limit", type=int, default=250)
    sch.add_argument("--order", default="market_cap_desc")
    sch.add_argument("--topnow-limit", type=int, default=100)
    sch.add_argument("--offline", action="store_true")
    sch.add_argument("--no-layers", action="store_true")
    sch.set_defaults(func=cmd_scheduler)

    sm = sub.add_parser("snapshot-mtf", help="Run snapshot/selection for multiple timeframe labels (scheduler should call at cadence)")
    sm.add_argument("--timeframes", default="spot,15m,1h,4h")
    sm.add_argument("--scope", default="crypto_spot")
    sm.add_argument("--vs-currency", default="usd")
    sm.add_argument("--coins-limit", type=int, default=250)
    sm.add_argument("--order", default="market_cap_desc")
    sm.add_argument("--topnow-limit", type=int, default=100)
    sm.add_argument("--offline", action="store_true")
    sm.add_argument("--no-selection", action="store_true")
    sm.set_defaults(func=cmd_snapshot_mtf)

    s = sub.add_parser("snapshot", help="Run snapshot + build TopNow selection")
    s.add_argument("--scope", default="crypto_spot")
    s.add_argument("--vs-currency", default="usd")
    s.add_argument("--coins-limit", type=int, default=250)
    s.add_argument("--order", default="market_cap_desc")
    s.add_argument("--topnow-limit", type=int, default=100)
    s.add_argument("--offline", action="store_true")
    s.set_defaults(func=cmd_snapshot)

    a = sub.add_parser("analysis", help="Prepare analysis scores for a selection")
    a.add_argument("selection_id", type=int)
    a.add_argument("snapshot_id")
    a.add_argument("--timeframe", default="spot")
    a.set_defaults(func=cmd_analysis)


    r = sub.add_parser("refresh", help="Refresh snapshot from a parent snapshot (creates new run+snapshot with lineage)")
    r.add_argument("parent_snapshot_id")
    r.add_argument("--scope", default="crypto_spot")
    r.add_argument("--vs-currency", default="usd")
    r.add_argument("--coins-limit", type=int, default=250)
    r.add_argument("--order", default="market_cap_desc")
    r.add_argument("--offline", action="store_true")
    r.add_argument("--reason", default="manual_refresh")
    r.set_defaults(func=cmd_refresh)


    rr = sub.add_parser("rules", help="Rules editor for expander engine")
    rrsub = rr.add_subparsers(dest="action", required=True)
    rshow = rrsub.add_parser("show")
    rshow.set_defaults(func=cmd_rules)
    rset = rrsub.add_parser("set")
    rset.add_argument("key")
    rset.add_argument("value")
    rset.add_argument("--type", default="float", choices=["float","int","str","json"])
    rset.set_defaults(func=cmd_rules)
    rreset = rrsub.add_parser("reset")
    rreset.set_defaults(func=cmd_rules)

    dec = sub.add_parser("decay", help="Apply simple registry decay (stage drops when not seen)")
    dec.set_defaults(func=cmd_decay)

    ex3 = sub.add_parser("export-stage3", help="Export stage>=N from expander_registry to JSON/CSV")
    ex3.add_argument("--min-stage", type=int, default=3)
    ex3.add_argument("--limit", type=int, default=500)
    ex3.add_argument("--out", default="stage3_export.json")
    ex3.set_defaults(func=cmd_export_stage3)

    reg = sub.add_parser("registry", help="Show global expander registry (current stages)")
    reg.add_argument("--limit", type=int, default=50)
    reg.add_argument("--symbol", default=None)
    reg.set_defaults(func=cmd_registry)

    obs = sub.add_parser("obs", help="Show expander observations for a symbol across snapshots")
    obs.add_argument("symbol")
    obs.add_argument("--limit", type=int, default=50)
    obs.set_defaults(func=cmd_obs)

    ee = sub.add_parser("expander-events", help="Show latest expander stage change events")
    ee.add_argument("--limit", type=int, default=50)
    ee.set_defaults(func=cmd_expander_events)

    ca = sub.add_parser("cleanup-auto", help="Configure scheduler auto cleanup for logs/exports (rules-backed)")
    cas = ca.add_subparsers(dest="action", required=True)
    cashow = cas.add_parser("show"); cashow.set_defaults(func=cmd_cleanup_auto)
    caset = cas.add_parser("set")
    caset.add_argument("--enable", type=int, default=1)
    caset.add_argument("--keep-days", type=int, default=14)
    caset.add_argument("--keep-last", type=int, default=50)
    caset.set_defaults(func=cmd_cleanup_auto)

    ra = sub.add_parser("retention-auto", help="Configure scheduler auto retention (rules-backed)")
    ras = ra.add_subparsers(dest="action", required=True)
    rashow = ras.add_parser("show"); rashow.set_defaults(func=cmd_retention_auto)
    raset = ras.add_parser("set")
    raset.add_argument("--enable", type=int, default=1)
    raset.add_argument("--keep", type=int, default=300)
    raset.add_argument("--global-keep", type=int, default=0)
    raset.set_defaults(func=cmd_retention_auto)

    rtt = sub.add_parser("retention", help="Prune old snapshots, keep last N (default per timeframe)")
    rtt.add_argument("--keep", type=int, default=200)
    rtt.add_argument("--global-keep", action="store_true", help="keep last N across all timeframes (not per timeframe)")
    rtt.set_defaults(func=cmd_retention)

    t = sub.add_parser("top", help="Show top composite scores for a snapshot")
    t.add_argument("snapshot_id")
    t.add_argument("--timeframe", default="spot")
    t.add_argument("--limit", type=int, default=25)
    t.set_defaults(func=cmd_top)

    ra = sub.add_parser("run-all", help="Run all layers + composite + expander promotion (step-mode engine)")
    ra.add_argument("run_id", type=int)
    ra.add_argument("snapshot_id")
    ra.add_argument("--selection-id", type=int, default=None)
    ra.add_argument("--timeframe", default="spot")
    ra.add_argument("--vs-currency", default="usd")
    ra.add_argument("--scope", default="crypto_spot")
    ra.set_defaults(func=cmd_runall)

    st = sub.add_parser("step", help="Run single layer (optional post composite/expander)")
    st.add_argument("run_id", type=int)
    st.add_argument("snapshot_id")
    st.add_argument("layer", help="layer name, e.g. spot_basic")
    st.add_argument("--selection-id", type=int, default=None)
    st.add_argument("--timeframe", default="spot")
    st.add_argument("--vs-currency", default="usd")
    st.add_argument("--scope", default="crypto_spot")
    st.add_argument("--post", action="store_true", help="also run composite+expander after layer")
    st.set_defaults(func=cmd_step)

    d = sub.add_parser("diff", help="Diff two snapshots (b - a) summary")
    d.add_argument("snapshot_a")
    d.add_argument("snapshot_b")
    d.add_argument("--timeframe", default="spot")
    d.add_argument("--limit", type=int, default=30)
    d.set_defaults(func=cmd_diff)

    e = sub.add_parser("export", help="Export selection CSV")
    e.add_argument("selection_id", type=int)
    e.add_argument("snapshot_id")
    e.add_argument("--timeframe", default="spot")
    e.add_argument("--out", default="exports/selection.csv")
    e.set_defaults(func=cmd_export)

    w = sub.add_parser("watchlist", help="Watchlist operations")
    wsub = w.add_subparsers(dest="action", required=True)

    wa = wsub.add_parser("add")
    wa.add_argument("symbol")
    wa.add_argument("--tag", default="")
    wa.set_defaults(func=cmd_watchlist)

    wr = wsub.add_parser("remove")
    wr.add_argument("symbol")
    wr.set_defaults(func=cmd_watchlist)

    wl = wsub.add_parser("list")
    wl.set_defaults(func=cmd_watchlist)

    wf = wsub.add_parser("refresh")
    wf.add_argument("snapshot_id")
    wf.add_argument("--timeframe", default="spot")
    wf.set_defaults(func=cmd_watchlist)

    wA = wsub.add_parser("alerts")
    wA.add_argument("--limit", type=int, default=200)
    wA.set_defaults(func=cmd_watchlist)

    return p

def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return int(args.func(args))

if __name__ == "__main__":
    raise SystemExit(main())

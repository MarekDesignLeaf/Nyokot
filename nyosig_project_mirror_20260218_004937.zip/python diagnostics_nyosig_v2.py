#!/usr/bin/env python3
from __future__ import annotations

import os
import sys
import time
import sqlite3
import traceback
from typing import List, Optional

LOG: List[str] = []
SQL_RING: List[str] = []
SQL_RING_MAX = 200  # posledn�ch 200 SQL statement�

def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line)
    LOG.append(line)

def ring_sql(stmt: str) -> None:
    s = (stmt or "").strip()
    if not s:
        return
    SQL_RING.append(s)
    if len(SQL_RING) > SQL_RING_MAX:
        del SQL_RING[0:len(SQL_RING) - SQL_RING_MAX]

def looks_like_root(path: str) -> bool:
    return (
        os.path.isdir(os.path.join(path, "core")) and
        os.path.isdir(os.path.join(path, "app"))
    )

def find_project_root() -> str:
    """
    Finds project root robustly:
    1) Walk up from script location (best if saved inside project).
    2) Walk up from current working directory.
    3) Check well-known default paths on Android.
    """
    candidates: List[str] = []

    # 1) script dir (works if you saved it into the project)
    try:
        script_dir = os.path.abspath(os.path.dirname(__file__))
        candidates.append(script_dir)
    except Exception:
        pass

    # 2) cwd
    candidates.append(os.path.abspath(os.getcwd()))

    # Walk up from each candidate
    for start in candidates:
        cur = start
        for _ in range(15):
            if looks_like_root(cur):
                return cur
            parent = os.path.dirname(cur)
            if parent == cur:
                break
            cur = parent

    # 3) common Android locations (your real one)
    defaults = [
        "/storage/emulated/0/NyoSig/NyoSig_Cryptolytix",
        "/storage/emulated/0/NyoSig/NyoSig_Cryptolytix/app",
    ]
    for d in defaults:
        d = os.path.abspath(d)
        if looks_like_root(d):
            return d

    raise RuntimeError(
        "Cannot find project root. Expected core/ and app/ folders.\n"
        "Put this script into /storage/emulated/0/NyoSig/NyoSig_Cryptolytix/ and run again."
    )

def dump_sqlite_master(con: sqlite3.Connection, name: str) -> None:
    row = con.execute(
        "SELECT sql FROM sqlite_master WHERE type='table' AND name=?;",
        (name,),
    ).fetchone()
    sql = row[0] if row and row[0] else None
    log(f"sqlite_master[{name}].sql = {sql}")

def table_cols(con: sqlite3.Connection, name: str) -> List[str]:
    row = con.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name=?;",
        (name,),
    ).fetchone()
    if not row:
        return []
    cur = con.execute(f"PRAGMA table_info({name});")
    return [r[1] for r in cur.fetchall()]

def save_logs(project_root: str) -> str:
    logs_dir = os.path.join(project_root, "logs")
    os.makedirs(logs_dir, exist_ok=True)
    path = os.path.join(logs_dir, "diagnostics_log.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(LOG) + "\n\n=== LAST SQL (ring) ===\n")
        f.write("\n".join(SQL_RING) + "\n")
    return path

def main() -> int:
    log("=== Nyosig diagnostics start ===")
    log(f"python: {sys.version.split()[0]}")
    log(f"cwd: {os.getcwd()}")

    try:
        project_root = find_project_root()
    except Exception:
        log("FATAL:\n" + traceback.format_exc())
        return 2

    log(f"project_root: {project_root}")

    if project_root not in sys.path:
        sys.path.insert(0, project_root)

    # Imports and real file paths (to catch �running old files�)
    try:
        from core import config as core_config
        from core import db as core_db
        from core import pipeline as core_pipeline
        log(f"core.db.__file__ = {getattr(core_db, '__file__', '??')}")
        log(f"core.pipeline.__file__ = {getattr(core_pipeline, '__file__', '??')}")
        log(f"core.config.__file__ = {getattr(core_config, '__file__', '??')}")
    except Exception:
        log("IMPORT FAILED:\n" + traceback.format_exc())
        out = save_logs(project_root)
        log(f"log saved: {out}")
        return 3

    # db_path from config
    try:
        paths = core_config.make_paths(project_root)
        db_path = getattr(paths, "db_path", None) or os.path.join(project_root, "db", "nyosig_cryptolytix.db")
    except Exception:
        db_path = os.path.join(project_root, "db", "nyosig_cryptolytix.db")

    log(f"db_path: {db_path}")

    con: Optional[sqlite3.Connection] = None
    try:
        if hasattr(core_db, "db_connect"):
            con = core_db.db_connect(db_path)  # type: ignore
        else:
            os.makedirs(os.path.dirname(db_path), exist_ok=True)
            con = sqlite3.connect(db_path)
            con.execute("PRAGMA foreign_keys = ON;")

        con.set_trace_callback(ring_sql)
        log("DB connected OK")

        # Absolute truth about schema
        for t in ["snapshots", "market_snapshots", "raw_snapshots", "runs", "topnow_selection", "state_log"]:
            dump_sqlite_master(con, t)
            log(f"cols[{t}] = {table_cols(con, t)}")

        # Boot steps � report exact fail point
        def call(step: str) -> None:
            fn = getattr(core_db, step, None)
            if not fn:
                log(f"boot {step}: MISSING")
                return
            try:
                fn(con)
                con.commit()
                log(f"boot {step}: OK")
            except Exception as e:
                log(f"boot {step}: FAIL -> {type(e).__name__}: {e}")
                log("TRACEBACK:\n" + traceback.format_exc())

        for step in ["ensure_core_schema", "ensure_core_indexes", "ensure_snapshot_schema", "ensure_indexes", "require_schema"]:
            call(step)

        log("=== AFTER BOOT ===")
        for t in ["snapshots", "market_snapshots", "raw_snapshots"]:
            dump_sqlite_master(con, t)
            log(f"cols[{t}] = {table_cols(con, t)}")

        # Offline pipeline test with SQL trace
        log("=== Pipeline offline test ===")
        def cb(m: str) -> None:
            log("pipeline: " + m)

        fn = getattr(core_pipeline, "run_snapshot_and_topnow", None) or getattr(core_pipeline, "run_pipeline", None)
        if not fn:
            log("pipeline: no entrypoint found")
        else:
            try:
                try:
                    out = fn(
                        project_root=project_root,
                        app_version="diagnostics",
                        scope_text="crypto_spot",
                        vs_currency="usd",
                        coins_limit=25,
                        order="market_cap_desc",
                        topnow_limit=10,
                        offline_mode=True,
                        log_cb=cb,
                    )
                except TypeError:
                    out = fn(
                        project_root=project_root,
                        scope="crypto_spot",
                        vs_currency="usd",
                        coins_limit=25,
                        order="market_cap_desc",
                        topnow_limit=10,
                        offline_mode=True,
                        log_cb=cb,
                    )
                log(f"pipeline: OK -> {out}")
            except Exception as e:
                log(f"pipeline: FAIL -> {type(e).__name__}: {e}")
                log("TRACEBACK:\n" + traceback.format_exc())

    except Exception:
        log("DB/BOOT failed:\n" + traceback.format_exc())
    finally:
        try:
            if con:
                con.close()
        except Exception:
            pass

    out = save_logs(project_root)
    log(f"log saved: {out}")
    log("=== Nyosig diagnostics end ===")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
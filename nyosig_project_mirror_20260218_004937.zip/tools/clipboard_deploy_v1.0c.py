#!/usr/bin/env python3
# clipboard_deploy_v1.0c.py
# ASCII only. Robust clipboard error logging.

import os
import re
import sys
import subprocess
import traceback
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog

EXPECTED_ROOT = "/storage/emulated/0/NyoSig/NyoSig_Cryptolytix"
ERROR_LOG = "clipboard_deploy_error.txt"

VERSION_RE = re.compile(r"\bv(\d+)\.(\d+)([a-z])?\b", re.IGNORECASE)
FNAME_WITH_VER_RE = re.compile(r"([A-Za-z0-9_.\-]+_v\d+\.\d+[a-z]?\.py)\b")

def log_error(msg):
    try:
        with open(ERROR_LOG, "a", encoding="ascii", errors="replace") as f:
            f.write(msg + "\n")
    except Exception:
        pass

def has_non_ascii(s):
    try:
        s.encode("ascii")
        return False
    except Exception:
        return True

def letter_to_int(ch):
    if not ch:
        return 0
    ch = ch.lower()
    return ord(ch) - ord("a") + 1 if "a" <= ch <= "z" else 0

def version_key(vt):
    return (vt[0], vt[1], letter_to_int(vt[2]))

def format_version(vt):
    return f"v{vt[0]}.{vt[1]}{vt[2]}" if vt[2] else f"v{vt[0]}.{vt[1]}"

def next_patch(vt):
    maj, minor, letter = vt
    if not letter:
        return (maj, minor, "a")
    n = letter_to_int(letter) + 1
    if n > 26:
        return (maj, minor + 1, "a")
    return (maj, minor, chr(ord("a") + n - 1))

def next_minor(vt):
    return (vt[0], vt[1] + 1, "a")

def next_major(vt):
    return (vt[0] + 1, 0, "a")

def allowed_next_versions(latest_vt):
    return [next_patch(latest_vt), next_minor(latest_vt), next_major(latest_vt)]

def find_latest_versioned_script(root_dir):
    candidates = []
    for name in os.listdir(root_dir):
        if not name.lower().endswith(".py"):
            continue
        m = re.search(r"_v(\d+)\.(\d+)([a-z])?\.py$", name, re.IGNORECASE)
        if not m:
            continue
        vt = (int(m.group(1)), int(m.group(2)), (m.group(3) or "").lower())
        candidates.append((version_key(vt), name, vt))
    if not candidates:
        return None
    candidates.sort(reverse=True)
    return candidates[0][1], candidates[0][2]

def unique_filename(root_dir, filename):
    base, ext = os.path.splitext(filename)
    if not os.path.exists(os.path.join(root_dir, filename)):
        return filename
    i = 1
    while True:
        cand = f"{base}_{i}{ext}"
        if not os.path.exists(os.path.join(root_dir, cand)):
            return cand
        i += 1

def extract_filename_from_text(text):
    m = FNAME_WITH_VER_RE.search(text)
    return m.group(1) if m else ""

def extract_version_from_filename(filename):
    m = re.search(r"_v(\d+)\.(\d+)([a-z])?\.py$", filename, re.IGNORECASE)
    if not m:
        return None
    return (int(m.group(1)), int(m.group(2)), (m.group(3) or "").lower())

def extract_any_version_from_text(text):
    m = VERSION_RE.search(text)
    if not m:
        return None
    return (int(m.group(1)), int(m.group(2)), (m.group(3) or "").lower())

class App(tk.Tk):
    def __init__(self, root_dir):
        super().__init__()
        self.root_dir = root_dir
        self.title("Clipboard deploy")
        self.geometry("760x420")

        try:
            self.lift()
            self.attributes("-topmost", True)
            self.after(250, lambda: self.attributes("-topmost", False))
        except Exception:
            pass

        latest = find_latest_versioned_script(self.root_dir)
        if not latest:
            messagebox.showerror("Error", "No versioned scripts found in root.")
            self.destroy()
            return

        self.latest_name, self.latest_vt = latest
        self.allowed_next = allowed_next_versions(self.latest_vt)

        frm = ttk.Frame(self, padding=10)
        frm.pack(fill="both", expand=True)

        ttk.Label(frm, text="Latest detected:", font=("TkDefaultFont", 12, "bold")).pack(anchor="w")
        ttk.Label(frm, text=self.latest_name).pack(anchor="w")
        ttk.Label(frm, text="Allowed next: " + ", ".join(format_version(v) for v in self.allowed_next)).pack(anchor="w", pady=(0,10))

        btn_row = ttk.Frame(frm)
        btn_row.pack(fill="x", pady=10)

        ttk.Button(btn_row, text="Vlozit ze schranky", command=self.on_paste).pack(side="left")
        ttk.Button(btn_row, text="Test clipboard", command=self.on_test_clip).pack(side="left", padx=8)

        self.status = tk.StringVar(value="Ready")
        ttk.Label(frm, textvariable=self.status).pack(anchor="w", pady=(6,6))

        self.err_box = tk.Text(frm, height=12, wrap="word")
        self.err_box.pack(fill="both", expand=True)
        self.err_box.insert("end", "If it crashes, check clipboard_deploy_error.txt in project root.\n")

    def set_err(self, text):
        self.err_box.delete("1.0", "end")
        self.err_box.insert("end", text)

    def on_test_clip(self):
        try:
            t = self.clipboard_get()
            if not t or not t.strip():
                self.set_err("Clipboard empty.")
                return
            head = t[:500]
            self.set_err("Clipboard read OK. First 500 chars:\n\n" + head)
        except Exception as e:
            tb = traceback.format_exc()
            self.set_err("Clipboard read FAILED:\n" + str(e) + "\n\n" + tb)
            log_error("TEST_CLIP_ERROR:\n" + str(e) + "\n" + tb)

    def on_paste(self):
        try:
            self._on_paste_impl()
        except Exception as e:
            tb = traceback.format_exc()
            self.set_err("CRASH in on_paste:\n" + str(e) + "\n\n" + tb)
            log_error("ON_PASTE_CRASH:\n" + str(e) + "\n" + tb)
            try:
                messagebox.showerror("Error", "Crash. See clipboard_deploy_error.txt")
            except Exception:
                pass

    def _on_paste_impl(self):
        try:
            text = self.clipboard_get()
        except Exception as e:
            tb = traceback.format_exc()
            self.set_err("Clipboard not accessible:\n" + str(e) + "\n\n" + tb)
            log_error("CLIPBOARD_GET_ERROR:\n" + str(e) + "\n" + tb)
            messagebox.showerror("Error", "Clipboard not accessible. Try copy then tap within 5 seconds.")
            return

        if not text or not text.strip():
            messagebox.showerror("Error", "Clipboard is empty.")
            return

        if has_non_ascii(text):
            messagebox.showerror("Error", "Clipboard contains non-ASCII characters.")
            return

        fname_in_text = extract_filename_from_text(text)
        vt_in_text = extract_version_from_filename(fname_in_text) if fname_in_text else None
        if vt_in_text is None:
            vt_in_text = extract_any_version_from_text(text)

        if vt_in_text is None:
            messagebox.showerror("Error", "No version detected in clipboard.")
            return

        prefix = self.latest_name.split("_v")[0]
        proposed_name = os.path.basename(fname_in_text) if fname_in_text else f"{prefix}_v{vt_in_text[0]}.{vt_in_text[1]}{vt_in_text[2]}.py"

        if vt_in_text not in self.allowed_next:
            best = self.allowed_next[0]
            best_name = f"{prefix}_v{best[0]}.{best[1]}{best[2]}.py"
            choice = messagebox.askyesnocancel(
                "Version mismatch",
                "YES = auto-fix to " + best_name + "\nNO = keep clipboard filename/version\nCANCEL = custom filename"
            )
            if choice is None:
                custom = simpledialog.askstring("Custom filename", "Enter filename (must end .py):")
                if not custom:
                    return
                custom = custom.strip()
                if not custom.lower().endswith(".py"):
                    messagebox.showerror("Error", "Filename must end with .py")
                    return
                save_name = os.path.basename(custom)
            elif choice is True:
                save_name = best_name
            else:
                save_name = proposed_name
        else:
            save_name = proposed_name

        save_name = unique_filename(self.root_dir, save_name)
        save_path = os.path.join(self.root_dir, save_name)

        with open(save_path, "w", encoding="ascii", errors="strict") as f:
            f.write(text)

        subprocess.Popen([sys.executable, save_path], cwd=self.root_dir)

        self.status.set("Saved and launched: " + save_name)
        messagebox.showinfo("OK", "Saved and launched:\n" + save_name)
        self.destroy()

def main():
    root_dir = os.getcwd()
    app = App(root_dir)
    app.mainloop()

if __name__ == "__main__":
    main()
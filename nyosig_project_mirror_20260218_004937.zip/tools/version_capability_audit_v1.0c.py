# Force UTF-8 output on Android/Pydroid to avoid UnicodeEncodeError
import sys
try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

#!/usr/bin/env python3
# version_capability_audit_v1.0c.py
# ASCII-only script that analyses Python GUI versions by CONTENT (not filename).
# Produces a report of "core functions and parameters" per file and diffs across versions.
#
# Usage:
#   python3 version_capability_audit_v1.0c.py /path/to/versions_dir
#   python3 version_capability_audit_v1.0c.py .
#
# Output:
#   ./reports/version_capability_audit_<UTC_TIMESTAMP>.txt
#   ./reports/version_capability_audit_<UTC_TIMESTAMP>.json
#
# Notes:
# - No reliance on filename: version is inferred from header text where possible, else "unknown".
# - Focuses on FUNCTIONALITY + PARAMETERS, not UI placement.
# - Safe: does not execute analysed files.

import os
import re
import ast
import json
import hashlib
import time
from dataclasses import dataclass, asdict
from typing import Dict, Any, List, Optional, Tuple

VERSION_RE = re.compile(r"\bv(\d+)\.(\d+)([a-z])?\b", re.IGNORECASE)
SHEBANG_RE = re.compile(r"^#!.*python", re.IGNORECASE)
ASCII_ONLY = True

CORE_FUNCS = [
    "apply_load",
    "apply_filters",
    "build_top",
    "commit_top_to_db",
    "analyse_top",
    "top_score",
    "db_connect",
    "ensure_top_tables",
]

CORE_TABLES = [
    "runs",
    "spot_markets",
    "top_sets",
    "top_set_items",
]

POSSIBLE_CG_HINTS = [
    "coingecko",
    "api.coingecko.com",
    "CoinGecko",
]

REQUESTS_HINTS = [
    "requests.get",
    "urllib.request",
    "http.client",
]

@dataclass
class FileFeature:
    path: str
    sha256: str
    inferred_version: str
    shebang_python: bool
    ascii_only: bool

    # Core capability flags
    has_core_funcs: Dict[str, bool]
    has_gui_tk: bool
    has_sqlite: bool
    has_network_hints: bool
    has_coingecko_hints: bool

    # Parameters / constants
    constants: Dict[str, Any]          # TIMEFRAMES, MODES, PROJECT_ROOT, DB_PATH, etc.
    exclude_stables: List[str]         # stable list if present
    buttons_text: List[str]            # button labels found in code
    combobox_values: Dict[str, List[str]]  # variable -> values list (best-effort)

    # DB access
    sql_tables_referenced: List[str]
    sql_queries_count: int

    # Top scoring fingerprints (so we can detect changes)
    top_score_fingerprint: str         # hash of top_score function body if present
    build_top_fingerprint: str         # hash of build_top function body if present

def _read_text(path: str) -> bytes:
    with open(path, "rb") as f:
        return f.read()

def _is_ascii(b: bytes) -> bool:
    if b.startswith(b"\xef\xbb\xbf"):
        b = b[3:]
    return all(x <= 127 for x in b)

def _sha256(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def _infer_version_from_text(text: str) -> str:
    # Try header first (first ~30 lines)
    head = "\n".join(text.splitlines()[:40])
    m = VERSION_RE.search(head)
    if m:
        major = int(m.group(1))
        minor = int(m.group(2))
        letter = (m.group(3) or "").lower()
        return f"v{major}.{minor}{letter}"
    # fallback: search whole file
    m = VERSION_RE.search(text)
    if m:
        major = int(m.group(1))
        minor = int(m.group(2))
        letter = (m.group(3) or "").lower()
        return f"v{major}.{minor}{letter}"
    return "unknown"

def _node_source_segment(text: str, node: ast.AST) -> str:
    try:
        seg = ast.get_source_segment(text, node)
        return seg or ""
    except Exception:
        return ""

def _fingerprint_function(text: str, fn_node: ast.FunctionDef) -> str:
    body_src = _node_source_segment(text, fn_node)
    if not body_src:
        # rough fallback: name + lineno + col offsets
        body_src = f"{fn_node.name}@{getattr(fn_node,'lineno',0)}"
    return hashlib.sha256(body_src.encode("utf-8", errors="ignore")).hexdigest()[:16]

class FeatureExtractor(ast.NodeVisitor):
    def __init__(self, text: str):
        self.text = text
        self.funcs: Dict[str, ast.FunctionDef] = {}
        self.imports: List[str] = []
        self.constants: Dict[str, Any] = {}
        self.exclude_stables: List[str] = []
        self.buttons_text: List[str] = []
        self.combobox_values: Dict[str, List[str]] = {}
        self.sql_tables: set = set()
        self.sql_queries_count: int = 0
        self.network_hints: bool = False
        self.coingecko_hints: bool = False

    def visit_Import(self, node: ast.Import):
        for n in node.names:
            self.imports.append(n.name)
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom):
        mod = node.module or ""
        self.imports.append(mod)
        self.generic_visit(node)

    def visit_FunctionDef(self, node: ast.FunctionDef):
        self.funcs[node.name] = node
        self.generic_visit(node)

    def visit_Assign(self, node: ast.Assign):
        # capture simple constants: NAME = <literal or list/set of literals>
        try:
            if len(node.targets) != 1:
                return
            t = node.targets[0]
            if not isinstance(t, ast.Name):
                return
            name = t.id
            val = self._literal_value(node.value)
            if val is not None:
                self.constants[name] = val
                if name.upper().startswith("EXCLUDE_STABLE") and isinstance(val, (list, set, tuple)):
                    self.exclude_stables = sorted([str(x) for x in val])
        finally:
            self.generic_visit(node)

    def _literal_value(self, node: ast.AST):
        # Return python value for basic literals/lists/sets/tuples/dicts
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, (ast.List, ast.Tuple, ast.Set)):
            items = []
            for el in node.elts:
                v = self._literal_value(el)
                if v is None:
                    return None
                items.append(v)
            if isinstance(node, ast.Set):
                return set(items)
            if isinstance(node, ast.Tuple):
                return tuple(items)
            return items
        if isinstance(node, ast.Dict):
            out = {}
            for k, v in zip(node.keys, node.values):
                kk = self._literal_value(k)
                vv = self._literal_value(v)
                if kk is None or vv is None:
                    return None
                out[kk] = vv
            return out
        return None

    def visit_Call(self, node: ast.Call):
        # detect tkinter buttons / ttk buttons
        try:
            fn = node.func
            fn_name = ""
            if isinstance(fn, ast.Attribute):
                fn_name = fn.attr
            elif isinstance(fn, ast.Name):
                fn_name = fn.id

            # buttons
            if fn_name in ("Button",):
                for kw in node.keywords:
                    if kw.arg == "text":
                        txt = self._literal_value(kw.value)
                        if isinstance(txt, str) and txt not in self.buttons_text:
                            self.buttons_text.append(txt)

            # combobox values
            if fn_name in ("Combobox",):
                values = None
                for kw in node.keywords:
                    if kw.arg == "values":
                        vv = self._literal_value(kw.value)
                        if isinstance(vv, (list, tuple)):
                            values = [str(x) for x in vv]
                if values:
                    key = f"Combobox@line{getattr(node,'lineno',0)}"
                    self.combobox_values[key] = values

            # SQL references
            if fn_name in ("execute", "executemany"):
                if node.args and isinstance(node.args[0], ast.Constant) and isinstance(node.args[0].value, str):
                    sql = node.args[0].value.lower()
                    self.sql_queries_count += 1
                    for t in CORE_TABLES:
                        if re.search(r"\b" + re.escape(t) + r"\b", sql):
                            self.sql_tables.add(t)
        finally:
            self.generic_visit(node)

    def visit_Constant(self, node: ast.Constant):
        try:
            if isinstance(node.value, str):
                s = node.value.lower()
                if any(h in s for h in REQUESTS_HINTS):
                    self.network_hints = True
                if any(h in s for h in POSSIBLE_CG_HINTS):
                    self.coingecko_hints = True
        finally:
            self.generic_visit(node)

def analyse_file(path: str) -> Optional[FileFeature]:
    try:
        b = _read_text(path)
    except Exception:
        return None

    ascii_ok = _is_ascii(b) if ASCII_ONLY else True
    try:
        text = b.decode("utf-8", errors="replace")
    except Exception:
        text = b.decode("latin-1", errors="replace")

    shebang = False
    first_line = text.splitlines()[0] if text.splitlines() else ""
    if SHEBANG_RE.search(first_line or ""):
        shebang = True

    inferred_version = _infer_version_from_text(text)
    sha = _sha256(b)

    # parse AST
    try:
        tree = ast.parse(text)
    except Exception:
        # file is syntactically broken; still record minimal info
        return FileFeature(
            path=path,
            sha256=sha,
            inferred_version=inferred_version,
            shebang_python=shebang,
            ascii_only=ascii_ok,
            has_core_funcs={k: False for k in CORE_FUNCS},
            has_gui_tk=("tkinter" in text.lower()),
            has_sqlite=("sqlite3" in text.lower()),
            has_network_hints=any(h in text.lower() for h in REQUESTS_HINTS),
            has_coingecko_hints=any(h in text.lower() for h in POSSIBLE_CG_HINTS),
            constants={},
            exclude_stables=[],
            buttons_text=[],
            combobox_values={},
            sql_tables_referenced=[],
            sql_queries_count=0,
            top_score_fingerprint="",
            build_top_fingerprint="",
        )

    ex = FeatureExtractor(text)
    ex.visit(tree)

    has_core = {k: (k in ex.funcs) for k in CORE_FUNCS}
    has_gui = ("tkinter" in ex.imports) or ("tkinter" in text.lower()) or ("ttk" in text.lower())
    has_sqlite = ("sqlite3" in ex.imports) or ("sqlite3" in text.lower())
    has_network = ex.network_hints or any(h in text.lower() for h in REQUESTS_HINTS)
    has_cg = ex.coingecko_hints or any(h in text.lower() for h in POSSIBLE_CG_HINTS)

    top_fp = ""
    if "top_score" in ex.funcs:
        top_fp = _fingerprint_function(text, ex.funcs["top_score"])
    build_fp = ""
    if "build_top" in ex.funcs:
        build_fp = _fingerprint_function(text, ex.funcs["build_top"])

    # pick key constants we care about (if present)
    constants = {}
    for k in ("PROJECT_ROOT", "DB_PATH", "TIMEFRAMES", "MODES", "FONT_SIZE_DEFAULT", "FONT_SIZE_MIN", "FONT_SIZE_MAX"):
        if k in ex.constants:
            v = ex.constants[k]
            if isinstance(v, set):
                v = sorted(list(v))
            constants[k] = v

    return FileFeature(
        path=path,
        sha256=sha,
        inferred_version=inferred_version,
        shebang_python=shebang,
        ascii_only=ascii_ok,
        has_core_funcs=has_core,
        has_gui_tk=bool(has_gui),
        has_sqlite=bool(has_sqlite),
        has_network_hints=bool(has_network),
        has_coingecko_hints=bool(has_cg),
        constants=constants,
        exclude_stables=ex.exclude_stables,
        buttons_text=sorted(ex.buttons_text),
        combobox_values=ex.combobox_values,
        sql_tables_referenced=sorted(list(ex.sql_tables)),
        sql_queries_count=ex.sql_queries_count,
        top_score_fingerprint=top_fp,
        build_top_fingerprint=build_fp,
    )

def scan_dir(root: str) -> List[str]:
    out = []
    for base, _, files in os.walk(root):
        for fn in files:
            if fn.lower().endswith(".py"):
                out.append(os.path.join(base, fn))
    return sorted(out)

def _short(p: str, root: str) -> str:
    try:
        rp = os.path.relpath(p, root)
        return rp
    except Exception:
        return p

def make_report(features: List[FileFeature], root: str) -> Tuple[str, Dict[str, Any]]:
    # Sort: inferred version if possible else by sha
    def vkey(ff: FileFeature):
        m = VERSION_RE.search(ff.inferred_version if ff.inferred_version.startswith("v") else ("v" + ff.inferred_version))
        if not m:
            return (999, 999, 999, ff.sha256)
        maj = int(m.group(1))
        minr = int(m.group(2))
        let = (m.group(3) or "").lower()
        li = 0 if not let else (ord(let) - ord("a") + 1)
        return (maj, minr, li, ff.sha256)

    feats = sorted(features, key=vkey, reverse=True)

    matrix = []
    for f in feats:
        row = {
            "file": _short(f.path, root),
            "version": f.inferred_version,
            "sha16": f.sha256[:16],
            "ascii": f.ascii_only,
            "tk": f.has_gui_tk,
            "sqlite": f.has_sqlite,
            "net": f.has_network_hints,
            "cg": f.has_coingecko_hints,
            "sql_tables": ",".join(f.sql_tables_referenced),
            "sql_q": f.sql_queries_count,
            "top_score_fp": f.top_score_fingerprint,
            "build_top_fp": f.build_top_fingerprint,
        }
        for k in CORE_FUNCS:
            row[f"fn:{k}"] = bool(f.has_core_funcs.get(k))
        matrix.append(row)

    diffs = []
    prev = None
    for f in feats:
        if prev is None:
            prev = f
            continue
        d = {"from": prev.inferred_version, "to": f.inferred_version, "from_file": _short(prev.path, root), "to_file": _short(f.path, root), "changes": []}

        for ck in ("TIMEFRAMES", "MODES", "PROJECT_ROOT", "DB_PATH"):
            pv = prev.constants.get(ck, None)
            nv = f.constants.get(ck, None)
            if pv != nv:
                d["changes"].append(f"CONST {ck} changed")

        for fn in CORE_FUNCS:
            pv = bool(prev.has_core_funcs.get(fn))
            nv = bool(f.has_core_funcs.get(fn))
            if pv != nv:
                d["changes"].append(f"FUNC {fn} {'added' if nv else 'removed'}")

        if prev.top_score_fingerprint != f.top_score_fingerprint and (prev.top_score_fingerprint and f.top_score_fingerprint):
            d["changes"].append("top_score logic changed (fingerprint)")
        if prev.build_top_fingerprint != f.build_top_fingerprint and (prev.build_top_fingerprint and f.build_top_fingerprint):
            d["changes"].append("build_top logic changed (fingerprint)")

        if set(prev.sql_tables_referenced) != set(f.sql_tables_referenced):
            d["changes"].append("SQL table usage changed")

        if d["changes"]:
            diffs.append(d)
        prev = f

    lines = []
    lines.append("Version capability audit (content-based)")
    lines.append("Root: " + os.path.abspath(root))
    lines.append("UTC: " + time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
    lines.append("Files analysed: " + str(len(feats)))
    lines.append("")

    for f in feats:
        lines.append("FILE: " + _short(f.path, root))
        lines.append("  version: " + f.inferred_version)
        lines.append("  sha256: " + f.sha256)
        lines.append("  ascii_only_ok: " + str(bool(f.ascii_only)))
        lines.append("  gui_tk: " + str(bool(f.has_gui_tk)) + "  sqlite: " + str(bool(f.has_sqlite)) + "  network_hints: " + str(bool(f.has_network_hints)) + "  coingecko_hints: " + str(bool(f.has_coingecko_hints)))
        if f.constants:
            lines.append("  constants: " + json.dumps(f.constants, ensure_ascii=True))
        if f.exclude_stables:
            lines.append("  exclude_stables_count: " + str(len(f.exclude_stables)))
        if f.buttons_text:
            lines.append("  buttons: " + ", ".join(f.buttons_text))
        if f.combobox_values:
            lines.append("  combobox_values: " + json.dumps(f.combobox_values, ensure_ascii=True))
        lines.append("  sql_tables: " + (", ".join(f.sql_tables_referenced) if f.sql_tables_referenced else "(none)") + "  sql_queries: " + str(f.sql_queries_count))
        lines.append("  top_score_fp: " + (f.top_score_fingerprint or "(none)") + "  build_top_fp: " + (f.build_top_fingerprint or "(none)"))
        lines.append("  core_funcs: " + ", ".join([fn for fn in CORE_FUNCS if f.has_core_funcs.get(fn)]) if any(f.has_core_funcs.values()) else "  core_funcs: (none)")
        lines.append("")

    if diffs:
        lines.append("DIFF SUMMARY (adjacent by version ordering)")
        for d in diffs:
            lines.append(f"  {d['from']} -> {d['to']}")
            lines.append("    from_file: " + d["from_file"])
            lines.append("    to_file:   " + d["to_file"])
            for c in d["changes"]:
                lines.append("    - " + c)
        lines.append("")
    else:
        lines.append("DIFF SUMMARY: no functional deltas detected by this heuristic.")
        lines.append("")

    payload = {
        "root": os.path.abspath(root),
        "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "files": [asdict(f) for f in feats],
        "matrix": matrix,
        "diffs": diffs,
        "notes": {
            "method": "AST parse + heuristics; does not execute files; ignores UI layout; compares functions/constants/fingerprints/SQL usage.",
            "version_inference": "regex from file header/body; if missing -> 'unknown'",
        },
    }
    return "\n".join(lines), payload

def main():
    import sys
    root = sys.argv[1] if len(sys.argv) > 1 else "."
    if not os.path.isdir(root):
        print("ERROR: not a directory:", root)
        raise SystemExit(2)

    py_files = scan_dir(root)
    feats = []
    for p in py_files:
        ff = analyse_file(p)
        if ff:
            feats.append(ff)

    ts = time.strftime("%Y%m%d_%H%M%S", time.gmtime())
    reports_dir = os.path.join(root, "reports")
    try:
        os.makedirs(reports_dir, exist_ok=True)
    except Exception:
        reports_dir = root

    txt_path = os.path.join(reports_dir, f"version_capability_audit_{ts}.txt")
    json_path = os.path.join(reports_dir, f"version_capability_audit_{ts}.json")

    report_text, payload = make_report(feats, root)

    with open(txt_path, 'w', encoding='utf-8', errors='replace') as f:
        f.write(report_text)

    with open(json_path, 'w', encoding='utf-8', errors='replace') as f:
        f.write(json.dumps(payload, ensure_ascii=True, indent=2))

    print("OK")
    print("TXT:", txt_path)
    print("JSON:", json_path)

if __name__ == "__main__":
    main()
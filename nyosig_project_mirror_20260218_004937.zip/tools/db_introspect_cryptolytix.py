#!/usr/bin/env python3
import sqlite3
import json
import sys
import os

DB_PATH = "/storage/emulated/0/NyoSig/NyoSig_Cryptolytix/nyosig_cryptolytix.db"
OUTPUT_JSON = "db_introspection_report.json"
OUTPUT_TXT = "db_introspection_report.txt"

def run():
    if not os.path.exists(DB_PATH):
        print(f"DB not found: {DB_PATH}")
        return

    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()

    # 1) List of tables
    cur.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;")
    tables = [r[0] for r in cur.fetchall()]

    report = {}
    report["tables"] = tables

    # 2) Schema per table
    report["schema"] = {}
    for t in tables:
        cur.execute(f"PRAGMA table_info('{t}')")
        cols = [{"cid": r[0], "name": r[1], "type": r[2], "notnull": r[3], "dflt_value": r[4], "pk": r[5]}
                for r in cur.fetchall()]
        report["schema"][t] = cols

    # 3) Row counts
    report["row_counts"] = {}
    for t in tables:
        try:
            cur.execute(f"SELECT COUNT(*) FROM '{t}'")
            count = cur.fetchone()[0]
            report["row_counts"][t] = count
        except:
            report["row_counts"][t] = None

    # 4) First rows data (up to 10)
    report["sample_data"] = {}
    for t in tables:
        try:
            cur.execute(f"SELECT * FROM '{t}' LIMIT 10")
            sample = cur.fetchall()
            report["sample_data"][t] = sample
        except:
            report["sample_data"][t] = None

    # 5) Indexes
    report["indexes"] = {}
    for t in tables:
        try:
            cur.execute(f"PRAGMA index_list('{t}')")
            idxs = cur.fetchall()
            report["indexes"][t] = idxs
        except:
            report["indexes"][t] = None

    # Save JSON
    with open(OUTPUT_JSON, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    # Save human readable
    with open(OUTPUT_TXT, "w", encoding="utf-8") as f:
        f.write("SQLite DB Introspection Report\n")
        f.write("=============================\n")
        f.write(f"Database: {DB_PATH}\n\n")

        f.write("Tables:\n")
        for t in tables:
            f.write(f"  - {t}\n")
        f.write("\n")

        for t in tables:
            f.write(f"Schema for table {t}:\n")
            for c in report["schema"].get(t, []):
                f.write(f"  {c}\n")
            f.write("\n")

        f.write("Row counts:\n")
        for t, ct in report["row_counts"].items():
            f.write(f"  {t}: {ct} rows\n")
        f.write("\n")

        f.write("Sample data per table (up to 10 rows):\n")
        for t, rows in report["sample_data"].items():
            f.write(f"  {t}:\n")
            if rows is None:
                f.write("    (no data or error)\n")
            else:
                for row in rows:
                    f.write(f"    {row}\n")
            f.write("\n")

        f.write("Indexes:\n")
        for t, idxs in report["indexes"].items():
            f.write(f"  {t}: {idxs}\n")
        f.write("\n")

    print(f"OK: JSON and TXT generated.")
    print(f"  - {OUTPUT_JSON}")
    print(f"  - {OUTPUT_TXT}")

if __name__ == "__main__":
    run()
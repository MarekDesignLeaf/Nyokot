#!/usr/bin/env python3
# project_audit_v1.0a.py
# Run from: /storage/emulated/0/NyoSig/NyoSig_Cryptolytix
# Creates: report_project_audit.txt
#
# What it does
# 1) Prints full folder tree with sizes and mtime
# 2) Finds all script versions (by filename patterns) and sorts them
# 3) Shows which GUI libs each script imports (tkinter vs PySimpleGUI etc.)
# 4) Checks for non ASCII chars in every .py file and reports exact positions
# 5) Inspects SQLite DB schema (tables, columns) and checks expected columns
# 6) Shows latest run row from runs table (best effort)
# 7) Optionally dumps headers of important text files and first lines of scripts

import os
import re
import sys
import json
import time
import hashlib
import sqlite3
from datetime import datetime

REPORT_NAME = "report_project_audit.txt"

# Expected root structure
EXPECTED_DB_REL = os.path.join("db", "nyosig_cryptolytix.db")

# Files that are usually important (will print a short preview if present)
IMPORTANT_HINTS = [
    "pravidla",
    "specifikace",
    "struktura",
    "postup",
    "architektura",
    "nyosig_cryptolytix_gui",
    "create_db",
    "db_migration",
]

# How many lines to preview from important text or scripts
PREVIEW_LINES = 80

# Version parsing helpers
RE_VER_1 = re.compile(r"(?:^|[_\-])v(\d+)\.(\d+)([a-z])(?:$|[_\-\.])", re.IGNORECASE)  # v1.1c
RE_VER_2 = re.compile(r"(?:^|[_\-])V(\d+)([a-z])(?:$|[_\-\.])", re.IGNORECASE)         # V06b style
RE_VER_3 = re.compile(r"(?:^|[_\-])v(\d+)\.(\d+)(?:$|[_\-\.])", re.IGNORECASE)         # v1.0
RE_VER_4 = re.compile(r"(?:^|[_\-])V(\d+)(?:$|[_\-\.])", re.IGNORECASE)                # V06

# Import detection
IMPORT_MARKERS = [
    ("tkinter", re.compile(r"^\s*(import\s+tkinter\b|from\s+tkinter\b)", re.MULTILINE)),
    ("pysimplegui", re.compile(r"^\s*(import\s+PySimpleGUI\b|from\s+PySimpleGUI\b)", re.MULTILINE)),
    ("customtkinter", re.compile(r"^\s*(import\s+customtkinter\b|from\s+customtkinter\b)", re.MULTILINE)),
    ("kivy", re.compile(r"^\s*(import\s+kivy\b|from\s+kivy\b)", re.MULTILINE)),
]

def now_iso():
    return datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")

def sha256_file(path, max_bytes=None):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        if max_bytes is None:
            while True:
                b = f.read(1024 * 1024)
                if not b:
                    break
                h.update(b)
        else:
            b = f.read(int(max_bytes))
            h.update(b)
    return h.hexdigest()

def safe_read_text(path, max_bytes=2_000_000):
    with open(path, "rb") as f:
        b = f.read(max_bytes)
    try:
        return b.decode("utf-8")
    except Exception:
        try:
            return b.decode("utf-8", errors="replace")
        except Exception:
            return ""

def is_ascii_only(text):
    for ch in text:
        if ord(ch) > 127:
            return False
    return True

def find_non_ascii_positions(text, limit=30):
    out = []
    for idx, ch in enumerate(text):
        if ord(ch) > 127:
            out.append((idx, ch, ord(ch)))
            if len(out) >= limit:
                break
    return out

def file_mtime(path):
    try:
        return datetime.utcfromtimestamp(os.path.getmtime(path)).strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return "unknown"

def file_size(path):
    try:
        return os.path.getsize(path)
    except Exception:
        return -1

def human_bytes(n):
    if n is None or n < 0:
        return "?"
    units = ["B", "KB", "MB", "GB", "TB"]
    v = float(n)
    for u in units:
        if v < 1024.0:
            if u == "B":
                return f"{int(v)} {u}"
            return f"{v:.2f} {u}"
        v /= 1024.0
    return f"{v:.2f} PB"

def walk_tree(root):
    rows = []
    for base, dirs, files in os.walk(root):
        dirs.sort()
        files.sort()
        rel_base = os.path.relpath(base, root)
        if rel_base == ".":
            rel_base = ""
        for d in dirs:
            p = os.path.join(base, d)
            rows.append(("DIR", os.path.join(rel_base, d), "", file_mtime(p)))
        for f in files:
            p = os.path.join(base, f)
            rows.append(("FILE", os.path.join(rel_base, f), human_bytes(file_size(p)), file_mtime(p)))
    return rows

def parse_version_from_name(name):
    low = name.lower()
    m = RE_VER_1.search(low)
    if m:
        maj = int(m.group(1)); minor = int(m.group(2)); letter = m.group(3)
        return (maj, minor, letter)
    m = RE_VER_3.search(low)
    if m:
        maj = int(m.group(1)); minor = int(m.group(2))
        return (maj, minor, "")
    m = RE_VER_2.search(name)
    if m:
        vnum = int(m.group(1)); letter = m.group(2)
        # Map V06b into 0.6b so it still sorts meaningfully
        return (0, vnum, letter.lower())
    m = RE_VER_4.search(name)
    if m:
        vnum = int(m.group(1))
        return (0, vnum, "")
    return None

def version_sort_key(vt):
    # vt = (maj, minor, letter)
    maj, minor, letter = vt
    lval = (ord(letter) - ord("a") + 1) if (letter and "a" <= letter <= "z") else 0
    return (maj, minor, lval)

def detect_imports(text):
    found = []
    for name, rx in IMPORT_MARKERS:
        if rx.search(text):
            found.append(name)
    return found

def sqlite_tables(con):
    rows = con.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").fetchall()
    return [r[0] for r in rows]

def sqlite_table_info(con, table):
    rows = con.execute(f"PRAGMA table_info({table})").fetchall()
    # (cid, name, type, notnull, dflt_value, pk)
    return [{"name": r[1], "type": r[2], "pk": r[5]} for r in rows]

def first_existing_col(cols, candidates):
    s = {c["name"] for c in cols}
    for cand in candidates:
        if cand in s:
            return cand
    return None

def get_latest_run_info(con):
    tables = sqlite_tables(con)
    if "runs" not in tables:
        return None, "runs table not found"
    cols = sqlite_table_info(con, "runs")
    created_col = first_existing_col(cols, ["created_utc", "created_at", "created", "fetched_utc", "timestamp", "ts_utc"])
    run_id_col = first_existing_col(cols, ["run_id", "id"])
    run_tag_col = first_existing_col(cols, ["run_tag"])
    status_col = first_existing_col(cols, ["status"])

    select_parts = []
    select_parts.append((run_id_col if run_id_col else "rowid") + " AS run_id")
    select_parts.append((run_tag_col if run_tag_col else "''") + " AS run_tag")
    select_parts.append((status_col if status_col else "''") + " AS status_any")
    if created_col:
        select_parts.append(created_col + " AS created_any")
        order_by = created_col + " DESC"
    else:
        select_parts.append("'' AS created_any")
        order_by = "rowid DESC"

    sql = "SELECT " + ", ".join(select_parts) + " FROM runs ORDER BY " + order_by + " LIMIT 1"
    row = con.execute(sql).fetchone()
    if not row:
        return None, "runs table is empty"
    d = dict(zip([c.split(" AS ")[-1] for c in select_parts], row))
    return d, None

def check_spot_markets_schema(con):
    tables = sqlite_tables(con)
    if "spot_markets" not in tables:
        return {"ok": False, "error": "spot_markets table not found", "columns": []}
    cols = sqlite_table_info(con, "spot_markets")
    names = [c["name"] for c in cols]
    # Accept symbol OR unified_symbol
    sym = ("symbol" in names) or ("unified_symbol" in names)
    pair = ("pair" in names)
    run_id = ("run_id" in names)
    ok = sym and pair and run_id
    missing = []
    if not sym:
        missing.append("symbol or unified_symbol")
    if not pair:
        missing.append("pair")
    if not run_id:
        missing.append("run_id")
    return {"ok": ok, "missing": missing, "columns": names}

def find_project_files(root):
    py = []
    txt = []
    sql = []
    docx = []
    other = []
    for base, _, files in os.walk(root):
        for f in files:
            p = os.path.join(base, f)
            rel = os.path.relpath(p, root)
            lf = f.lower()
            if lf.endswith(".py"):
                py.append(rel)
            elif lf.endswith(".txt"):
                txt.append(rel)
            elif lf.endswith(".sql"):
                sql.append(rel)
            elif lf.endswith(".docx"):
                docx.append(rel)
            else:
                other.append(rel)
    py.sort(); txt.sort(); sql.sort(); docx.sort(); other.sort()
    return py, txt, sql, docx, other

def important_file(relpath):
    low = relpath.lower()
    for h in IMPORTANT_HINTS:
        if h in low:
            return True
    return False

def preview_file(root, relpath, max_lines=PREVIEW_LINES):
    p = os.path.join(root, relpath)
    if not os.path.exists(p):
        return []
    low = relpath.lower()
    if low.endswith(".txt") or low.endswith(".py") or low.endswith(".sql"):
        text = safe_read_text(p)
        lines = text.splitlines()
        return lines[:max_lines]
    # Do not try to parse docx here (Pydroid often does not have python-docx)
    return []

def main():
    root = os.getcwd()
    report_path = os.path.join(root, REPORT_NAME)

    out = []
    out.append("Project audit report")
    out.append("Time: " + now_iso())
    out.append("Root: " + root)
    out.append("")

    # Tree
    out.append("Folder tree")
    out.append("Type | Path | Size | mtime_utc")
    tree_rows = walk_tree(root)
    for t, p, s, mt in tree_rows:
        out.append(f"{t} | {p} | {s} | {mt}")
    out.append("")

    # File lists
    py_files, txt_files, sql_files, docx_files, other_files = find_project_files(root)
    out.append("Counts")
    out.append(f"py: {len(py_files)}  txt: {len(txt_files)}  sql: {len(sql_files)}  docx: {len(docx_files)}  other: {len(other_files)}")
    out.append("")

    # Versions
    out.append("Detected script versions (from filenames)")
    versions = []
    for rel in py_files:
        name = os.path.basename(rel)
        vt = parse_version_from_name(name)
        if vt:
            versions.append((version_sort_key(vt), vt, rel))
    versions.sort(key=lambda x: x[0])
    if versions:
        for _, vt, rel in versions:
            out.append(f"ver {vt[0]}.{vt[1]}{vt[2]}  file {rel}")
        best = versions[-1][2]
        out.append("")
        out.append("Highest version by filename parsing")
        out.append(best)
    else:
        out.append("No versions detected in filenames")
    out.append("")

    # Import scan + ASCII scan
    out.append("Script scan (imports and ASCII)")
    for rel in py_files:
        p = os.path.join(root, rel)
        text = safe_read_text(p)
        imps = detect_imports(text)
        ascii_ok = is_ascii_only(text)
        out.append(f"{rel}")
        out.append(f"  mtime {file_mtime(p)}  size {human_bytes(file_size(p))}")
        out.append(f"  imports {', '.join(imps) if imps else 'none_detected'}")
        out.append(f"  ascii_only {str(ascii_ok)}")
        if not ascii_ok:
            bad = find_non_ascii_positions(text, limit=20)
            for idx, ch, code in bad:
                out.append(f"    non_ascii pos {idx} code {code} char_repr {repr(ch)}")
        out.append("")
    out.append("")

    # DB checks
    db_rel = EXPECTED_DB_REL
    db_path = os.path.join(root, db_rel)
    out.append("DB check")
    out.append("Expected DB path: " + db_rel)
    out.append("Exists: " + str(os.path.exists(db_path)))
    if os.path.exists(db_path):
        try:
            con = sqlite3.connect(db_path)
            try:
                tnames = sqlite_tables(con)
                out.append("Tables: " + ", ".join(tnames))
                # runs
                run_info, run_err = get_latest_run_info(con)
                if run_err:
                    out.append("Latest run: " + run_err)
                else:
                    out.append("Latest run: " + json.dumps(run_info, ensure_ascii=True))
                # spot_markets schema
                sm = check_spot_markets_schema(con)
                out.append("spot_markets schema ok: " + str(sm.get("ok")))
                if not sm.get("ok"):
                    out.append("spot_markets missing: " + ", ".join(sm.get("missing", [])))
                # print spot_markets columns (short)
                cols = sm.get("columns", [])
                out.append("spot_markets columns count: " + str(len(cols)))
                out.append("spot_markets columns: " + ", ".join(cols[:80]))
            finally:
                con.close()
        except Exception as e:
            out.append("DB open error: " + str(e))
    out.append("")

    # Important file previews
    out.append("Important file previews (first lines)")
    candidates = []
    for rel in (txt_files + sql_files + py_files):
        if important_file(rel):
            candidates.append(rel)
    candidates = sorted(set(candidates))
    if not candidates:
        out.append("No important files matched hints")
    else:
        for rel in candidates:
            out.append("")
            out.append("FILE " + rel)
            prev = preview_file(root, rel, max_lines=PREVIEW_LINES)
            if not prev:
                out.append("(no preview available)")
            else:
                for line in prev:
                    # Keep report ASCII safe
                    try:
                        line.encode("ascii")
                        out.append(line)
                    except Exception:
                        out.append(line.encode("ascii", errors="replace").decode("ascii"))
    out.append("")

    # Recommendations for continuing work (purely from observed facts)
    out.append("Next step hints")
    out.append("1) If any .py shows ascii_only False, remove non ASCII chars (they break your rule).")
    out.append("2) If GUI script expects columns that DB does not have, fix GUI query to match DB schema (use PRAGMA table_info).")
    out.append("3) If a script imports PySimpleGUI and it is not installed, switch it to tkinter or install PySimpleGUI.")
    out.append("4) Keep versioning monotonic. Never overwrite. New file name only.")
    out.append("")

    with open(report_path, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(out) + "\n")

    print("OK")
    print("Report written to: " + report_path)

if __name__ == "__main__":
    main()
#!/usr/bin/env python3
# clipboard_deploy_v1.0a.py
# Run from project root. Finds latest versioned script in root, lets you paste code from clipboard,
# validates version sequence, saves with confirmed name, then launches it with Python3.

import os
import re
import sys
import subprocess
import tkinter as tk
from tkinter import messagebox, simpledialog

EXPECTED_ROOT = "/storage/emulated/0/NyoSig/NyoSig_Cryptolytix"

VERSION_RE = re.compile(r"\bv(\d+)\.(\d+)([a-z])?\b", re.IGNORECASE)
FNAME_WITH_VER_RE = re.compile(r"([A-Za-z0-9_.\-]+_v\d+\.\d+[a-z]?\.py)\b")

def letter_to_int(ch):
    if not ch:
        return 0
    return ord(ch.lower()) - ord("a") + 1 if "a" <= ch.lower() <= "z" else 0

def parse_version_str(vstr):
    m = VERSION_RE.search(vstr if vstr.lower().startswith("v") else "v" + vstr)
    if not m:
        return None
    return (int(m.group(1)), int(m.group(2)), (m.group(3) or "").lower())

def version_key(vt):
    return (vt[0], vt[1], letter_to_int(vt[2]))

def format_version(vt):
    return f"v{vt[0]}.{vt[1]}{vt[2]}" if vt[2] else f"v{vt[0]}.{vt[1]}"

def next_patch(vt):
    if not vt[2]:
        return (vt[0], vt[1], "a")
    n = letter_to_int(vt[2]) + 1
    return (vt[0], vt[1], chr(ord("a") + n - 1))

def next_minor(vt):
    return (vt[0], vt[1] + 1, "a")

def next_major(vt):
    return (vt[0] + 1, 0, "a")

def allowed_next_versions(latest_vt):
    return [next_patch(latest_vt), next_minor(latest_vt), next_major(latest_vt)]

def find_latest_versioned_script(root_dir):
    candidates = []
    for name in os.listdir(root_dir):
        m = re.search(r"_v(\d+)\.(\d+)([a-z])?\.py$", name, re.IGNORECASE)
        if m:
            vt = (int(m.group(1)), int(m.group(2)), (m.group(3) or "").lower())
            candidates.append((version_key(vt), name, vt))
    if not candidates:
        return None
    candidates.sort(reverse=True)
    return candidates[0][1], candidates[0][2]

def unique_filename(root_dir, filename):
    base, ext = os.path.splitext(filename)
    i = 1
    candidate = filename
    while os.path.exists(os.path.join(root_dir, candidate)):
        candidate = f"{base}_{i}{ext}"
        i += 1
    return candidate

def has_non_ascii(s):
    try:
        s.encode("ascii")
        return False
    except Exception:
        return True

def extract_filename_from_text(text):
    m = FNAME_WITH_VER_RE.search(text)
    return m.group(1) if m else ""

def extract_version_from_filename(filename):
    m = re.search(r"_v(\d+)\.(\d+)([a-z])?\.py$", filename, re.IGNORECASE)
    return (int(m.group(1)), int(m.group(2)), (m.group(3) or "").lower()) if m else None

def extract_any_version_from_text(text):
    m = VERSION_RE.search(text)
    return (int(m.group(1)), int(m.group(2)), (m.group(3) or "").lower()) if m else None

class App(tk.Tk):
    def __init__(self, root_dir):
        super().__init__()
        self.root_dir = root_dir
        self.title("Clipboard deploy")
        self.geometry("720x320")

        latest = find_latest_versioned_script(root_dir)
        if not latest:
            messagebox.showerror("Error", "No versioned scripts found.")
            self.destroy()
            return

        self.latest_name, self.latest_vt = latest
        self.allowed_next = allowed_next_versions(self.latest_vt)

        tk.Label(self, text=f"Latest: {self.latest_name}", font=("TkDefaultFont", 12, "bold")).pack(anchor="w", padx=10, pady=5)
        tk.Label(self, text="Allowed: " + ", ".join(format_version(v) for v in self.allowed_next)).pack(anchor="w", padx=10)

        tk.Button(self, text="Vlozit ze schranky", command=self.on_paste, height=2).pack(padx=10, pady=20)
        self.status = tk.StringVar(value="Ready")
        tk.Label(self, textvariable=self.status).pack(anchor="w", padx=10)

    def on_paste(self):
        try:
            text = self.clipboard_get()
        except Exception:
            messagebox.showerror("Error", "Clipboard error")
            return

        if has_non_ascii(text):
            messagebox.showerror("Error", "Non-ASCII characters detected")
            return

        fname = extract_filename_from_text(text)
        vt = extract_version_from_filename(fname) if fname else extract_any_version_from_text(text)
        if not vt:
            messagebox.showerror("Error", "No version detected")
            return

        prefix = self.latest_name.split("_v")[0]
        save_name = fname if fname else f"{prefix}_v{vt[0]}.{vt[1]}{vt[2]}.py"

        if vt not in self.allowed_next:
            vt = self.allowed_next[0]
            save_name = f"{prefix}_v{vt[0]}.{vt[1]}{vt[2]}.py"

        save_name = unique_filename(self.root_dir, save_name)
        path = os.path.join(self.root_dir, save_name)

        with open(path, "w", encoding="ascii", errors="strict") as f:
            f.write(text)

        subprocess.Popen([sys.executable, path], cwd=self.root_dir)
        self.status.set(f"Saved and launched: {save_name}")
        self.destroy()

def main():
    root_dir = os.getcwd()
    if os.path.normpath(root_dir) != os.path.normpath(EXPECTED_ROOT):
        messagebox.showwarning("Warning", f"Expected root:\n{EXPECTED_ROOT}\nCurrent:\n{root_dir}")
    app = App(root_dir)
    app.mainloop()

if __name__ == "__main__":
    main()
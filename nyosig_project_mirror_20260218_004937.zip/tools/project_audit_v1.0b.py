#!/usr/bin/env python3
# project_audit_v1.0b.py
# Run from: /storage/emulated/0/NyoSig/NyoSig_Cryptolytix
# Creates: reports/project_audit_YYYYMMDD_HHMMSS.txt
#
# What it does (read-only):
# 1) Full folder tree (sizes, mtime UTC)
# 2) Detects all versioned scripts (filename + header) and picks highest
# 3) Detects GUI libs per script (tkinter / PySimpleGUI / customtkinter / kivy)
# 4) Scans ALL .py for non-ASCII characters (positions + codepoints)
# 5) Inspects SQLite DB schema (tables, columns, keys, indexes)
# 6) Best-effort: finds DB tables referenced in .py and checks if they exist
# 7) Best-effort: shows latest row from runs table (if present)
# 8) Previews important text files (ASCII-safe) to support safe continuation

import os
import re
import sys
import json
import time
import hashlib
import sqlite3
from datetime import datetime, timezone

EXPECTED_ROOT = "/storage/emulated/0/NyoSig/NyoSig_Cryptolytix"
REPORTS_DIR = "reports"
DB_REL = os.path.join("db", "nyosig_cryptolytix.db")

SKIP_DIRS = {
    "__pycache__",
    ".git",
    ".idea",
    ".vscode",
    ".pytest_cache",
}

TEXT_EXTS = {".txt", ".md", ".sql", ".json", ".yaml", ".yml", ".env", ".ini", ".cfg"}

IMPORTANT_HINTS = [
    "pravidla",
    "specifikace",
    "struktura",
    "postup",
    "architektura",
    "readme",
    "analyza_trhu",
    "schema",
    "migration",
    "create_db",
    "db",
]

PREVIEW_LINES = 120
MAX_TEXT_BYTES = 2_000_000

# Version parsing patterns:
# - *_v1.2a.py
# - *_v1.2.py
# - V06b style: *_V06b.py (mapped to v0.6b for sorting only)
RE_VER_NAME_1 = re.compile(r"_v(\d+)\.(\d+)([a-z])?\.py$", re.IGNORECASE)
RE_VER_NAME_2 = re.compile(r"_V(\d+)([a-z])?\.py$", re.IGNORECASE)

# Header version: looks for "v1.2a" within first lines
RE_VER_HDR = re.compile(r"\bv(\d+)\.(\d+)([a-z])?\b", re.IGNORECASE)

# Import detection
IMPORT_MARKERS = [
    ("tkinter", re.compile(r"^\s*(import\s+tkinter\b|from\s+tkinter\b)", re.MULTILINE)),
    ("pysimplegui", re.compile(r"^\s*(import\s+PySimpleGUI\b|from\s+PySimpleGUI\b)", re.MULTILINE)),
    ("customtkinter", re.compile(r"^\s*(import\s+customtkinter\b|from\s+customtkinter\b)", re.MULTILINE)),
    ("kivy", re.compile(r"^\s*(import\s+kivy\b|from\s+kivy\b)", re.MULTILINE)),
]

# Best-effort DB reference detection in scripts
RE_SQL_FROM = re.compile(r"\bFROM\s+([A-Za-z_][A-Za-z0-9_]*)\b", re.IGNORECASE)
RE_SQL_JOIN = re.compile(r"\bJOIN\s+([A-Za-z_][A-Za-z0-9_]*)\b", re.IGNORECASE)
RE_SQL_INTO = re.compile(r"\bINTO\s+([A-Za-z_][A-Za-z0-9_]*)\b", re.IGNORECASE)
RE_SQL_UPDATE = re.compile(r"\bUPDATE\s+([A-Za-z_][A-Za-z0-9_]*)\b", re.IGNORECASE)


def utc_now():
    return datetime.now(timezone.utc)


def utc_stamp():
    return utc_now().strftime("%Y%m%d_%H%M%S")


def fmt_utc(ts):
    return datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def safe_read_bytes(path, max_bytes=MAX_TEXT_BYTES):
    try:
        with open(path, "rb") as f:
            return f.read(max_bytes)
    except Exception:
        return b""


def safe_read_text_utf8(path, max_bytes=MAX_TEXT_BYTES):
    b = safe_read_bytes(path, max_bytes=max_bytes)
    if not b:
        return ""
    try:
        return b.decode("utf-8")
    except Exception:
        return b.decode("utf-8", errors="replace")


def to_ascii_safe(s):
    if s is None:
        return ""
    try:
        s.encode("ascii")
        return s
    except Exception:
        return s.encode("ascii", errors="replace").decode("ascii")


def file_size(path):
    try:
        return os.path.getsize(path)
    except Exception:
        return -1


def human_bytes(n):
    if n is None or n < 0:
        return "?"
    units = ["B", "KB", "MB", "GB", "TB"]
    v = float(n)
    for u in units:
        if v < 1024.0:
            if u == "B":
                return f"{int(v)} {u}"
            return f"{v:.2f} {u}"
        v /= 1024.0
    return f"{v:.2f} PB"


def file_mtime_utc(path):
    try:
        return fmt_utc(os.path.getmtime(path))
    except Exception:
        return "unknown"


def sha256_file(path, max_bytes=None):
    h = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            if max_bytes is None:
                for chunk in iter(lambda: f.read(1024 * 1024), b""):
                    h.update(chunk)
            else:
                remaining = int(max_bytes)
                while remaining > 0:
                    chunk = f.read(min(1024 * 1024, remaining))
                    if not chunk:
                        break
                    h.update(chunk)
                    remaining -= len(chunk)
        return h.hexdigest()
    except Exception as e:
        return f"<<HASH_ERROR:{type(e).__name__}:{e}>>"


def is_text_file(path):
    low = path.lower()
    _, ext = os.path.splitext(low)
    if ext in TEXT_EXTS:
        return True
    if ext == ".py":
        return True
    return False


def walk_tree(root):
    rows = []
    for base, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        dirs.sort()
        files.sort()
        rel_base = os.path.relpath(base, root)
        if rel_base == ".":
            rel_base = ""
        for d in dirs:
            p = os.path.join(base, d)
            rows.append(("DIR", os.path.join(rel_base, d).replace("\\", "/"), "", file_mtime_utc(p)))
        for f in files:
            p = os.path.join(base, f)
            rows.append(("FILE", os.path.join(rel_base, f).replace("\\", "/"), human_bytes(file_size(p)), file_mtime_utc(p)))
    return rows


def parse_version_from_filename(name):
    low = name.lower()
    m = RE_VER_NAME_1.search(low)
    if m:
        maj = int(m.group(1))
        minor = int(m.group(2))
        letter = (m.group(3) or "").lower()
        return (maj, minor, letter, f"v{maj}.{minor}{letter}")
    m2 = RE_VER_NAME_2.search(name)
    if m2:
        vnum = int(m2.group(1))
        letter = (m2.group(2) or "").lower()
        # Map V06b into v0.6b for sorting only.
        return (0, vnum, letter, f"v0.{vnum}{letter}")
    return None


def parse_version_from_header(text):
    head = "\n".join(text.splitlines()[:80])
    m = RE_VER_HDR.search(head)
    if not m:
        return None
    maj = int(m.group(1))
    minor = int(m.group(2))
    letter = (m.group(3) or "").lower()
    return (maj, minor, letter, f"v{maj}.{minor}{letter}")


def letter_to_int(ch):
    if not ch:
        return 0
    ch = ch.lower()
    if "a" <= ch <= "z":
        return ord(ch) - ord("a") + 1
    return 0


def version_key(vt):
    # vt: (maj, minor, letter, label)
    return (vt[0], vt[1], letter_to_int(vt[2]))


def detect_imports(text):
    found = []
    for name, rx in IMPORT_MARKERS:
        if rx.search(text):
            found.append(name)
    return found


def find_non_ascii_positions(text, limit=50):
    out = []
    for i, ch in enumerate(text):
        if ord(ch) > 127:
            out.append((i, ch, ord(ch)))
            if len(out) >= limit:
                break
    return out


def list_project_files(root):
    py_files = []
    txt_files = []
    sql_files = []
    other_files = []
    for base, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for f in files:
            rel = os.path.relpath(os.path.join(base, f), root).replace("\\", "/")
            lf = f.lower()
            if lf.endswith(".py"):
                py_files.append(rel)
            elif lf.endswith(".txt") or lf.endswith(".md"):
                txt_files.append(rel)
            elif lf.endswith(".sql") or lf.endswith(".json") or lf.endswith(".yml") or lf.endswith(".yaml"):
                sql_files.append(rel)
            else:
                other_files.append(rel)
    py_files.sort()
    txt_files.sort()
    sql_files.sort()
    other_files.sort()
    return py_files, txt_files, sql_files, other_files


def important_file(relpath):
    low = relpath.lower()
    for h in IMPORTANT_HINTS:
        if h in low:
            return True
    return False


def preview_file_lines(root, relpath, max_lines=PREVIEW_LINES):
    p = os.path.join(root, relpath)
    if not os.path.exists(p):
        return []
    if not is_text_file(p):
        return []
    txt = safe_read_text_utf8(p)
    lines = txt.splitlines()
    out = []
    for line in lines[:max_lines]:
        out.append(to_ascii_safe(line))
    return out


def sqlite_tables(con):
    rows = con.execute("SELECT name, type FROM sqlite_master WHERE type IN ('table','view') ORDER BY type, name").fetchall()
    return rows


def sqlite_table_info(con, table):
    rows = con.execute(f"PRAGMA table_info('{table}')").fetchall()
    # (cid, name, type, notnull, dflt_value, pk)
    return [{"name": r[1], "type": r[2], "notnull": r[3], "pk": r[5], "default": r[4]} for r in rows]


def sqlite_foreign_keys(con, table):
    rows = con.execute(f"PRAGMA foreign_key_list('{table}')").fetchall()
    return rows


def sqlite_indexes(con, table):
    rows = con.execute(f"PRAGMA index_list('{table}')").fetchall()
    return rows


def get_latest_run(con):
    # best-effort: if runs exists, pick latest by created_utc if exists else rowid
    tnames = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
    if "runs" not in tnames:
        return None, "runs table not found"

    cols = sqlite_table_info(con, "runs")
    colnames = [c["name"] for c in cols]

    created_col = None
    for cand in ["created_utc", "created_at", "created", "fetched_utc", "ts_utc", "timestamp"]:
        if cand in colnames:
            created_col = cand
            break

    run_id_col = "run_id" if "run_id" in colnames else None

    if created_col:
        order = f"{created_col} DESC"
    else:
        order = "rowid DESC"

    select_cols = []
    if run_id_col:
        select_cols.append(run_id_col)
    if created_col:
        select_cols.append(created_col)
    # add a few more if exist
    for cand in ["source", "vs_currency", "coins_limit", "notes", "status"]:
        if cand in colnames and cand not in select_cols:
            select_cols.append(cand)

    if not select_cols:
        select_cols = ["rowid"]

    sql = "SELECT " + ", ".join(select_cols) + " FROM runs ORDER BY " + order + " LIMIT 1"
    row = con.execute(sql).fetchone()
    if not row:
        return None, "runs table is empty"
    d = dict(zip(select_cols, row))
    return d, None


def extract_db_table_references_from_text(text):
    refs = set()
    for rx in [RE_SQL_FROM, RE_SQL_JOIN, RE_SQL_INTO, RE_SQL_UPDATE]:
        for m in rx.finditer(text):
            refs.add(m.group(1))
    return refs


def write_report(root):
    ts = utc_stamp()
    reports_dir = os.path.join(root, REPORTS_DIR)
    os.makedirs(reports_dir, exist_ok=True)
    report_path = os.path.join(reports_dir, f"project_audit_{ts}.txt")

    out = []
    out.append("Project audit report (ASCII)")
    out.append("Time UTC: " + utc_now().strftime("%Y-%m-%d %H:%M:%S"))
    out.append("Expected root: " + EXPECTED_ROOT)
    out.append("Actual root:   " + root)
    out.append("")

    if os.path.normpath(root) != os.path.normpath(EXPECTED_ROOT):
        out.append("WARNING: Not running from expected root.")
        out.append("Run from: /storage/emulated/0/NyoSig/NyoSig_Cryptolytix")
        out.append("")

    # Folder tree
    out.append("Folder tree")
    out.append("Type | Path | Size | mtime_utc")
    for t, p, s, mt in walk_tree(root):
        out.append(f"{t} | {to_ascii_safe(p)} | {to_ascii_safe(s)} | {to_ascii_safe(mt)}")
    out.append("")

    # File lists
    py_files, txt_files, sql_files, other_files = list_project_files(root)
    out.append("Counts")
    out.append(f"py: {len(py_files)}  txt/md: {len(txt_files)}  sql/json/yml: {len(sql_files)}  other: {len(other_files)}")
    out.append("")

    # Scripts: version + header + imports + ascii scan
    out.append("Python scripts scan")
    out.append("Path | mtime_utc | size | sha256 | ver_name | ver_hdr | imports | ascii_only")
    versions = []
    non_ascii_files = []

    for rel in py_files:
        abs_p = os.path.join(root, rel)
        mtime = file_mtime_utc(abs_p)
        size = human_bytes(file_size(abs_p))
        h = sha256_file(abs_p)
        text = safe_read_text_utf8(abs_p)

        vn = parse_version_from_filename(os.path.basename(rel))
        vh = parse_version_from_header(text)

        vn_label = vn[3] if vn else ""
        vh_label = vh[3] if vh else ""

        if vn:
            versions.append((version_key(vn), vn_label, rel))
        if vh and (not vn):
            versions.append((version_key(vh), vh_label, rel))

        imps = detect_imports(text)
        ascii_ok = True
        try:
            text.encode("ascii")
        except Exception:
            ascii_ok = False

        if not ascii_ok:
            bad = find_non_ascii_positions(text, limit=30)
            non_ascii_files.append((rel, bad))

        out.append(
            f"{to_ascii_safe(rel)} | {to_ascii_safe(mtime)} | {to_ascii_safe(size)} | {to_ascii_safe(h)} | "
            f"{to_ascii_safe(vn_label)} | {to_ascii_safe(vh_label)} | {to_ascii_safe(','.join(imps) if imps else '')} | "
            f"{'True' if ascii_ok else 'False'}"
        )

    out.append("")
    # Highest version
    out.append("Detected versions (sorted ascending)")
    if versions:
        versions_sorted = sorted(versions, key=lambda x: x[0])
        for k, vlabel, rel in versions_sorted:
            out.append(f"{to_ascii_safe(vlabel):8s}  {to_ascii_safe(rel)}")
        highest = versions_sorted[-1]
        out.append("")
        out.append("Highest version (by parsing):")
        out.append(to_ascii_safe(highest[1]) + "  " + to_ascii_safe(highest[2]))
    else:
        out.append("No versioned scripts detected by filename/header patterns.")
    out.append("")

    # Non-ascii report
    out.append("Non-ASCII scan results")
    if not non_ascii_files:
        out.append("OK: No non-ASCII characters found in .py files.")
    else:
        out.append("FAIL: Non-ASCII characters found. These files violate your rule:")
        for rel, bad in non_ascii_files:
            out.append("")
            out.append("FILE: " + to_ascii_safe(rel))
            for idx, ch, code in bad:
                out.append(f"  pos={idx}  code={code}  char_repr={to_ascii_safe(repr(ch))}")
    out.append("")

    # DB schema
    db_path = os.path.join(root, DB_REL)
    out.append("SQLite DB check")
    out.append("DB rel path: " + to_ascii_safe(DB_REL))
    out.append("DB exists: " + ("True" if os.path.exists(db_path) else "False"))
    out.append("")
    db_tables = set()
    if os.path.exists(db_path):
        try:
            con = sqlite3.connect(db_path)
            try:
                items = sqlite_tables(con)  # list of (name,type)
                out.append("Objects:")
                for name, typ in items:
                    out.append(f"{to_ascii_safe(typ.upper())}: {to_ascii_safe(name)}")
                    if typ == "table":
                        db_tables.add(name)
                out.append("")

                for name, typ in items:
                    if typ != "table":
                        continue
                    out.append("TABLE: " + to_ascii_safe(name))
                    cols = sqlite_table_info(con, name)
                    if cols:
                        out.append("  Columns:")
                        for c in cols:
                            out.append(
                                "    "
                                + to_ascii_safe(c["name"])
                                + " "
                                + to_ascii_safe(c["type"])
                                + f" notnull={int(c['notnull'])} pk={int(c['pk'])} default={to_ascii_safe(str(c['default']))}"
                            )
                    else:
                        out.append("  (no columns returned)")

                    fks = sqlite_foreign_keys(con, name)
                    if fks:
                        out.append("  Foreign keys:")
                        for fk in fks:
                            out.append("    " + to_ascii_safe(str(fk)))

                    idxs = sqlite_indexes(con, name)
                    if idxs:
                        out.append("  Indexes:")
                        for ix in idxs:
                            out.append("    " + to_ascii_safe(str(ix)))
                    out.append("")

                # Latest run
                out.append("Latest run (best-effort)")
                run_info, run_err = get_latest_run(con)
                if run_err:
                    out.append(to_ascii_safe(run_err))
                else:
                    out.append(to_ascii_safe(json.dumps(run_info, ensure_ascii=True)))
                out.append("")
            finally:
                con.close()
        except Exception as e:
            out.append("DB open/error: " + to_ascii_safe(f"{type(e).__name__}: {e}"))
            out.append("")
    else:
        out.append("DB not found at expected path.")
        out.append("")

    # Best-effort: DB references in scripts
    out.append("Best-effort: DB table references found in scripts")
    referenced = set()
    for rel in py_files:
        abs_p = os.path.join(root, rel)
        text = safe_read_text_utf8(abs_p)
        referenced |= extract_db_table_references_from_text(text)
    if not referenced:
        out.append("No table names detected by simple SQL regex.")
    else:
        ref_sorted = sorted(referenced)
        out.append("Referenced tables (unique): " + ", ".join(to_ascii_safe(x) for x in ref_sorted))
        if db_tables:
            missing = [t for t in ref_sorted if t not in db_tables]
            present = [t for t in ref_sorted if t in db_tables]
            out.append("Present in DB: " + (", ".join(to_ascii_safe(x) for x in present) if present else "(none)"))
            out.append("Missing in DB: " + (", ".join(to_ascii_safe(x) for x in missing) if missing else "(none)"))
    out.append("")

    # Important previews
    out.append("Important file previews (first lines)")
    candidates = []
    for rel in (txt_files + sql_files + py_files):
        if important_file(rel):
            candidates.append(rel)
    candidates = sorted(set(candidates))
    if not candidates:
        out.append("No important files matched hints.")
    else:
        for rel in candidates:
            out.append("")
            out.append("FILE: " + to_ascii_safe(rel))
            prev = preview_file_lines(root, rel, max_lines=PREVIEW_LINES)
            if not prev:
                out.append("(no preview available)")
            else:
                for line in prev:
                    out.append(line)
    out.append("")

    # Next-step hints (facts only)
    out.append("Next-step hints (from observed facts)")
    if non_ascii_files:
        out.append("1) Remove non-ASCII characters from listed .py files (rule violation).")
    else:
        out.append("1) Non-ASCII check passed for .py files.")
    if os.path.exists(db_path):
        out.append("2) DB exists at db/nyosig_cryptolytix.db. If GUI crashes, check script DB queries vs actual schema above.")
    else:
        out.append("2) DB missing at db/nyosig_cryptolytix.db. Any DB-dependent GUI will fail until DB exists.")
    out.append("3) Keep versioning monotonic. Never overwrite. Always save as a new filename.")
    out.append("")

    # Write report
    with open(report_path, "w", encoding="ascii", errors="strict", newline="\n") as f:
        f.write("\n".join(out) + "\n")

    return report_path


def main():
    root = os.getcwd()
    path = write_report(root)
    print("OK")
    print("Report written to:")
    print(path)


if __name__ == "__main__":
    main()
#!/usr/bin/env python3
# nyosig_runtime_guard_v1.0a.py
# Import this from launcher/GUI before showing UI.
# Enforces: no duplicate version label with different hash (hard stop),
# and records every launch into state DB.

import os
import re
import time
import hashlib
import sqlite3
from pathlib import Path

try:
    import tkinter as tk
    from tkinter import messagebox
except Exception:
    tk = None
    messagebox = None

VERSION_RE = re.compile(r"\bv(\d+)\.(\d+)([a-z])?\b", re.IGNORECASE)

def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def now_utc_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

def extract_version_from_name(name: str) -> str:
    m = re.search(r"_v(\d+)\.(\d+)([a-z])?\.py$", name, flags=re.IGNORECASE)
    if not m:
        return ""
    major = int(m.group(1))
    minor = int(m.group(2))
    letter = (m.group(3) or "").lower()
    return f"v{major}.{minor}{letter}" if letter else f"v{major}.{minor}"

def ensure_schema(con: sqlite3.Connection):
    con.execute("""
    CREATE TABLE IF NOT EXISTS versions (
      version_label TEXT NOT NULL,
      sha256 TEXT NOT NULL,
      rel_path TEXT NOT NULL,
      abs_path TEXT NOT NULL,
      first_seen_utc TEXT NOT NULL,
      last_seen_utc TEXT NOT NULL,
      PRIMARY KEY (version_label, sha256)
    );
    """)
    con.execute("""
    CREATE TABLE IF NOT EXISTS runs (
      run_id INTEGER PRIMARY KEY AUTOINCREMENT,
      launched_utc TEXT NOT NULL,
      script_rel_path TEXT NOT NULL,
      script_sha256 TEXT NOT NULL,
      version_label TEXT,
      note TEXT
    );
    """)
    con.execute("CREATE INDEX IF NOT EXISTS idx_versions_label ON versions(version_label);")
    con.execute("CREATE INDEX IF NOT EXISTS idx_runs_launched ON runs(launched_utc);")

def _msg_error(title: str, text: str):
    if messagebox and tk:
        try:
            r = tk.Tk()
            r.withdraw()
            messagebox.showerror(title, text)
            r.destroy()
            return
        except Exception:
            pass
    raise SystemExit(text)

def guard_and_record(project_root: str, state_db_path: str, script_path: str, version_label: str = ""):
    pr = Path(project_root).resolve()
    sdb = Path(state_db_path).resolve()
    sp = Path(script_path).resolve()

    if not pr.exists():
        _msg_error("NyoSig", "Project root not found:\n" + str(pr))
    if not sdb.parent.exists():
        sdb.parent.mkdir(parents=True, exist_ok=True)

    script_rel = ""
    try:
        script_rel = sp.relative_to(pr).as_posix()
    except Exception:
        script_rel = sp.name

    vlabel = (version_label or "").strip() or extract_version_from_name(sp.name)
    script_hash = sha256_file(sp)
    utc = now_utc_iso()

    con = sqlite3.connect(str(sdb))
    try:
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA journal_mode=WAL;")
        ensure_schema(con)

        if vlabel:
            # register version
            con.execute("""
            INSERT OR IGNORE INTO versions(version_label, sha256, rel_path, abs_path, first_seen_utc, last_seen_utc)
            VALUES(?,?,?,?,?,?)
            """, (vlabel, script_hash, script_rel, str(sp), utc, utc))
            con.execute("""
            UPDATE versions SET last_seen_utc=?, rel_path=?, abs_path=? WHERE version_label=? AND sha256=?
            """, (utc, script_rel, str(sp), vlabel, script_hash))

            # hard stop on duplicates (same label, different hash)
            rows = con.execute("SELECT sha256, rel_path FROM versions WHERE version_label=?", (vlabel,)).fetchall()
            uniq = {r["sha256"] for r in rows}
            if len(uniq) > 1:
                detail = "\n".join([f"- {r['rel_path']}  {str(r['sha256'])[:12]}" for r in rows])
                _msg_error("NyoSig", "Duplicate version label detected:\n" + vlabel + "\n\nVariants:\n" + detail)

        # record run
        con.execute("""
        INSERT INTO runs(launched_utc, script_rel_path, script_sha256, version_label, note)
        VALUES(?,?,?,?,?)
        """, (utc, script_rel, script_hash, vlabel or None, ""))

        con.commit()
    finally:
        con.close()

    return {"utc": utc, "version_label": vlabel, "script_rel_path": script_rel, "state_db": str(sdb)}
